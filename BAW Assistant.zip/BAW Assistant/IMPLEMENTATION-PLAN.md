# Implementation plan — handoff spec for Opus 5

**Audience:** the Claude (Opus 5) session that executes this work.
**Prepared:** 2026-08-29 by a review session, from a full read of the source, a
byte-level comparison against the deployed tree, and live probes of the running
server. Everything in §2 is **verified, not suspected** — do not re-derive it,
and do not soften it.

> **2026-08-31.** Phases 7 and 8 are built. **`HANDOFF.md` is the current
> state** - what is deployed, the one file that is not, the remaining work in
> three stages, and the traps this session paid for. Read it after §0 and
> before anything else.

**Read order for your first session:**
1. `PROJECT.md` in this folder, end to end. It is accurate: its claims were
   adversarially re-verified and held (see §2.0), and it has been kept current
   as the work below landed.
2. Load the `baw-websphere-webapp` and `baw-coach-view` skills. Between them
   they carry every verified fact about Designer internals and the WAS build
   contract. Do not re-derive those findings.
3. This file.

---

## 0. STATUS — read this before anything else

**All six phases are built, deployed and verified live.** Build
`20260830-170814` is on the server and matches this tree; the working tree is
clean; 36 commits carry the work, each recording what was verified and how.

> **2026-08-30, second session.** Twelve further commits took the rule set from
> 123 to **174** by making the readers see what the artifacts actually contain.
> Read `knowledge/rule-packs/` before touching rules - five notes there carry
> the measured evidence behind every one of them.

What that produced, in one place:

| | |
|---|---|
| F1 critical | Closed. The API was completely unauthenticated - an anonymous POST created a live rule. Now 401. |
| F2–F12 | All fixed and verified live. |
| Build gate | 123 → **202 checks**, plus two front-end suites and a 34-test Playwright suite. |
| Rules | **19 active policy**, 155 draft. Four promoted on measured evidence. |
| Repairs | `/api/fix` built; 4 rules declare a fix. |
| Compare | `/compare.jsp` - snapshot vs track, findings introduced vs fixed. |
| Corpus | 3 real applications, 3.7M characters, harvested and measured, plus **Test PA** (`2063.54dfabb5-c3d4-43aa-8e8a-5f64b0437fd0`) as the shape reference. |
| Scope | Every rule declares `develop` / `snapshot`. 163 are both; 11 are snapshot-only. |

### What the second session on 2026-08-30 added

**38 rules**, every one a draft measured against real artifacts before being
written, and every one carrying its own count in its rationale. The engine
gained three things it did not have: an object read as a one-row collection
(`any: "settings"`), `any: "artifact"` to reach an artifact's own fields, and
`gt`/`gte`/`lt`/`lte` inside a where-predicate.

The readers gained far more. They now see per-type `settings`, EPVs and their
variables, enumerated types, lanes and their teams, exposed-variable aliases,
multi-instance loops, gateway conditions, terminate-event settings, boundary
error routing, UCA parameters, activity subjects, and the difference between a
heritage and a client-side human service. `knowledge/artifact-catalog/
artifact-model-map.md` records where each of those lives - **read it before
probing anything, it will save a live probe every time.**

**Five defects were found in rules that were already shipping**, all by reading
what a rule matched rather than counting how often it matched:

- `FLOW.TOO_MANY_STEPS` (active policy) counted data objects as steps - 44% of
  flow models to 20%.
- `SQL.PRODUCT_TABLE` was 89% blind while the corpus reported it silent.
- `FLOW.UNCONNECTED_STEP` fired on every artifact with steps, because `isFalse`
  is satisfied by an absent key and the diagram read carries no connectivity.
- `UI.COACH_PER_SERVICE` could never fire live: the diagram says
  `com.ibm...TFormTask` and the committed reader says `TFormTask`.
- `PROC.GATEWAY_CONDITION_INCOMPLETE` counted parallel gateways, which take
  every path and need no conditions.

The lesson each time: **a silent rule is not necessarily a quiet rule, and a
loud one is not necessarily right.** Read the lines.

**What is genuinely left**, in the order I would take it:

1. **Bind `assistant-author` to a real WebSphere group.** Console-only, no
   rebuild. Until then any *authenticated* user can author rules. This is the
   only outstanding security item.
2. **Decide on three loud rules.** `LOOSE_EQUALITY` (1,624 hits on one
   application), `NULL.LIST_INDEX` (1,634) and `NULL.TW_LOCAL_CHAIN` (2 to 141
   depending on the application) are **correct, not noisy**. Promoting them
   means accepting a backlog, which is the owner's call. Evidence per rule is
   in `knowledge/rule-packs/quietness-2026-08-29.md`.
3. ~~**Per-artifact-type rules**~~ and ~~**the checklist prompts**~~ **DONE
   2026-08-30, deployed and verified live.** 38 rules added across two
   sessions, taking the set from 123 to 174. Every one is a draft carrying its
   own measured count. The five notes in `knowledge/rule-packs/` are the
   record; read them rather than re-deriving.

4. ~~**The whole-application review**~~ **BUILT 2026-08-30, not yet deployed.** The owner
   settled the shape on 2026-08-30: **there is no `.twx` export.** It reads
   live artifacts over REST at a container ref, which is a named snapshot or
   the tip of a branch or track. A separate page, modelled on IBM's own IDA
   report (`ref/images/`): the user picks a process app or toolkit, then a
   branch or snapshot, and presses **Analyse**.

   Everything underneath it exists. `tools/harvest-corpus.js` already sweeps
   every artifact at a containerRef; a snapshot ref already behaves exactly
   like a branch ref; `com.bawassistant.Corpus` already runs all 107 automated
   rules over the result; `listProcessApps` and `listSnapshots` already return
   the selectors. **What is missing is the page and an endpoint behind it,**
   not the capability.

   It owns 23 catalogued practices and 41 of IBM's IDA rules, which nothing
   else can answer - toolkit inventory, unused artifacts, migration counts,
   cross-artifact questions. The IDA report's structure maps almost one to one
   onto what a Finding already carries: Symptom is `message`, Best Practice is
   `remediation` plus `rationale`, Reference is `source`, and the severity tabs
   and category chips are `severity` and `category`.

   **Built as Phase 8 (§3), which records the three facts probed live on
   2026-08-30 that it depends on: the toolkit list endpoint, why batching is
   mandatory, and what `calledElement` means.** `review.jsp` plus
   `POST /api/review`. Cross-checked headlessly against `Corpus` over Test PA
   — 117 surfaces and 362 artifact findings from both paths — but **`/api/review`
   is deployed and verified live.** Test PA: 218 artifacts, 138 code surfaces,
   ~500 findings in ~50 rules, 12 seconds in a browser, and *Sample Process
   With All* raising exactly its documented 16. Building it exposed five
   defects - see
   `knowledge/rule-packs/whole-application-review-2026-08-30.md`.

4b. **The panel UX and a design system (owner request, 2026-08-30).** Group
   artifact-level and script-level findings, collapse a finding to one line,
   severity and category filters, a font-size control, and an enterprise-grade
   UI in Carbon's idiom. **Planned as Phase 7 (§3), and it comes first** -
   item 5 of that request is a design system, items 1-4 are the panel applying
   it, and Phase 8's report is the second thing to apply it. Static files only,
   so it deploys without a Stop/Start.

5. **Promote a first batch.** 156 of the 175 rules are drafts and nothing has
   been promoted since the original four. Several read as ready on their
   measured evidence - `UCA.DISABLED` (5 of 62), `UCA.NO_IMPLEMENTATION` (2),
   `PROC.GATEWAY_CONDITION_INCOMPLETE`, `PROC.ERROR_ROUTED_BACK` - while others
   are deliberately loud and need a standards decision rather than a promotion:
   `DOC.ARTIFACT_UNDOCUMENTED` (18 of 18), `PROC.AT_RISK_ON` (29 of 29),
   `PERF.RESULT_SET_NOT_RELEASED` (174 of 179). Each rule states its own count.

6. **Two rules are blocked on one fact each, not on effort.**
   *Prefer Service (No Task)* needs the field that carries the distinction
   named - `activityExtension.transactionalBehavior` and
   `userTaskSettings.enableAutoFlow` are both candidates and guessing between
   them would ship a rule built on an assumption. *Team filter service is
   simple* is cross-artifact by nature: you reach the service from a team of
   `type: "TeamByService"` through its `teamService` reference, so it belongs
   to the whole-application review.

7. **Four thresholds are still unsettled.** Business object attributes (ours
   20, IDA 50), components in one process (ours 10 steps, Stream 20),
   searchable variables (Stream 10, IDA 25 - ours is 25), and the EPV limit,
   where the customer's own workbook says 30 on two rows and 40-50 on a third.
   The table is in `knowledge/rule-packs/baw-best-practices-catalogue.md` §M.

8. **Rules that have still never fired** on any real code are unproven rather
   than proven safe. `node tools/open-work.js` and `node tools/answer-sheet.js`
   regenerate what is outstanding from the catalogue rather than from memory.

**Blocked, not schedulable:** the AI path (item 6) still waits on whether a
WebSphere servlet may call an approved model endpoint. Procurement, not
engineering.

Everything in §2 and §3 below is kept as the record of what was found and what
was done about it. The per-phase "DONE and verified" blocks carry the live
evidence; the specification blocks that follow each one describe what was
built and why, and are worth reading before changing that area.

---

## 1. Non-negotiables

These override anything you might otherwise prefer. Every one has already cost
a real defect on this project or is a locked product decision (PROJECT.md §7).

1. **`build.ps1` is the only way to build.** Expected tail today:
   `202/202 checks passed`, `verified 107  failing 0`, `probe sample: 51
   findings`, `clean control: 0 findings`. If you add self-test checks the
   count changes — update PROJECT.md §5 in the same change. There are also
   `npm test` (55 front-end model checks, run by the build when Node is
   present) and `npm run test:designer` (34 Playwright checks against the live
   Designer, deliberately NOT in the build).
2. **Ask the owner before every deploy.** `deploy-assistant.ps1` needs an
   elevated shell; a Java change needs the admin-console path (PROJECT.md §6)
   and a Stop/Start. Never deploy on your own initiative — not even "just to
   test".
3. **Test against the live server, not by reasoning.** This has found a real
   bug every single time on this project — including during this review (F1
   and F2 were both proven live, not argued). Server:
   `https://localhost:9443/assistant/`, creds `admin/admin`, REST reachable
   with `curl -sk -u admin:admin` — no browser needed for probes.
4. **Confirm the servlet is live before trusting behaviour.** A probe once
   raced an application restart by a minute and reported a working fix as
   failed (PROJECT.md §3.4). Cheap check: the `build` stamp in `/api/status`
   (exists after Phase 2) or the deployed class mtime (before it).
5. **Zero third-party jars.** WebSphere ships no JSON API; `Json.java` is the
   parser. Never propose or add a dependency.
6. **Java 8 bytecode (major 52) on WAS 8.5.5.** Wrong bytecode fails at class
   load — not at build, not at deploy. `-source 1.8 -target 1.8`, never
   `--release` (that is a JDK 9+ flag).
7. **Policy rules ship in the WAR; drafts persist in the overlay** at
   `…\Node1Profile\bawAssistantRules\`. Promotion is export → commit →
   redeploy, and that redeploy **is** the governance gate, not an obstacle.
   Never weaken it, never add a shortcut around it.
8. **The checklist's vocabulary wins.** `impactedArea`, `priority`,
   `primaryReviewer`, `checkText` are the checklist's own field names, kept
   verbatim. Do not rename them.
9. **The engine must stay able to review a whole application at a ref**
   (path 2 of PROJECT.md §1). **No `.twx` export** - the owner settled this on
   2026-08-30: the review reads live artifacts at a container ref, which is a
   named snapshot or the tip of a branch or track. Nothing you build may
   foreclose it. Keep every reader DOM-free and every read parameterised by
   containerRef; Phase 4's reader registry exists to serve this.
10. **The assistant never authors artifacts, with one bounded exception that
    is now BUILT.** `/api/fix` edits the developer's buffer at their explicit
    request, behind a diff-first gate, one line at a time, and only for active
    policy rules. **And the Designer autosaves**, so an applied repair reaches
    the committed artifact within seconds without anyone pressing Save -
    verified live, commitSeq 22 to 23. Treat Apply as a change to the artifact.
    Nothing else in the product may write anywhere. See PROJECT.md §7.
11. **Playwright/Chrome hygiene:** launch with a dedicated `--user-data-dir`,
    attach over CDP on 9222, and shut down **by profile directory, never by
    process name** — a name-wide kill closes the owner's own browser.
12. **Report honestly.** If something doesn't work or isn't built, say so
    plainly with the output. Never report partial success as done.
13. **Never edit `knowledge\review-checklist\` sources.** The workbook is the
    customer's governance artifact. The §3.3 precedent is binding: correct at
    the endpoint (what a person is asked), never rewrite the source.

14. **Never commit harvested application code.** `samples/corpus*/` is real
    customer source, pulled on demand by `tools/harvest-corpus.js` and
    gitignored. A narrow ignore pattern once let 2,099 files of a customer's
    code be staged; it was caught before any push, and the pattern was the bug.

This folder **is** a git repository as of 2026-08-29 (commit `7376840` carries
the product as it was deployed). The old history lives in
`D:\ExperimentSoftware\TWX\twx-explorer\`, which also contains `twxexplorer`,
an unrelated Python tool that is not part of this product. There is no remote:
nothing has ever been pushed anywhere.

---

## 2. Verified findings register

Evidence gathered 2026-08-29. Commands in Appendix A.

### 2.0 Claims that were checked and HOLD

Do not re-verify these; the work is done.

- **PROJECT.md §1 counts** — recounted directly from `house-rules.json`:
  123 rules = 49 buffer + 7 artifact + 67 manual; 14 active / 109 draft;
  56 rules carry examples; 66 distinct manual questions after case-insensitive
  collapse. Every number exact.
- **PROJECT.md §3 (three fixes "fixed, deployed and verified")** — all three
  present in source; `hub.js`, `bridge.js`, `house-rules.json`,
  `RuleStore.class`, `ApiServlet.class` are **byte-identical (MD5)** between
  this folder and the deployed tree under `installedApps`; live `/api/status`
  reports the corrected 49/7/67 split; live `/api/checklist?type=CoachView`
  returns `forReview: 37` (down from 38) with the duplicate collapse working.
- **PROJECT.md §6 (deploy script cannot ship Java)** — confirmed: the copy
  list at `deploy-assistant.ps1:51-56` has no `WEB-INF\classes` entry, and
  `build.ps1:192-194` still tells the user to run that script "…Java classes
  changed, so Stop/Start…". The currently deployed classes are up to date only
  because the admin-console path was used.
- **Baseline build reproduces** — `build.ps1` run untouched on 2026-08-29
  produced exactly the §5 tail, `17 classes copied into the WAR`, and
  `BawAssistantEAR-deploy.ear  117790 bytes`. The freshly compiled classes are
  MD5-identical to the deployed ones, so **the live server currently equals
  this source tree**. That is your baseline; any later divergence is yours.
- **Front end has no XSS sink** — every dynamic value in `hub.js`, `rules.js`,
  `tester.js`, `app.js` renders through `textContent` / `createTextNode`; the
  only `innerHTML` uses are static markup or `= ''` clears; the two `html:`
  annotation snippets (`bridge.js:984`, `app.js:654`) interpolate only a
  whitelisted CSS kind. This bounds F1's blast radius: an injected rule cannot
  escalate to script execution on the BAW origin.

### 2.1 The register

| # | Sev | Where |
|---|-----|-------|
| F1 | **Critical** | no security constraint in the WAR; `ApiServlet.java:409-413` |
| F2 | High | `bridge.js:533-547` (`loadVariables`) |
| F3 | High | `deploy-assistant.ps1:51-56`; `build.ps1:192-194` |
| F4 | Medium | `BufferLinter.java:291-337` (`maskComments`) |
| F5 | Medium | `ArtifactChecker.java:166-183`; `Rule.java:250-272` |
| F6 | Medium | `Json.java:154-158` |
| F7 | Low | `ApiServlet.java:66-71` |
| F8 | Low | `hub.js:397-410` (`revealLine`) |
| F9 | Low | `hub.js:134-143` (`loadChecklist`) |
| F10 | Low | `BufferLinter.java:339-358` |
| F11 | Info | `hub.js:820`; `hub.js:56` |
| F12 | Info | deployed `WEB-INF\web.xml` (generated) — **changes Phase 1** |

---

**F1 — Critical. The entire API is unauthenticated.**
The source WAR is descriptor-free, so WAS never challenges `/assistant/*`.
Proven live: `POST /api/rules/save` with **no credentials** returned 200 and
the rule entered the running set for every developer (total went 123→124; the
probe rule was then deleted, also without credentials). Anyone who can reach
port 9443 can inject rules whose message and remediation text render in every
developer's gutter panel, or delete legitimate drafts.
The `baw.assistant.author.role` hook cannot fix this as built: without a
**declared** servlet security role, WAS `isUserInRole` returns false for
everyone, so setting the property would lock out all authors, and leaving it
empty admits anonymous callers. The container must authenticate first.
**Fix:** Phase 1.

**F2 — High. Coach-view variables are never read, but reported as committed.**
`loadVariables` sends CoachView editors to the `coachview` REST endpoint and
then parses the **BPMN** shape: `data.definitions.rootElement[0].
ioSpecification`. Proven live against `AR Demo View`: the coach-view payload
has **no `definitions` key at all** — its model is under `data.CoachViewModel`
(keys: `header`, `inlineScript`, `layout`). So the parse yields zero variables
for every coach view, yet the result is non-null, `variablesAreCommitted` is
set true, and the hub renders "0 input/output variables (as last saved,
commit N)" — asserting confidence in data it never obtained. Every
variable-scoped artifact rule is silently inert on coach views.
The same file's `readModel` (`bridge.js:373-392`) parses `CoachViewModel`
correctly, so the two functions disagree about the same endpoint.
**Fix:** Phase 4, first commit.

**F3 — High. A Java fix can appear deployed and silently not be.**
Confirmed as PROJECT.md §6 claims. Following the build's printed instruction
after a Java change restarts the *old* classes — the failure §3.4 already
brushed against once.
**Fix:** Phase 2.

**F4 — Medium. A quote in a regex literal poisons comment masking.**
`maskComments` tracks string state but not regex literals. The docstring calls
that a missed-finding trade-off; it is not. `var re = /['"]/;` opens string
state that never closes, so every subsequent `//` and `/* */` comment in the
buffer goes **unmasked**, and buffer rules then fire on commented-out code —
false positives, the precise failure the clean-control gate exists to prevent.
An unterminated string mid-edit does the same for everything below it, and
lint runs on every debounced keystroke. Character-class quotes (`/["']/`) are
routine in coach-view code.
**Fix:** Phase 3.

**F5 — Medium. Artifact-rule regexes are unvalidated at load and unbounded at run.**
`Rule.from` compiles and gates `pattern`/`notWhen` for buffer rules, but a
`matches`/`notMatches` regex inside an artifact rule's `check` is compiled per
row per request, and a `PatternSyntaxException` silently returns false — a typo
removes a check with no error, exactly what build gate 2 exists to stop. There
is also no `Deadline` wrapper here, unlike `BufferLinter`, so a catastrophic
pattern in a saved draft runs unbounded on the request thread. Input strings
are short (names), but combined with F1 the asymmetry is unjustified.
**Fix:** Phase 3.

**F6 — Medium. Malformed `\u` escape returns 500, not 400.**
`Integer.parseInt(hex, 16)` throws `NumberFormatException`, which is not a
`Json.JsonException`, so `ApiServlet`'s handler (lines 213-221) misses it and
the container returns a raw 500. Unreachable from the shipped front end
(`JSON.stringify` emits well-formed escapes) but trivially reachable by any
other caller, and it misclassifies a client error as a server fault.
**Fix:** Phase 3.

**F7 — Low. `GET /api/rules` re-verifies every example-carrying rule per load.**
Each rule-browser load runs `RuleVerifier.verify` for all ~49 buffer rules with
examples, each entitled to a 250 ms budget per example. Normally milliseconds;
worst case one pathological draft (see F1) makes every `rules.jsp` load take
seconds on a request thread. Verdicts are deterministic per rule content.
**Fix:** Phase 3.

**F8 — Low. `revealLine` picks the last matching editor document-wide.**
It queries `[data-test-attr="…jseditor"]` across the whole Designer document
and takes the last match — the "never `.last()` blindly" trap PROJECT.md §11
documents. With two artifacts open (editors accumulate in the DOM), clicking a
finding can drive a hidden editor while the visible one does not move.
**Fix:** Phase 4.

**F9 — Low. A failed checklist fetch is never retried for that type.**
`state.checklistType` is set *before* the fetch resolves; on failure the
checklist is nulled but the type sticks, so the guard treats it as loaded and
the review block silently stays absent until the developer opens a different
artifact type. One transient error during startup costs the checklist for the
whole session — the same class of quiet suppression §3.1 fixed.
**Fix:** Phase 4.

**F10 — Low. Suppression directives are honored inside string literals.**
`collectSuppressions` scans raw lines, not masked text, so
`var s = "baw-lint-disable RULE.ID";` disables a rule file-wide. Note the
inversion when fixing: directives live in comments, which masking blanks — so
mask *strings only* for this pass.
**Fix:** Phase 3 (lowest priority in the batch).

**F11 — Info. Two cosmetic loose ends.**
`hub.js:820` calls `setStatus(…, 'ok')`, a status class that does not exist in
`app.css` (the styled one is `good`), so the save notice renders unstyled.
`state.timing.annotate` (`hub.js:56`) is declared but never measured, so the
diagnostic row can never attribute time to painting.
**Fix:** Phase 3.

**F12 — Info, but it changes Phase 1. WAS generated a `metadata-complete` web.xml.**
Discovered 2026-08-29 during Phase 0 orientation. The source WAR has no
`web.xml`, but the **deployed** one does, and it is
`metadata-complete="true"`, with `AssistantApi` → `/api/*` baked in from the
`@WebServlet` annotation. Annotations are therefore **not scanned at runtime**;
that generated descriptor is what routes the API today. Consequences: a servlet
added by annotation alone would not be mapped after a reinstall, and the
security constraint you add in Phase 1 **must ship in a source `web.xml` that
also re-declares the servlet and its mapping** — a descriptor carrying only the
constraint would leave every endpoint 404 after install. Recorded in
PROJECT.md §11.

---

## 3. Phase plan

Work the phases in order. Each ends with a **gate**: acceptance criteria that
must pass before the next phase starts. Phases 1 and 2 share one deploy;
Phase 3 is its own deploy; Phase 4 is static-only deploys. Batch deploys where
the plan says to — every deploy is a request to the owner.

### Phase 0 — Orientation and baseline (no changes) — **DONE 2026-08-29**

Completed during handover; recorded here so you do not repeat it.

- PROJECT.md read; both skills loaded.
- Live `/api/status`: 123 rules, 49/7/67, `draftWritable: true`, `problems: []`.
- Anonymous `GET /api/status` → **200** (F1 re-confirmed).
- Baseline `build.ps1` run untouched: `123/123 checks passed`,
  `verified 56  failing 0`, `probe sample: 51 findings`,
  `clean control: 0 findings`, `17 classes copied`, EAR 117,790 bytes.
- Freshly built classes are MD5-identical to deployed → live server equals
  this source tree.
- F12 discovered (see §2.1) and written into PROJECT.md §11.

**Owner decisions taken 2026-08-29 — both resolved, do not re-ask:**

1. **Version control: yes, `git init` here.** Done. Repo initialised in this
   folder with commit `7376840`, "Initial commit: BAW Assistant as deployed" —
   38 files, matching the running server byte for byte, and including the three
   fixes PROJECT.md §3 listed as uncommitted (§8 item 13 is now closed).
   `.gitignore` excludes `WEB-INF/classes/` and `BawAssistantEAR-deploy.ear`
   (build.ps1 regenerates both; precedent commit `c9789bb`) and
   `bawAssistantRules/`, so a stray copy of the draft overlay can never be
   committed into the WAR and become de-facto policy without a redeploy.
   History for the *old* tree still lives in `twx-explorer`; this repo starts
   fresh and deliberately contains only the product.
2. **Authoring role: declare now, bind to WebSphere groups later.** The owner's
   answer was "we'll use WebSphere groups later", so Phase 1 splits into
   plumbing (now) and policy (later):
   - **Now:** declare both `assistant-user` and `assistant-author` in
     `web.xml`, and at install map **both** to *All Authenticated*. This alone
     closes F1 — the anonymous write path — which is the critical half.
   - **Later:** rebind `assistant-author` to the chosen WebSphere group. That
     is a **pure admin-console change** (Security role to user/group mapping),
     needing no rebuild and no redeploy, which is exactly why the role must be
     *declared* now even though the group is undecided.
   - Do **not** ship with `assistant-author` unmapped: `isUserInRole` would
     then be false for everyone and the Rule Studio would 403 for all users.

### Phases 1 and 2 — **DONE and verified live 2026-08-29**

Deployed via the admin console full-EAR path; build `20260829-173918`.
Every gate below was run against the running server and passed.

| Probe | Result |
|---|---|
| anonymous `GET /api/status` | **401**, `WWW-Authenticate: Basic realm="BAW Assistant"` |
| anonymous `GET /assistant/` | **401** |
| wrong password | **401** |
| `admin:admin GET /api/status` | **200**, `build.id = 20260829-173918` — matches the build exactly, so the new servlet really shipped |
| **anonymous `POST /api/rules/save`** | **401** — the exact request that previously returned 200 and injected a live rule. Rule set unchanged at 123. |
| anonymous `POST /api/rules/delete` | **401** |
| authorized save | **200**, lifecycle forced to `draft`, total 124 |
| authorized delete | **200**, `deleted: true`, total back to 123 |
| audit trail | both operations in SystemOut.log with user, source address and outcome |
| LTPA-only request (no credentials) | **200** — a developer already in BAW is never prompted |

Two things learned in the process, both now in PROJECT.md §11: an **unmapped
role returns 403, not 401**, and locks out every authenticated user (the
install wizard makes that step easy to skip — check for an
`authorizationTable` element in the deployed `deployment.xml` to confirm);
and **LTPA SSO satisfies the constraint**, so BASIC costs developers nothing.

One honest limitation: anonymous attempts are rejected by the container
before reaching the servlet, so they produce **no application audit line**.
Only authenticated activity appears in the `[BAW-ASSISTANT-AUDIT]` trail;
anonymous probes are visible only in WebSphere's own security logging.

**Remaining from Phase 1, deferred by the owner:** `assistant-author` is
mapped to All Authenticated, so any *authenticated* user can still author
drafts. Binding it to a real WebSphere group is console-only — no rebuild, no
redeploy. `/api/status` reports `mayAuthor`, so the rebinding can be verified
without attempting a write.

---

### Phase 1 — Close the authentication hole (F1) *(specification, as built)*

**Goal:** unauthenticated callers get 401 everywhere; authenticated
non-authors get 403 on the two write endpoints; the browser flow is unchanged,
because same-origin sessions already carry LTPA.

1. Add `BawAssistant.war/WEB-INF/web.xml`, Servlet 3.0 schema. **Per F12 it
   must re-declare the servlet and mapping**, not only the constraint:
   - `<servlet>` + `<servlet-mapping>`: `AssistantApi` →
     `com.bawassistant.ApiServlet` → `/api/*`.
   - `<security-constraint>` over `/*` requiring role `assistant-user`.
   - `<security-role>` for `assistant-user` **and** `assistant-author` —
     declaring the role is what makes `isUserInRole` functional (see F1).
   - `<login-config><auth-method>BASIC</auth-method></login-config>` — browser
     sessions ride LTPA SSO and are never prompted; `curl` uses `-u`.
   - Do **not** set `metadata-complete="true"` yourself; let the explicit
     declarations stand on their own.
2. `mayAuthor` (`ApiServlet.java:409-413`): keep the sysprop override, but
   change the default. An empty property must now **deny** and fall back to
   `req.isUserInRole("assistant-author")`, not `return true` — the container
   authenticates from this phase on, so open-by-default is no longer a
   deliberate hook, just a hole.
3. Audit logging: one `System.out.println` per save and delete —
   timestamp, action, rule id, `getRemoteUser()`, `getRemoteAddr()`. Lands in
   SystemOut.log, zero dependencies, answers "who changed the rules?".
4. Role mapping happens at install: admin console → application → *Security
   role to user/group mapping*. Per the Phase 0 decision, map **both**
   `assistant-user` and `assistant-author` to *All Authenticated* for now;
   the WebSphere group for `assistant-author` is chosen later and rebound in
   the console alone. **Document the clicks in `deploy-assistant.ps1`'s
   header** so the next installer cannot miss them, and state plainly there
   that until the group is bound, any authenticated user can author drafts —
   the anonymous hole is closed, the author/user distinction is not yet
   enforced.

**Cautions.** Deploy this phase via the **admin-console full-EAR path**, not
the file-copy script — WAS regenerates `web_merged.xml` at install and a
copied-in descriptor will not take effect. After deploy, confirm the hub still
loads for a browser already logged into BAW.

**Gate** (live, after an owner-approved deploy):

```
curl -sk -o /dev/null -w "%{http_code}\n" https://localhost:9443/assistant/api/status      → 401
curl -sk -u admin:admin  https://localhost:9443/assistant/api/status                        → 200
curl -sk -X POST         .../api/rules/save -d '{"rule":{…}}'            (no creds)         → 401
curl -sk -u admin:admin -X POST .../api/rules/save …   (admin NOT in author group)          → 403
                                                       (admin IN author group)              → 200
```
Then delete the probe rule. The hub must lint normally in a logged-in browser,
and SystemOut.log must show the audit line for the probe save.

### Phase 2 — Make deploys trustworthy (F3) — same deploy as Phase 1

1. `deploy-assistant.ps1`: either add `WEB-INF\classes\com\bawassistant\*.class`
   to the copy list (printing the ND caveat: the config-repo master wins, a
   node resync can revert, the console path is the durable one), or add a
   `-Java` switch that refuses with instructions. Pick one — either must make
   it impossible to *believe* a Java change shipped when it did not.
2. `build.ps1` closing message: two branches. Static-only → run the script.
   Java changed → use the admin-console path (PROJECT.md §6). The build can
   tell, by hashing the classes before and after the copy step.
3. **Build stamp.** `build.ps1` writes
   `WEB-INF\classes\com\bawassistant\build-info.properties`
   (`built=<ISO-8601>`, `buildId=<yyyymmdd-HHmmss>`); `ApiServlet` reads it
   from the classpath and adds a `"build"` field to `/api/status`. This is the
   one-curl answer to "is my fix actually live?" (non-negotiable 4) and the
   deploy-verification primitive every later phase leans on.

**Gate:** `/api/status` returns the stamp; a static-only deploy updates JS and
the stamp does **not** move (proving it tracks classes, not files); the
Phase 1 Java deploy shows a new stamp. PROJECT.md §5 and §6 updated in the
same change.

### Phase 3 — **DONE and verified live 2026-08-29**

Deployed via the admin console; build `20260829-204425`, confirmed by the
stamp in `/api/status`. The build gate grew from 123 to 134 checks, all
passing.

| Probe | Result |
|---|---|
| regex literal then a commented-out `debugger` | **no findings** — F4 fixed; the comment stays masked |
| directive inside a string literal | finding **still reported** — F10 fixed; a string cannot disable a rule |
| the same directive in a real comment | **suppressed** — genuine suppression still works |
| `POST /api/lint` with a malformed `\uZZZZ` | **400** with `bad \u escape`, was a raw 500 — F6 fixed |
| anonymous `POST /api/rules/save` | **401** — Phase 1 holds, no regression |
| `/api/rules` x3 | 200 in ~0.22 s; 49 verified, 0 failing, no rule problems |

A note on the build, worth keeping. The first Phase 3 build **failed the
latency gate at 126 ms** against a 100 ms budget, which looked like a
regression introduced by the extra masking pass. Profiling said otherwise:
masking costs 0.1 ms, and the identical classes linted the identical buffer
in 26.8 ms against a 25.4 ms baseline. It was noise on a loaded machine, and
two later builds measured 39.2 ms and passed. **Profile before optimising** -
trusting that first number would have meant rewriting code that was never
slow.

---

### Phase 3 — Engine hardening batch (F4, F5, F6, F7, F10, F11) *(specification, as built)*

One build, one Java deploy. **Each fix gets a `SelfTest` case that fails before
and passes after** — the total check count will grow past 123, so update
PROJECT.md §5's expected tail in the same change.

1. **F4** `maskComments`: reset quote state at `\n` for `'` and `"` (neither
   may legally span lines in JS); keep backtick state across lines for template
   literals. Self-test: `var re = /['"]/;` followed by a commented-out defect
   on the next line must yield **zero** findings.
2. **F5** `Rule.from`: walk the `check` tree (including `and`/`or`/`not`
   nesting), compile every `matches`/`notMatches` once, and return
   `broken(id, …)` on failure so the rule fails the build like a bad buffer
   pattern. Keep the compiled patterns so `ArtifactChecker` stops recompiling
   per row. Factor `BufferLinter.Deadline` out to package level and apply the
   same budget to artifact matching.
3. **F6** `Json.readString`: validate the four hex digits, or catch
   `NumberFormatException` and rethrow as `JsonException`. Self-test:
   `Json.parse("\"\\uZZZZ\"")` throws `JsonException`; a live probe to
   `/api/lint` with that body returns **400**, not 500.
4. **F7** `ApiServlet` `/rules`: cache `RuleVerifier.Result` per rule, keyed to
   a generation counter bumped in `RuleStore.invalidate()`, or compute verdicts
   once inside `RuleStore.load` alongside `problems`. A warm cache must do no
   verification work.
5. **F10** `collectSuppressions`: scan a **strings-masked** copy (comments must
   survive — that is where directives live). Drop this one if it fights the
   F4 masker refactor; say so rather than forcing it.
6. **F11**: `'ok'` → `'good'` at `hub.js:820`; either measure
   `timing.annotate` around `B.annotate` in `runLint`, or delete the field.

**Gate:** build green at the new check count; clean control still 0 findings;
live — the F4 snippet through `/api/lint` produces no comment-zone findings,
and a deliberately broken `matches` regex is refused at save with a visible
error rather than silently disabling the check.

### Phase 4 — **DONE and verified live 2026-08-29**

Static-only deploy (the build said so, correctly). Verified three ways:
against captured payloads, against live REST, and in the real Designer.

**Live REST, all eleven probe artifacts read successfully** through the one
generic endpoint - coach views reporting `vars=n/a` rather than a fabricated
zero, and their committed code surfaces found.

**In the Designer**, with an AppSettings editor and a CoachView editor both
in the DOM (the accumulation case), the bridge picked the visible one and
`readArtifactModel()` returned for `AR Demo View`:

```
variablesApply : false          <- the F2 fix; no invented signature
settings       : 6 header flags <- previously all discarded
surfaces       : inlineJavaScript, eventHandlersUnload
commitSeq      : 22
```

The unload handler is the one the editor never shows beside the inline
script, so it was invisible to review before this.

The docked panel rendered `no surface  ·  no vars, 1 step` and
`37 checks for review  ·  CoachView  ·  49 answered here` - the checklist
count matching PROJECT.md's own table, which also exercises the F9 retry
path on a type change.

Two notes for whoever tests next. Chrome **throttles timers in hidden
tabs**, so the hub's 500 ms poll effectively stops while another tab is in
front; drive the hub tab, or bring it forward, before waiting on the panel.
And the test browser was shut down **by profile directory** - 10 processes
matched, 24 belonging to the owner were left alone.

---

### Phase 4 — Enrich the artifact model in bridge.js (pending item 4; F2, F8, F9) *(specification, as built)*

Use the method that has worked here (PROJECT.md §9): **probe the live payloads
first**, design the model against what is actually there. Static-only deploys.

1. **Fix the lie first (F2), before any enrichment.** Branch `loadVariables`
   by editor kind: CoachView parses `data.CoachViewModel` (shape already proven
   in `readModel`); flow-shaped types keep the BPMN parse. If a parse finds
   nothing recognisable, return **null** so the existing "unavailable — could
   not read the saved model" path renders. `variablesAreCommitted: true` over
   silently-empty data must become impossible for every type.
2. **Probe protocol.** For each of the seven artifact types, fetch the model
   using the poIds in Appendix B, save the payloads under
   `knowledge\artifact-catalog\payloads\` (provenance, not runtime), and record
   per type: where variables live, where steps live (remember the client-side
   human service nests under
   `extensionElements.userTaskImplementation[0].flowElement`), and what
   settings exist — service settings, coach-view config options, UCA
   properties, BO attributes, `bpdExtension` flags. **`incoming`/`outgoing`,
   variable defaults and coach-view handlers are absent when empty, not
   empty** — never read absence as an error.
3. **Reader registry.** Replace the single parse with
   `{ editorType: { endpoint, parse(body) → model | null } }`. Each entry
   returns the engine-facing shape, extended beyond `variables` + `components`
   with `settings` and per-type extras. **These parsers must be callable
   outside the Designer window** — they are the future `.twx` report's readers
   (non-negotiable 9). Keep them free of DOM access.
4. **F8:** export the scope-aware `surfaceHost` lookup from `BawBridge` and use
   it in `revealLine` instead of the document-wide query.
5. **F9:** reset `state.checklistType` in `loadChecklist`'s catch.
6. **jsdom harness.** Add `test/` per the `baw-coach-view` skill's harness
   pattern, with a mocked `dijit` / Orion / document. Encode PROJECT.md §11's
   selector findings as assertions: the `.jseditor` suffix convention, the
   Properties-panel sibling scope for service flows, `offsetParent` visibility,
   the editor-accumulation rule, and the annotation-type registration order.
   Wire it into `build.ps1` **only if Node is already on this machine** — check
   first, and do not add a Node dependency to the build without asking.
7. Per-artifact-type rules (pending item 7) then follow as pure rule authoring
   against the enriched model, with `fires`/`quiet` examples as always. The
   migration-risk classifier (item 8) becomes schedulable.

**Gate:** on the live server every one of the seven types shows either real
variables/settings or the honest "unavailable" note — **zero confident-empty
states**; at least one new coach-view config rule fires end-to-end in the
panel; the harness runs green.

### Phase 5 — Quietness corpus and promotion tooling (pending item 2; alongside 4+)

1. Ask the owner for real application code — the CAPOC app at minimum, ideally
   a production-scale one. Harvest committed script surfaces over REST into
   `samples\corpus\`. Read-only, as always.
2. A small PowerShell driver over the **existing** `Emit` harness: run all 123
   rules across the corpus and emit a per-rule fire-rate table (rule id, files
   hit, total hits, sample lines). No engine changes needed.
3. Promotion, one rule at a time: acceptable fire rate → owner reviews →
   export → flip lifecycle in the export diff → commit → redeploy.
   **Never in bulk** — the owner's precedent is a rule that went from 94,074
   findings to 144 once targeted.

**Gate:** a fire-rate report exists for all 42 unproven drafts; the noisiest
are fixed or withdrawn; the promotion path has been walked once end to end
with the owner.

### Phase 6 — `/api/fix` (pending item 5)

Server computes, developer applies.

- Eligible only when `enforcement: "auto-fixable"` **and**
  `lifecycle: "active"` (`Rule.java` already forces drafts off the flag — keep
  that gate).
- `POST /api/fix {code, language, ruleIds?}` → per-finding
  `{line, before, after}`. The server never touches an artifact.
- The panel shows a diff per finding; the developer applies each one; bridge
  writes to the **Orion buffer**, so the developer still saves through
  Designer and IBM's own save pipeline and validators stay authoritative.
- Record the exception in PROJECT.md §7, as non-negotiable 10 requires.

**Gate:** one auto-fixable rule works end to end live — finding → diff →
apply → buffer changes → save → finding gone on re-lint.

### Phase 7 — Design system and panel UX (owner request, 2026-08-30)

Five things the owner asked for in the docked panel, plus the one that turns
them into a system:

1. group artifact-level and script/sub-component findings separately;
2. collapse a finding to one line, expand it for the detail — the panel is a
   long scroll today because every row renders its rationale, remediation,
   rule id and fix controls at all times;
3. severity and category filters as small button groups;
4. a font-size +/- control;
5. an enterprise-grade UI in the idiom of IBM's Carbon design system.

**Item 5 is a design system, items 1-4 are the panel applying it, and the
Phase 8 report is the second thing to apply it.** That is why this phase comes
first: built the other way round, the whole-application review gets styled
twice.

Two constraints were checked rather than assumed, and both shape the work:

- **No Carbon library.** Non-negotiable 5 (zero third-party jars, and by the
  same argument no third-party front-end framework) rules it out, and so does
  where the panel lives: `PANEL_CSS` is injected into the *Designer's own
  document*, where an unprefixed external stylesheet would fight Dojo's CSS.
  That is why every panel class is `bawp-` prefixed today. So: Carbon's design
  *language* — its type scale, 8px spacing grid, grey ramp, 2px focus ring —
  hand-rolled. IBM Plex Sans is already the panel's font stack.
- **`#bawp-meta` and `#bawp-list` must keep their ids.**
  `test/designer/harness.js` reads both by id and asserts on
  `list.textContent`. This decides a design detail: a collapsed row hides its
  detail with CSS and never leaves it unrendered, or the 34-check Playwright
  suite goes red and the panel stops being text-searchable.

The token table cannot be a shared file. `PANEL_CSS` must stay prefixed and
self-contained; `css/app.css` styles five ordinary pages. One documented token
table, applied by hand in both, is the deliberate cost.

**Steps.**

- **A0** Baseline `build.ps1` with no changes, so a restyle that breaks the
  gate is distinguishable from a gate that was already red.
  **DONE 2026-08-30:** `184/184`, `verified 107 failing 0`, `probe sample: 51`,
  `clean control: 0`, build `20260830-201408`.
- **A1** Write the token table down first, in `knowledge/`.
- **A2** Rewrite `PANEL_CSS` onto the tokens, every size in `em` rooted at
  `.bawp`, so one root value scales the panel.
- **A3** Restructure `renderPanel()`: four labelled collapsible groups — *This
  artifact*, *This script*, *Process Designer*, *Review checklist* — counts in
  each header, one-line rows that expand.
- **A4** Filter bar and font +/-, offering only the severities and categories
  actually present. Font size, filters and collapsed state persist in
  `localStorage`.
- **A5** Apply the same tokens to `css/app.css`, restyling the hub, rules,
  tester, compare and probe pages together.
- **A6** Extend `npm test` with grouping/filtering/ordering checks; run it and
  `build.ps1`. A changed check count changes PROJECT.md §5 in the same commit.
- **A7** **Ask the owner to deploy.** Static files only, so
  `deploy-assistant.ps1` from an elevated shell; no Stop/Start.
- **A8** Verify in the Designer, not by reasoning: hard refresh, then
  `npm run test:designer`.

**Gate:** the panel groups, collapses, filters and scales live in the
Designer, and the 34 Playwright checks still pass.

### Phase 8 — The whole-application review (pending item 4)

Shape settled by the owner on 2026-08-30 and recorded in §0 item 4 and
PROJECT.md §7: **no `.twx` export**, live artifacts at a container ref, a
separate page modelled on IBM's IDA report (`ref/images/`).

**The sweep runs in the browser; the analysis runs on the server.** The
readers are 2,334 lines of `bridge.js` keyed on `domainProperty`, and
`harvest-corpus.js` already *imports* them rather than reimplementing them,
precisely so a second copy cannot drift — a Java reimplementation would be
that second copy. The browser also holds the LTPA session; the servlet holds
no BAW credentials, so this must not depend on the server-to-server question
that blocks the AI path.

Three facts probed live on 2026-08-30 that the work depends on:

- **Toolkits come from `/rest/bpm/wle/v1/toolkit`** — 115 of them, in the same
  `processAppsList` shape. `/toolkits` is 404. Every one has
  `defaultBranchID: null`, so `listProcessApps`'s `filter(a => !!a.branchRef)`
  would silently drop all 115; their refs live in `installedSnapshots[]` as
  `.ID` (a snapshot) and `.branchID`. Both were confirmed to serve `/assets`
  for the Test TK toolkit.
- **Batching is mandatory, not a nicety.** `MAX_BODY_CHARS` is 2 MB and the
  largest harvested application is 957 artifacts / 2,041,023 characters before
  JSON escaping. One POST cannot carry an application.
- **`calledElement` is a real poId on a `callActivity`, and `null` genuinely
  means unimplemented** — the three "System task" nodes in *Sample Process
  With All* are the fixture's deliberate defect, not a reference stored
  elsewhere.

**Steps.**

- **B1** `bridge.js`: `listToolkits()`, refs from `installedSnapshots`. Pinned
  in `test/bridge-model.test.js`.
- **B2** `POST /api/review` — a batch of artifacts in, findings tagged with
  artifact identity out. Stateless and purely per-batch. Duplicate detection
  stays on the client, computed across all batches from normalised-code
  hashes, because it needs the whole set and the endpoint must not become
  stateful to get it.
- **B3** `SelfTest` checks for the endpoint's shape and the batch loop; build
  count and PROJECT.md §5 updated in the same commit.
- **B4** `review.jsp` + `js/review.js` in Phase 7's design system: chooser
  (app or toolkit -> branch or snapshot -> Analyse), summary tiles, artifacts
  summary, check-result details with severity tabs, category chips, search and
  expandable rule rows, and the two honesty panels — artifacts the readers
  could not parse, and the manual checklist grouped by type. The IDA report's
  structure maps one to one: Symptom is `message`, Best Practice is
  `remediation` plus `rationale`, Reference is `source`, and the tabs and chips
  are `severity` and `category`.
- **B5** Register **both** files in `deploy-assistant.ps1`'s explicit list and
  link the page from `index.jsp`. Its own comment warns that forgetting one
  ships a page that loads and does nothing.
- **B6** **Ask the owner to deploy.** Java changed, so the admin console and a
  Stop/Start, then wait for `/api/status` to report the new build id before
  probing anything.
- **B7** Verify against Test PA: *Sample Process With All* must contribute its
  16 findings. Then the real check — harvest the same ref with
  `harvest-corpus.js`, run `com.bawassistant.Corpus` over it headlessly, and
  compare totals. Two independent paths to the same number is proof; the page
  agreeing with itself is not.
- **B8** **DONE.** PROJECT.md, §0 item 4 here, and the evidence note at
  `knowledge/rule-packs/whole-application-review-2026-08-30.md`, which carries
  the measured numbers, the two-path cross-check, and the five defects the
  feature exposed - none of which any earlier test could have found.

**Deliberately not in this phase, each for a stated reason.**

- **Unused-artifact detection (catalogue B11, I8).** `calledElement` covers
  `callActivity`, but a coach flow references a view by `viewUUID`, a UCA by
  its attached service and a team by `teamService`. A reachability graph
  missing any of those calls live artifacts dead, which is the exact class of
  false positive this project keeps catching. It needs its own measurement
  pass first.
- **Toolkit dependency depth (I1-I5).** No dependency endpoint found yet.
- **A health score.** IDA prints one; ours would be an unmeasured weighting,
  and a single number is the one thing on a report that gets quoted and
  targeted. Ship the counts, calibrate the bands against the three real
  corpora (2.04M, 1.41M and 266K characters), then add it.

**No new rule kind.** `Corpus.java` states the engine's position and it holds:
every rule kind judges one thing in isolation, so a set-level fact — duplicate
code, per-type counts, migration counts — belongs to the report, not to a rule
that would lie about what it can see.

**Gate:** a named snapshot and a branch tip both produce a report; its total
matches a headless `Corpus` run over the same ref.

---

## 4. Enterprise roadmap

Sequenced after Phase 6 unless the owner redirects. Each is shaped to fit the
constraints: zero jars, WAS 8.5.5, file-backed persistence in the profile
directory (the `DraftStore` pattern), engine stays `.twx`-capable.

**R1. Snapshot-diff review — "review only what changed."** PROJECT.md §11
already proves the enabler: a snapshot ref (`2064.…`) works as a
`containerRef`. Compare the current track against the last deployed snapshot,
list changed artifacts, run artifact rules and committed-code lint on both
sides, and show *new* findings versus *fixed* ones. Reviewers stop
re-reviewing the whole app; the delta is the review. **Highest-leverage cheap
feature** — REST plus the Phase 4 readers plus a diff, no new engine.

**R2. Checklist sign-off tracking — the 67 manual rows become a workflow.**
The data model already exists: `primaryReviewer` carries the sign-off stage
(Self / Self & Peer / Self & Peer & SME). Persist per-artifact, per-snapshot
answers — checked / N-A / comment, by whom, when — in a file-backed store
beside the draft overlay (`bawAssistantReviews\`), one JSON per artifact +
snapshot. Panel: a progress line ("12 of 37 reviewed"), checkboxes on the
review block, a "my stage" filter for peer and SME reviewers. The checklist
stops being a spreadsheet someone forgets and becomes the review record.

**R3. Pre-deployment report and CI quality gate.** Path 2, finally built: a
headless entry point (Phase 4 readers + engine over a snapshot ref or an
exported `.twx`) producing JSON plus a self-contained HTML report — findings
by severity with provenance, checklist coverage including R2 sign-off state,
per-artifact drill-down. Add a **severity budget** exit code (criticals = 0 or
fail) so a pipeline can gate snapshot promotion. This is the artifact
stakeholders who never open Designer actually consume.

**R4. Findings trend metrics.** Append-only JSONL in the profile directory
(one line per lint/check summary: app, artifact, counts, timestamp) and a small
dashboard JSP. Surfaces rules that nag without ever being fixed (candidates for
demotion or auto-fix), artifacts that need refactoring, and whether the tool is
actually reducing findings over time.

**R5. Zero-friction start.** Replace the pasted `containerRef` with a picker —
the REST inventory already enumerates process apps and branches. Remember the
last choice; auto-dock the panel when the Designer becomes ready. This removes
the one step that currently requires tribal knowledge.

**R6. Richer gutter UX.** The Orion annotation `title` already renders on
hover — extend it to carry the rationale and checklist cell, so hovering a
squiggle *teaches the standard*. Add a per-finding affordance that shows (never
inserts) the `baw-lint-disable-next-line` comment to copy. Juniors converge on
house style without a reviewer repeating themselves.

**R7. Rule packs.** Formalise the split between engine and LSEG content: the
export format (version 2, everything reconstructable) becomes the pack format,
plus a manifest (name, version, owner). Teams import a pack as drafts and
promote through their own gate. One engine serves many teams.

**R8. AI assistance (pending item 6 — blocked on procurement; design now).**
Do not build transport until the server-to-server question is answered. Do
shape the payload: a finding already carries message, rationale, provenance,
priority and reviewer stage — that JSON *is* the prompt context. First
features when unblocked, in value order: **explain this finding** (rationale →
narrative for juniors); **propose a fix plus quiet examples** (feeds the
tester's `fires`/`quiet` discipline); **draft a rule from a review comment**
(an SME writes prose, the model drafts the JSON, a human promotes it through
the existing gate). The governance gate already built is precisely what makes
AI authoring safe to add.

**R9. Operational polish (rolling).** Backup-by-default in the deploy script;
surface `/api/status` `problems` on the hub when the draft directory is
unwritable; a documented upgrade path (console update, role mappings survive);
and the three thin documents a product needs — admin guide, rule-authoring
guide, checklist-mapping reference — each written for a reader who was not
present for the project.

---

## 5. Working agreements

- **Per phase:** say what you are about to change → change it → run
  `build.ps1` → ask the owner to deploy → verify the gate live → report,
  including anything that did **not** work.
- **Deploy verification is always** the `/api/status` build stamp (after
  Phase 2), then the phase's gate probes. Never conclude from behaviour alone
  within a minute of a restart.
- **When a live probe surprises you, believe the server, not this plan.**
  Update this file and PROJECT.md §11 with what you learned — F12 is the
  worked example.
- **Keep PROJECT.md current:** §5 expected tail, §6 deploy story, §7 locked
  decisions (Phase 6's exception), §8 pending list as phases complete.

---

## Appendix A — probe commands used, and the two mutations made

Read-only probes:

```bash
curl -sk -u admin:admin https://localhost:9443/assistant/api/status
curl -sk -o /dev/null -w "%{http_code}" https://localhost:9443/assistant/api/status   # no creds → 200
curl -sk -u admin:admin "https://localhost:9443/assistant/api/checklist?type=CoachView"
curl -sk -u admin:admin "https://localhost:9443/rest/bpm/wle/pd/v1/assets?containerRef=<ref>"
curl -sk -u admin:admin "https://localhost:9443/rest/bpm/wle/pd/v1/coachview/<poId>?containerRef=<ref>"
curl -sk -u admin:admin "https://localhost:9443/rest/bpm/wle/pd/v1/bpmn2/<poId>?containerRef=<ref>"
```

Two mutations, both reverted, both proving F1:

```bash
# 1. saved a disabled non-matching draft rule with NO credentials  → HTTP 200
curl -sk -X POST https://localhost:9443/assistant/api/rules/save \
     -H "Content-Type: application/json" \
     -d '{"rule":{"id":"zz-review-probe-delete-me","kind":"buffer",…,"enabled":false}}'
# 2. deleted it again with NO credentials                          → HTTP 200, deleted:true
curl -sk -X POST https://localhost:9443/assistant/api/rules/delete \
     -H "Content-Type: application/json" -d '{"id":"zz-review-probe-delete-me"}'
```

Server state after cleanup: 123 rules, `problems: []` — confirmed identical to
before the probe.

## Appendix B — live probe reference data

Test branch (Main): `2063.595f5dc8-e7e0-469e-845d-26497db1f58a`
Process app: Coding Assistant PoC (`CAPOC`)

| Type | Name | poId |
|---|---|---|
| CoachView | AR Demo View | `64.4bd440cd-8629-403c-9c45-bbc6278c792b` |
| CoachView | CommitProbe View | `64.7d4d3a0a-3eba-47e0-a37e-ec64f65c05db` |
| SERVICEFLOW | ProbeServiceFlow | `1.b11f1741-1579-4c83-9a16-be58af94b3bd` |
| SERVICEFLOW | ProcessTenRecords | `1.8451c195-f628-40b5-9612-c7600cefbb1f` |
| COACHFLOW | ProbeClientSideHS | `1.dcfaebbc-8b8f-4701-a9a5-3438ee6d83cd` |
| CaseProcess | Demo Approval Process | `25.ffb1c87f-60be-4f70-afb3-d460f404c2db` |
| UCA | ProbeTimerUCA | `4.9a4478ac-afba-4811-91f7-d6b2fd95d450` |
| BusinessObject | ProbeCustomerBO | `12.fd827a0d-44cc-4b6e-b694-6ca8f41b54ba` |
| Team | ProbeApproverTeam | `24.9e453f91-9867-4ffa-b07b-8fa5ec432270` |
| RESTService | ProbeRestService | `2051.f061b41b-71d4-4334-a50a-db8444d051d3` |
| ProcessAppSettings | Process App Settings | `63.28cef944-907f-42ef-9627-e0094a00b29f` |

Shapes confirmed during the review:

- **CoachView** (`/coachview/…`) — `data.CoachViewModel` with keys `header`,
  `inlineScript`, `layout`. **No `definitions` key** — this is F2.
- **COACHFLOW / client-side human service** (`/bpmn2/…`) — one `rootElement`,
  which *does* carry `ioSpecification` (empty on this probe artifact), and
  nests its flow under
  `extensionElements.userTaskImplementation[0].flowElement`, as PROJECT.md §11
  warns.
- `envVarSet` returns HTTP 500 for its poId (PROJECT.md §8 item 12). Parked;
  do not chase it.

<#
    Build the BAW Assistant: compile, verify, test, package.

        powershell -ExecutionPolicy Bypass -File .\build.ps1

    Does NOT deploy - deployment needs an elevated shell and is a separate,
    deliberate act. Run .\deploy-assistant.ps1 afterwards.

    Five things this exists to stop happening:

      1. Java 6 bytecode. WAS 8.5.5 runs Java 6 by default with Java 8 as an
         optional SDK. Compiling for the wrong one fails at CLASS LOAD - not at
         build, not at deploy, but the first time a servlet is touched. Every
         class is checked for major version 52 before anything is packaged.

      2. Shipping a broken rule. A rule whose regex does not compile is skipped
         silently by the engine, so a typo removes a check without any error.
         The self-test loads the real rules file and fails the build instead.

      3. Shipping a rule that fires on correct code. False positives are what
         get linters switched off. The clean control must return zero findings.

      4. A rule that has quietly stopped doing what its author promised. Every
         rule carries examples it must flag and examples it must leave alone;
         all of them are run, and a mismatch fails the build.

      5. A stale WAR. The classes under BawAssistant.war are copied from this
         build every time, so the exploded tree can never drift from src/.
#>

[CmdletBinding()]
param(
    [string] $Jdk    = 'C:\Program Files\Java\jdk1.8.0_202',
    [string] $Stubs  = 'C:\WebSphere Runtime Stubs\v8.5\dev',
    [switch] $SkipTests
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$ear  = Join-Path $root 'BawAssistantEAR.ear'
$war  = Join-Path $ear  'BawAssistant.war'
$rules = Join-Path $war 'WEB-INF\rules\house-rules.json'
$work = Join-Path $env:TEMP 'baw-assistant-build'

function Step($n) { Write-Host "`n$n" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  OK    $m" -ForegroundColor Green }
function Info($m) { Write-Host "  ..    $m" -ForegroundColor DarkGray }
function Die($m)  { Write-Host "  FAIL  $m" -ForegroundColor Red; exit 1 }

$javac = Join-Path $Jdk 'bin\javac.exe'
$java  = Join-Path $Jdk 'bin\java.exe'
$jar   = Join-Path $Jdk 'bin\jar.exe'
foreach ($t in @($javac, $java, $jar)) {
    if (-not (Test-Path $t)) { Die "not found: $t  (pass -Jdk to override)" }
}

$j2ee = Join-Path $Stubs 'JavaEE\6.0\j2ee.jar'
if (-not (Test-Path $j2ee)) { Die "servlet stubs not found: $j2ee  (pass -Stubs)" }
$cp = ($j2ee, (Join-Path $Stubs 'was_public.jar')) -join ';'

Write-Host "BAW Assistant - build" -ForegroundColor Cyan
Info "jdk   $Jdk"
Info "stubs $Stubs"

# ---------------------------------------------------------------- 1. compile
Step '1. Compile'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory -Path $work -Force | Out-Null
$classes = Join-Path $work 'classes'
New-Item -ItemType Directory -Path $classes -Force | Out-Null

$sources = @(
    (Get-ChildItem (Join-Path $ear 'src\main\java\com\bawassistant') -Filter *.java)
    (Get-ChildItem (Join-Path $ear 'src\test\java\com\bawassistant') -Filter *.java)
) | ForEach-Object { $_.FullName }

# -source/-target, NOT --release: --release is a JDK 9+ flag.
& $javac -source 1.8 -target 1.8 -nowarn -encoding UTF-8 -cp $cp -d $classes $sources
if ($LASTEXITCODE -ne 0) { Die "compilation failed" }
Ok "$($sources.Count) source files"

# ------------------------------------------------------- 2. bytecode version
Step '2. Verify bytecode is Java 8 (major 52)'
$bad = @()
Get-ChildItem $classes -Recurse -Filter *.class | ForEach-Object {
    $fs = [System.IO.File]::OpenRead($_.FullName)
    try {
        $b = New-Object byte[] 8
        [void]$fs.Read($b, 0, 8)
        # bytes 6-7 are the major version, big-endian
        $major = ($b[6] -shl 8) -bor $b[7]
    } finally { $fs.Close() }
    if ($major -ne 52) { $bad += "$($_.Name) is major $major" }
}
if ($bad.Count) { $bad | ForEach-Object { Write-Host "  $_" }; Die "wrong bytecode version" }
Ok "all classes are major 52"

# ------------------------------------------------------------- 3. self-test
if (-not $SkipTests) {
    Step '3. Rule engine self-test'
    # Tee'd, because a self-test that fails once and passes on the retry is
    # worse than one that fails every time - without the output there is
    # nothing to diagnose and the honest response is to shrug.
    $log = Join-Path $work 'selftest.log'
    & $java -cp $classes com.bawassistant.SelfTest $rules | Tee-Object -FilePath $log
    if ($LASTEXITCODE -ne 0) {
        Write-Host "  failing checks:" -ForegroundColor Red
        Select-String -Path $log -Pattern '\[FAIL\]' | ForEach-Object {
            Write-Host "    $($_.Line.Trim())" -ForegroundColor Red
        }
        Write-Host "  full output: $log" -ForegroundColor DarkGray
        Die "self-test failed"
    }

    Step '4. Every rule against its own examples'
    # The self-test already asserts this, but calling it out separately means the
    # build log answers "how many rules have earned promotion" without reading
    # 117 lines of test output.
    $verify = & $java -cp $classes com.bawassistant.Verify $rules
    $verify | Where-Object { $_ -match '^(FAIL|ERROR|THIN|BROKEN)' } | ForEach-Object {
        Write-Host "  $_" -ForegroundColor Red
    }
    if ($LASTEXITCODE -ne 0) { Die "a rule no longer matches its own examples" }
    Ok ($verify | Select-Object -Last 1).Trim()

    Step '5. Sample probe and clean control'
    $probe = Join-Path $root 'samples\probe-all-rules.js'
    $clean = Join-Path $root 'samples\probe-all-rules-fixed.js'

    if (Test-Path $probe) {
        $hits = & $java -cp $classes com.bawassistant.Emit $rules $probe
        $n = @($hits | Where-Object { $_ }).Count
        if ($n -lt 15) { Die "probe found only $n findings - rules may not be loading" }
        Ok "probe sample: $n findings"
    } else { Info "no probe sample, skipped" }

    if (Test-Path $clean) {
        # The one that matters. A rule that fires on correct code is worse than
        # no rule at all, because it teaches developers to ignore the gutter.
        $fp = & $java -cp $classes com.bawassistant.Emit $rules $clean
        $fp = @($fp | Where-Object { $_ })
        if ($fp.Count -gt 0) {
            $fp | ForEach-Object { Write-Host "  false positive: $_" -ForegroundColor Red }
            Die "clean control produced $($fp.Count) finding(s) - fix or drop the rule"
        }
        Ok "clean control: 0 findings"
    } else { Info "no clean control, skipped" }
} else {
    Info 'tests skipped by request'
}

# --------------------------------------------- 5b. front-end model readers
#
# bridge.js is the riskiest file in the product - it owns every assumption
# about IBM's DOM and REST shapes - and until now nothing tested it. These run
# against real payloads captured from the live server.
#
# findings.js is the second front-end file with a gate, and for a different
# reason: it decides severity order, filtering and counting for BOTH the docked
# panel and the whole-application review, so a mistake there is wrong twice and
# in public. Its severity order has to agree with Rule.severityRank.
#
# Node is NOT a build requirement. If it is absent the build says so and
# carries on, because the Java gates are what protect the deployed artifact and
# refusing to build on a machine without Node would be a worse trade.
if (-not $SkipTests) {
    Step '5b. Front-end model readers'
    $node = Get-Command node -ErrorAction SilentlyContinue
    $jsTests = @('test\bridge-model.test.js', 'test\findings.test.js')
    if (-not $node) {
        Info 'node not found - front-end tests skipped (Java gates unaffected)'
    } else {
        foreach ($rel in $jsTests) {
            $jsTest = Join-Path $root $rel
            if (-not (Test-Path $jsTest)) {
                Info "$rel not found, skipped"
                continue
            }
            $jsOut = & $node.Source $jsTest 2>&1
            if ($LASTEXITCODE -ne 0) {
                $jsOut | Where-Object { $_ -match '\[FAIL\]' } | ForEach-Object {
                    Write-Host "  $_" -ForegroundColor Red
                }
                Die "$rel failed"
            }
            Ok ("$rel  " + ($jsOut | Select-Object -Last 1).ToString().Trim())
        }
    }
}

# ------------------------------------------------- 5. refresh the exploded WAR
Step '6. Refresh WAR classes'
$target = Join-Path $war 'WEB-INF\classes\com\bawassistant'
New-Item -ItemType Directory -Path $target -Force | Out-Null

# Fingerprint what is already in the WAR, so the closing message can tell the
# truth about whether a Java change actually needs shipping. Without this the
# build told everyone to run deploy-assistant.ps1 "because Java classes
# changed" on every single build, including builds where they had not.
$before = @{}
Get-ChildItem $target -Filter *.class | ForEach-Object {
    $before[$_.Name] = (Get-FileHash $_.FullName -Algorithm MD5).Hash
}

Get-ChildItem $target -Filter *.class | Remove-Item -Force
# The test harness is not part of the product.
Get-ChildItem (Join-Path $classes 'com\bawassistant') -Filter *.class |
    Where-Object { $_.Name -notmatch '^(SelfTest|Emit|Verify|Corpus)' } |
    ForEach-Object { Copy-Item $_.FullName (Join-Path $target $_.Name) -Force }

$after = @{}
Get-ChildItem $target -Filter *.class | ForEach-Object {
    $after[$_.Name] = (Get-FileHash $_.FullName -Algorithm MD5).Hash
}
$javaChanged = $false
if ($before.Count -ne $after.Count) { $javaChanged = $true }
else {
    foreach ($k in $after.Keys) {
        if (-not $before.ContainsKey($k) -or $before[$k] -ne $after[$k]) {
            $javaChanged = $true; break
        }
    }
}
Ok "$($after.Count) classes copied into the WAR"

# The build stamp. /api/status echoes this back, which turns "is my fix
# actually live?" into one curl instead of comparing file timestamps under
# installedApps. A probe once raced an application restart and reported a
# working fix as broken; this is the cheap check that would have caught it.
$buildId = Get-Date -Format 'yyyyMMdd-HHmmss'
$builtAt = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
@("# Written by build.ps1. Not source - see .gitignore.",
  "buildId=$buildId",
  "built=$builtAt") -join "`r`n" |
    Out-File -FilePath (Join-Path $target 'build-info.properties') `
             -Encoding ascii -Force
Ok "build stamp $buildId"

# ------------------------------------------------------------- 6. package
Step '7. Package'
$stage = Join-Path $work 'stage'
New-Item -ItemType Directory -Path (Join-Path $stage 'META-INF') -Force | Out-Null

Push-Location $war
& $jar cf (Join-Path $stage 'BawAssistant.war') .
Pop-Location
if ($LASTEXITCODE -ne 0) { Die "could not build the WAR" }

Copy-Item (Join-Path $ear 'META-INF\application.xml') (Join-Path $stage 'META-INF\') -Force

$out = Join-Path $root 'BawAssistantEAR-deploy.ear'
Push-Location $stage
& $jar cf $out BawAssistant.war META-INF
Pop-Location
if ($LASTEXITCODE -ne 0) { Die "could not build the EAR" }

$size = (Get-Item $out).Length
$ruleDoc = Get-Content $rules -Raw | ConvertFrom-Json
$active = @($ruleDoc.rules | Where-Object { $_.lifecycle -ne 'draft' }).Count
$draft  = @($ruleDoc.rules | Where-Object { $_.lifecycle -eq 'draft' }).Count

Ok "BawAssistantEAR-deploy.ear  $size bytes"

Write-Host "`nBuilt." -ForegroundColor Cyan
Write-Host "  rules      $($ruleDoc.rules.Count)  ($active active, $draft draft)"
Write-Host "  build      $buildId"
Write-Host "  artifact   $out"

# Say what this build actually needs, rather than one fixed sentence.
#
# The old message always told the user to run deploy-assistant.ps1 AND claimed
# Java classes had changed. That script copies an explicit file list which has
# never included WEB-INF\classes, so following the instruction after a Java
# change restarted the OLD classes and the fix silently did not ship.
Write-Host "`nNext:" -ForegroundColor Cyan
if ($javaChanged) {
    Write-Host "  Java classes CHANGED in this build." -ForegroundColor Yellow
    Write-Host "  deploy-assistant.ps1 cannot ship them - it copies static files only."
    Write-Host "  Use the admin console (this is also the only way to ship WEB-INF\web.xml):"
    Write-Host "    Applications -> WebSphere enterprise applications -> BawAssistant"
    Write-Host "    -> Update -> Replace the entire application -> $([IO.Path]::GetFileName($out))"
    Write-Host "    -> Save -> synchronise nodes -> Start"
    Write-Host "  Then confirm the running build with:"
    Write-Host "    curl -sk -u admin:admin https://localhost:9443/assistant/api/status"
    Write-Host "    it must report build.id = $buildId" -ForegroundColor Yellow
} else {
    Write-Host "  No Java change in this build - static files only."
    Write-Host "  An ELEVATED shell can copy them straight into the node:"
    Write-Host "    powershell -ExecutionPolicy Bypass -File .\deploy-assistant.ps1"
    Write-Host "  A hard browser refresh is enough afterwards; no Stop/Start needed."
}

tw.local.sendWorkflow = 'N';

if(tw.local.policyToProcess.policyDetail.reinsured != 'N'
    && tw.local.policyToProcess.policyDetail.reinsuranceCreated == 'Y'
    && tw.local.policyToProcess.policyClaimStatus == 'Deny - Closed'){
        tw.local.sendWorkflow = 'Y';
    }
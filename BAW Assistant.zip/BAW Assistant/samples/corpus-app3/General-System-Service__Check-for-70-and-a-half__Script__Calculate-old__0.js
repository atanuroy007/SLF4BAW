if (tw.local.dateOfBirth != null){
   
       // prep
       
       var inDOB = new Date(tw.local.dateOfBirth.getFullYear()
                    ,tw.local.dateOfBirth.getMonth()
                    ,tw.local.dateOfBirth.getDate());
       var birthDate = new Date(inDOB);
       
       var today = new tw.object.Date();
             
       var revisedBirthMonth = 0;
       var revisedBirthYear = 0;
       var actualAge = 0;

       //calculate actual age
       actualAge = today.getFullYear() - birthDate.getFullYear();
             
       if (birthDate.getMonth() > today.getMonth()){
           actualAge--;
             
       }
       else {
           if (birthDate.getMonth() == today.getMonth()){
               if (birthDate.getDate() > today.getDate()){
                   actualAge--;   
                                     
               }              
           }
       }
       //assign value for actual age to BPM Variable
       if(actualAge<0){
           actualAge = 0;
       }
       tw.local.currentAge = actualAge;
       
       
       
       
       
       
       
       var actualMonths = 0;
       actualMonths = today.getMonth() - birthDate.getMonth();
       
       if(birthDate.getMonth() > today.getMonth()){
           actualMonths = 0;
       }
       else{
     //      if(birthDate.getMonth() == today.getMonth()){
               if(birthDate.getDate() > today.getDate()){
                   actualMonths--;
               }
      //     }
       }
       if(actualMonths < 0){
           actualMonths = 0;
       }
       tw.local.ageMonths = actualMonths;
}
var dateOfDeathMet = 'N';
var deathYear = tw.local.dateOfDeath.getFullYear();

if(tw.local.currentAge > 69 && tw.local.ageMonths > 5 && dateOfDeathMet == 'Y'){
    tw.local.yesNo = 'Y';
} else {
    tw.local.yesNo = 'N';
}
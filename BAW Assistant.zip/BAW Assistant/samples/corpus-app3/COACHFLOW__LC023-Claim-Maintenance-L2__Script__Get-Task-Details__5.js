//Get Instance ID
if (!!tw.system.processInstance) {
    var task = tw.system.processInstance.task;
    if (!!task) {

        var instance = tw.system.processInstance;
        if (!!instance) {
            var process = instance.process;
            tw.local.bpdInstanceID = instance.id;
        }
    }
}

//Config
tw.local.labelWidth = "150px";
tw.local.lockedByClaims = [];
tw.local.banUCAvars = {};
tw.local.banUCAvars.date = new Date();
tw.local.banUCAvars.lanID = tw.system.user.name;
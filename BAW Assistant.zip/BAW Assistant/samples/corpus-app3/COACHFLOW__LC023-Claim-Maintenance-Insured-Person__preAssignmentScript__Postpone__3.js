if(tw.system.currentTask != null){
    tw.system.currentTask.reassignTo(tw.system.org.team.PG_LC_Maintenance);
}
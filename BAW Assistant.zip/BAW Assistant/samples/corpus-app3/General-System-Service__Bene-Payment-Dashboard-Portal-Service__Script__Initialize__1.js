tw.local.currentPolicyToProcess = new tw.object.PolicyToProcess();
/*
tw.local.interestCalculation = new tw.object.InterestCalculation();
tw.local.interestCalculationHTML = '';
tw.local.breakdownHTML = '';
tw.local.interestToPayRule = '';
*/
//tw.local.beneficiaryPayment = new tw.object.BeneficiaryPayment();

/*
tw.local.deathBenefitBeneficiary = new tw.object.DeathBenefit();
tw.local.deathBenefitBeneficiary.credits = new tw.object.Credits();
tw.local.deathBenefitBeneficiary.debits = new tw.object.Debits();
tw.local.deathBenefitBeneficiary.credits.faceAmount = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.paidUpAdditions = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.corridorAmount = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.optionBCD = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.premiumRefund = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.accumulatedDividends = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.dividendsOnDeposits = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.dividendsOnDepositInterest = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.proratedDividends = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.terminationDividends = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.oneYearTermCoverage = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.termRiderOnBaseInsured = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.termRiderOnOthers = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.childrensRider = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.credits.manuallyField = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.debits.loanPrincipal = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.debits.loanInterest = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.debits.premiumDue = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.debits.lienPrincipal = new tw.object.DeathBenefitEntry();
tw.local.deathBenefitBeneficiary.debits.lienInterest = new tw.object.DeathBenefitEntry();
*/

//tw.local.currentBeneficiary = new tw.object.BeneficiaryDetail();
//tw.local.currentBeneficiary.address = new tw.object.listOf.Address();
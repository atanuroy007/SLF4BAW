
if ( tw.local.approvalCriteria.listLength > 0 ) {
    for ( var idx = 0 ; idx < tw.local.approvalCriteria.listLength ; idx++ ) {
            if ( tw.local.payTaskData[tw.local.counter].value == tw.local.approvalCriteria[idx].beneficiary_Death_Benefit_Id ) {
                if ( tw.local.approvalCriteria[idx].type_Of_Processer == "A" ) {                          
                    tw.local.idListApprovers[tw.local.idListApprovers.listLength] = new tw.object.NameValuePair();
                    tw.local.idListApprovers[tw.local.idListApprovers.listLength-1].name = tw.local.payTaskData[tw.local.counter].name;
                    tw.local.idListApprovers[tw.local.idListApprovers.listLength-1].value = tw.local.payTaskData[tw.local.counter].value;                    
                    tw.local.payTaskData.removeIndex(tw.local.counter);
                    tw.local.counter--; 
                    //Row located ... no need to keep looping
                    break;
                }                 
            }                     
    }                                
}

if (tw.local.counter < -1){
    tw.local.counter = 0; 
} else {
    tw.local.counter++; 
}
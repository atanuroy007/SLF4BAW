if (tw.local.statusMessage.indexOf('Record updated')  > 1) {
	tw.local.panelApplyUpdateLabel = "";
}
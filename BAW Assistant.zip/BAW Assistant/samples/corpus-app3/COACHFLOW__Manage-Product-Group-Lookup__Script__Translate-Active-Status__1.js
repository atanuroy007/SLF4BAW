//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};

// Translate active status
if (tw.local.activeStatus == true) {
	tw.local.productGroup.activeInd = 'Y';
} else {
	tw.local.productGroup.activeInd = 'N';
}
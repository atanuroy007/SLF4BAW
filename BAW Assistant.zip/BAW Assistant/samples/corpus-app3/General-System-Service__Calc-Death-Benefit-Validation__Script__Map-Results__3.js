var errorRequest = 'Enter a value';
tw.local.validationMessage = '';
var cdbValidationMessage = '';

var deceasedIs = '';
var policyNo = '';
var policyType = '';


for(var i=0; i < tw.local.results[0].rows.listLength; i++) {
    policyNo = tw.local.results[0].rows[i].indexedMap['CONTRACT_NO'];
	policyType = tw.local.results[0].rows[i].indexedMap['POLICY_TYPE'];
	if(policyType == 'IND ANNUITY'){
            deceasedIs = tw.local.results[0].rows[i].indexedMap['DEATH_OF_ANNUITY'];
        } else {
            deceasedIs = tw.local.results[0].rows[i].indexedMap['DECEASED_NOT_BASE_INSURED_IND'];
	} 
}


if(!(deceasedIs != null && deceasedIs.length > 0)){
            var field = '';
            if(policyType == 'IND ANNUITY'){
                field = 'Death Of';
            } else {
                field = 'Deceased Is';
            }
            cdbValidationMessage = cdbValidationMessage + '<br> POLICY #' + policyNo + ' - ' + field + ': ' + errorRequest;
        }

if(cdbValidationMessage != null && cdbValidationMessage.length > 0){
    tw.local.validationMessage = cdbValidationMessage;
}
tw.local.counter = 0;
tw.local.hasContestable=false;
tw.local.hasCreditor=false;
tw.local.hasSpecialHandlingBasedInsured=false;
tw.local.hasSpecialHandlingOtherInsured=false;

// This determines display of the claims questions if certain policy condition questions are met.
for(var i = 0; i < tw.local.policyToProcessList.listLength; i++) {
    if (tw.local.policyToProcessList[i].policyQuestions.creditorAssignment=="Y")
        tw.local.hasCreditor=true;
    if (tw.local.policyToProcessList[i].policyQuestions.contestable=="Y")
        tw.local.hasContestable=true;
    if (tw.local.policyToProcessList[i].policyQuestions.deceasedIsNotInsured == "B" 
            && tw.local.policyToProcessList[i].policyQuestions.otherInsuredIsDeceased == "Y") {
         tw.local.hasSpecialHandlingBasedInsured = true;       
     }
    if (tw.local.policyToProcessList[i].policyQuestions.deceasedIsNotInsured == "O" 
            || tw.local.policyToProcessList[i].policyQuestions.otherInsuredIsDeceased == "Y") {
         tw.local.hasSpecialHandlingOtherInsured= true;       
     }
} 
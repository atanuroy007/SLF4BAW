var answer = '';
for(var i=0; i < tw.local.results[0].rows.listLength; i++) {
/*
    var indicator = tw.local.results[0].rows[i].indexedMap['CLAIM_WITNESSED_BY_AGENT_IND'];
    if(indicator == null || indicator.toString().length < 1){
        var beneName = tw.local.results[0].rows[i].indexedMap['CLIENT_NAME_TEXT'];
        answer = answer + '<br> Beneficiary ' + beneName + ' - Claim Form Notarized/Witnessed: Please enter a value' ;
    }
*/
}
if(answer != null && answer.length > 0){
    answer = '<br> <u>Beneficiary Level:</u>' + answer;
}
tw.local.result = answer;
//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};
 function validateSSN (elementValue){
       var  ssnPattern = /^[0-9]{3}\-?[0-9]{2}\-?[0-9]{4}$/;
       return ssnPattern.test(elementValue);
}
   
tw.local.canProceed = true;
if (tw.local.claimNumber.length == 0 &&    tw.local.deceasedName.length == 0 &&    tw.local.deceasedSSN.length == 0 &&    tw.local.policyNumber.length == 0 &&    tw.local.instanceID.length == 0) {
    tw.system.coachValidation.addValidationError ("tw.local.claimNumber", "You need to search for something!  Please enter a claim number.");
    tw.local.canProceed = false;
} else {
	if(tw.local.deceasedSSN.length > 0){
		if(validateSSN(tw.local.deceasedSSN) == false) {
		tw.system.coachValidation.addValidationError ("tw.local.deceasedSSN", "Please enter SSN in the correct format.");	
		tw.local.canProceed = false;
		}	
	}
}
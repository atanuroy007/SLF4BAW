//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};

if (tw.local.deceasedName !== null && tw.local.deceasedName !== '') {
        if (tw.local.deceasedName.indexOf(" ") > 0) {
            tw.local.name0 = tw.local.deceasedName.split(" ")[0];
            tw.local.name1 = tw.local.deceasedName.split(" ")[1];
            tw.local.name2 = tw.local.deceasedName.split(" ")[2];
        }
    }
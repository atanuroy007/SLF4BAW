tw.local.parameterList = new tw.object.listOf.SQLParameter();
/*
CLAIM_NO
, CLAIM_STATUS
, ASSIGNED_REP_LAN_ID
FROM BPMLIFECLAIMS.CLAIM WHERE
CLAIM_ID = ?
*/

//1 CLAIM_ID
var param = new tw.object.SQLParameter();
param.value = tw.local.policyID;
param.type = 'INTEGER';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

//2 ACTIVE_IND
var param = new tw.object.SQLParameter();
param.value = '1';
param.type = 'VARCHAR(1)';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

tw.local.reinsuranceData = new tw.object.ReinsuranceData();
tw.local.reinsuranceData.claimID = tw.local.claimID;
tw.local.reinsuranceData.policyID = tw.local.policyToProcess.policyId;
tw.local.reinsuranceData.typeOfTask = 'Pay';
tw.local.reinsuranceData.instanceID = tw.system.currentProcessInstanceID;
var holdBAN = tw.local.bankAccountNumber;
if ((tw.local.message == "Tokenize Successful!")  || (tw.local.message == "Found existing token")) {
    tw.local.bankAccountNumber = tw.local.token;
}
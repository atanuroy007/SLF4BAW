tw.local.parameterList = new tw.object.listOf.SQLParameter();
//1 CLAIM_ID
var param = new tw.object.SQLParameter();
param.value = tw.local.claimID;
param.type = 'INTEGER';
tw.local.parameterList[tw.local.parameterList.listLength] = param;
//1 ACTIVE_IND
var param = new tw.object.SQLParameter();
param.value = 'Y'
param.type = 'VARCHAR(1)';
tw.local.parameterList[tw.local.parameterList.listLength] = param;
//RELATIONSHIP_TYPE_IND
var param = new tw.object.SQLParameter();
param.value = 'O'
param.type = 'VARCHAR(1)';
tw.local.parameterList[tw.local.parameterList.listLength] = param;
//P.POLICY_ID
var param = new tw.object.SQLParameter();
param.value = tw.local.policyID;
param.type = 'INTEGER';
tw.local.parameterList[tw.local.parameterList.listLength] = param;
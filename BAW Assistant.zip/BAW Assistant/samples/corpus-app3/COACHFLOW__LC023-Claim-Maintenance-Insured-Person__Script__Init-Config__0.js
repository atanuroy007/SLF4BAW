//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};
//Get Instance ID
if (!!tw.system.processInstance) {
    var task = tw.system.processInstance.task;
    if (!!task) {
    	  tw.local.taskId = task.id;
        var instance = tw.system.processInstance;
        if (!!instance) {
            var process = instance.process;
            tw.local.bpdInstanceID = instance.id;
        }
    }
}
//Config
tw.local.cnfgLabelWidth = "150px";
tw.local.hasValidationErrors = "";
tw.local.statusMessage = "";
tw.local.panelApplyUpdateLabel = "Apply Update";
tw.local.lockedClaimBy = 'LC023 Claim Maintenance Insured Record,'+tw.local.bpdInstanceID+','+tw.local.taskId+','+tw.system.user.fullName;
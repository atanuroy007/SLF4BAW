var outputMappingData = tw.local.referenceNumber + tw.local.success + tw.local.error + tw.local.message;
if(tw.system.currentProcessInstanceID != null && tw.system.currentProcessInstanceID.length > 0){
    log.info(tw.system.model.processApp.acronym + " - " 
           + tw.system.currentTask.processActivityName
           + " - Check BAN Token > Validate Token (POST) - Instance Id# - " 
           + tw.system.currentProcessInstanceID
           + " - omd - " + outputMappingData);
} else {
    log.info("Check BAN Token > Validate Token (POST) - omd - " + outputMappingData);
}
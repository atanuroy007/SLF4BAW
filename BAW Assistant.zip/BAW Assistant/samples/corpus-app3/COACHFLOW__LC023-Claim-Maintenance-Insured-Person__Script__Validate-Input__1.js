//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};
tw.local.hasValidationErrors = "N"; 	// Set to N [No] unless the data fails a validation test
//Is the field blank?
if (tw.local.claimMainInsPerson.ipn.length == 0) {
    	tw.local.hasValidationErrors = "Y";
    		tw.system.coachValidation.addValidationError ("tw.local.claimMainInsPerson.ipn", "This input is required.");
}			
// Did the data change?
if (tw.local.claimMainInsPerson.ipn == tw.local.hldClaimMainInsPerson.ipn) {
      tw.local.hasValidationErrors = "Y";
	tw.system.coachValidation.addValidationError ("tw.local.claimMainInsPerson.ipn", "The data entered didnot change.  Please confirmed entered data or click the Back button.");
}
tw.local.approveActivity = "N";
tw.local.isReadOnly = "";
tw.local.uiMessage = "";
// Get current user id
tw.local.currentUserId = tw.system.user_loginName;
if (tw.local.currentUserId == null){
    tw.local.currentUserId = "";
}    
// Get Activity Name
if(tw.system.currentTask != null){
    tw.local.activityName = tw.system.currentTask.processActivityName;
}
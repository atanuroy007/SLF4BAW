tw.local.policyNumberGuarMinD = {};
tw.local.policyNumberGuarMinD.CompanyCode = "UA1";
tw.local.policyNumberGuarMinD.PolicyNumber = "F1000476AA";
tw.local.policyNumberGuarMinD.PolicyProcThru = "2020-01-26";
tw.local.policyNumberGuarMinD.PolicyProcTime = "";
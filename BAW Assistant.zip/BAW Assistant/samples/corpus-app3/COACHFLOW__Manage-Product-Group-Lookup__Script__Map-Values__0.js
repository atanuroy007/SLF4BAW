//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};

tw.local.selectedIndex = tw.local.productGroups.listAllSelectedIndices[0];
tw.local.productGroup = tw.local.productGroups[tw.local.selectedIndex];

// Translate active indicator
if (tw.local.productGroup.activeInd == 'Y') {
	tw.local.activeStatus = true;
} else {
	tw.local.activeStatus = false;
}
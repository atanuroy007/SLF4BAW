tw.local.parameterList = new tw.object.listOf.SQLParameter();
/*
OPTION_CATEGORY
, OPTION_NAME
, OPTION_VALUE
, ACTIVE_IND
, CREATED_DATE
, CREATED_BY
, OPTION_LOOKUP_ID
*/
// OPTION_CATEGORY
var param = new tw.object.SQLParameter();
param.value = tw.local.category
param.type = 'VARCHAR';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

// OPTION_NAME
var param = new tw.object.SQLParameter();
param.value = tw.local.optionList[tw.local.counter].name;
param.type = 'VARCHAR';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

// OPTION_VALUE
var param = new tw.object.SQLParameter();
param.value = tw.local.optionList[tw.local.counter].value;
param.type = 'VARCHAR';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

// ACTIVE_IND
var param = new tw.object.SQLParameter();
param.value = 'Y';
param.type = 'VARCHAR';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

// CREATED_DATE
var param = new tw.object.SQLParameter();
param.value = new TWDate();
param.type = 'DATE';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

// CREATED_BY
var param = new tw.object.SQLParameter();
param.value = tw.system.user_loginName;
param.type = 'VARCHAR';
tw.local.parameterList[tw.local.parameterList.listLength] = param;

// OPTION_LOOKUP_ID
var param = new tw.object.SQLParameter();
param.value = tw.local.optionID;
param.type = 'INTEGER';
tw.local.parameterList[tw.local.parameterList.listLength] = param;
//  This JavaScript will run within the browser and must use the client-side JavaScript syntax supported by the browser. For example,
//	      - To instantiate a complex object:					- To instantiate a list:
//				tw.local.customer = {};								tw.local.addresses = [];
//				tw.local.customer.name = "Jane";				tw.local.addresses[0] = {};

// Validate Legacy Company
if (tw.local.productGroup.legacyCompany.length > 4) {
	var message = "The value entered is too long. Please enter a value that is 4 characters or less.";
	tw.system.coachValidation.addValidationError ("tw.local.productGroup.legacyCompany", message);
}

// Validate Company Code
if (tw.local.productGroup.companyCode.length > 3) {
	var message = "The value entered is too long. Please enter a value that is 3 characters or less.";
	tw.system.coachValidation.addValidationError ("tw.local.productGroup.companyCode", message);
}

// Validate Business Unit
if (tw.local.productGroup.businessUnit.length > 5) {
	var message = "The value entered is too long. Please enter a value that is 5 characters or less.";
	tw.system.coachValidation.addValidationError ("tw.local.productGroup.businessUnit", message);
}

// Validate Lob Code
if (tw.local.productGroup.lobCode.length > 20) {
	var message = "The value entered is too long. Please enter a value that is 20 characters or less.";
	tw.system.coachValidation.addValidationError ("tw.local.productGroup.lobCode", message);
}

// Validate Product Group
if (tw.local.productGroup.productGroup.length > 5) {
	var message = "The value entered is too long. Please enter a value that is 5 characters or less.";
	tw.system.coachValidation.addValidationError ("tw.local.productGroup.productGroup", message);
}

// Validate Description
if (tw.local.productGroup.description.length > 50) {
	var message = "The value entered is too long. Please enter a value that is 50 characters or less.";
	tw.system.coachValidation.addValidationError ("tw.local.productGroup.description", message);
}
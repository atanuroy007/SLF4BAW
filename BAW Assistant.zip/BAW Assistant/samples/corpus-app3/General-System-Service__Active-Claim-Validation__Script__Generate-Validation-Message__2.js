var errorRequest = 'Enter a value';
var finalValidation = '';
var claimValidation = '';
//AW: Check Claim validations
if(tw.local.mismatchList != null && tw.local.mismatchList.listLength > 0 && tw.local.claim != null && tw.local.claim.insuredDataMismatchVerified != 'Y'){
    claimValidation = claimValidation + '<br> Insured Data Mismatch Verified: ' + errorRequest;
}
// D20170301 PILOT-0016 MULTIPLE HITS ON CLIENT
if(tw.local.claim.multipleHitsClientInd == 'Y' && tw.local.claim.multipleHitsClientVerifiedInd != 'Y'){
    claimValidation = claimValidation + '<br> Multiple Hits On Client: ' + errorRequest;
}
//AW: Generate final validation message
if(claimValidation == null){
    claimValidation = '';
}
if(tw.local.validationMessage == null){
    tw.local.validationMessage = '';
}
if(claimValidation.length > 0){
    claimValidation = '<br> <u>Claim Level:</u>' + claimValidation;
}
if(tw.local.validationMessage.length > 0){
    tw.local.validationMessage = '<br> <u>Policy Level:</u>' + tw.local.validationMessage;
}
if(claimValidation.length > 0 || tw.local.validationMessage.length > 0){
    finalValidation = '<p class="redText"><strong>Active Claim Validation Error(s):</strong><br><i>**The Status was not accepted due to the following errors:</i>' + claimValidation + tw.local.validationMessage + '</p>';
}
tw.local.validationMessage = finalValidation;

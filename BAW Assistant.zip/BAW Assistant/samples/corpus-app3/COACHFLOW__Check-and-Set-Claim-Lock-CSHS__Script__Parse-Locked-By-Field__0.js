var lockedBySplit = tw.local.claimLockedBy.split(',');
tw.local.coachName = lockedBySplit[0];
tw.local.instanceID = lockedBySplit[1];
tw.local.taskID = lockedBySplit[2];
tw.local.userID = lockedBySplit[3];
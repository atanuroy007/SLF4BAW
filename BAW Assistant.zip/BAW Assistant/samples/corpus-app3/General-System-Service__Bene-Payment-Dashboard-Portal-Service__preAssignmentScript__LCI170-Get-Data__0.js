//tw.local.instanceID = tw.system.currentProcessInstanceID;
//if(tw.local.instanceID == null){
//    tw.local.instanceID = 0;
//}
tw.local.currentPolicyToProcess = new tw.object.PolicyToProcess();
tw.local.claimID = 0;
tw.local.selectedIndex = tw.local.claimSearchList.listAllSelectedIndices[0];
if (tw.local.selectedIndex > -1) {
    tw.local.claimID = tw.local.claimSearchList[tw.local.selectedIndex].claimID;	
} else {
	tw.local.infoMessage = '<p style="color:red"><em>Please make a selection.</em></p>';
}
tw.local.counter = 0;
if(tw.local.payTaskData != null){
    tw.local.idListApprovers = new tw.object.listOf.NameValuePair();
}
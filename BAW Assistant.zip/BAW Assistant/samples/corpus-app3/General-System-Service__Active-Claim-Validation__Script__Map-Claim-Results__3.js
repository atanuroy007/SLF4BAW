var errorRequest = 'Enter a value';
tw.local.validationMessage = '';
var activeValidationMessage = '';
var currentPolicyNumber = '';
if(tw.local.currentPolicyToProcess != null){
    currentPolicyNumber = tw.local.currentPolicyToProcess.policyNumber;
}
//AW: Check Policy Validations
for(var i=0; i < tw.local.results[0].rows.listLength; i++) {
    var policyNo = '';
    if(tw.local.currentPolicyToProcess != null){
        policyNo = tw.local.results[0].rows[i].indexedMap['CONTRACT_NO'];
    }
    var deceasedIs = '';
    var policySystem = '';
    var policyType = '';
    var dataSource = '';
    if(policyNo != currentPolicyNumber){
        policySystem = tw.local.results[0].rows[i].indexedMap['POLICY_SYSTEM'];
        policyType = tw.local.results[0].rows[i].indexedMap['POLICY_TYPE'];
        dataSource = tw.local.results[0].rows[i].indexedMap['DATA_SOURCE'];
        if(policyType == 'IND ANNUITY'){
            deceasedIs = tw.local.results[0].rows[i].indexedMap['DEATH_OF_ANNUITY'];
        } else {
            deceasedIs = tw.local.results[0].rows[i].indexedMap['DECEASED_NOT_BASE_INSURED_IND'];
        }
    } else {
        policySystem = tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.policySystem;
        policyType = tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.policyType;
        if(policyType == 'IND ANNUITY'){
            deceasedIs = tw.local.currentPolicyToProcess.policyDetail.annuityDetail.deathOf;
        } else {
            deceasedIs = tw.local.currentPolicyToProcess.policyQuestions.deceasedIsNotInsured;
        }
        dataSource = tw.local.currentPolicyToProcess.dataSource;
    }
    if(policySystem == null){
        policySystem = '';
    }
    if(policySystem == null || policySystem.length < 1){
        activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Policy System: ' + errorRequest;
    }
    if(policyNo != currentPolicyNumber){
        //AW: We are checking the database
        if(!(checkVal(tw.local.results[0].rows[i].indexedMap['CURRENT_COMPANY']))){
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Current Company: ' + errorRequest;
        }
        if(!(checkVal(tw.local.results[0].rows[i].indexedMap['INSURED_STATE']))){
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Insured State: ' + errorRequest;
        }
        if(dataSource == 'M' && !(checkVal(tw.local.results[0].rows[i].indexedMap['ISSUE_STATE']))){
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Issue State: ' + errorRequest;
        }
        if(dataSource == 'M' && !(checkVal(tw.local.results[0].rows[i].indexedMap['OWNER_STATE']))){
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Owner State: ' + errorRequest;
        }
        if(dataSource == 'M' && !(checkVal(tw.local.results[0].rows[i].indexedMap['REPORTING_STATE']))){
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Reporting State: ' + errorRequest;
        }
        if(!(deceasedIs != null && deceasedIs.length > 0)){
            var field = '';
            if(policyType == 'IND ANNUITY'){
                field = 'Death Of';
            } else {
                field = 'Deceased Is';
            }
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + tw.local.results[0].rows[i].indexedMap['CONTRACT_NO'] + ' - ' + field + ': ' + errorRequest;
        }
        if(!(checkVal(tw.local.results[0].rows[i].indexedMap['DEATH_BENEFIT']))){
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Death Benefit Amount: Use the Death Benefit button to enter an amount';
        }
         
            
    } else {
        //AW: We are checking the current policy object (not database)
        //policyNo is equal to currentPolicyNumber
        if(tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail == null || tw.local.currentPolicyToProcess.policyDetail.policySystem == null || tw.local.currentPolicyToProcess.policyDetail.policySystem.length < 1){
            //AW: We are checking if the system value is null
            if(tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.policySystem == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.policySystem.length < 1){
                //AW: We are checking if the override value is null
                activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Policy System: ' + errorRequest;
            }
        }
        if(tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride == null || (!(checkVal(tw.local.currentPolicyToProcess.currentCompany)) && !(checkVal(tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.currentCompany)) && !(checkVal(tw.local.currentPolicyToProcess.policyDetail.currentCompany)))){
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Current Company: ' + errorRequest;
        }
        if(tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.insuredState == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.insuredState.length < 1){
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Insured State: ' + errorRequest;
        }
        if(tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.deathBenefitAmount == null || tw.local.currentPolicyToProcess.deathBenefitAmount < 0.01){
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Death Benefit Amount: Use the Death Benefit button to enter an amount';
        }
        if(tw.local.currentPolicyToProcess.dataSource == 'M' && (tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.issueState == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.issueState.length < 1)){
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Issue State: ' + errorRequest;
        }
        if(tw.local.currentPolicyToProcess.dataSource == 'M' && (tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.ownerState == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.ownerState.length < 1)){
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Owner State: ' + errorRequest;
        }
        if(tw.local.currentPolicyToProcess.dataSource == 'M' && (tw.local.currentPolicyToProcess == null || tw.local.currentPolicyToProcess.policyDetail == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.reportingState == null || tw.local.currentPolicyToProcess.policyDetail.policyDetailsOverride.reportingState.length < 1)){
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - Reporting State: ' + errorRequest;
        }
        if(!(deceasedIs != null && deceasedIs.length > 0)){
            var field = '';
            if(policyType == 'IND ANNUITY'){
                field = 'Death Of';
            } else {
                field = 'Deceased Is';
            }
            activeValidationMessage = activeValidationMessage + '<br> POLICY #' + policyNo + ' - ' + field + ': ' + errorRequest;
        }
    }
}
if(activeValidationMessage != null && activeValidationMessage.length > 0){
    tw.local.validationMessage = activeValidationMessage;
}

function checkVal(val){
//length
    if(val == null || val.toString() == null || val.toString().length < 1){
        return false;
    } else {
        return true;
    }
}
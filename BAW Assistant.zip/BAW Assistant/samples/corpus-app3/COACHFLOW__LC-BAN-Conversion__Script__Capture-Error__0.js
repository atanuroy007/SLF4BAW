tw.local.errorMessage = tw.error.data;
tw.local.serviceName = "LC Ban Conversion L1";
tw.local.dashboardPortalBP = new tw.object.DashboardPortalBenePayment();

tw.local.dashboardPortalBP.lifeClaimPolicyNumber = tw.local.currentPolicyToProcess.policyNumber;

if(tw.system.currentTask != null){
    tw.local.dashboardPortalBP.instanceID = tw.system.currentProcessInstanceID;   
}

try{
//tw.local.dashboardPortalBP.instanceID = tw.system.currentProcessInstance.id.split(".")[1];
tw.local.dashboardPortalBP.lifeClaimBeneFullName = tw.local.currentBeneficiaryAssignment.name;
//log.error('currentBeneficiaryAssignment.NAME - ' + tw.local.dashboardPortalBP.lifeClaimBeneFullName);
} catch (e) {
}

tw.local.dashboardPortalBP.lifeClaimAssignedRepName = tw.local.claim.assignedRepName;
tw.local.dashboardPortalBP.dashboardPortalBenePaymentComplete = false;
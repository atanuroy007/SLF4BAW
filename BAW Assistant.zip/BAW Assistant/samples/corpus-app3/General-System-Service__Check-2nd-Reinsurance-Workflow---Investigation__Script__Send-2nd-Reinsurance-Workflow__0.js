tw.local.sendWorkflow = 'N';

if(tw.local.policyToProcess.policyDetail.reinsured == 'Y' 
    && tw.local.policyToProcess.policyDetail.investigation.investigationStatus == 'Fees Paid in Full'
    && tw.local.policyToProcess.policyDetail.investigation.investigationStatus != tw.local.priorInvestigationStatus
    && tw.local.policyToProcess.policyClaimStatus == 'Paid in Full'){
        tw.local.sendWorkflow = 'Y';
    }
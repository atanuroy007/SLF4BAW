/*
AW: First we find the date when the deceased would turn 70 and a half
*/

var targetDate = new TWDate();
targetDate.setDate(tw.local.dateOfBirth.getDate());
targetDate.setFullYear(tw.local.dateOfBirth.getFullYear()+70);
targetDate.setMonth(tw.local.dateOfBirth.getMonth()+6);

/*
AW: Then we set the target date as April 2nd of the following year (set as EPVs
note: this is because the phrasing says AFTER April 1st instead of ON OR AFTER
*/
targetDate.setFullYear(targetDate.getFullYear()+1);
targetDate.setDate(2);
targetDate.setMonth(3);

/*
AW: We reset the hours, minutes, seconds, and milliseconds
as we are only concerned with the day, month, and year
*/

tw.local.dateOfDeath.setHours(0);
tw.local.dateOfDeath.setMinutes(0);
tw.local.dateOfDeath.setSeconds(0);
tw.local.dateOfDeath.setMilliseconds(0);
targetDate.setHours(0);
targetDate.setMinutes(0);
targetDate.setSeconds(0);
targetDate.setMilliseconds(0);

/*
If the variance between the date of death and the target date is greater
than or equal to 0, then the deceased has met the criteria for 70 and a half
*/

var variance = tw.local.dateOfDeath - targetDate;

if(variance >= 0){
    tw.local.yesNo = 'Y';
} else {
    tw.local.yesNo = 'N';
}
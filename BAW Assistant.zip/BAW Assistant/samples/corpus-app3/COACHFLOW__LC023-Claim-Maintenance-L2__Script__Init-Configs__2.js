tw.local.claimNumber = '';
tw.local.deceasedName = '';
tw.local.deceasedSSN = '';
tw.local.policyNumber = '';
tw.local.claimSearchList = [];
tw.local.infoMessage = '';
tw.local.cnfgViewEditButton = "R";  // ReadOnly
tw.local.selectedIndex = null;
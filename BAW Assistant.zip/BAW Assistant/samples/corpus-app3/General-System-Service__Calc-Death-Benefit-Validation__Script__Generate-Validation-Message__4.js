var finalValidation = '';

if(tw.local.validationMessage == null){
    tw.local.validationMessage = '';
}
if(tw.local.validationMessage.length > 0){
    tw.local.validationMessage = '<br> <u>Policy Level:</u>' + tw.local.validationMessage;
}

if(tw.local.validationMessage.length > 0){
    finalValidation = '<p class="redText"><strong>Death Benefit Calculation Validation Error:</strong><br><i>**Cannot proceed due to the following error:</i>' +  tw.local.validationMessage + '</p>';
}
tw.local.validationMessage = finalValidation;
tw.local.infoMessage = "";
if (tw.local.claimSearchList.length > 0) {
	tw.local.cnfgViewEditButton = "E"; //Editble
} else {
	tw.local.cnfgViewEditButton = "R"; //ReadOnly
	tw.local.infoMessage = '<p style="color:red"><em>No results found for criteria entered.</em></p>';
}
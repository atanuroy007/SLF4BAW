  if (tw.local.dateOfBirth != null){
   
       // prep
       
       var inDOB = new Date(tw.local.dateOfBirth.getFullYear()
                    ,tw.local.dateOfBirth.getMonth()
                    ,tw.local.dateOfBirth.getDate());
       var birthDate = new Date(inDOB);
       
       var today = new tw.object.Date();
             
       var revisedBirthMonth = 0;
       var revisedBirthYear = 0;
       var actualAge = 0;

       //calculate actual age
       actualAge = today.getFullYear() - birthDate.getFullYear();
             
       if (birthDate.getMonth() > today.getMonth()){
           actualAge--;
             
       }
       else {
           if (birthDate.getMonth() == today.getMonth()){
               if (birthDate.getDate() > today.getDate()){
                   actualAge--;   
                                     
               }              
           }
       }
       //assign value for actual age to BPM Variable
       tw.local.currentAge = actualAge;

   }
//Checks for locked claims and sets a message depending on if it finds locked claims or not.
if(tw.local.lockedByClaims.length != null){
	if(tw.local.lockedByClaims.length > 0){
	tw.local.LockedClaimMessage = "<font color=red><em>Locked Claims have been found, check with Developer(s) or Business SME prior to continuing.</em></font>";
	}else{
	tw.local.LockedClaimMessage = "Unable To Find Any Locked Claims, click the Continue(Override) button.";
	}
}
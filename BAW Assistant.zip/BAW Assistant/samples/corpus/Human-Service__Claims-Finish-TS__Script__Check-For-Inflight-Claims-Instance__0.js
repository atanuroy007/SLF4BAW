tw.local.isClaimsMVP2Instance=true;

tw.local.displayReinsuranceDate=new TWDate();
    tw.local.displayReinsuranceDate.parse(String(tw.epv.reinsuranceVisibility.reinsuranceSectionDate), "yyyy-MM-dd");
    if(tw.system.currentProcessInstance.startDate>tw.local.displayReinsuranceDate){
        tw.local.isClaimsMVP2Instance=false;
    }
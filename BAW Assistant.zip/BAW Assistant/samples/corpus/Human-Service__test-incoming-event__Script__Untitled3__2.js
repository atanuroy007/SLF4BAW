//tw.local.taskName=tw.system.findActivityInstanceByID("2072.58209").id

tw.local.taskCount=tw.system.findProcessInstanceByID("2072.58209").tasks.length;


/*var acp = new tw.object.toolkit.SYSD.ActivityListProperties();
acp.hiddenFilter = ''; // HIDDEN or ''
acp.checkActions = []; // no idea - seems to take any string with no effect
acp.sortCriteria = []; // no idea - some enum of ActivitySortCriteria
acp.filters = [{
        repeatableFilter: 'REPEATABLE',
        requiredFilter: 'REQUIRED',
        optionTypeFilter: ['OPTIONAL', 'REQUIRED'],
        executionTypeFilter: ['AUTOMATIC', 'MANUAL'],
        activityTypeFilter: ['USER_TASK', 'SUB_PROCESS'],
        executionStateFilter: ['COMPLETED','READY', 'WORKING', 'WAITING']
}];

tw.system.findProcessInstanceByID(123).retrieveActivityList(acp, 10, 0, true).activities*/
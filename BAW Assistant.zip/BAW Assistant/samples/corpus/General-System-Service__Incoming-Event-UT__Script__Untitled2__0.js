tw.local.Untitled1=new TWDate();
//tw.local.Untitled1=Date(tw.epv.featureAvailability.reinsuranceSectionDate);

//tw.local.Untitled2=String(tw.epv.featureAvailability.testString);
tw.local.Untitled1.parse(String(tw.epv.featureAvailability.testString), "yyyy-MM-dd");


/*tw.local.Untitled2=String(tw.epv.featureAvailability.reinsuranceSectionDate);
tw.local.Untitled1.parse(tw.local.Untitled2, "yyyy-MM-dd");*/

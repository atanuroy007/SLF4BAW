if (this.validateTooltip != undefined) {
	this.validateTooltip.destroyRecursive();
	delete this.validateTooltip;
}

if (this.onChangeHandle) {
	connect.disconnect(this.onChangeHandle);
}

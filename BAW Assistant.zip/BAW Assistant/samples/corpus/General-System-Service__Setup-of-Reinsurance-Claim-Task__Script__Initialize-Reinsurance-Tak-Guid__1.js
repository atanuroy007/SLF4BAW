/*tw.local.claims.load(tw.local.claims.metadata("key"));
var k=tw.local.claims.reinsurancePoliciesStatus.listLength;
tw.local.claims.reinsurancePoliciesStatus[k]=new tw.object.reinsuranceTaskGuidStatusPair();
tw.local.claims.reinsurancePoliciesStatus[k].taskGuid=tw.local.taskGuid;
tw.local.claims.reinsurancePoliciesStatus[k].status="Started";
tw.local.claims.save();*/

tw.local.claims.reinsuranceGuids[tw.local.claims.reinsuranceGuids.listLength]=tw.local.taskGuid;
tw.local.claims.save();
.policyCell{
    font-size:10pt;
}
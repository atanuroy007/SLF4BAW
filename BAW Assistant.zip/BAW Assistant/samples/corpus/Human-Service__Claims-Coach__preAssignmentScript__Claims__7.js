tw.local.coreButtonData = new tw.object.CoreButtonData();
tw.local.coreButtonVisibility = new tw.object.CoreButtonVisibility();
tw.local.coreButtonVisibility.complete=false;
tw.local.coreButtonData.coreButtonVisibility = tw.local.coreButtonVisibility;
tw.local.coreButtonData.defaultCNDesktopURL = tw.local.docLauncherAutoOpen.defaultCNDesktopURL;
tw.local.approvalButton=false;

tw.local.payButtonData = new tw.object.PayButtonData();
tw.local.payButtonData.defaultCNDesktopURL = tw.local.docLauncherAutoOpen.defaultCNDesktopURL;

//Added for BPM Upgrade fix 10/05/2022
if(tw.local.claimantDetails.listLength == 0){
	tw.local.claimantDetails[0] = new tw.object.claimantDetails();
}
tw.local.reinsuranceClaimDetails.worklistData.primaryPolicyNumber=tw.local.reinsurancePolicyInformation.policyNumber
tw.local.reinsuranceClaimDetails.worklistData.caseCount=1;
if (tw.local.reinsurancePolicyInformation.insuredName[0] != null && tw.local.reinsurancePolicyInformation.insuredName.listLength != null) {
    if (tw.local.reinsurancePolicyInformation.insuredName.listLength > 1){
        tw.local.reinsuranceClaimDetails.worklistData.insuredName =  tw.local.reinsurancePolicyInformation.insuredName[0].name+ " + ";
    }else {
         tw.local.reinsuranceClaimDetails.worklistData.insuredName =  tw.local.reinsurancePolicyInformation.insuredName[0].name;
    } 
}
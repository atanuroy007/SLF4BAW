    tw.local.claims.claimantsDetails=tw.local.claimantDetails;
//    for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++)
//      tw.local.claims.claimantsDetails.listAllSelected=tw.local.claimantDetails.listAllSelected;
    tw.local.claims.save();
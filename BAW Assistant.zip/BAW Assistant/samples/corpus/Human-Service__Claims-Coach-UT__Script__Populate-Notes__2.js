tw.local.notesData = new tw.object.NotesCoachViewData();
tw.local.notes = new tw.object.listOf.Note();
tw.local.notes[0] = new tw.object.Note();
tw.local.notes[0].createdBy = "K253779";
tw.local.notes[0].creationDate = new TWDate();
tw.local.notes[0].text = "WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Returned to WorklisTask Ret";
tw.local.notes[0].fullName = "Hima, Kancheti";

tw.local.notes[1] = new tw.object.Note();
tw.local.notes[1].createdBy = "K253779";
tw.local.notes[1].creationDate = new TWDate();
tw.local.notes[1].text = "More notes";
tw.local.notes[1].fullName = "Hima, Kancheti";

tw.local.notes[2] = new tw.object.Note();
tw.local.notes[2].createdBy = "SYSTEM";
tw.local.notes[2].creationDate = new TWDate();
tw.local.notes[2].text = "Task Returned to Worklist";
tw.local.notes[2].fullName = "SYSTEM";

tw.local.notesData.notes = new tw.object.listOf.NoteRowData();
tw.local.notesData.notes[0] = new tw.object.NoteRowData();
tw.local.notesData.notes[0].noteInfo = tw.local.notes[0].fullName + " (" + tw.local.notes[0].creationDate.format("MM/dd/yy hh:mm a") + "): ";
tw.local.notesData.notes[0].noteText = tw.local.notes[0].text;

tw.local.notesData.notes[1] = new tw.object.NoteRowData();
tw.local.notesData.notes[1].noteInfo = tw.local.notes[1].fullName + " (" + tw.local.notes[1].creationDate.format("MM/dd/yy hh:mm a") + "): ";
tw.local.notesData.notes[1].noteText = tw.local.notes[1].text;

tw.local.notesData.notes[2] = new tw.object.NoteRowData();
tw.local.notesData.notes[2].noteInfo = tw.local.notes[2].fullName + " (" + tw.local.notes[2].creationDate.format("MM/dd/yy hh:mm a") + "): ";
tw.local.notesData.notes[2].noteText = tw.local.notes[2].text;
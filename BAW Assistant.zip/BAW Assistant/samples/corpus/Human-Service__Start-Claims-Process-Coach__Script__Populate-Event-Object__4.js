tw.local.incomingEvent.businessData.cases = new tw.object.listOf.Case();

for(var i=0;i<tw.local.policyList.listLength;i++){
    tw.local.incomingEvent.businessData.cases[i] = new tw.object.Case();
    tw.local.incomingEvent.businessData.cases[i].policyNumber = tw.local.policyList[i];
    tw.local.incomingEvent.businessData.cases[i].proposedInsured = new tw.object.listOf.ProposedInsured();
    tw.local.incomingEvent.businessData.cases[i].proposedInsured[0] = new tw.object.ProposedInsured();
}

tw.local.transactionCode=95;

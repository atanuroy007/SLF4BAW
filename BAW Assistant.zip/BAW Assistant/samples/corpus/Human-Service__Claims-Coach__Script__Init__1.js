tw.local.coachTitle = tw.local.taskName;
tw.local.referalGroups = new  tw.object.listOf.NameValuePair();
tw.local.approvalGroups = new  tw.object.listOf.NameValuePair();
tw.local.approvalSelected = new  tw.object.NameValuePair();
tw.local.referalSelected = new tw.object.NameValuePair();
tw.local.errorMessage="";
tw.local.displayCloseout=false;
    

tw.local.approvalTypes = new tw.object.listOf.String();
tw.local.approvalTypes[0] = "No";
tw.local.approvalTypes[1] = "Yes"; 
tw.local.approvalTypes[2] = "";

tw.local.approvalOptions = new tw.object.listOf.String();
tw.local.approvalOptions[0] = "No";
tw.local.approvalOptions[1] = "Yes"; 
tw.local.approvalOptions[2] = "";

tw.local.yesAndNoOptions = new tw.object.listOf.String();
tw.local.yesAndNoOptions[0] = "No";
tw.local.yesAndNoOptions[1] = "Yes";

if(tw.local.taskName == tw.resource.TaskNames.ClaimsSetUp || tw.local.taskName == tw.resource.TaskNames.ClaimsExamine || tw.local.taskName == tw.resource.TaskNames.ClaimsNewNotice){
    tw.local.displayCloseout = true;  
}
    
if(tw.local.taskName==tw.resource.TaskNames.ClaimsExamine){
    tw.local.approvalGroups[0] = new tw.object.NameValuePair();
    tw.local.approvalGroups[0].name="Director";
    tw.local.approvalGroups[0].value=tw.resource.SecurityGroups.lifeAdminDirector;
    tw.local.approvalGroups[1] = new tw.object.NameValuePair();
    tw.local.approvalGroups[1].name="Assistant Claim Director";
    tw.local.approvalGroups[1].value=tw.resource.SecurityGroups.lifeAdminAssistantClaimDirector;
    tw.local.approvalGroups[2] = new tw.object.NameValuePair();
    tw.local.approvalGroups[2].name="Sr. Claim Acct Manager";
    tw.local.approvalGroups[2].value=tw.resource.SecurityGroups.lifeAdminSrClaimAcctManager;
    tw.local.approvalGroups[3] = new tw.object.NameValuePair();
    tw.local.approvalGroups[3].name="Life Claim Analyst";
    tw.local.approvalGroups[3].value=tw.resource.SecurityGroups.lifeAdminLifeClaimAnalyst;
    tw.local.approvalGroups[4] = new tw.object.NameValuePair();
    tw.local.approvalGroups[4].name="Assistant Claim Analyst/Examiner";
    tw.local.approvalGroups[4].value=tw.resource.SecurityGroups.lifeAdminAssistantClaimAnalystOrExaminer;
    tw.local.reinsuranceInformationEntered=new tw.object.ReinsurancePolicyInformation();
    tw.local.reinsuranceInformationEntered.policyNumber=tw.object.String();
    tw.local.reinsuranceInformationEntered.contestable=tw.object.String();
    tw.local.reinsuranceInformationEntered.litigation=null;
    tw.local.reinsuranceInformationEntered.dateOfDeath=null;
    tw.local.displayReinsuranceSection=false;
    tw.local.displayReinsuranceDate=new TWDate();
    tw.local.displayReinsuranceDate.parse(String(tw.epv.reinsuranceVisibility.reinsuranceSectionDate), "yyyy-MM-dd");
    if(tw.system.currentProcessInstance.startDate>tw.local.displayReinsuranceDate){
        tw.local.displayReinsuranceSection=true;
    }
    
}

if(tw.local.taskName==tw.resource.TaskNames.ClaimsNewNotice){

    tw.local.reinsuranceInformationEntered=new tw.object.ReinsurancePolicyInformation();
    tw.local.reinsuranceInformationEntered.policyNumber=tw.object.String();
    tw.local.reinsuranceInformationEntered.contestable=tw.object.String();
    tw.local.reinsuranceInformationEntered.litigation=null;
    tw.local.reinsuranceInformationEntered.dateOfDeath=null;
    tw.local.displayReinsuranceSection=false;
    tw.local.displayReinsuranceDate=new TWDate();
    tw.local.displayReinsuranceDate.parse(String(tw.epv.reinsuranceVisibility.reinsuranceSectionDate), "yyyy-MM-dd");
    if(tw.system.currentProcessInstance.startDate>tw.local.displayReinsuranceDate){
        tw.local.displayReinsuranceSection=true;
    }
    
}

if(tw.local.taskName==tw.resource.TaskNames.ClaimsApprovalReject){
    tw.local.claimantSelectedForApprovalReject.approverLevel.name="";
    tw.local.claimantSelectedForApprovalReject.approverLevel.value="";
    tw.local.approvalGroups[0] = new tw.object.NameValuePair();
    tw.local.approvalGroups[0].name="Director";
    tw.local.approvalGroups[0].value=tw.resource.SecurityGroups.lifeAdminDirector;
    tw.local.approvalGroups[1] = new tw.object.NameValuePair();
    tw.local.approvalGroups[1].name="Assistant Claim Director";
    tw.local.approvalGroups[1].value=tw.resource.SecurityGroups.lifeAdminAssistantClaimDirector;
    tw.local.approvalGroups[2] = new tw.object.NameValuePair();
    tw.local.approvalGroups[2].name="Sr. Claim Acct Manager";
    tw.local.approvalGroups[2].value=tw.resource.SecurityGroups.lifeAdminSrClaimAcctManager;
    tw.local.approvalGroups[3] = new tw.object.NameValuePair();
    tw.local.approvalGroups[3].name="Life Claim Analyst";
    tw.local.approvalGroups[3].value=tw.resource.SecurityGroups.lifeAdminLifeClaimAnalyst;
    tw.local.approvalGroups[4] = new tw.object.NameValuePair();
    tw.local.approvalGroups[4].name="Assistant Claim Analyst/Examiner";
    tw.local.approvalGroups[4].value=tw.resource.SecurityGroups.lifeAdminAssistantClaimAnalystOrExaminer;
}



else if(tw.local.taskName==tw.resource.TaskNames.ClaimsSetUp || tw.local.taskName==tw.resource.TaskNames.FinalizeClaims){
        tw.local.referalGroups[0] = new tw.object.NameValuePair();
        tw.local.referalGroups[0].name="Express Claims";
        tw.local.referalGroups[0].value=tw.resource.SecurityGroups.lifeAdminExpressClaims;
        tw.local.referalGroups[1] = new tw.object.NameValuePair();
        tw.local.referalGroups[1].name="Contestable Claims";
        tw.local.referalGroups[1].value=tw.resource.SecurityGroups.lifeAdminContestableClaims;
        tw.local.referalGroups[2] = new tw.object.NameValuePair();
        tw.local.referalGroups[2].name="Under two million";
        tw.local.referalGroups[2].value=tw.resource.SecurityGroups.lifeAdminLessThanTwoMillion;
        tw.local.referalGroups[3] = new tw.object.NameValuePair();
        tw.local.referalGroups[3].name="Over two million";
        tw.local.referalGroups[3].value=tw.resource.SecurityGroups.lifeAdminMoreThanTwoMillion;
        tw.local.referalGroups[4] = new tw.object.NameValuePair();
        tw.local.referalGroups[4].name="Spectrum Claim";
        tw.local.referalGroups[4].value=tw.resource.SecurityGroups.lifeAdminSpectrumClaims;
           
}else if(tw.local.taskName==tw.resource.TaskNames.ReinsuranceClaim){
    tw.local.dateOfDeath=tw.local.reinsurancePolicyInformation.dateOfDeath.formatDate();
    
}

if(tw.env.com.principal.ind.cn.popDocLauncher == "false"){
    tw.local.displayDocumentSection = true;
}
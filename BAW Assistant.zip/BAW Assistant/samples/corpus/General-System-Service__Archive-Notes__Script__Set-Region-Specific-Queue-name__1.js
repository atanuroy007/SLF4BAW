tw.local.region = tw.env.com.principal.ind.regionName;
if(tw.local.region.toUpperCase().indexOf("A", 0) > 0){    
    tw.local.edcQueue = tw.local.edcQueue.replace("IND", "IND." + tw.local.region.toUpperCase());
}
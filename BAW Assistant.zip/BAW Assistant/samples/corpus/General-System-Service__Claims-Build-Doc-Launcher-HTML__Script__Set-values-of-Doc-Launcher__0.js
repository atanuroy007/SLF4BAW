tw.local.policyNumbers = new tw.object.listOf.String();
tw.local.clientIds = new tw.object.listOf.String();

for(var i =0;i<tw.local.externalProcessData.cases.listLength;i++){
    tw.local.policyNumbers[tw.local.policyNumbers.listLength] = tw.local.externalProcessData.cases[i].policyNumber;
    if(tw.local.externalProcessData.cases[i] != null){
        for(var j=0;j<tw.local.externalProcessData.cases[i].proposedInsured.listLength;j++){
            if(tw.local.externalProcessData.cases[i].proposedInsured[j].clientId != null && tw.local.externalProcessData.cases[i].proposedInsured[j].clientId != ""){
                tw.local.clientIds[tw.local.clientIds.listLength] = tw.local.externalProcessData.cases[i].proposedInsured[j].clientId;
            }
        }
        
    }
}
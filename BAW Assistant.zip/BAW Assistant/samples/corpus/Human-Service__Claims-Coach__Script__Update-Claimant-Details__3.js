var tempClaimantDetails = new tw.object.claimantDetails();
tempClaimantDetails.claimantName=tw.local.firstName+ ", " +tw.local.lastName;
tempClaimantDetails.policyNumber=tw.local.policyTiedToClaimant;
tempClaimantDetails.paymentStatus="Not Started";
tempClaimantDetails.disburseBenefitCreated="N";

var index;
//The below logic has been added as part of BPM Upgrade fix 10/05/2022 
if(tw.local.claimantDetails.listLength == 1){
	if(tw.local.claimantDetails[0].policyNumber == ""){ // if the claimantDetail object is the one that was created from "pre" step of claims coach
		index = 0;
	} else {
		index = 1;
	}
} else {
	index = tw.local.claimantDetails.listLength;
}

tw.local.claimantDetails[index] = tempClaimantDetails;

//var index = tw.local.claimantDetails.listLength
//
//tw.local.claimantDetails[index]= new tw.object.claimantDetails();
//tw.local.claimantDetails[index].claimantName=tw.local.firstName+ ", " +tw.local.lastName;
//tw.local.claimantDetails[index].policyNumber=tw.local.policyTiedToClaimant;
//tw.local.claimantDetails[index].paymentStatus="Not Started";
//tw.local.claimantDetails[index].disburseBenefitCreated="N";

tw.local.firstName="";
tw.local.lastName="";
tw.local.policyTiedToClaimant="";
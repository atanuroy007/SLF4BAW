tw.local.counter = tw.local.counter - 1;
tw.local.noteInfo.text = tw.local.notesList[tw.local.counter];
tw.local.policyListBeforeEditProcess= new tw.object.listOf.String();

for(var i=0;i<tw.local.externalProcessData.cases.listLength;i++){
    tw.local.policyListBeforeEditProcess[i] = tw.local.externalProcessData.cases[i].policyNumber; 
   
    }    

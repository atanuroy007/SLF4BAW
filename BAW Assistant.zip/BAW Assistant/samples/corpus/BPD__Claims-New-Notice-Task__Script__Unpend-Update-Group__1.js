var claimsSetUpTask = tw.system.findTaskByID(tw.local.lastTask);
claimsSetUpTask.reassignBackToRole();
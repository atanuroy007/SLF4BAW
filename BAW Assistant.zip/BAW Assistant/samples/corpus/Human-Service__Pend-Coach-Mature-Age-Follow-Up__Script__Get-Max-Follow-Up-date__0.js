tw.local.maxFollowupDate = new TWDate();
var maxDays = Number(tw.epv.LASRVCE_Process.maxPendDays);
tw.local.maxFollowupDate.setDate(tw.local.maxFollowupDate.getDate() + maxDays);
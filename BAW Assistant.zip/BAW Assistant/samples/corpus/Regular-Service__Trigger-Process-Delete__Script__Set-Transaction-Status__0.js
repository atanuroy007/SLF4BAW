tw.local.claims.transactionStatus=Number(tw.resource.TransactionStatuses.Deleted);
tw.local.claims.taskCompletedBy=tw.system.user_loginName;
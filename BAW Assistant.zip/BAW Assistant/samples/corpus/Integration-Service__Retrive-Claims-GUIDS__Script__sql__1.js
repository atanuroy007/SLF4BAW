tw.local.sql
select RTRIM(prcs_instcguid_txt) FROM <#=tw.env.com.principal.ind.db2SchemaQualifier#>.BPM_PRCS WHERE PRCS_INSTCGUID_TXT in 
( select PRCS_INSTCGUID_TXT from <#=tw.env.com.principal.ind.db2SchemaQualifier#>.BPM_PRCS_CNTR where cntr_id=?  ) 
and PRCS_APP_CD =10 with ur;
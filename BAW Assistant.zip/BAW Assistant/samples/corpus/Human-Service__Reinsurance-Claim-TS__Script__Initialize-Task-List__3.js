tw.local.reinsuranceTaskList=new tw.object.listOf.String();
tw.local.reinsuranceTaskList[0]="Review file";
tw.local.reinsuranceTaskList[1]="Initial notice letter";
tw.local.reinsuranceTaskList[2]="Request for payment letter";
tw.local.reinsuranceTaskList[3]="Collect payment";
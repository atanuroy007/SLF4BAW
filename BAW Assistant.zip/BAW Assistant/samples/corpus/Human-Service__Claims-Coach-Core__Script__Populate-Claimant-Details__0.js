//tw.local.claims.load(tw.local.claims.metadata("key"));

tw.local.claimantDetails = new tw.object.listOf.claimantDetails();
tw.local.claimantDetails = tw.local.claims.claimantsDetails;
tw.local.claimantDetails.listClearAllSelected();

for(var i=0; i<tw.local.claimantDetails.listLength; i++){ 
    tw.local.claimantDetails[i].approvalType="";
    tw.local.claimantDetails[i].approverLevel=null;
}
if(tw.local.taskName=="Approval Claim"){
    for(var i=0;i<tw.local.claimantsSelectedForApproval.listLength;i++){
        tw.local.claimantsSelectedForApproval[i].approvalSent="";
    }
}

tw.local.retainedReinsuranceTaskList=new tw.object.listOf.String();
tw.local.retainedReinsuranceTaskList=tw.local.reinsuranceTaskList;
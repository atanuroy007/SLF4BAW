tw.local.claimsXml
<variable type="Claims" sharedKey="SharedObject.3685c125-e1e7-4c12-afd6-4d4886e8060f" sharedVersionID="34">
  <process type="Process">
    <principalEmployeeIndicator type="Boolean"><![CDATA[false]]></principalEmployeeIndicator>
    <commonProcessContext type="CommonProcessContext">
      <regionId type="String"></regionId>
      <processName type="String"><![CDATA[Life Admin Claims Process-4000250]]></processName>
      <processInstanceGuid type="String"><![CDATA[34e884af-86b8-4e4b-991d-d562caf1f01f]]></processInstanceGuid>
      <keyBusinessDataId type="String"></keyBusinessDataId>
      <loggingCorrelationId type="String"></loggingCorrelationId>
    </commonProcessContext>
    <processRoutingData type="ProcessRoutingData">
      <bmaIndicator type="Boolean"><![CDATA[false]]></bmaIndicator>
      <incomingState type="String"></incomingState>
      <replacementIndicator type="Boolean"><![CDATA[false]]></replacementIndicator>
      <internal1035Indicator type="Boolean"><![CDATA[false]]></internal1035Indicator>
      <external1035Indicator type="Boolean"><![CDATA[false]]></external1035Indicator>
      <reworkCase type="Boolean"><![CDATA[false]]></reworkCase>
      <reworkPreviousTaskGuid type="String"></reworkPreviousTaskGuid>
      <freeLookTimeOut type="Boolean"><![CDATA[false]]></freeLookTimeOut>
      <external1035Routing type="String"></external1035Routing>
      <replacementInGoodOrderIndicator type="Boolean"><![CDATA[false]]></replacementInGoodOrderIndicator>
      <bypassUnderwritingIndicator type="Boolean"><![CDATA[false]]></bypassUnderwritingIndicator>
      <uwReviewToUWIndicator type="Boolean"><![CDATA[false]]></uwReviewToUWIndicator>
      <uwReviewToMedicalIndicator type="Boolean"><![CDATA[false]]></uwReviewToMedicalIndicator>
      <cosignDecision type="String"></cosignDecision>
      <cosignRequesterUW type="String"></cosignRequesterUW>
      <cosignDecisionBy type="String"></cosignDecisionBy>
      <isSecondCosignInitiated type="Boolean"><![CDATA[false]]></isSecondCosignInitiated>
      <isAUEligible type="Boolean"><![CDATA[false]]></isAUEligible>
      <reissueCase type="Boolean"><![CDATA[false]]></reissueCase>
    </processRoutingData>
    <displayProcessName type="String"><![CDATA[Life Admin Claims Process]]></displayProcessName>
    <worklistData type="WorklistData">
      <primaryPolicyNumber type="String"><![CDATA[4000250]]></primaryPolicyNumber>
      <caseCount type="Integer"><![CDATA[2]]></caseCount>
      <insuredName type="String"><![CDATA[SUMMER, HOLDEN]]></insuredName>
      <fieldOfficeNumber type="String"><![CDATA[00001]]></fieldOfficeNumber>
      <faceAmount type="Decimal"><![CDATA[2500000.0]]></faceAmount>
      <assignedTeam type="Integer"><![CDATA[43]]></assignedTeam>
      <netAmountAtRisk type="Integer"><![CDATA[0]]></netAmountAtRisk>
      <diCUPA type="Integer"><![CDATA[0]]></diCUPA>
      <oeblpCUPA type="Integer"><![CDATA[0]]></oeblpCUPA>
      <dbokprCUPA type="Integer"><![CDATA[0]]></dbokprCUPA>
      <cashWithAppInd type="String"><![CDATA[N]]></cashWithAppInd>
      <transactionCntlID type="Integer"><![CDATA[77795]]></transactionCntlID>
      <productName type="String"><![CDATA[UL9+]]></productName>
    </worklistData>
    <instanceName type="String"><![CDATA[Life Admin Claims Process-4000250]]></instanceName>
    <processCreationDate type="Date"><![CDATA[2019/03/07 03:32:13.907 CST]]></processCreationDate>
    <packetFolderId type="String"></packetFolderId>
    <processVersion type="Integer"><![CDATA[3]]></processVersion>
    <lineOfBusiness type="String"><![CDATA[L]]></lineOfBusiness>
  </process>
  <imagePacketIds type="String[]">
    <item></item>
  </imagePacketIds>
  <referralSelected type="NameValuePair">
    <name type="String"></name>
    <value type="String"></value>
  </referralSelected>
  <approvalSelected type="NameValuePair">
    <name type="String"></name>
    <value type="String"></value>
  </approvalSelected>
  <taskCompletedBy type="String"><![CDATA[P605264]]></taskCompletedBy>
  <transactionControlId type="Integer"><![CDATA[77795]]></transactionControlId>
  <transactionStatus type="Integer"><![CDATA[2]]></transactionStatus>
  <claimantsDetails type="claimantDetails[]">
    <item>
      <claimantName type="String"><![CDATA[ed, sad]]></claimantName>
      <policyNumber type="String"><![CDATA[4000250]]></policyNumber>
      <approvalType type="String"></approvalType>
      <approverLevel type="NameValuePair" />
      <paymentStatus type="String"><![CDATA[Not Approved]]></paymentStatus>
      <approvalSent type="String"></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
    <item>
      <claimantName type="String"><![CDATA[dsdf, eer]]></claimantName>
      <policyNumber type="String"><![CDATA[4000250]]></policyNumber>
      <approvalType type="String"></approvalType>
      <approverLevel type="NameValuePair" />
      <paymentStatus type="String"><![CDATA[Not Approved]]></paymentStatus>
      <approvalSent type="String"><![CDATA[No]]></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
    <item>
      <claimantName type="String"><![CDATA[dds, gbf]]></claimantName>
      <policyNumber type="String"><![CDATA[4000250]]></policyNumber>
      <approvalType type="String"></approvalType>
      <approverLevel type="NameValuePair" />
      <paymentStatus type="String"><![CDATA[Not Approved]]></paymentStatus>
      <approvalSent type="String"><![CDATA[No]]></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
    <item>
      <claimantName type="String"><![CDATA[vdf, gfd]]></claimantName>
      <policyNumber type="String"><![CDATA[4000382]]></policyNumber>
      <approvalType type="String"></approvalType>
      <approverLevel type="NameValuePair" />
      <paymentStatus type="String"><![CDATA[Not Approved]]></paymentStatus>
      <approvalSent type="String"></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
    <item>
      <claimantName type="String"><![CDATA[gh, df]]></claimantName>
      <policyNumber type="String"><![CDATA[4000382]]></policyNumber>
      <approvalType type="String"></approvalType>
      <approverLevel type="NameValuePair" />
      <paymentStatus type="String"><![CDATA[Not Approved]]></paymentStatus>
      <approvalSent type="String"></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
    <item>
      <claimantName type="String"><![CDATA[gfh, df]]></claimantName>
      <policyNumber type="String"><![CDATA[4000250]]></policyNumber>
      <approvalType type="String"></approvalType>
      <approverLevel type="NameValuePair" />
      <paymentStatus type="String"><![CDATA[Not Started]]></paymentStatus>
      <approvalSent type="String"></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
  </claimantsDetails>
  <claimantsSelectedForApproval type="claimantDetails[]">
    <item>
      <claimantName type="String"><![CDATA[gh, df]]></claimantName>
      <policyNumber type="String"><![CDATA[4000382]]></policyNumber>
      <approvalType type="String"><![CDATA[Yes]]></approvalType>
      <approverLevel type="NameValuePair">
        <name type="String"><![CDATA[Life Claim Analyst]]></name>
        <value type="String"><![CDATA[LA-Life_Claim_Analyst]]></value>
      </approverLevel>
      <paymentStatus type="String"><![CDATA[Approval in Progress]]></paymentStatus>
      <approvalSent type="String"><![CDATA[No]]></approvalSent>
      <disburseBenefitCreated type="String"><![CDATA[N]]></disburseBenefitCreated>
    </item>
  </claimantsSelectedForApproval>
  <setupTaskGuid type="String"><![CDATA[1ba41ef0-1882-4455-9236-764066c70cc9]]></setupTaskGuid>
  <examineTaskGuid type="String"><![CDATA[a29d0ba3-a7d2-4b42-b441-2e4dbba5092b]]></examineTaskGuid>
  <reinsurancePolicies type="String[]" />
  <reinsuranceGuids type="String[]" />
  <examineGroupAssigned type="String"><![CDATA[LA-Express_Claims]]></examineGroupAssigned>
  <followUpDateExamineClaim type="Date"><![CDATA[2019/04/08 03:33:48.129 CDT]]></followUpDateExamineClaim>
  <approvalTaskOwner type="String"><![CDATA[P150407]]></approvalTaskOwner>
  <isLastDisbursementTask type="Boolean"><![CDATA[false]]></isLastDisbursementTask>
  <groupAssignedToApprovalReject type="String"><![CDATA[LA-Express_Claims]]></groupAssignedToApprovalReject>
  <approvalRejectTaskGuidMap type="NameValuePair[]">
    <item>
      <name type="String"><![CDATA[2078.683454]]></name>
      <value type="String"><![CDATA[31788479-54a4-40f9-8e5f-80458a5ade03]]></value>
    </item>
    <item>
      <name type="String"><![CDATA[2078.683460]]></name>
      <value type="String"><![CDATA[7864640a-d7b0-465e-86b7-b8b5c68ebb64]]></value>
    </item>
    <item>
      <name type="String"><![CDATA[2078.683471]]></name>
      <value type="String"><![CDATA[c5834311-dae0-4a75-9566-1402bee7a31f]]></value>
    </item>
    <item>
      <name type="String"><![CDATA[2078.683475]]></name>
      <value type="String"><![CDATA[a3e56bac-fde6-44bc-8185-0ad6dce2dcdd]]></value>
    </item>
  </approvalRejectTaskGuidMap>
</variable>
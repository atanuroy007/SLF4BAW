tw.local.previousFollowupDate = tw.local.followupDate;

/*
@dojoConfigUpdateStart 
   dojoConfig.packages.push({
      name: 'com_ibm_bpm_coach_controls',
      location: com_ibm_bpm_coach.getManagedAssetUrl('coach_ng_utilities.zip',
				com_ibm_bpm_coach.assetType_WEB, 'SYSC') + "/com_ibm_bpm_coach_controls"
   });
   dojoConfig.packages.push({
      name: 'com.ibm.bpm.coach.controls',
      location: com_ibm_bpm_coach.getManagedAssetUrl('coach_ng_utilities.zip',
				com_ibm_bpm_coach.assetType_WEB, 'SYSC') + "/com/ibm/bpm/coach/controls"
   });
@dojoConfigUpdateEnd
@layerRequiredStart
{
   "nonDebug": ["com_ibm_bpm_coach_controls/controls"]
}
@layerRequiredEnd
*/

if (!this.updateStyle) {
	this.constructor.prototype.updateStyle = function() {
		var buttonNode = this.context.element.querySelector(".BPMButton");
		var stretch = !!this.context.getStyle() ? (!!this.context.getStyle().width || !!this.context.getStyle().minWidth) : false;

		if(stretch) {
			buttonNode.style.width = "100%";
		} else {
			buttonNode.style.width = "";
		}
	}
}

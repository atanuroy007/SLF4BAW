if(tw.epv.LDI_Common.enableTraceLevelLogging == "true")
   PFGBPM.INDBPM.Log.info(tw.system.currentProcessInstanceID + ": Update Current Task Subject - Parse Task Subject - End");

tw.local.variablePolicies = new tw.object.listOf.String();

for(var i=0; i<tw.local.results.getAttribute("recordCount"); i++){
    tw.local.variablePolicies[i] = tw.local.results.record[i].column[0].getText();  
}
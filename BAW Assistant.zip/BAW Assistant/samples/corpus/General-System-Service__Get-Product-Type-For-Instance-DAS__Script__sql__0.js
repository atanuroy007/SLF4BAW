tw.local.sql
Select RTRIM(CNTR_ID) AS CNTR_ID from <#=tw.local.db2SchemaQualifier#>.BPM_PRCS_CNTR 
where PRCS_INSTCGUID_TXT = ?
and IND_PRODUCT_CD in ( SELECT RTRIM(IND_PRODUCT_CD)
FROM <#=tw.local.db2SchemaQualifier#>.ind_product
WHERE var_prdct_flg = ?
AND ind_lob_cd = ?) with ur ;
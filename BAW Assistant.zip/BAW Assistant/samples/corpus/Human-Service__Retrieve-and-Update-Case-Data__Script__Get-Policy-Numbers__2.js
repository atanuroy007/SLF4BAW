tw.local.policyEndIndex = tw.local.policyStartIndex + Number(tw.epv.HoldingServiceIntegrationEpvs.policyFetchMaxCount);

if (tw.local.policyEndIndex > tw.local.externalProcessData.cases.listLength)
    tw.local.policyEndIndex = tw.local.externalProcessData.cases.listLength;

tw.local.policyNumbers = new tw.object.listOf.String();    
for (var i=tw.local.policyStartIndex;i < tw.local.policyEndIndex;i++){
    if(tw.local.externalProcessData.cases[i].currentCaseIndicator == true)
        tw.local.policyNumbers[tw.local.policyNumbers.listLength] = tw.local.externalProcessData.cases[i].policyNumber;
}

tw.local.policyStartIndex = tw.local.policyEndIndex;
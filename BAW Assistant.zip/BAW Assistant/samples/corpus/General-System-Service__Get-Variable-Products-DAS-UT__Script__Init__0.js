tw.local.datasource='jdbc/IndLifeAdminClaimsProcessDataSource';
tw.local.db2SchemaQualifier='ITA1';
tw.local.message="";
tw.local.error="";
tw.local.taskName = tw.resource.TaskNames.ClaimsResearch;    
tw.local.taskAssignmentExpression = "ROLE:" + tw.resource.SecurityGroups.lifeAdminResearch;
tw.local.taskDueDate = tw.system.currentProcessInstance.dueDate;
tw.local.taskDueDate.setDate(tw.local.taskDueDate.getDate() + 200);
tw.local.taskPriority = 200;

//set initial follow up date
tw.local.followUpDate = new TWDate()
tw.local.followUpDate.setDate(tw.local.followUpDate.getDate() + 1000);

//set task state variable to ready
tw.local.stateReady = tw.resource.TaskStates.TaskActive;

// Task Subject Values
tw.local.task = new tw.object.Task();
tw.local.task.taskSubject = tw.local.taskName;
tw.local.task.taskState = tw.resource.TaskStates.TaskActive;
tw.local.task.taskEligibleGroup = tw.resource.SecurityGroups.lifeAdminResearch;
tw.local.task.taskStateDateTime = new TWDate();
tw.local.taskCode= tw.resource.TaskCodes.ClaimsResearch;
tw.local.errorMessage="";

if(tw.local.reinsuranceInformationEntered.policyNumber==null||
tw.local.reinsuranceInformationEntered.dateOfDeath==null|| 
tw.local.reinsuranceInformationEntered.contestable==null|| tw.local.reinsuranceInformationEntered.contestable=="" ||
tw.local.reinsuranceInformationEntered.litigation==null || tw.local.reinsuranceInformationEntered.litigation==""){
    tw.local.errorMessage="Please enter all details to create a Reinsurance task";
}

if(tw.local.reinsuranceInformationEntered.dateOfDeath>=new TWDate()){
    tw.local.errorMessage="Please select a date prior to the current date";
}

for(var i=0;i<tw.local.reinsurancePolicies.listLength;i++){
   if(tw.local.reinsurancePolicies[i]==tw.local.reinsuranceInformationEntered.policyNumber){
        tw.local.errorMessage="A reinsurance task exists for the selected policy";
    }
}
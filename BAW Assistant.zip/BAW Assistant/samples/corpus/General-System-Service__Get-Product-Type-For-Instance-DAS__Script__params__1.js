tw.local.parameters = new tw.object.listOf.SQLParameter();
var i=0;

tw.local.parameters[i] = new tw.object.SQLParameter();
tw.local.parameters[i].value = tw.local.processInstanceGuid;
tw.local.parameters[i].type = "VARCHAR";
tw.local.parameters[i].mode = "IN";
i++;

tw.local.parameters[i] = new tw.object.SQLParameter();
tw.local.parameters[i].value = 'Y';
tw.local.parameters[i].type = "VARCHAR";
tw.local.parameters[i].mode = "IN";
i++;

tw.local.parameters[i] = new tw.object.SQLParameter();
tw.local.parameters[i].value = 'L';
tw.local.parameters[i].type = "VARCHAR";
tw.local.parameters[i].mode = "IN";

// Build the input key string to the doc launcher.  The key string is created with these fields:
// Packet folder id (0 to many, each separated by + sign) & 
// CNTR=contract ID+CLNT=client id+EMP=employer client id-employer case number
//
var contracts = "";
var clients = "";
var clientsPlusSign = false;
var employer = "";
var packetFolderIdList = new Array();
var packetIdExists;
var docLauncherKeyString = "";

//Loop through packet IDs to pass to the Doc Launcher
/*for (var i = 0; i < tw.local.imagePacketIds.listLength; i ++) {
   if (tw.local.imagePacketIds[i] != null && tw.local.imagePacketIds[i] != "") {
        packetFolderIdList[i] = tw.local.imagePacketIds[i];             
   }
}*/
        

//Loop through external data and pull out contract ID, client ID and employer data
for (var i=0; i < tw.local.externalProcessData.cases.listLength; i++) {
    if (tw.local.externalProcessData.cases[i].policyNumber != "") {
        if (i > 0) {
        contracts = contracts + "+";
        }
        contracts = contracts + "CNTR=" + tw.local.externalProcessData.cases[i].policyNumber;
       
       if(tw.local.externalProcessData.cases[i].proposedInsured !=null){
        for (var j=0; j < tw.local.externalProcessData.cases[i].proposedInsured.listLength; j++) {
            if (tw.local.externalProcessData.cases[i].proposedInsured[j].clientId != "") {
                if (clientsPlusSign == false) {
                    clientsPlusSign = true;
                    clients = clients + "CLNT=" + tw.local.externalProcessData.cases[i].proposedInsured[j].clientId;
                } else {
                clients = clients + "+";
                clients = clients + "CLNT=" + tw.local.externalProcessData.cases[i].proposedInsured[j].clientId;        
                }
            }
        }
        }
        
    }   
}

//Build the employer key string
if (tw.local.externalProcessData.businessCase.employer.clientId != null) {
    if (tw.local.externalProcessData.businessCase.employer.clientId != "") {
        employer = "EMP=" + tw.local.externalProcessData.businessCase.employer.clientId;
        if (tw.local.externalProcessData.businessCase.caseId != null){
            var str = "" + String(tw.local.externalProcessData.businessCase.caseId);
            var pad = "000";
            pad = pad.substring(0, pad.length - str.length) + str;
            employer += "-" + pad;
        }
    }
}

//Build the Doc Launcher key string field

//Add the packet folder ids
docLauncherKeyString = "pfgimage:ImageSearch.clsWDC:";
for (var i=0; i < packetFolderIdList.length; i++) {
    if (i>0){
        docLauncherKeyString = docLauncherKeyString + "+";
    }
    docLauncherKeyString = docLauncherKeyString + packetFolderIdList[i];
}

docLauncherKeyString = docLauncherKeyString + "&";

if (contracts != "") {
    docLauncherKeyString = docLauncherKeyString + contracts;
}

if (clients != "") {
    if (contracts != "") {
        docLauncherKeyString = docLauncherKeyString + "+" + clients; 
    } else { 
        docLauncherKeyString = docLauncherKeyString + clients; 
    }
}

if (employer != null) {
    if (employer != "") {
        docLauncherKeyString = docLauncherKeyString + "+" + employer;
    }
}

docLauncherKeyString = docLauncherKeyString + "&9999&BPMProcess&LDStandard";
tw.local.docLauncherAutoOpen = new tw.object.DocLauncherAutoOpen();
tw.local.docLauncherAutoOpen.docLauncherKeyString = docLauncherKeyString;
//Currently setting the boolean to True so that it will auto pop doc Launcher.
tw.local.docLauncherAutoOpen.displayDocLauncher = true;


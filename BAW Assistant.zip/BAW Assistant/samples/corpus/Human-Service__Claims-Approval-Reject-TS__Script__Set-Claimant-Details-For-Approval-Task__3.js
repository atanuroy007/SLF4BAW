tw.local.claimantsSelectedForApproval = new tw.object.listOf.claimantDetails();
tw.local.claimantsSelectedForApproval[0]= tw.local.claimantSelectedForApprovalReject;


for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
   if(tw.local.claims.claimantsDetails[i].policyNumber==tw.local.claimantSelectedForApprovalReject.policyNumber &&
      tw.local.claims.claimantsDetails[i].claimantName==tw.local.claimantSelectedForApprovalReject.claimantName){
        tw.local.claims.claimantsDetails[i].paymentStatus="Approval in Progress";
        tw.local.claims.approvalSelected.value=tw.local.claimantSelectedForApprovalReject.approverLevel.value
        tw.local.claims.approvalSelected.name=tw.local.claimantSelectedForApprovalReject.approverLevel.name
        break;
        }
    }


tw.local.claims.save();

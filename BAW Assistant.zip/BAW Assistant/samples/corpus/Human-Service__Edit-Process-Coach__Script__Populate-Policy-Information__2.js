tw.local.policyInformationViewData = new tw.object.listOf.PolicyInformationViewData();

for(var i=0;i<tw.local.externalProcessData.cases.listLength;i++){
    tw.local.policyInformationViewData[i] = new tw.object.PolicyInformationViewData();
    tw.local.policyInformationViewData[i].policyNumber = tw.local.externalProcessData.cases[i].policyNumber;
    tw.local.policyInformationViewData[i].insuredNames = new tw.object.listOf.Insured();
    if(tw.local.externalProcessData.cases[i].proposedInsured!=null){
    for(var j=0;j<tw.local.externalProcessData.cases[i].proposedInsured.listLength;j++){
        var insured = new tw.object.Insured();
        if(tw.local.externalProcessData.cases[i].proposedInsured[j].lastName!=null && tw.local.externalProcessData.cases[i].proposedInsured[j].firstName!=null){
            insured.name = tw.local.externalProcessData.cases[i].proposedInsured[j].lastName + ", " + tw.local.externalProcessData.cases[i].proposedInsured[j].firstName;
        }
        tw.local.policyInformationViewData[i].insuredNames[j] = insured;
    }    
  }
}
tw.local.addedPolicy="";
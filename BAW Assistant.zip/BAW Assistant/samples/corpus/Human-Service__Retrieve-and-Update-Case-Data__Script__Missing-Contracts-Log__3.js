PFGBPM.INDBPM.Log.info("Instance ID: " + tw.system.currentProcessInstanceID
    + ", Missing Contracts found. Email sent to IndLifeServNonAuto. , End log entry...");

tw.local.sql
select RTRIM(prcs_instcguid_txt) from <#=tw.env.com.principal.ind.db2SchemaQualifier#>.bpm_prcs_cntr 
where cntr_id=?
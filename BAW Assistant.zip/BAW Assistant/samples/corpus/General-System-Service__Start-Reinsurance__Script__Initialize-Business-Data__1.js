tw.local.event.businessData.cases[0]=new tw.object.Case();
tw.local.event.businessData.cases[0].proposedInsured=new tw.object.listOf.ProposedInsured();
tw.local.event.businessData.cases[0].policyNumber=tw.local.reinsurancePolicyInformation.policyNumber;
tw.local.event.businessData.cases[0].fieldOfficeNumber=tw.local.worklistData.fieldOfficeNumber;
// If we are doing a Return after a Save For Later, we want to reassign to the person who saved it.
if (tw.local.lastSavedByUser != "" && tw.local.lastSavedByUser != null) {
    tw.system.currentTask.reassignTo(tw.local.lastSavedByUser);
    tw.local.newTaskOwnerUser = tw.local.lastSavedByUser;
    tw.local.newTaskOwnerGroup = null;
} else {
    // This task state is the last task state. If it was previously pended, we want to reassign
    // back to the user it was pended to.
    if(tw.local.task.taskState == tw.resource.TaskStates.TaskPend){
        if(tw.local.lastTaskOwner!=null){
        tw.system.currentTask.reassignTo(tw.local.lastTaskOwner);
        tw.local.newTaskOwnerUser = tw.local.lastTaskOwner;
        tw.local.newTaskOwnerGroup = null;
        }else{
            tw.system.currentTask.reassignBackToRole();
            tw.local.newTaskOwnerUser = null;
            tw.local.newTaskOwnerGroup = tw.system.currentTask.assignedTo.name;
        }
    }
    else {
            tw.system.currentTask.reassignBackToRole();
            tw.local.newTaskOwnerUser = null;
            tw.local.newTaskOwnerGroup = tw.system.currentTask.assignedTo.name;
         }    
}
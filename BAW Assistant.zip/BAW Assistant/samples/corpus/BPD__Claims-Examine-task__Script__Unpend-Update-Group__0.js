var claimsExamineTask = tw.system.findTaskByID(tw.local.lastTask);
claimsExamineTask.reassignBackToRole();
tw.local.PendStatus=true;
if(claimsExamineTask.subject.search("Pend")==-1){
  tw.local.PendStatus=false;  
}











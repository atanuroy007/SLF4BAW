tw.local.claims.imagePacketIds = new tw.object.listOf.String();
tw.local.claims.imagePacketIds[tw.local.claims.imagePacketIds.listLength] = tw.local.incomingEvent.documentData.packetFolderId;
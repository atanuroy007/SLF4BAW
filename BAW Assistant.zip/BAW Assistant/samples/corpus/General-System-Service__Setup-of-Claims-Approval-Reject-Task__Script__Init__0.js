tw.local.taskName = tw.resource.TaskNames.ClaimsApprovalReject;    
tw.local.taskAssignmentExpression = tw.local.apprpovalRejectOwner;
tw.local.taskPriority=0;

tw.local.taskDueDate = tw.system.currentProcessInstance.dueDate;
//set initial follow up date
tw.local.followUpDate = new TWDate();
tw.local.followUpDate.setDate(tw.local.followUpDate.getDate() + 1000);

//set task state variable to ready
tw.local.stateReady = tw.resource.TaskStates.TaskActive;

// Task Subject Values
tw.local.task = new tw.object.Task();
tw.local.task.taskSubject = tw.local.taskName;
tw.local.task.taskState = tw.resource.TaskStates.TaskActive;
tw.local.task.taskEligibleGroup =tw.local.claims.examineGroupAssigned;
//tw.local.task.taskSavedBy=tw.local.claims.approvalTaskOwner;

tw.local.task.taskStateDateTime = new TWDate();
tw.local.taskCode= tw.resource.TaskCodes.ClaimsApprovalReject;

tw.local.task.assignedToUser=tw.local.apprpovalRejectOwner;
tw.system.findTaskByID(tw.system.currentTask.id).owner=tw.local.apprpovalRejectOwner;

tw.local.claims.transactionStatus = Number(tw.resource.TransactionStatuses.Completed);
tw.local.claims.isFromFinalizeClaims=false;
tw.local.policyListAfterEditProcess= new tw.object.listOf.String();

for(var i=0;i<tw.local.externalProcessData.cases.listLength;i++){
    tw.local.policyListAfterEditProcess[i] = tw.local.externalProcessData.cases[i].policyNumber; 
    }    


var count=0;

for(var i=0;i<tw.local.policyListAfterEditProcess.listLength;i++){
    for(var j=0;j<tw.local.policyListBeforeEditProcess.listLength;j++){
        if(tw.local.policyListAfterEditProcess[i]==tw.local.policyListBeforeEditProcess[j]){
            count++;
        }
    }
}

if(tw.local.policyListBeforeEditProcess.listLength==count && tw.local.policyListAfterEditProcess.listLength==count){
    tw.local.arePoliciesEdited=false;
}else{
     tw.local.arePoliciesEdited=true;
}
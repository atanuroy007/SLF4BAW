tw.local.claims.taskCompletedBy=tw.system.user_loginName;
tw.local.guidCounter=0;
tw.local.policyStartIndex = 0;
tw.local.policyEndIndex = 0;
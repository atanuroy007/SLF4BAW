tw.local.followupDate = new TWDate();
var maxDays = 30;
tw.local.followupDate.setDate(tw.local.followupDate.getDate()+maxDays);



var fpDate = tw.local.followupDate.format("MM/dd/yyyy");

if(tw.local.followupDate.getDay()!=1 && tw.local.followupDate.getDay() != 7){
  for(var i=0;i<tw.local.holidays.listLength;i++){
    if(tw.local.holidays[i] == fpDate ){
        tw.local.followupDate.setDate(tw.local.followupDate.getDate()+1);
        fpDate=tw.local.followupDate.format("MM/dd/yyyy");
         }
          
       if(tw.local.followupDate.getDay() == 1){
           tw.local.followupDate.setDate(tw.local.followupDate.getDate()+1);
           fpDate=tw.local.followupDate.format("MM/dd/yyyy");
        }
        else if(tw.local.followupDate.getDay() == 7){
            tw.local.followupDate.setDate(tw.local.followupDate.getDate()+2);
            fpDate=tw.local.followupDate.format("MM/dd/yyyy");
        } 
           break;
     }
}
  if(tw.local.followupDate.getDay() == 1){
     tw.local.followupDate.setDate(tw.local.followupDate.getDate()+1);
     fpDate=tw.local.followupDate.format("MM/dd/yyyy");
     for(var i=0;i<tw.local.holidays.listLength;i++){
         if(tw.local.holidays[i] == fpDate){
                    tw.local.followupDate.setDate(tw.local.followupDate.getDate()+1);
                    fpDate=tw.local.followupDate.format("MM/dd/yyyy");
                    break;
                }
            }     
    }
 else if(tw.local.followupDate.getDay() == 7){
    tw.local.followupDate.setDate(tw.local.followupDate.getDate()+2);
    fpDate=tw.local.followupDate.format("MM/dd/yyyy");
    for(var i=0;i<tw.local.holidays.listLength;i++){
        if(tw.local.holidays[i] == fpDate ){
              tw.local.followupDate.setDate(tw.local.followupDate.getDate()+1);
                fpDate=tw.local.followupDate.format("MM/dd/yyyy");
                 break;
             }
         }   
    }        
        


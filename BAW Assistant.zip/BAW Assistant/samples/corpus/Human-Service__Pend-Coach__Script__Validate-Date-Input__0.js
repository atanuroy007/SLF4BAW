tw.local.errorMessage="";
var followupTime = new Date();
var currentDate = new Date();
var currentTime = new Date(); 
tw.local.currentDate = new TWDate();
 

if (typeof tw.local.followupDate == "undefined"){
    tw.local.errorMessage = "Please enter a follow up date.";
}else{
    followupTime.setTime(tw.local.followupDate);
    currentTime.setTime(currentDate);
    var fpDate = tw.local.followupDate.format("MM/dd/yyyy");
    if ((followupTime - currentTime) < 1800000)
        {
            tw.local.errorMessage = "Follow up date/time should be 30 minutes ahead of current date/time.";
        }
        else if(tw.local.followupDate.getDay() == 1)
        {
            tw.local.errorMessage = fpDate + " is a Sunday. Please choose another day.";
        }
        else if(tw.local.followupDate.getDay() == 7)
        {
            tw.local.errorMessage = fpDate + " is a Saturday. Please choose another day.";
        }  
        if(tw.local.taskName==tw.resource.TaskNames.ClaimsExamine && tw.local.followupDate> tw.local.examineTaskUnpendDate && tw.local.currentDate<tw.local.examineTaskUnpendDate){
          tw.local.errorMessage ="You cannot pend for a date which is more than 30 days from creation of Examine Claim Task";
        }     
        else if(tw.local.errorMessage == "")
        {
            for(var i=0;i<tw.local.holidays.listLength;i++)
            {
                if(tw.local.holidays[i] == fpDate)
                {
                    tw.local.errorMessage = fpDate + " is a PFG holiday. Please choose another day.";
                    break;
                }
            }
        }
        
        
}

tw.local.claimantsToSendForApprovalReject= new tw.object.listOf.claimantDetails();

for(var i=0;i<tw.local.claims.claimantsSelectedForApproval.listLength;i++){
    if(tw.local.claims.claimantsSelectedForApproval[i].approvalSent=="No"){
        tw.local.claimantsToSendForApprovalReject[tw.local.claimantsToSendForApprovalReject.listLength]=tw.local.claims.claimantsSelectedForApproval[i];
    }
 }

tw.local.claims.save();













  
if(tw.env.com.principal.ind.cn.popDocLauncher == "true"){
    tw.local.docLauncherAutoOpen.displayDocLauncher = true;
    tw.local.docLauncherAutoOpen.defaultCNDesktopURL = tw.env.com.principal.ind.cn.contentNavigatorDesktop;
}else{
    tw.local.docLauncherAutoOpen.displayDocLauncher = false;
}
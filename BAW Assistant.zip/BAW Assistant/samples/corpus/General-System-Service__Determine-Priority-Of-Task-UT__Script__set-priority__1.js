
    for(var i=0; i<tw.local.variableProducts.listLength; i++){
        if(tw.local.variableProducts[i] == tw.local.Claims.process.worklistData.productName){
            tw.local.Claims.isVariableProduct = true;
            break;
        }
    }

if(tw.local.Claims.isVariableProduct == true){
    tw.local.setupClaimPriority = 'Highest';
}
else{
    tw.local.setupClaimPriority = 'Normal';
}
tw.local.claims.load(tw.local.claims.metadata("key"));
tw.local.isLastTask=true;
for (var i= 0;i<tw.local.claims.reinsurancePoliciesStatus.listLength;i++){    
    if(tw.local.claims.reinsurancePoliciesStatus[i].status!="Completed"){
        tw.local.isLastTask=false;
    }
}
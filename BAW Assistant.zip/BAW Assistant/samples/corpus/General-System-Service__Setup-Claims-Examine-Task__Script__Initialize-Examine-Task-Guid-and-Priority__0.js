/*
if(tw.local.claims.process.worklistData.productName.search('VUL')){
tw.local.taskPriorityExamineClaims = 'Highest';
}else{
tw.local.taskPriorityExamineClaims ='Lowest';
}*/

if(tw.local.claims.isVariableProduct == true){
    tw.local.taskPriorityExamineClaims = 'High';
}else{
    tw.local.taskPriorityExamineClaims ='Lowest';
}

tw.local.claims.examineTaskGuid=tw.local.taskGuid;
tw.local.claims.save();
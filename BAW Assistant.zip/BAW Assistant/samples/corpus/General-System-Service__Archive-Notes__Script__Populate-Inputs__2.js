tw.local.imagePdfData.policyNumbersAsCsv="";
for(var i=0;i<tw.local.policyNumbersList.listLength;i++){
    if(i != 0){
        tw.local.imagePdfData.policyNumbersAsCsv = tw.local.imagePdfData.policyNumbersAsCsv + ",";
    }    
    tw.local.imagePdfData.policyNumbersAsCsv = tw.local.imagePdfData.policyNumbersAsCsv+ tw.local.policyNumbersList[i];
}
tw.local.imagePdfData.processName = tw.local.processName;
tw.local.imagePdfData.transactionStatusDate = tw.local.transactionStatusDate;
tw.local.imagePdfData.edcQueue = tw.local.edcQueue;
PFGBPM.INDBPM.Log.info("Archived policy(s)Life Admin Claims Process:" + tw.local.imagePdfData.policyNumbersAsCsv);
tw.local.notesList = new tw.object.listOf.String();
var indexCounter = 0;
var i=0;
if (tw.local.notesText.length >  tw.local.maxCharatersPerLine){
    while ((tw.local.notesText.length - i) > tw.local.maxCharatersPerLine){
        var pos = tw.local.notesText.substr(i, tw.local.maxCharatersPerLine).lastIndexOf(' ');
        tw.local.notesList[indexCounter] = new String();
        tw.local.notesList[indexCounter] = tw.local.notesText.substr(i,pos);
        i = i+pos+1;
        indexCounter = indexCounter +1;
    }
}
tw.local.notesList[indexCounter] = new String();
tw.local.notesList[indexCounter] = tw.local.notesText.substr(i,tw.local.notesText.length);
tw.local.bpmTaskStatusChangeEventData = new tw.object.BPMTaskStatusChangeEventData();
if(tw.local.claims.transactionStatus==tw.resource.TransactionStatuses.Completed){
    tw.local.bpmTaskStatusChangeEventData.statusCode = tw.resource.TaskStatusCodes.Completed;
    tw.local.claims.taskCompletedBy=tw.system.findTaskByID(tw.local.taskId).assignedTo.name;
}else if(tw.local.claims.transactionStatus==tw.resource.TransactionStatuses.Deleted){
    tw.local.bpmTaskStatusChangeEventData.statusCode = tw.resource.TaskStatusCodes.Deleted;
}else if(tw.local.claims.transactionStatus==tw.resource.TransactionStatuses.ClosedOut){
    tw.local.bpmTaskStatusChangeEventData.statusCode = tw.resource.TaskStatusCodes.ClosedOut;
}


tw.local.bpmTaskStatusChangeEventData.taskCode = tw.local.taskCode;
tw.local.bpmTaskStatusChangeEventData.taskActingUser = tw.local.claims.taskCompletedBy;
tw.local.bpmTaskStatusChangeEventData.newTaskOwnerUser = null;
tw.local.bpmTaskStatusChangeEventData.newTaskOwnerGroup = null;
tw.local.bpmTaskStatusChangeEventData.taskPriority = tw.local.taskPriority;
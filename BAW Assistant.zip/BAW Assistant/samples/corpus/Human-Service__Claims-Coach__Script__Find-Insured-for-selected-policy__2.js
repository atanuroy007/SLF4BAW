for(var i=0;i<tw.local.policyInformationViewData.listLength;i++){
    if(tw.local.policyInformationViewData[i].policyNumber==tw.local.reinsuranceInformationEntered.policyNumber){
        tw.local.reinsuranceInformationEntered.insuredName = new tw.object.listOf.Insured();
        tw.local.reinsuranceInformationEntered.insuredName=tw.local.policyInformationViewData[i].insuredNames;
    }
}
tw.local.reinsurancePolicies[tw.local.reinsurancePolicies.listLength]=tw.local.reinsuranceInformationEntered.policyNumber;
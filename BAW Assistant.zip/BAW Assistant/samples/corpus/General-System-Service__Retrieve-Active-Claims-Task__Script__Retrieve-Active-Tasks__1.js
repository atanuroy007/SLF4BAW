var colInstanceId = new TWSearchColumn();
colInstanceId.name = TWSearchColumn.ProcessInstanceColumns.ID;
colInstanceId.type = TWSearchColumn.Types.ProcessInstance;

var colInstanceName = new TWSearchColumn();
colInstanceName.type = TWSearchColumn.Types.ProcessInstance;
colInstanceName.name = TWSearchColumn.ProcessInstanceColumns.Name; // name of BPD

var colProcessName = new TWSearchColumn();
colProcessName.type = TWSearchColumn.Types.ProcessInstance;
colProcessName.name = TWSearchColumn.ProcessInstanceColumns.ProcessApp; 

var condProcessName = new TWSearchCondition;
condProcessName.column=colProcessName;
condProcessName.operator = TWSearchCondition.Operations.Equals;
condProcessName.value = "LACLMS"; 

var colInstanceStatus = new TWSearchColumn(); 
colInstanceStatus.type = TWSearchColumn.Types.ProcessInstance; 
colInstanceStatus.name = TWSearchColumn.ProcessInstanceColumns.Status; 

var colTaskSubject = new TWSearchColumn();
colTaskSubject.type = TWSearchColumn.Types.Task;
colTaskSubject.name = TWSearchColumn.TaskColumns.Subject;

var colTaskID = new TWSearchColumn;
colTaskID.type = TWSearchColumn.Types.Task;
colTaskID.name = TWSearchColumn.TaskColumns.ID;

var condInstanceStatus = new TWSearchCondition; 
condInstanceStatus.column = colInstanceStatus; 
condInstanceStatus.operator = TWSearchCondition.Operations.Equals; 
condInstanceStatus.value = tw.local.processStatus;

var colProcessInstanceGuid = new TWSearchColumn;
colProcessInstanceGuid.type = TWSearchColumn.Types.BusinessData;
colProcessInstanceGuid.name = "LNBFP_ProcessInstanceGuid";

var colProcessVersion =  new TWSearchColumn();
colProcessVersion.type = TWSearchColumn.Types.BusinessData;
colProcessVersion.name = "LNBFP_ProcessVersion";

var condProcessInstanceGuid = new TWSearchCondition; 
condProcessInstanceGuid.column = colProcessInstanceGuid; 
condProcessInstanceGuid.operator = TWSearchCondition.Operations.Equals; 
condProcessInstanceGuid.value = tw.local.processGuid[tw.local.lcv];

var colDueDate = new TWSearchColumn;
colDueDate.type = TWSearchColumn.Types.ProcessInstance
colDueDate.name = TWSearchColumn.ProcessInstanceColumns.DueDate


var order1 = new TWSearchOrdering();
order1.column = colInstanceId;
order1.order = TWSearchOrdering.Orders.Ascending;


var search = new TWSearch();
search.columns = 
new Array(
  colInstanceStatus
, colInstanceId
, colProcessName
, colDueDate
, colProcessInstanceGuid
, colProcessVersion
, colInstanceName
, colTaskSubject
, colTaskID
);

//KA added preexistign condInstanceStatus to array to pull back only active
var conditions = new Array(condProcessInstanceGuid, condInstanceStatus, condProcessName);


search.conditions = conditions;


search.organizedBy = TWSearch.OrganizeByTypes.Task;
search.orderBy = new Array(order1 );
//search.orderBy = new Array(orderFieldRep, orderSequenceNumber, order1 );

tw.local.serviceOrderTasks = new tw.object.listOf.ProcessInstanceSearchResult();
var results = search.execute();

for(var i = 0; i < results.rows.length; i++) {
  var row = results.rows[i];
  tw.local.serviceOrderTasks[i] = new tw.object.ProcessInstanceSearchResult();

  if (row.values[0] != null) {  
      tw.local.serviceOrderTasks[i].processInstanceStatus = row.values[0].toString();
  } else {
      tw.local.serviceOrderTasks[i].processInstanceStatus = "Not Defined";
  }
  
  if (row.values[1] != null) {  
      tw.local.serviceOrderTasks[i].processInstanceID = row.values[1].toString();
  } else {
      tw.local.serviceOrderTasks[i].processInstanceID = "Not Defined";
  }
  if (row.values[2] != null) {
      tw.local.serviceOrderTasks[i].processDefinitionName = row.values[2].toString();
  } else {
      tw.local.serviceOrderTasks[i].processDefinitionName = "Not Defined";
  }
  if (row.values[3] != null) {
      tw.local.serviceOrderTasks[i].processInstanceCreateDate = row.values[3];
  } 
  
  if (row.values[4] != null) {
      tw.local.serviceOrderTasks[i].processGUID = row.values[4].toString();
  } else {
      tw.local.serviceOrderTasks[i].processGUID = "Not Defined";
  }
  if (row.values[5] != null) {
      tw.local.serviceOrderTasks[i].processVersion = row.values[5];
  } 
  if (row.values[6] != null) {
      tw.local.serviceOrderTasks[i].processInstanceName = row.values[6].toString();
  } else {
      tw.local.serviceOrderTasks[i].processInstanceName = "Not Defined";
  }
  if (row.values[7] != null) {
      tw.local.serviceOrderTasks[i].processTaskSubject = row.values[7].toString();
  } else {
      tw.local.serviceOrderTasks[i].processTaskSubject = "Not Defined.";
  }
  if (row.values[8] != null) {
      tw.local.serviceOrderTasks[i].processTaskID = row.values[8].toString();
  } else {
      tw.local.serviceOrderTasks[i].processTaskID = "Not Defined.";
  }
}
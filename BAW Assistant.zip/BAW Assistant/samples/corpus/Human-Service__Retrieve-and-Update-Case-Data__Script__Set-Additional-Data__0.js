if(tw.local.caseInfoResponse.businessCase != null){
    tw.local.externalProcessData.businessCase = tw.local.caseInfoResponse.businessCase;
} else {
    tw.local.externalProcessData.businessCase = new tw.object.BusinessCase();
    tw.local.externalProcessData.businessCase.employer = new tw.object.Employer();
}
/*
@dojoConfigUpdateStart 
   dojoConfig.packages.push({
      name: 'com_ibm_bpm_coach_controls',
      location: com_ibm_bpm_coach.getManagedAssetUrl('coach_ng_utilities.zip',
				com_ibm_bpm_coach.assetType_WEB, 'SYSC') + "/com_ibm_bpm_coach_controls"
   });
   dojoConfig.packages.push({
      name: 'com.ibm.bpm.coach.controls',
      location: com_ibm_bpm_coach.getManagedAssetUrl('coach_ng_utilities.zip',
				com_ibm_bpm_coach.assetType_WEB, 'SYSC') + "/com/ibm/bpm/coach/controls"
   });
@dojoConfigUpdateEnd
@layerRequiredStart
{
   "nonDebug": ["dijit/dijit_bpm",
                "dojox/dojox_bpm",
                "com_ibm_bpm_coach_controls/controls"]
}
@layerRequiredEnd
*/

if (!this.SHOW_CALENDAR) {
    this.constructor.prototype.SHOW_CALENDAR = {
    	onClick : "onClick",
    	inline : "inline",
    	never : "never"
    };

    this.constructor.prototype.CALENDAR_TYPE = {
    	gregorian : "gregorian",
    	hebrew : "hebrew",
    	islamic : "islamic"
    };

	this.constructor.prototype._formatDate = function(value) {
		if (!this._dateLocaleModule) {
			var calendarType = this.context.options && this.context.options.calendarType ? this.context.options.calendarType.get("value") : this.CALENDAR_TYPE.gregorian;
			var includeTimePicker = this.context.options && this.context.options.includeTimePicker ? this.context.options.includeTimePicker.get("value") : false;
			this._formatOptions = {};
			this._formatOptions.dateOptions = {};
			this._formatOptions.dateOptions.constraints = {};
			this._formatOptions.dateOptions.constraints.selector = 'date';
			this._formatOptions.dateOptions.constraints.fullYear = true;
			this._formatOptions.timeOptions = {};
			this._formatOptions.timeOptions.constraints = {};
			this._formatOptions.timeOptions.constraints.selector = 'time';
			this._formatOptions.timeOptions.constraints.fullYear = true;
			this._formatOptions.includeTime = includeTimePicker;

			switch(calendarType)
			{
				case this.CALENDAR_TYPE.hebrew:
					this._formatOptions.datePackage = hebrew;
					break;
				case this.CALENDAR_TYPE.islamic:
					this._formatOptions.datePackage = islamic;
					break;
				case this.CALENDAR_TYPE.gregorian:
				default:
			}

			var dateTimePattern = this.context.options && this.context.options.dateFormat && this.context.options.dateFormat.get("value")
									? this.context.options.dateFormat.get("value") : "";

			var datePattern;
			var timePattern;
			if(dateTimePattern) {
				//Assuming date time format will come in as a date pattern only, time pattern only,
				//  or a <date_pattern> <time_pattern> (separated by a space)

				var pattern = dateTimePattern;
				var datePatternRegEx = /y|M|E|e|D|d/g;
				var timePatternRegEx = /K|k|H|h|m|s|S|a/g;

				var indexOfFirstDatePatternMatch = pattern.search(datePatternRegEx);
				var indexOfFirstTimePatternMatch = pattern.search(timePatternRegEx);
				// Since some time formats can have spaces in them, check for a space, the check to see that the dateTimePattern
				// matches both the time and date patterns.
				if(indexOfFirstDatePatternMatch > -1 && indexOfFirstTimePatternMatch > -1) {
					datePattern = pattern.substring(indexOfFirstDatePatternMatch, indexOfFirstTimePatternMatch).replace(/^\s+|\s+$/g,'');
					timePattern = pattern.substring(indexOfFirstTimePatternMatch).replace(/^\s+|\s+$/g,'');
				} else {
					if(indexOfFirstDatePatternMatch > -1) {
						datePattern = pattern;
						this._formatOptions.includeTime = false;
					} else {
						timePattern = pattern;
					}
				}
			}
			if(datePattern){
				this._formatOptions.dateOptions.constraints.datePattern = datePattern;
			}
			if(timePattern){
				this._formatOptions.timeOptions.constraints.timePattern = timePattern;
			}

			var dateModule = this._formatOptions.datePackage || dojoDate;
			this._dateClassObj = dateModule.Date || Date;
			this._dateLocaleModule = this._formatOptions.datePackage ? this._formatOptions.datePackage.locale : dojoDateLocale;
			
			this._dateWithMS = new this._bpmDateWithMSMixin();
			this._dateWithMS = lang.mixin(this._dateWithMS, {
			    dateModule: dateModule,
			    _invalidDate: new Date("").toString(),
				_isInvalidDate: function(/*Date*/ value){
					// summary:
					//		Runs various tests on the value, checking for invalid conditions
					// tags:
					//		private
					return !value || isNaN(value) || typeof value != "object" || value.toString() == this._invalidDate;
				}
			});
		}
		if(!value) {
			return '';
		}
		if(value instanceof Date && !(this._dateClassObj instanceof Date)){
			value = this._dateWithMS.createDateWithMS(value);
		}
		var result = [ this._dateLocaleModule.format(value, this._formatOptions.dateOptions.constraints) ];
		if (this._formatOptions.includeTime) {
			result.push(this._dateLocaleModule.format(value, this._formatOptions.timeOptions.constraints));
		}
		return result.join(" ");
	};

	this.constructor.prototype._createControl = function() {
		var labelElement = this.context.element.getElementsByTagName("label")[0];
		var inputElement = this.context.element.querySelector("span.dateTimePickerElement");
		var dateValue = this.context.binding && ((this.context.binding.get("value") instanceof Date) || 
					 (this.context.binding.get("value") === null))? this.context.binding.get("value") : null;
		var showCalendar = this.context.options && this.context.options.showCalendar ?  this.context.options.showCalendar.get("value") : this.SHOW_CALENDAR.onClick;
		var calendarType = this.context.options && this.context.options.calendarType ? this.context.options.calendarType.get("value") : this.CALENDAR_TYPE.gregorian;
		var includeTimePicker = this.context.options && this.context.options.includeTimePicker ? this.context.options.includeTimePicker.get("value") : false;
		var dateFormat = this.context.options && this.context.options.dateFormat && this.context.options.dateFormat.get("value")
						? this.context.options.dateFormat.get("value") : "";
		var blackoutDates = this.context.options && this.context.options.blackoutDates ? this.context.options.blackoutDates.get("value") : [];
		var nlsMsgs = utilities.initLocalizedMessages(this.context);

		var args = {
			fName : "calendar",
			initialValue : dateValue,
			showCalendar : showCalendar,
			calendarType : calendarType,
			includeTimePicker : includeTimePicker,
			blackoutDates : blackoutDates,
			inputDomNode : inputElement,
			calendarIconText : nlsMsgs["DateTimePicker_CalendarIconText"],
			dateAriaText : nlsMsgs["DateTimePicker_DateAriaText"],
			timeAriaText : nlsMsgs["DateTimePicker_TimeAriaText"]
		}

		if (dateFormat) {
			args.dateTimePattern = dateFormat;
		}

		this.dateTimePickerControl = this.initDateTimePicker(args);

		//update Label htmlFor
		if (labelElement != undefined  && this.dateTimePickerControl != undefined ) {
			labelElement.id = this.context.element.id + "_label";
			this.dateTimePickerControl.set("labelledby", labelElement.id);
		}

		this.onChangeHandle = connect.connect(this.dateTimePickerControl, "onChange", this,
			function(value) {
				this.context.log("onChangeHandle", ["value: ", value]);
				if(!(typeof this.context == "undefined") &&
					!(typeof this.context.binding == "undefined") &&
					((this.context.binding.get("value") instanceof Date) || 
					 (this.context.binding.get("value") == null))){
			 
					if (this.dateTimePickerControl.isValid()){
					    var setNewVal = true;
					    //check previously stored date against the embedded date control
					    //to ensure that we do not update the binding unless it has changed.
					    if (!!this._prevDateVal) {
						    if (this.dateTimePickerControl.getValue()) {
						        if (!!this.dateTimePickerControl.getValue().toGregorian) {
						            if (this._prevDateVal == this.dateTimePickerControl.getValue().toGregorian().getTime()) {
						                setNewVal = false;
						            }
						        } else if (this._prevDateVal == this.dateTimePickerControl.getValue().getTime()) {
						            setNewVal = false;
						        }
						    }
					    } else if (this._prevDateVal == this.dateTimePickerControl.getValue()) {
					        setNewVal = false;
					    }
					    if (setNewVal) {
						    this.context.binding.set("value", this.dateTimePickerControl.getValue());
						}
					} else if (this.context.binding.get("value") != null) {
						this.context.binding.set("value", null);
					}
				}
			});

		var validDiv = this.context.element.querySelector(".coachValidationDiv");
		var img = this.context.element.querySelector(".coachValidationDiv img");
		var timeBox = this.context.element.querySelector(".dijitTimeTextBox");
		var dateBox = this.context.element.querySelector(".dijitDateTextBox");
		if (timeBox != null) {
			timeBox.parentNode.parentNode.appendChild(validDiv);
			domClass.remove(img, "smallImg");
		} else if (dateBox != null) {
			if (showCalendar == this.SHOW_CALENDAR.never) {
				var inputContainer = this.context.element.querySelector(".dijitInputContainer");
				inputContainer.parentNode.insertBefore(validDiv, inputContainer);
			} else {
				dateBox.parentNode.parentNode.appendChild(validDiv);
			}
			domClass.remove(img, "smallImg");
		}
	};

    this.constructor.prototype.commonTemplate = '' +
    	'<div class="dijit dijitReset dijitInline dijitLeft" id="widget_${id}" role="${role}">' +
    	'	<div class="dijitReset dijitRight dijitButtonNode dijitArrowButton dijitDownArrowButton dijitArrowButtonContainer"' +
    	'		data-dojo-attach-point="_buttonNode, _popupStateNode" role="presentation">' +
    	'		<input class="dijitReset dijitInputField dijitArrowButtonInner" type="image" src="${_blankGif}" alt="" tabIndex="-1" readonly="readonly" role="presentation" ${_buttonInputDisabled} />' +
    	'		<span class="dropDownText">&#9660;</span>' +
    	'	</div>' +
    	'	<div class="dijitReset dijitValidationContainer">' +
    	'		<input class="dijitReset dijitInputField dijitValidationIcon dijitValidationInner" value="&#935; " type="text" tabIndex="-1" readonly="readonly" role="presentation"/>' +
    	'	</div>' +
    	'	<div class="dijitReset dijitInputField dijitInputContainer">' +
    	'		<label data-dojo-attach-point="hiddenAriaLabel" id="widget_InputContainer_${id}_label" style="display: none;">${ariaText}</label>' +
    	'		<input class="dijitReset dijitInputInner" ${!nameAttrSetting} type="text" autocomplete="off" data-dojo-attach-point="textbox,focusNode" role="textbox" aria-haspopup="${hasDownArrow}" />' +
    	'	</div>' +
    	'</div>';

    this.constructor.prototype._bpmTimePicker = declare(_TimePicker, {
    	_showText: function(){
    		// summary:
    		//		Displays the relevant choices in the drop down list
    		// tags:
    		//		private
    		var fromIso = stamp.fromISOString;
    		this.timeMenu.innerHTML = "";
    		this._clickableIncrementDate=fromIso(this.clickableIncrement);
    		this._visibleIncrementDate=fromIso(this.visibleIncrement);
    		this._visibleRangeDate=fromIso(this.visibleRange);
    		// get the value of the increments and the range in seconds (since 00:00:00) to find out how many divs to create
    		var
    			sinceMidnight = function(/*Date*/ date){
    			return date.getHours() * 60 * 60 + date.getMinutes() * 60 + date.getSeconds();
    			},
    			clickableIncrementSeconds = sinceMidnight(this._clickableIncrementDate),
    			visibleIncrementSeconds = sinceMidnight(this._visibleIncrementDate),
    			visibleRangeSeconds = sinceMidnight(this._visibleRangeDate);
    
    		// round reference date to previous visible increment
    		
    		// this.value of dojox.date.islamic.Date type, does not have "getTime()"
    		// therefore this.value of dojox.date.islamic.Date type has to be converted to Gregorian
    		var gregorianDate;
    		if(this.value instanceof Date){
    			gregorianDate = this.value;
    		}else if(this.value instanceof dojox.date.islamic.Date || this.value instanceof dojox.date.hebrew.Date){
    			gregorianDate = this.value.toGregorian();				
    		}
    			
    		var	time = (gregorianDate || this.currentFocus).getTime();
    
    		this._refDate = new Date(time - time % (visibleIncrementSeconds*1000));
    		this._refDate.setFullYear(1970,0,1); // match parse defaults
    
    		// assume clickable increment is the smallest unit
    		this._clickableIncrement = 1;
    		// divide the visible range by the clickable increment to get the number of divs to create
    		// example: 10:00:00/00:15:00 -> display 40 divs
    		this._totalIncrements = visibleRangeSeconds / clickableIncrementSeconds;
    		// divide the visible increments by the clickable increments to get how often to display the time inline
    		// example: 01:00:00/00:15:00 -> display the time every 4 divs
    		this._visibleIncrement = visibleIncrementSeconds / clickableIncrementSeconds;
    		// divide the number of seconds in a day by the clickable increment in seconds to get the
    		// absolute max number of increments.
    		this._maxIncrement = (60 * 60 * 24) / clickableIncrementSeconds;
    
    		var
    			// Find the nodes we should display based on our filter.
    			// Limit to 10 nodes displayed as a half-hearted attempt to stop drop down from overlapping <input>.
    			after = this._getFilteredNodes(0, Math.min(this._totalIncrements >> 1, 10) - 1),
    			before = this._getFilteredNodes(0, Math.min(this._totalIncrements, 10) - after.length, true, after[0]);
    		array.forEach(before.concat(after), function(n){this.timeMenu.appendChild(n);}, this);
    	}
    });

    this.constructor.prototype._bpmDateWithMSMixin = declare(null, {
        createDateWithMS : function() {
    		var toReturn;
    		var len = arguments.length;
    		if (!len) {
    			toReturn = new Date();
    		} else if(len == 1) {
    			var arg0 = arguments[0];
    			if (!this._isInvalidDate(arg0)) {
    				var dateClassObj = this.dateModule.Date || Date;
    				toReturn = new dateClassObj(arg0.getTime());				
    			}
    		} else {
    			toReturn = new Date(arguments);
    		}
    		return toReturn;
        }
    });
    
    this.constructor.prototype._bpmTimeTextBox = declare([TimeTextBox, this._bpmDateWithMSMixin], {
    	templateString: this.commonTemplate,
    	_blankGif: require.toUrl("dojo/resources/blank.gif"),
    	role : "combobox",
    	ariaText: "time section",
    	popupClass: this._bpmTimePicker,
    	constructor: function(args) {
    		this.inherited("constructor", arguments);
    		if(args.ariaText != undefined){
    			this.ariaText = args.ariaText;
    		}
    		this.dateClassObj = lang.hitch(this, this.createDateWithMS);
    	},
    	displayMessage: function(/*String*/ message){
    		// summary:
    		//		Overridable method to display validation errors/hints.
    		//		By default uses a tooltip.
    		// tags:
    		//		extension
    		Tooltip.hide(this.domNode);
    		if(message && this.focused){
    			Tooltip.show(message, this.domNode, this.tooltipPosition, !this.isLeftToRight());
    		}
    	}
    });
    
    this.constructor.prototype._bpmDateTextBox = declare([DateTextBox, this._bpmDateWithMSMixin], {
    	templateString: this.commonTemplate,
    	_blankGif: require.toUrl("dojo/resources/blank.gif"),
    	readOnly : false,
    	disabled : false,
    	_stopClickEvents : false,
    	disabledDates : [],
    	hasDownArrow: false,
    	role : "combobox",
    	ariaText: "date section",
    	constructor: function(args) {
    		this.inherited("constructor", arguments);
    		this.disabledDates = args.blackoutDates || this.disabledDates;
    		this.readOnly = args.readOnly;
    		this.disabled = args.disabled;
    		if(args.hasDownArrow == false){
    			this.role = "textbox";
    		}
    		if(args.ariaText != undefined){
    			this.ariaText = args.ariaText;
    		}
    		this.dateClassObj = lang.hitch(this, this.createDateWithMS);;
    	},
    	displayMessage: function(/*String*/ message){
    		// summary:
    		//		Overridable method to display validation errors/hints.
    		//		By default uses a tooltip.
    		// tags:
    		//		extension
    		Tooltip.hide(this.domNode);
    		if(message && this.focused){
    			Tooltip.show(message, this.domNode, this.tooltipPosition, !this.isLeftToRight());
    		}
    	},
		rangeCheck: function(/*Date*/ date, /*dijit.form.RangeBoundTextBox.__Constraints*/ constraints){
			var datesAreEqual = this.disabledDates.items &&
				array.some(this.disabledDates.items, function(item) {
					return (item instanceof Date && date instanceof Date && 
									dojoDate.compare(item, date, "date") == 0) ||
							(item instanceof Date && date instanceof dojox.date.islamic.Date && 
									dojoDate.compare(item, date.toGregorian(), "date") == 0) ||
							(item instanceof Date && date instanceof dojox.date.hebrew.Date && 
									dojoDate.compare(item, date.toGregorian(), "date") == 0);
			});
			if (!datesAreEqual && (!!constraints.min || !!constraints.max)) {
			    return this.inherited(arguments);
			} 
			return !datesAreEqual;
		},
    	openDropDown: function(/*Function*/ callback){
    		if(this.openOnClick){
    			this.inherited(arguments);
    
    			var coachViewNode = this.domNode;
    			while (! domClass.contains(coachViewNode, "CoachView")) {
    				coachViewNode = coachViewNode.parentNode;
    			}
    			if (domClass.contains(coachViewNode, "coachValidationContainer")) {
    				domClass.add(this.dropDown.domNode.parentNode, "coachValidationContainer");
    			}
    		}
    	},
    	_disconnectAllHandlers: function(){
    		if(!lang.isArray(this._mouseUpHandles)) {
    			this._mouseUpHandles = [];
    		} else {
    			for(var index = 0; index < this._mouseUpHandles.length; index++){
    				var handle = this._mouseUpHandles[index];
    				this.disconnect(handle);
    			}
    			this._mouseUpHandles = [];		
    		}
    
    		if(!lang.isArray(this._mouseoverHandles)) {
    			this._mouseoverHandles = [];
    		} else {
    			for(var index = 0; index < this._mouseoverHandles.length; index++){
    				var handle = this._mouseoverHandles[index];
    				this.disconnect(handle);
    			}
    			this._mouseoverHandles = [];
    		}
    	},
    	_onDropDownMouseDown: function(/*Event*/ e){
    		// summary:
    		//		Callback when the user mousedown's on the arrow icon
    		if(this.disabled || this.readOnly){ return; }
    
    		// Prevent default to stop things like text selection, but don't stop propogation, so that:
    		//		1. TimeTextBox etc. can focusthe <input> on mousedown
    		//		2. dropDownButtonActive class applied by _CssStateMixin (on button depress)
    		//		3. user defined onMouseDown handler fires
    		e.preventDefault();
    
    		if(!lang.isArray(this._mouseUpHandles))
    			this._mouseUpHandles = [];
    		if(!lang.isArray(this._mouseoverHandles))
    			this._mouseoverHandles = [];
    
    		var _docHandler = this.connect(win.doc, touch.release, "_onDropDownMouseUp");
    		var _mouseoverHandler = this.connect(win.doc, "mouseover", "_disconnectAllHandlers");
    		
    		this._mouseUpHandles.push(_docHandler);
    		this._mouseoverHandles.push(_mouseoverHandler);
    		
    		this.toggleDropDown();
    	},
    	_onDropDownMouseUp: function(/*Event?*/ e){
    		if(e && this._mouseUpHandles && this._mouseUpHandles.length > 0){			
    			this._disconnectAllHandlers();
    		}
    		this.inherited(arguments);
    	}
    });
    
    this.constructor.prototype._bpmCalendar = declare(Calendar, {
    	readOnly : false,
    	disabled : false,
    	disabledDates : [],
    	constructor: function(args) {
    		this.readOnly = args.readOnly;
    		this.disabled = args.disabled;
    		this.inherited("constructor", arguments);
    		this.disabledDates = args.blackoutDates || this.disabledDates;
    		if(args.value) {
    			this.currentFocus = args.value;
    		}
    	},
    
    	postCreate : function() {
    		this.inherited(arguments);
    		this.focusNode = this.domNode;
    		this.hiddenAriaLabel = domConstruct.create("label", {id: this.id + "_hiddenAriaLabel", innerHTML: this.ariaText, style : {display : "none"}});
    	},
    
    	isDisabledDate: function(/*Date*/date, /*String?*/locale){
    		// summary:
    		// disables dates contained in disabledDates[];
    		var datesAreEqual = this.disabledDates.items &&
    			array.some(this.disabledDates.items, function(item) {
    				return (item instanceof Date && date instanceof Date && 
    								dojoDate.compare(item, date, "date") == 0) ||
    						(item instanceof Date && date instanceof dojox.date.islamic.Date && 
    								dojoDate.compare(item, date.toGregorian(), "date") == 0) ||
    						(item instanceof Date && date instanceof dojox.date.hebrew.Date && 
    								dojoDate.compare(item, date.toGregorian(), "date") == 0);
    		})
    
    		return datesAreEqual;
    	},
    
    	isValid: function() {
    		return this._isValidDate(this.get("value"));
    	}	
    });
    
    this.constructor.prototype._bpmDateTimePicker = declare([_WidgetBase, _TemplatedMixin], {
    	templateString: '' +
    	'<div dojoAttachPoint="pickerDiv" id="widget_${id}" class="BPMDateTimePicker">' +
    	'  <span class="leftPicker" dojoAttachPoint="leftPicker" style="vertical-align: top;"></span>' +
    	'  <span class="calImage" dojoAttachPoint="calImage"><span class="calImageText">&#x25A6;</span></span>' + 
    	'  <span class="rightPicker" dojoAttachPoint="rightPicker" style="vertical-align: top;"></span>' +
    	'</div>',
    
    	_blankGif: require.toUrl("dojo/resources/blank.gif"),
    	datePattern: "",
    	timePattern: "",
    	datePatternRegEx: /y|M|E|e|D|d/g,
    	timePatternRegEx: /K|k|H|h|m|s|S|a/g,
    	_SHOW_CALENDAR: this.SHOW_CALENDAR,
    	_CALENDAR_TYPE: this.CALENDAR_TYPE,
    	_localScope_bpmDateTextBox: this._bpmDateTextBox,
    	_localScope_bpmTimeTextBox: this._bpmTimeTextBox,
    	_localScope_bpmCalendar: this._bpmCalendar,
    	showDateWidget: this.SHOW_CALENDAR.onClick,
    	showTimeWidget: true,
    	readOnly : false,
    	disabled : false,
    	connectHandles: [],
    	constructor: function(args){
    		if(args.showDateWidget){
    			this.showDateWidget = args.showDateWidget;
    		}
    		if(args.dateTimePattern) {
    			//Assuming date time format will come in as a date pattern only, time pattern only,
    			//  or a <date_pattern> <time_pattern> (separated by a space)
    
    			var pattern = args.dateTimePattern;
    
    			var indexOfFirstDatePatternMatch = pattern.search(this.datePatternRegEx);
    			var indexOfFirstTimePatternMatch = pattern.search(this.timePatternRegEx);
    			// Since some time formats can have spaces in them, check for a space, the check to see that the dateTimePattern
    			// matches both the time and date patterns.
    			if(indexOfFirstDatePatternMatch > -1 && indexOfFirstTimePatternMatch > -1) {
    				this.datePattern = pattern.substring(indexOfFirstDatePatternMatch, indexOfFirstTimePatternMatch).replace(/^\s+|\s+$/g,'');
    				this.timePattern = pattern.substring(indexOfFirstTimePatternMatch).replace(/^\s+|\s+$/g,'');
    			} else {
    				if(indexOfFirstDatePatternMatch > -1) {
    					this.datePattern = pattern;
    					this.showTimeWidget = false;
    				} else {
    					this.timePattern = pattern;
    					this.showDateWidget = this._SHOW_CALENDAR.never;
    				}
    			}
    		}
    
    		var dateOptions = {};
    		var timeOptions = {};
    
    		dateOptions.readOnly = args.readOnly || this.readOnly;
    		timeOptions.readOnly = args.readOnly || this.readOnly;
    		dateOptions.disabled = args.disabled || this.disabled;
    		timeOptions.disabled = args.disabled || this.disabled;
    
    		dateOptions.constraints = {};
    		dateOptions.constraints.selector = 'date';
    		if(this.datePattern){
    			dateOptions.constraints.datePattern = this.datePattern;
    		}
    
    		timeOptions.constraints = {};
    		timeOptions.constraints.selector = 'time';
    		if(this.timePattern){
    			timeOptions.constraints.timePattern = this.timePattern;
    		}
    
    		if(args.blackoutDates){
    			dateOptions.blackoutDates = args.blackoutDates;
    		}
    		if(args.calendarIconText){
    			this.calendarIconText = args.calendarIconText;
    		} else {
    			this.calendarIconText = "Show Calendar";
    		}
    		if(args.dateAriaText){
    			dateOptions.ariaText = args.dateAriaText;
    		}
    		if(args.timeAriaText){
    			timeOptions.ariaText = args.timeAriaText;
    		}
    
    
    		// Note: do not pass args to child widgets, else we ge dup ids, and the children can't register with dijit
    		switch(args.calendarType)
    		{
    			case this._CALENDAR_TYPE.hebrew:
    				// moved to view's this.load function
    				// console.log(CALENDAR_TYPE.hebrew);
    				dateOptions.value = args.value;
    				dateOptions.datePackage = "dojox.date.hebrew";
    				break;
    
    			case this._CALENDAR_TYPE.islamic:
    				// moved to view's this.load function
    				// console.log(CALENDAR_TYPE.islamic);
    				dateOptions.value = args.value;
    				dateOptions.datePackage = "dojox.date.islamic";
    				break;
    
    			case this._CALENDAR_TYPE.gregorian:
    			default:
    				// moved to view's this.load function
    				// console.log(this._CALENDAR_TYPE.gregorian);
    				// console.log("switch default");
    		}
    
    		this._dateOptions = dateOptions;
    		this._timeOptions = timeOptions;
    	},
    
    	postCreate: function(){
    		this._dateOptions.dir = this._dateOptions.dir || utilities.BiDi.findElementDirection(this.domNode);
    		this._timeOptions.dir = this._dateOptions.dir || this._timeOptions.dir
    		
    		if(this.showDateWidget == this._SHOW_CALENDAR.inline){
    			this.dateBoxWidget = new this._localScope_bpmCalendar(this._dateOptions);
    		}else if(this.showDateWidget == this._SHOW_CALENDAR.never){
    			this._dateOptions.hasDownArrow = false;
    			this._dateOptions.openOnClick = false;
    			this.dateBoxWidget = new this._localScope_bpmDateTextBox(this._dateOptions);
    		}else{
    			this._dateOptions.openOnClick = true;
    			this.dateBoxWidget = new this._localScope_bpmDateTextBox(this._dateOptions);
    		}
    
    		this.timeBoxWidget = new this._localScope_bpmTimeTextBox(this._timeOptions);
    		this.timeBoxWidget.value = this.dateBoxWidget.value;
    	
    		this.dateBoxWidget.placeAt(this.leftPicker);
    
    		if(this.showDateWidget == this._SHOW_CALENDAR.inline) {
    			domConstruct.place(this.dateBoxWidget.hiddenAriaLabel, this.dateBoxWidget.domNode, 'before');
    		}
    
    		if(this.showTimeWidget) {
    			this.timeBoxWidget.placeAt(this.rightPicker);
    		}
    
    		if (this.showDateWidget == this._SHOW_CALENDAR.onClick || this.showDateWidget == this._SHOW_CALENDAR.inline) {
    			if(this.showDateWidget == this._SHOW_CALENDAR.inline){
    				domClass.add(this.dateBoxWidget.domNode, 'dijitInline');
    			}
    			if (this.showDateWidget == this._SHOW_CALENDAR.onClick) {
    		        this.imgWidget = domConstruct.create("img", {src: this._blankGif, className: "calImage", alt: this.calendarIconText});
    		        domConstruct.place(this.imgWidget, this.calImage);
    		        this.connectHandles.push(this.connect(this.imgWidget, "onclick", function(){
    		        	this.dateBoxWidget.focus();
    		        	this.dateBoxWidget.toggleDropDown();}
    		        ));
    			}
    			if (this.showTimeWidget) {
    				domClass.add(this.dateBoxWidget.domNode, 'dateSelectionDoubleInputTextBox');
    				domClass.add(this.timeBoxWidget.domNode, 'dateSelectionDoubleInputTextBox');
    			} else {
    				domClass.add(this.dateBoxWidget.domNode, 'dateSelectionSingleInputTextBox');
    			}
    		} else if (this.showTimeWidget) {
    			domClass.add(this.timeBoxWidget.domNode, 'dateSelectionSingleInputTextBox');
    		}
    
    		this.timeBoxWidget.startup();
    
    		this.connectHandles.push(this.connect(this.timeBoxWidget, "onChange", "internalOnChangeTime"));
    		this.connectHandles.push(this.connect(this.dateBoxWidget, "onChange", "internalOnChangeDate"));
    	},
    
    	// overwrite the attr function when someone whats to retrive the value
    	attr: function attr(name, val){
    		if (name == "value") {
    			if (val === undefined || val == "") {
    				// get value
    				var rc;
    				if (this.dateBoxWidget.value == undefined) {
    					rc = null;
    				} else if (this.dateBoxWidget.displayedValue != undefined && this.dateBoxWidget.displayedValue == "") {
    					rc = null;
    				} else {
    					if (!this.isTimeValid()) {
    						this.dateBoxWidget.value.setHours(0);
    						this.dateBoxWidget.value.setMinutes(0);
    						this.dateBoxWidget.value.setSeconds(0);
    						this.dateBoxWidget.value.setMilliseconds(0);
    					} else {
    						this.dateBoxWidget.value.setHours(this.timeBoxWidget.value.getHours());
    						this.dateBoxWidget.value.setMinutes(this.timeBoxWidget.value.getMinutes());
    						this.dateBoxWidget.value.setSeconds(this.timeBoxWidget.value.getSeconds());
    						this.dateBoxWidget.value.setMilliseconds(this.timeBoxWidget.value.getMilliseconds());
    					}
    
    					if (this.isDateValid()) {
    						this.timeBoxWidget.set("value", this.dateBoxWidget.value);
    						rc = this.dateBoxWidget.value;
    					} else {
    						rc = null;
    					}
    				}
    				return rc;
    			} else {
    				// set the date and time
    				this.timeBoxWidget.set("value", val); // time part
    				this.dateBoxWidget.set("value", val); // date part
    			}
    		}
    	},
    	isDateValid: function() {
    		if (this.dateBoxWidget.value === null) {
    			return true;
    		}
    		if (this.dateBoxWidget.value === undefined) {
    			return false;
    		}
    		
    		if(this.dateBoxWidget.value instanceof dojox.date.islamic.Date || this.dateBoxWidget.value instanceof dojox.date.hebrew.Date){
    			return !isNaN(this.dateBoxWidget.value.toGregorian().getTime());
    		}else{
    			return !isNaN(this.dateBoxWidget.value.getTime());
    		}
    	},
    	isTimeValid: function() {
    		if (this.timeBoxWidget.value == null) {
    			return false;
    		}
    					
    		if(this.timeBoxWidget.value instanceof dojox.date.islamic.Date || this.timeBoxWidget.value instanceof dojox.date.hebrew.Date){
    			return !isNaN(this.timeBoxWidget.value.toGregorian().getTime());
    		}else{
    			return !isNaN(this.timeBoxWidget.value.getTime());
    		}
    	},
    	setValue: function(value){
    		this.attr("value", value);
    	},
    	getValue: function(){
    		return this.attr("value");
    	},
    
    	isValid : function() {
    		return this.dateBoxWidget.isValid() && this.timeBoxWidget.isValid();
    	},
    
    	setDisabled : function(disabled) {
    		if (this.dateBoxWidget) this.dateBoxWidget.setDisabled(disabled);
    		if (this.timeBoxWidget) this.timeBoxWidget.setDisabled(disabled);
    	},
    
    	// overwrite validate function to toggle coach related error class
    	validate: function(isRequired) {
    		// TODO: only handle dateBox for now
    		if (this.isValid()) {
    			if (!isRequired || this.dateBoxWidget.valueNode.value > 0)
    			  switchFromErrorClass(this.dateBoxWidget.domNode);
    		} else {
    			switchToErrorClass(this.dateBoxWidget.domNode);
    		}
    		return this.dateBoxWidget.inherited(arguments);
    	},
    
    	onChange: function(value){
    		// TODO: Not really sure what purpose this has
    		// console.log("ON CHANGE");
    	},
    
    	internalOnChangeTime: function(value) {
    		if (this.isTimeValid() &&
    			this.dateBoxWidget.displayedValue != undefined && this.dateBoxWidget.displayedValue == "") {
    			// the time part is set but the date part is empty
    			this.dateBoxWidget.set("value", new Date());
    		}
    		this.internalOnChange(value);
    	},
    	internalOnChangeDate: function(value) {
    		this.internalOnChange(value);
    	},
    	internalOnChange: function(value){
    		var _this = this;
    		setTimeout(function(){
    			var gregorianValue;
    			var dateValue  = _this.attr("value");
    			if(dateValue instanceof Date){
    				gregorianValue = dateValue;
    			}else if(dateValue instanceof dojox.date.islamic.Date || 
    					dateValue instanceof dojox.date.hebrew.Date){
    				gregorianValue = dateValue.toGregorian();				
    			}
    			_this.onChange(gregorianValue);
    		},0);
    	},
    	_setReadOnlyAttr: function(/*Boolean*/ value){
    		if(this.dateBoxWidget instanceof this._localScope_bpmDateTextBox) {
    			this.dateBoxWidget._setReadOnlyAttr(value);
    		}
    		this.timeBoxWidget._setReadOnlyAttr(value);
    	},
    
    	_setDisabledAttr: function(/*Boolean*/ value){
    		if(this.dateBoxWidget instanceof this._localScope_bpmDateTextBox) {
    			this.dateBoxWidget._setDisabledAttr(value);
    		}
    		this.timeBoxWidget._setDisabledAttr(value);
    	},
    
    	_setRequiredAttr: function(/*Boolean*/ value){
    		if(this.dateBoxWidget instanceof this._localScope_bpmDateTextBox) {
    			this.dateBoxWidget._setRequiredAttr(value);
    		}
    		this.timeBoxWidget._setRequiredAttr(value);
    	},
    
    	_setLabelledbyAttr: function(/*String*/ value) {
    		if(this.dateBoxWidget instanceof this._localScope_bpmDateTextBox ||
    			this.dateBoxWidget instanceof this._localScope_bpmCalendar)
    		{
    			var ariaData = domAttr.get(this.dateBoxWidget.focusNode, "aria-labelledby");
    			ariaData = (ariaData != undefined) ? " " + ariaData : "";
    			domAttr.set(this.dateBoxWidget.focusNode, "aria-labelledby", this.dateBoxWidget.hiddenAriaLabel.id + " " + value + ariaData);
    		}
    		domAttr.set(this.timeBoxWidget.focusNode, "aria-labelledby", this.timeBoxWidget.hiddenAriaLabel.id + " " + value);
    	},
    	
    	destroy: function() {
    		for (var i=0; i<this.connectHandles.length; i++) {
    			connect.disconnect(this.connectHandles[i]);
    		}
    		if (!!this.dateBoxWidget && !!this.dateBoxWidget.destroy) {
    			this.dateBoxWidget.destroy();
    		}
    		if (!!this.timeBoxWidget && !!this.timeBoxWidget.destroy) {
    			this.timeBoxWidget.destroy();
    		}
    		this.inherited(arguments);
    	}
    });

    this.constructor.prototype.initDateTimePicker = function(args) {
        var nameAttribute = args.fName;
    	var valueAttribute = args.initialValue;
    	var datePattern = args.dateTimePattern;
    	this.context.log("initDateTimePicker", ["calendarType: ", args.calendarType]);
    	
        var dateWidget = new this._bpmDateTimePicker({
            name: nameAttribute,
            dateTimePattern: datePattern,
            boundToDate: true,
    		value: valueAttribute,
    		blackoutDates : args.blackoutDates,
    		showDateWidget: args.showCalendar,
    		showTimeWidget: args.includeTimePicker,
    		calendarType : args.calendarType,
    		dateAriaText : args.dateAriaText,
    		timeAriaText : args.timeAriaText
           }, args.inputDomNode);
    
        dateWidget.attr("value", valueAttribute);
    
    	dateWidget.startup();
    	return dateWidget;
    }
    //function to reset the date/time widget(s)
    this.constructor.prototype._resetWidgets = function() {
	//This function reverts the control back to its original state (used when a structural config option changes after 
	//the initial load). It does this by destroying any created widgets resetting any state variables and resetting
	//the dom structure back to the original state.

	this._dateLocaleModule = null;
	if (!!this.dateTimePickerControl && !!this.dateTimePickerControl.destroyRecursive) {
		this.dateTimePickerControl.destroyRecursive();
	}
	this.dateTimePickerControl = null;
	if (!!this.validateTooltip && !!this.validateTooltip.destroyRecursive) {
		this.validateTooltip.destroyRecursive();
	}
	this.validateTooltip = null;
	
	if (this.onChangeHandle) {
		connect.disconnect(this.onChangeHandle);
	}

	//reset to the original DOM
	this.context.element.innerHTML = this._originalDOM;
    }
}
tw.local.errorMessage="";
if(tw.local.taskName==tw.resource.TaskNames.ClaimsSetUp){
    if(tw.local.referalSelected==null){
       tw.local.errorMessage= "Select a Referral Group";
    }else if(tw.local.referalSelected.value==""){
        tw.local.errorMessage="Select a Referral Group";
    }
}else if(tw.local.taskName==tw.resource.TaskNames.FinalizeClaims){ 
    if(tw.local.referalSelected==undefined){
        tw.local.referalSelected=new tw.object.NameValuePair();
    }
}
else if(tw.local.taskName==tw.resource.TaskNames.ClaimsApproval){ 
    for(var i=0;i<tw.local.claimantsSelectedForApproval.listLength;i++){
        if(tw.local.claimantsSelectedForApproval[i].approvalSent==""){
            tw.local.errorMessage="You need to take action to proceed";
            break;
        }
    }
    if(tw.local.errorMessage==""){
        for(var i =0;i<tw.local.claimantsSelectedForApproval.listLength;i++){
            for(var j=0;j<tw.local.claimantDetails.listLength;j++){
                if(tw.local.claimantsSelectedForApproval[i].claimantName==tw.local.claimantDetails[j].claimantName && tw.local.claimantsSelectedForApproval[i].policyNumber==tw.local.claimantDetails[j].policyNumber){
                    if(tw.local.claimantsSelectedForApproval[i].approvalSent=="Yes"){
                        tw.local.claimantDetails[j].paymentStatus="Disbursement in Progress";
                       // tw.local.claimantDetails[j].save();
                    }else if(tw.local.claimantsSelectedForApproval[i].approvalSent=="No"){
                        tw.local.claimantDetails[j].paymentStatus="Not Approved";
                      //  tw.local.claimantDetails[j].save();
                    }
                }
            }
         }
     }  
}else if(tw.local.taskName==tw.resource.TaskNames.ClaimsExamine){
    if(tw.local.claimantDetails.listLength==0){
       tw.local.errorMessage="You need to add at least one claimant to complete";
    }
    else{
    for(var i=0;i<tw.local.claimantDetails.listLength;i++){
        if(tw.local.claimantDetails[i].paymentStatus!="Paid"){
            tw.local.errorMessage="Payment for all claimants should be in Paid status to proceed";
        }   
    }
 }
}
else if(tw.local.taskName==tw.resource.TaskNames.ReinsuranceClaim){
    if(tw.local.reinsuranceTaskList.listAllSelected.listLength!=4){
        tw.local.errorMessage="Please check all checkboxes before completing the task";
    }
    for(var i=0;i<tw.system.currentProcessInstance.tasks.length;i++){
        var taskSubject = tw.system.currentProcessInstance.tasks[i].subject;
        var taskStatus = tw.system.currentProcessInstance.tasks[i].status;
        var subject = taskSubject.split("|");
        var taskName = subject[0];
        if((taskName==tw.resource.TaskNames.FinalizeClaims||taskName==tw.resource.TaskNames.ClaimsExamine) && taskStatus!="Closed"){
            tw.local.errorMessage="Claim Process is in Progress";
            break;
        }
    }
         
}

else if(tw.local.taskName==tw.resource.TaskNames.ClaimsApprovalReject){
         if(tw.local.claimantSelectedForApprovalReject.approverLevel==null){
       tw.local.errorMessage= "Please select Approver Level to proceed";
    }else if(tw.local.claimantSelectedForApprovalReject.approverLevel.value==""){
        tw.local.errorMessage="Please select Approver Level to proceed";
    }
  
}
else if(tw.local.taskName==tw.resource.TaskNames.ClaimsResearch){
    if(tw.local.createSetUpClaimsTask == null || tw.local.createSetUpClaimsTask == undefined || tw.local.createSetUpClaimsTask == ''){
        tw.local.errorMessage= "Please select a decision to create Set Up Claim Task";
    }
}

if(tw.local.taskName==tw.resource.TaskNames.DisburseBenefit){

        if(tw.local.errorMessage==""){
        for(var i =0;i<tw.local.claimantsSelectedForDisbursement.listLength;i++){
            for(var j=0;j<tw.local.claimantDetails.listLength;j++){
                if(tw.local.claimantsSelectedForDisbursement[i].claimantName==tw.local.claimantDetails[j].claimantName && tw.local.claimantsSelectedForDisbursement[i].policyNumber==tw.local.claimantDetails[j].policyNumber){
                  tw.local.claimantDetails[j].paymentStatus="Paid";
                       
                    }
            }
         }
       }  
}


tw.local.claims = new tw.object.Claims();
tw.local.claims.process= new tw.object.Process();
tw.local.claims.reinsurancePolicies=new tw.object.listOf.String();
tw.local.claims.reinsuranceGuids=new tw.object.listOf.String();
tw.local.claims.process.commonProcessContext = new tw.object.CommonProcessContext();
tw.local.claims.process.commonProcessContext.processInstanceGuid =tw.system.process.instanceId;
tw.local.claims.process.commonProcessContext.processName = tw.system.model.processApp.acronym;

tw.local.claims.process.displayProcessName ='Life Admin Claims Process';
tw.local.claims.process.lineOfBusiness = 'L';
tw.local.claims.isFromFinalizeClaims=false;

tw.local.claims.process.worklistData = new tw.object.WorklistData();
tw.local.claims.process.worklistData.primaryPolicyNumber = "";
tw.local.claims.process.worklistData.caseCount = 0;
tw.local.claims.process.worklistData.insuredName = "";
tw.local.claims.process.worklistData.fieldOfficeNumber = "";
tw.local.claims.process.worklistData.faceAmount = 0.0;
tw.local.claims.process.worklistData.employerName = "";
tw.local.claims.process.worklistData.assignedTeam = 0;
tw.local.claims.process.worklistData.netAmountAtRisk = 0;
tw.local.claims.process.worklistData.transactionCntlID =77795;

tw.local.claims.process.instanceName = tw.system.currentProcessInstance.name;
tw.local.instanceName = tw.local.claims.process.instanceName;
tw.local.retryCounter = 0;
tw.local.claims.transactionControlId=77795;
tw.local.claims.claimantsDetails= new tw.object.listOf.claimantDetails();
tw.local.claims.approvalRejectTaskGuidMap = new tw.object.listOf.NameValuePair();

tw.local.transactionDeletedStatusCode=3;

tw.local.claims.isLastDisbursementTask=false;
tw.local.claims.isVariableProduct=false;
tw.local.isResearchTaskToBeCreated=false;
PFGBPM.INDBPM.Log.info("Reinsurance guid: "+tw.local.reinsuranceTaskGuids[tw.local.guidCounter]);
tw.local.guidCounter++;
tw.local.policyList=new tw.object.listOf.String();
for(var i=0;i<tw.local.externalProcessData.cases.listLength;i++){
    if(tw.local.externalProcessData.cases[i].currentCaseIndicator == true)
    {
        tw.local.policyList[i] = tw.local.cases[i].policyNumber;
    }
    if(tw.local.externalProcessData.cases[i].proposedInsured[0].lastName !=""){
        tw.local.insuredName=tw.local.externalProcessData.cases[i].proposedInsured[0].firstName + ", " + tw.local.externalProcessData.cases[i].proposedInsured[0].lastName;
    }
}
tw.local.followUpDate = new TWDate();
var maxDays = 30;
tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+maxDays);



var fpDate = tw.local.followUpDate.format("MM/dd/yyyy");

if(tw.local.followUpDate.getDay()!=1 && tw.local.followUpDate.getDay() != 7){
  for(var i=0;i<tw.local.pfgHolidays.listLength;i++){
    if(tw.local.pfgHolidays[i] == fpDate ){
        tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+1);
        fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
         }
          
       if(tw.local.followUpDate.getDay() == 1){
           tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+1);
           fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
        }
        else if(tw.local.followUpDate.getDay() == 7){
            tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+2);
            fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
        } 
           break;
     }
}
  if(tw.local.followUpDate.getDay() == 1){
     tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+1);
     fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
     for(var i=0;i<tw.local.pfgHolidays.listLength;i++){
         if(tw.local.pfgHolidays[i] == fpDate){
                    tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+1);
                    fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
                    break;
                }
            }     
    }
 else if(tw.local.followUpDate.getDay() == 7){
    tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+2);
    fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
    for(var i=0;i<tw.local.pfgHolidays.listLength;i++){
        if(tw.local.pfgHolidays[i] == fpDate ){
              tw.local.followUpDate.setDate(tw.local.followUpDate.getDate()+1);
                fpDate=tw.local.followUpDate.format("MM/dd/yyyy");
                 break;
             }
         }   
    }        
        

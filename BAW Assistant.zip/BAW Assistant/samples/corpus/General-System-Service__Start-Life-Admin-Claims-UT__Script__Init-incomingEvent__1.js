tw.local.initialIncomingEvent = new tw.object.IncomingEvent();
tw.local.initialIncomingEvent.businessData = new tw.object.EventBusinessData();
tw.local.initialIncomingEvent.businessData.cases = new tw.object.listOf.Case();
tw.local.initialIncomingEvent.businessData.cases[0] = new tw.object.Case();

tw.local.initialIncomingEvent.businessData.cases[0].policyNumber = "4000250";
tw.local.initialIncomingEvent.businessData.cases[0].fieldOfficeNumber = "0001";
tw.local.initialIncomingEvent.businessData.cases[0].proposedInsured = new tw.object.listOf.ProposedInsured();
tw.local.initialIncomingEvent.businessData.cases[0].proposedInsured[0] = new tw.object.ProposedInsured();
tw.local.initialIncomingEvent.businessData.cases[0].proposedInsured[0].clientId = "1324567";
tw.local.initialIncomingEvent.businessData.cases[0].proposedInsured[0].firstName = "JOHN";
tw.local.initialIncomingEvent.businessData.cases[0].proposedInsured[0].lastName = "SMITH";

tw.local.initialIncomingEvent.businessData.businessCase = new tw.object.BusinessCase();
tw.local.initialIncomingEvent.businessData.businessCase.employer = new tw.object.Employer();

tw.local.initialIncomingEvent.documentData = new tw.object.EventDocumentData();
tw.local.initialIncomingEvent.documentData.virtualStatusUpdated = false;
tw.local.initialIncomingEvent.documentData.noteInfo = new tw.object.Note();
tw.local.initialIncomingEvent.documentData.noteInfo.createdBy = "System";
tw.local.initialIncomingEvent.documentData.noteInfo.text = "test note";
tw.local.initialIncomingEvent.documentData.documents = new tw.object.listOf.Document();
tw.local.initialIncomingEvent.documentData.documents[0] = new tw.object.Document();
tw.local.initialIncomingEvent.documentData.documents[0].docTypeCode = "custinqr";
tw.local.initialIncomingEvent.documentData.documents[0].policyList = new tw.object.listOf.String();
tw.local.initialIncomingEvent.documentData.documents[0].policyList[0] = "4000253";
tw.local.initialIncomingEvent.documentData.documents[0].clientList = new tw.object.listOf.String();
tw.local.initialIncomingEvent.documentData.documents[0].clientList[0] = "1234567";
tw.local.initialIncomingEvent.documentData.documents[0].insuredName = "First Last";
tw.local.initialIncomingEvent.documentData.documents[0].pageCount = "2";
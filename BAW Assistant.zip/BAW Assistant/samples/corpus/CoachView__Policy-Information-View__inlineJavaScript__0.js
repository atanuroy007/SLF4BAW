.policyTable{
    max-height:125px;
}

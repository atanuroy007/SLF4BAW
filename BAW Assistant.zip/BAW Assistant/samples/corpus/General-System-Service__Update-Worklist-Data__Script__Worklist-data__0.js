
tw.local.worklist = new tw.object.WorklistData();

tw.local.worklist.transactionCntlID=77795;
tw.local.worklist.primaryPolicyNumber = tw.local.primaryPolicyCase.policyNumber;

tw.local.worklist.caseCount = tw.local.caseCount;
    
if (tw.local.primaryPolicyCase.fieldOfficeNumber != null){
    tw.local.worklist.fieldOfficeNumber = tw.local.primaryPolicyCase.fieldOfficeNumber;
    tw.local.externalProcessData.primaryFieldOfficeNumber = tw.local.worklist.fieldOfficeNumber;
}else{
    if(tw.local.externalProcessData.primaryFieldOfficeNumber != null){
        tw.local.worklist.fieldOfficeNumber = tw.local.externalProcessData.primaryFieldOfficeNumber;
    }else{
        tw.local.worklist.fieldOfficeNumber = "00000";
    }
}
if(tw.local.primaryPolicyCase.faceAmount != null)        
    tw.local.worklist.faceAmount = tw.local.primaryPolicyCase.faceAmount;
else
    tw.local.primaryPolicyCase.faceAmount =0;
    
if(tw.local.externalProcessData.netAmountAtRisk != null)        
    tw.local.worklist.netAmountAtRisk = tw.local.externalProcessData.netAmountAtRisk;
else
    tw.local.worklist.netAmountAtRisk =0;

if(tw.local.externalProcessData.diCUPA != null)        
    tw.local.worklist.diCUPA = tw.local.externalProcessData.diCUPA;
else
    tw.local.worklist.diCUPA =0;

if(tw.local.externalProcessData.oeblpCUPA != null)        
    tw.local.worklist.oeblpCUPA = tw.local.externalProcessData.oeblpCUPA;
else
    tw.local.worklist.oeblpCUPA =0;

if(tw.local.externalProcessData.dbokprCUPA != null)        
    tw.local.worklist.dbokprCUPA = tw.local.externalProcessData.dbokprCUPA;
else
    tw.local.worklist.dbokprCUPA =0;

if(tw.local.caseCount>1){
if (tw.local.primaryPolicyCase.proposedInsured[0] != null && tw.local.primaryPolicyCase.proposedInsured.listLength != null) {
    if (tw.local.primaryPolicyCase.proposedInsured.listLength > 1){
        tw.local.worklist.insuredName = tw.local.primaryPolicyCase.proposedInsured[0].lastName + ", " + tw.local.primaryPolicyCase.proposedInsured[0].firstName + " + ";
    }else {
        tw.local.worklist.insuredName = tw.local.primaryPolicyCase.proposedInsured[0].lastName + ", " + tw.local.primaryPolicyCase.proposedInsured[0].firstName;
    } 
     }
    tw.local.worklist.insuredName= tw.local.worklist.insuredName ;
}
else
{
 if (tw.local.primaryPolicyCase.proposedInsured[0] != null && tw.local.primaryPolicyCase.proposedInsured.listLength != null) {
    if (tw.local.primaryPolicyCase.proposedInsured.listLength > 1){
        tw.local.worklist.insuredName = tw.local.primaryPolicyCase.proposedInsured[0].lastName + ", " + tw.local.primaryPolicyCase.proposedInsured[0].firstName + " + ";
    }else {
        tw.local.worklist.insuredName = tw.local.primaryPolicyCase.proposedInsured[0].lastName + ", " + tw.local.primaryPolicyCase.proposedInsured[0].firstName;
    } 
   }
}

//tw.local.workList.insuredName = tw.local.workList.insuredName +"+"+ extraPolicyNoCount.toString();

tw.local.worklist.assignedTeam = tw.local.externalProcessData.assignedTeamCode;
if (tw.local.externalProcessData.businessCase != null){
    if (tw.local.externalProcessData.businessCase.employer != null){
        tw.local.worklist.employerName = tw.local.externalProcessData.businessCase.employer.employerName;   
    }
}

if(tw.local.externalProcessData.cwaInd != null && tw.local.externalProcessData.cwaInd == 'Y'){
     tw.local.worklist.cashWithAppInd = tw.local.externalProcessData.cwaInd;
}else
    tw.local.worklist.cashWithAppInd = 'N';

if(tw.local.externalProcessData.transControlId != null){
     tw.local.worklist.transactionCntlID = tw.local.externalProcessData.transControlId;
}


if(tw.local.primaryPolicyCase.product.productCode!=null){
      if(tw.local.caseCount>1){
       tw.local.worklist.productName=tw.local.primaryPolicyCase.product.productCode +"+";
      }
      else{
      tw.local.worklist.productName=tw.local.primaryPolicyCase.product.productCode ;
      }
 } 
   
 


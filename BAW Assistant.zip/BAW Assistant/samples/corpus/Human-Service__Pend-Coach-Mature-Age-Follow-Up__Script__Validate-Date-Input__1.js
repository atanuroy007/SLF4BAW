tw.local.errorMessage="";
var followupTime = new Date();
var currentDate = new Date();
var currentTime = new Date(); 
tw.local.currentDate = new TWDate();
var maxPendTime = new Date();

maxPendTime.setTime(tw.local.maxFollowupDate);
 
if (typeof tw.local.followupDate == "undefined"){
    tw.local.errorMessage = "Please enter a follow up date.";
}else{
    followupTime.setTime(tw.local.followupDate);
    currentTime.setTime(currentDate);
    var fpDate = tw.local.followupDate.format("MM/dd/yyyy");
    if (((followupTime - currentTime) < 1800000) || (followupTime > maxPendTime))
        {
            tw.local.errorMessage = "Follow up date/time should be between 30 minutes and " + tw.epv.LASRVCE_Process.maxPendDays + " calendar days ahead of current date/time.";
        }
        else if(tw.local.followupDate.getDay() == 1)
        {
            tw.local.errorMessage = fpDate + " is a Sunday. Please choose another day.";
        }
        else if(tw.local.followupDate.getDay() == 7)
        {
            tw.local.errorMessage = fpDate + " is a Saturday. Please choose another day.";
        }       
        else if(tw.local.errorMessage == "")
        {
            for(var i=0;i<tw.local.holidays.listLength;i++)
            {
                if(tw.local.holidays[i] == fpDate)
                {
                    tw.local.errorMessage = fpDate + " is a PFG holiday. Please choose another day.";
                    break;
                }
            }
        }       
        
}


tw.local.errorMessage="";

if(tw.local.notesData.newNoteText.length>1000){
        tw.local.errorMessage="The maximum limit is 1000 characters";
    }
tw.local.docLauncherAutoOpen.displayDocLauncher = false;
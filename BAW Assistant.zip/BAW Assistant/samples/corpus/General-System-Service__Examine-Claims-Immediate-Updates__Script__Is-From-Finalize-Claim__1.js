if(tw.local.isFromFinalizeClaim==true){
tw.local.taskstatus=tw.resource.TaskStatusCodes.Ready;
}
else{
tw.local.taskstatus=tw.resource.TaskStatusCodes.Pended;

}
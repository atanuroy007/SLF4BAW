if(tw.local.caseInfoResponse == null){
    PFGBPM.INDBPM.Log.info("Instance ID: " + tw.system.currentProcessInstance.id
    + ", Instance GUID: " + tw.local.processInstanceGuid 
    + ", Get Case Info IS response is null. getHoldings Call Could be Broken. "
    + "Input1 policyNumbers= " + tw.local.policyNumbers + ", Input2 regionId= " + tw.local.regionId + ", End log entry...");
}
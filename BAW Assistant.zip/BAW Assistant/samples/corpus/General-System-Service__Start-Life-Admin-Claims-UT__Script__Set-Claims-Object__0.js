tw.local.claims = new tw.object.Claims();
tw.local.claims.process= new tw.object.Process();

tw.local.claims.process.commonProcessContext = new tw.object.CommonProcessContext();
tw.local.claims.process.commonProcessContext.processInstanceGuid = "40000"
tw.local.claims.process.commonProcessContext.processName = tw.system.model.processApp.acronym;

tw.local.claims.process.displayProcessName ='Life Admin Claims Process';
tw.local.claims.process.lineOfBusiness = 'L';

tw.local.claims.process.worklistData = new tw.object.WorklistData();
tw.local.claims.process.worklistData.primaryPolicyNumber = "";
tw.local.claims.process.worklistData.caseCount = 0;
tw.local.claims.process.worklistData.insuredName = "";
tw.local.claims.process.worklistData.fieldOfficeNumber = "";
tw.local.claims.process.worklistData.faceAmount = 0.0;
tw.local.claims.process.worklistData.employerName = "";
tw.local.claims.process.worklistData.assignedTeam = 0;
tw.local.claims.process.worklistData.netAmountAtRisk = 0;
tw.local.claims.process.worklistData.transactionCntlID = 0;
tw.local.retryCounter = 0;
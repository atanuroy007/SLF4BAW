.button{
   width:15%;
   
}
.BPMButton{
    width:170px;
}
tw.local.claimantDetails.listClearAllSelected();
for (var i=0;i<tw.local.claimantDetails.listLength;i++){
     tw.local.claimantDetails[i].approverLevel= new tw.object.NameValuePair();
     tw.local.claimantDetails[i].approvalType="";
     tw.local.claimantDetails[i].approverLevel.name="";
}

tw.local.docLauncherAutoOpen.displayDocLauncher = false;
tw.local.policyInformationViewData = new tw.object.listOf.PolicyInformationViewData();
tw.local.policyList = new tw.object.listOf.String();

for(var i=0;i<tw.local.externalProcessData.cases.listLength;i++){
    tw.local.policyInformationViewData[i] = new tw.object.PolicyInformationViewData();
    tw.local.policyInformationViewData[i].policyNumber = tw.local.externalProcessData.cases[i].policyNumber;
    tw.local.policyList[i] = tw.local.externalProcessData.cases[i].policyNumber;
    tw.local.policyInformationViewData[i].insuredNames = new tw.object.listOf.Insured();
    for(var j=0;j<tw.local.externalProcessData.cases[i].proposedInsured.listLength;j++){
        var insured = new tw.object.Insured();
        insured.name = tw.local.externalProcessData.cases[i].proposedInsured[j].lastName + ", " + tw.local.externalProcessData.cases[i].proposedInsured[j].firstName;
        tw.local.policyInformationViewData[i].insuredNames[j] = insured;
    }    
}
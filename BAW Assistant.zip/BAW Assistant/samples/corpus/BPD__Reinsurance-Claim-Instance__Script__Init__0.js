tw.local.reinsuranceClaimDetails=new tw.object.ReinsuranceClaimDetails();
tw.local.reinsuranceClaimDetails.worklistData=new tw.object.WorklistData();
tw.local.reinsuranceClaimDetails.worklistData=tw.local.claims.process.worklistData;
tw.local.instanceName="Reinsurance Claim-"+tw.local.reinsurancePolicyInformation.policyNumber;
tw.local.displayProcessName="Life Admin Claims Process";
tw.local.lineOfBusiness="L";
tw.local.processCreationDate=tw.local.claims.process.processCreationDate;
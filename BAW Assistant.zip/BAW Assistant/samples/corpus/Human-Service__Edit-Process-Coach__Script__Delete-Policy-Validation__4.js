if(tw.local.policyInformationViewData.listSelected==null){
    tw.local.errorMessage="Select a policy to delete.";
}else if(tw.local.policyInformationViewData.listLength==1){
    tw.local.errorMessage="There should be atleast one policy in the list to process the request.";
}
if(tw.local.policyInformationViewData.listSelected!=null){
for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
    if(tw.local.policyInformationViewData.listSelected.policyNumber==tw.local.claims.claimantsDetails[i].policyNumber) {
        if(tw.local.claims.claimantsDetails[i].paymentStatus=="Approval in Progress" || tw.local.claims.claimantsDetails[i].paymentStatus=="Paid" ||
            tw.local.claims.claimantsDetails[i].paymentStatus=="Disbursement in Progress" || tw.local.claims.claimantsDetails[i].paymentStatus=="Not Approved"){
              tw.local.errorMessage="You cannot delete this policy number as the task is in progress";   
              break;   
        }
    }
}
}
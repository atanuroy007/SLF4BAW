tw.system.coachValidation = new tw.object.CoachValidation();
tw.system.coachValidation.validationErrors = new tw.object.listOf.CoachValidationError();

if(tw.local.firstName == ""){
    tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.firstName", "This is a required field.");
}else{
    if (!tw.local.firstName.match(/^[a-zA-Z]*$/)){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.firstName", "This field contains non alpha characters");
    }
}

if(tw.local.lastName == ""){
    tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.lastName", "This is a required field.");
}else{
     if (!tw.local.lastName.match(/^[a-zA-Z]*$/)){
         tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.lastName", "This field contains non alpha characters");
     }
}

if(tw.local.policyTiedToClaimant == ""){
    tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.policyTiedToClaimant", "Please select the policy number");
}  

if(tw.local.firstName!="" && tw.local.lastName!="" && tw.local.policyTiedToClaimant!=""){
    var claimantName = tw.local.firstName+ ", " +tw.local.lastName;
    for(var i=0;i<tw.local.claimantDetails.listLength;i++){
        if(tw.local.claimantDetails[i].policyNumber==tw.local.policyTiedToClaimant && tw.local.claimantDetails[i].claimantName.toLowerCase()== claimantName.toLowerCase()){
            tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.policyTiedToClaimant", "There should not be a duplicate entry");
        }
    }  
}    
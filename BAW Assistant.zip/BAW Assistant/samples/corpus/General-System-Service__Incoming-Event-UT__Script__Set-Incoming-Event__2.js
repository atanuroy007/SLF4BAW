tw.local.incomingEventXml
<variable type="IncomingEvent">
  <eventType type="String" />
  <businessData type="EventBusinessData">
    <applicationSource type="String"><![CDATA[Indexing]]></applicationSource>
    <businessCase type="BusinessCase">
      <businessCaseTypeIndicator type="String" />
      <employer type="Employer" />
    </businessCase>
    <cases type="Case[]">
      <item>
        <policyNumber type="String"><![CDATA[4000250]]></policyNumber>
        <currentCaseIndicator type="Boolean"><![CDATA[true]]></currentCaseIndicator>
        <appSignedDate type="Date"><![CDATA[2015/05/19 02:32:38.761 CDT]]></appSignedDate>
        <fieldOfficeNumber type="String"><![CDATA[12345]]></fieldOfficeNumber>
        <owner type="Owner">
          <ownerFirstName type="String"><![CDATA[JOHN]]></ownerFirstName>
          <ownerLastName type="String"><![CDATA[WASHINGTON]]></ownerLastName>
        </owner>
        <proposedInsured type="ProposedInsured[]">
          <item>
            <clientId type="String"><![CDATA[4072940]]></clientId>
            <firstName type="String"><![CDATA[JOHN]]></firstName>
            <lastName type="String"><![CDATA[WASHINGTON]]></lastName>
          </item>
        </proposedInsured>
      </item>
    </cases>
  </businessData>
  <documentData type="EventDocumentData">
    <packetFolderId type="String"><![CDATA[98865B12A283EC3501F7CDC77CCF95EF]]></packetFolderId>
    <virtualStatusUpdated type="Boolean"><![CDATA[true]]></virtualStatusUpdated>
    <documents type="Document[]">
      <item>
        <docTypeCode type="String"><![CDATA[billings]]></docTypeCode>
        <policyList type="String[]">
          <item><![CDATA[4000250]]></item>
        </policyList>
        <requirementInformation type="RequirementInformation" />
      </item>
      <item>
        <docTypeCode type="String"><![CDATA[abcdef]]></docTypeCode>
        <policyList type="String[]">
          <item><![CDATA[4002367]]></item>
        </policyList>
        <requirementInformation type="RequirementInformation" />
      </item>
    </documents>
  </documentData>
</variable>
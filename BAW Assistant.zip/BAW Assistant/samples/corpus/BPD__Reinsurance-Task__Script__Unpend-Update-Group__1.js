var reinsuranceTask = tw.system.findTaskByID(tw.local.lastTask);
if(reinsuranceTask.subject.search("Pend")==-1){
    tw.local.pendStatus=false;
}else{   
    reinsuranceTask.reassignBackToRole();
    tw.local.pendStatus=true;
}




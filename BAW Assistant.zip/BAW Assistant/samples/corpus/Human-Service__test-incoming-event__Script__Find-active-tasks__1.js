tw.local.taskCount=tw.system.currentProcessInstance.tasks.length;

PFGBPM.INDBPM.Log.info("In find Active Tasks: task count "+tw.local.taskCount);

tw.local.unpendTask=false;
for(var i=0;i<tw.system.currentProcessInstance.tasks.length;i++){
    tw.local.taskSubject=tw.system.currentProcessInstance.tasks[i].subject;
    if (tw.local.taskSubject != null && tw.local.taskSubject != ""){
        var subject = tw.local.taskSubject.split("|");
        var j=0;
        tw.local.taskName = subject[j++];
        tw.local.taskState = subject[j++];
        PFGBPM.INDBPM.Log.info("taskName: "+tw.local.taskName+"taskState: "+tw.local.taskState);
    }
    if(tw.local.taskState=="Pend" && (tw.local.taskName=="SetUp Claim" || tw.local.taskName=="Examine Claim" || tw.local.taskName=="Finalize Claim")){
        tw.local.unpendTask=true;
        PFGBPM.INDBPM.Log.info("unpendTask: "+tw.local.unpendTask);
        break;
    }
}
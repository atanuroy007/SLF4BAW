if(tw.local.saveButton==true && tw.local.policyList.listLength==0){
         tw.local.error="Enter valid policy information";
}

tw.local.disburseBenefitTriggerDate = new TWDate();
tw.local.disburseBenefitTriggerDate.setDate(tw.local.disburseBenefitTriggerDate.getDate() +1);
tw.local.disburseBenefitTriggerDate.setHours(4);
tw.local.disburseBenefitTriggerDate.setMinutes(0);
tw.local.disburseBenefitTriggerDate.setSeconds(0);
tw.local.disburseBenefitTriggerDate.setMilliseconds(0);

if(tw.local.disburseBenefitTriggerDate.getDay() == 1){
   tw.local.disburseBenefitTriggerDate.setDate(tw.local.disburseBenefitTriggerDate.getDate() + 1); 
   tw.local.disburseBenefitTriggerDate.setHours(4);
   tw.local.disburseBenefitTriggerDate.setMinutes(0);
   tw.local.disburseBenefitTriggerDate.setSeconds(0);
   tw.local.disburseBenefitTriggerDate.setMilliseconds(0);
}
if(tw.local.disburseBenefitTriggerDate.getDay() == 7){
   tw.local.disburseBenefitTriggerDate.setDate(tw.local.disburseBenefitTriggerDate.getDate() + 2); 
   tw.local.disburseBenefitTriggerDate.setHours(4);
   tw.local.disburseBenefitTriggerDate.setMinutes(0);
   tw.local.disburseBenefitTriggerDate.setSeconds(0);
   tw.local.disburseBenefitTriggerDate.setMilliseconds(0);
}
var fpDate = tw.local.disburseBenefitTriggerDate.format("MM/dd/yyyy");
for(var i=0;i<tw.local.holidays.listLength;i++){
    if(tw.local.holidays[i] == fpDate){
        tw.local.disburseBenefitTriggerDate.setDate(tw.local.disburseBenefitTriggerDate.getDate() + 1); 
        tw.local.disburseBenefitTriggerDate.setHours(4);
        tw.local.disburseBenefitTriggerDate.setMinutes(0);
        tw.local.disburseBenefitTriggerDate.setSeconds(0);
        tw.local.disburseBenefitTriggerDate.setMilliseconds(0);
        fpDate = tw.local.disburseBenefitTriggerDate.format("MM/dd/yyyy");  
        i=0;
    }
    if(tw.local.disburseBenefitTriggerDate.getDay() == 7){
        tw.local.disburseBenefitTriggerDate.setDate(tw.local.disburseBenefitTriggerDate.getDate() + 2); 
        tw.local.disburseBenefitTriggerDate.setHours(4);
        tw.local.disburseBenefitTriggerDate.setMinutes(0);
        tw.local.disburseBenefitTriggerDate.setSeconds(0);
        tw.local.disburseBenefitTriggerDate.setMilliseconds(0);
        fpDate = tw.local.disburseBenefitTriggerDate.format("MM/dd/yyyy"); 
        i=0;
    }
    if(tw.local.disburseBenefitTriggerDate.getDay() == 1){
        tw.local.disburseBenefitTriggerDate.setDate(tw.local.disburseBenefitTriggerDate.getDate() + 1); 
        tw.local.disburseBenefitTriggerDate.setHours(4);
        tw.local.disburseBenefitTriggerDate.setMinutes(0);
        tw.local.disburseBenefitTriggerDate.setSeconds(0);
        tw.local.disburseBenefitTriggerDate.setMilliseconds(0);
        fpDate = tw.local.disburseBenefitTriggerDate.format("MM/dd/yyyy"); 
        i=0;
    }
}

//tw.system.rescheduleTimer(tw.local.timerID, tw.local.disburseBenefitTriggerDate);
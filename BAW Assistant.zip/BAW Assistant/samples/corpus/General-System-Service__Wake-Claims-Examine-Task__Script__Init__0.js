/*
tw.local.taskName = tw.resource.TaskNames.ClaimsExamine;    
tw.local.taskAssignmentExpression = "ROLE:" + tw.local.claims.referralSelected.value;
tw.local.taskDueDate = tw.system.currentProcessInstance.dueDate;
tw.local.taskDueDate.setDate(tw.local.taskDueDate.getDate() + 100);
tw.local.taskPriority = 100;

//set initial follow up date
tw.local.followUpDate = new TWDate()
tw.local.followUpDate.setDate(tw.local.followUpDate.getDate() + 1000);

//set task state variable to ready
tw.local.stateReady = tw.resource.TaskStates.TaskActive;

// Task Subject Values
tw.local.task = new tw.object.Task();
tw.local.task.taskSubject = tw.local.taskName;
tw.local.task.taskState = tw.resource.TaskStates.TaskActive;
tw.local.task.taskEligibleGroup =tw.local.claims.referralSelected.value;
tw.local.task.taskStateDateTime = new TWDate();
tw.local.taskCode= tw.resource.TaskCodes.ClaimsExamine;*/

tw.local.test="Test";
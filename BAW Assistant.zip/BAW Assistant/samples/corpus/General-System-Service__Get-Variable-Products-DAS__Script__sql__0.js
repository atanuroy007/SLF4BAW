tw.local.sql
SELECT RTRIM(IND_PRODUCT_CD)
FROM <#=tw.local.db2SchemaQualifier#>.ind_product
WHERE var_prdct_flg = ?
AND ind_lob_cd = ?
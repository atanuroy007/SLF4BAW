
if (tw.local.taskPriority != null){
    tw.local.task.taskPriority = tw.local.taskPriority;
}

if (tw.local.taskSubtasks != null)
{
    tw.local.task.taskSubtasks = tw.local.taskSubtasks;
}
    
if (tw.local.taskState != null)
{
    // If the taskState is being changed, also change taskStateDateTime to right now
    // if a taskStateDateTime wasn't passed in
    if (tw.local.taskState != tw.local.task.taskState)
    {
         tw.local.task.taskStateDateTime = tw.local.taskStateDateTime;
         tw.local.task.taskState = tw.local.taskState;
         if(tw.local.taskState == "Pend")
         {
             // The state is changing to Pend, then we may have to update the
             // taskUnpendDateTime. If it isn't null, update it.
             if(tw.local.taskUnpendDateTime != null)
             {
                 tw.local.task.taskUnpendDateTime = tw.local.taskUnpendDateTime
             }
             else
             {
                 // do nothing leave the value of  tw.local.task.taskUnpendDateTime as is
             }
         }
         // If the task isn't Pend, then there shouldn't be an unpendDateTime, so set it to null
         // so it gets updated to blank in the task narrative.
         else
         {
             tw.local.task.taskUnpendDateTime = null;
         }
    }
}
/*tw.local.task.assignedToUser="abc";*/
if (tw.local.taskLockedBy != null)
{
    tw.local.task.taskLockedBy = tw.local.taskLockedBy;
}
if (tw.local.taskSavedBy != null)
{
    tw.local.task.taskSavedBy = tw.local.taskSavedBy;
}
if (tw.local.taskEligibleGroup != null)
{
    tw.local.task.taskEligibleGroup = tw.local.taskEligibleGroup;
}
if (tw.local.taskDynamicEligibilityRule != null)
{
    tw.local.task.taskDynamicEligibilityRule = tw.local.taskDynamicEligibilityRule;
}
/*if(tw.local.variableProducts != null ){
    for(var i=0; i<tw.local.variableProducts.listLength; i++){
        if(tw.local.variableProducts[i] == tw.local.Claims.process.worklistData.productName){
            tw.local.Claims.isVariableProduct = true;
            break;
        }
    }
}*/

if(tw.local.variablePolicies != null && tw.local.variablePolicies.listLength > 0){
    tw.local.Claims.isVariableProduct = true;
}

if(tw.local.Claims.isVariableProduct == true){
    tw.local.setupClaimPriority = 'High';
}
else{
    tw.local.setupClaimPriority = 'Normal';
}

tw.local.Claims.save();
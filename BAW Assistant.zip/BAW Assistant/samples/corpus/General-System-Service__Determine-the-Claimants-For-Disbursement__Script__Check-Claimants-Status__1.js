tw.local.createDisburseBenefit=false;
tw.local.claimantsSelectedForDisbursement= new tw.object.listOf.claimantDetails();

tw.local.claims.load(tw.local.claims.metadata("key"));

if(tw.local.claims.claimantsDetails.listLength>0){
    for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
        if(tw.local.claims.claimantsDetails[i].paymentStatus=="Disbursement in Progress" && tw.local.claims.claimantsDetails[i].disburseBenefitCreated=="N"){
            tw.local.claims.claimantsDetails[i].disburseBenefitCreated="Y";
            //tw.local.claims.claimantsDetails[i].save();
            tw.local.claimantsSelectedForDisbursement[tw.local.claimantsSelectedForDisbursement.listLength] = new tw.object.claimantDetails();
            tw.local.claimantsSelectedForDisbursement[tw.local.claimantsSelectedForDisbursement.listLength-1] = tw.local.claims.claimantsDetails[i];
            tw.local.createDisburseBenefit=true;
            
        }
    }
}

tw.local.claims.save();
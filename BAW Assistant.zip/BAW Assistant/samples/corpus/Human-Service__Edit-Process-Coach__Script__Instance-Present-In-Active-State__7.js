tw.local.errorMessage="";

if(tw.local.processInstanceSearchResults.listLength>0){
      tw.local.errorMessage="You cannot add this policy. There is an existing claim process on this contract";
 }
 
tw.local.errorEditClaimant="";

if(tw.local.claimantDetails.listSelected==null){
    tw.local.errorEditClaimant="Select a claimant to delete.";
}
if(tw.local.claimantDetails.listSelected!=null){
   if(tw.local.claimantDetails[tw.local.claimantDetails.listSelectedIndex].paymentStatus=="Approval in Progress" || 
    tw.local.claimantDetails[tw.local.claimantDetails.listSelectedIndex].paymentStatus=="Disbursement in Progress" || 
    tw.local.claimantDetails[tw.local.claimantDetails.listSelectedIndex].paymentStatus=="Paid" ||
    tw.local.claimantDetails[tw.local.claimantDetails.listSelectedIndex].paymentStatus=="Not Approved" ){
        tw.local.errorEditClaimant="You cannot delete this claimant as the task is in progress";
   }
 }
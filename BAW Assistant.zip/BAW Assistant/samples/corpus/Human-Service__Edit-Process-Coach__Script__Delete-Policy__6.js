tw.local.claims.load(tw.local.claims.metadata("key"));
for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){   
    if(tw.local.policyInformationViewData.listSelected.policyNumber==tw.local.claims.claimantsDetails[i].policyNumber) {
        tw.local.claims.claimantsDetails.removeIndex(i);
        i=0;
    }
}
tw.local.claims.save();
/*for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
    tw.local.claims.keyData[i]=tw.local.claims.claimantsDetails[i].metadata("key");
} */
/*for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
    tw.local.claims.claimantsDetails[i].save();
}*/



for(var i=0;i<tw.local.externalProcessData.cases.listLength;i++){
    if(tw.local.externalProcessData.cases[i].policyNumber==tw.local.policyInformationViewData.listSelected.policyNumber){
        tw.local.externalProcessData.cases.removeIndex(i);
    }
}

/*if(tw.local.claims.process.worklistData.productName.search('VUL')){
tw.local.taskPriorityExamineClaims = 'Highest';
}else{
tw.local.taskPriorityExamineClaims ='Normal';
}
*/
tw.local.claims.setupTaskGuid=tw.local.taskGuid;
tw.local.claims.save();
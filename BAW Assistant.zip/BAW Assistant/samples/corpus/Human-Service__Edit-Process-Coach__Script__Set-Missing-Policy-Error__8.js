tw.local.errorMessage = tw.system.error.toString(true);

if (tw.local.errorMessage.indexOf("does not exist on the mainframe")!= -1){
    tw.local.errorMessage = "You have entered an invalid policy number";
}else{
    tw.local.errorMessage = "Edit Process cannot happen due to technical errors. Please contact IT";
}

tw.local.externalProcessData.cases.removeIndex(tw.local.externalProcessData.cases.listLength-1);
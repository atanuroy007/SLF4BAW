if(tw.epv.LDI_Common.enableTraceLevelLogging == "true")
   PFGBPM.INDBPM.Log.info(tw.system.currentProcessInstanceID + ": Update Current Task Subject - Get Current Task Subject - End");
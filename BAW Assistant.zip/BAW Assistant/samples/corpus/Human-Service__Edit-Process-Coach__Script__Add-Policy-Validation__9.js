tw.system.coachValidation = new tw.object.CoachValidation();
tw.system.coachValidation.validationErrors = new tw.object.listOf.CoachValidationError();

    if (tw.local.addedPolicy == ""){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addedPolicy", "You must enter a policy number");
    }
    else if(tw.local.addedPolicy.search("^[0-9]+$")){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addedPolicy", "You must enter a valid number");
    }
    else if(tw.local.addedPolicy.length < 7){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addedPolicy", "You must enter a policy number that is 7 characters long");
    }

    for(var i=0;i<tw.local.policyInformationViewData.listLength;i++){
        if(tw.local.addedPolicy==tw.local.policyInformationViewData[i].policyNumber){
            tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addedPolicy", "You cannot enter one policy number more than once");
        }
    }   

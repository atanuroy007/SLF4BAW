tw.local.emailSubject = 'Error in process ' + tw.system.model.processApp.name  + " " + tw.system.currentProcessInstanceID + " - " + tw.env.com.principal.ind.regionName; 

tw.local.emailBody = 'Hello, \n\nPolicy number ' + tw.local.caseInfoResponse.missingPolicyNumbers[0] + ' does not exist on the mainframe and has caused a Life Admin Claims error in BPM. Can you please take a look? The instance in error will be deleted. \n\n'
+ 'Thank you, \nIW Helpdesk';
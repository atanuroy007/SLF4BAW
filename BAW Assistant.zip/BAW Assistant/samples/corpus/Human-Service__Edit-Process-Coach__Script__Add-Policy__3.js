tw.local.externalProcessData.cases[tw.local.externalProcessData.cases.listLength]=new tw.object.Case();
tw.local.externalProcessData.cases[tw.local.externalProcessData.cases.listLength-1].policyNumber=tw.local.addedPolicy;
tw.local.externalProcessData.cases[tw.local.externalProcessData.cases.listLength-1].currentCaseIndicator=true;
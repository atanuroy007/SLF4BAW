tw.local.claims.approvalRejectTaskGuidMap[tw.local.claims.approvalRejectTaskGuidMap.listLength] = new tw.object.NameValuePair();
tw.local.claims.approvalRejectTaskGuidMap[tw.local.claims.approvalRejectTaskGuidMap.listLength-1].name=tw.local.taskId;
tw.local.claims.approvalRejectTaskGuidMap[tw.local.claims.approvalRejectTaskGuidMap.listLength-1].value=tw.local.taskGuid;
tw.local.claims.save();
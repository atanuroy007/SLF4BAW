
tw.local.variableProducts = new tw.object.listOf.String();

for(var i=0; i<tw.local.results.getAttribute("recordCount"); i++){
    tw.local.variableProducts[i] = tw.local.results.record[i].column[0].getText();  
}
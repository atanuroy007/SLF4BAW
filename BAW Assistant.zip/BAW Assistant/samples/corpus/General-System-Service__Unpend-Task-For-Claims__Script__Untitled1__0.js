tw.system.currentTask.reassignTo("ROLE:" + tw.resource.SecurityGroups.lifeAdminSetUpClaims);
tw.system.currentTask.reassignBackToRole();
var task = tw.local.taskId.split(".");
tw.local.taskId = task[1];

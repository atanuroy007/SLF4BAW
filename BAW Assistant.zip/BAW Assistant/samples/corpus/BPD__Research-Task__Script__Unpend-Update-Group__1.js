var claimsResearchTask = tw.system.findTaskByID(tw.local.lastTask);
claimsResearchTask.reassignBackToRole();
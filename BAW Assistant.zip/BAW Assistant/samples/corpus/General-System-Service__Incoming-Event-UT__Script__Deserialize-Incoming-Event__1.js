tw.local.incomingEvent = tw.system.serializer.fromXml(tw.local.incomingEventXml);
//tw.local.claims = tw.system.serializer.fromXml(tw.local.claimsXml);
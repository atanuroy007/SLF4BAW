tw.local.policyList = new tw.object.listOf.String();
for(var i = 0;i < tw.local.externalProcessData.cases.listLength;i++){
    if(tw.local.externalProcessData.cases[i].currentCaseIndicator == true){
        tw.local.policyList[tw.local.policyList.listLength] = tw.local.externalProcessData.cases[i].policyNumber;
    }
}
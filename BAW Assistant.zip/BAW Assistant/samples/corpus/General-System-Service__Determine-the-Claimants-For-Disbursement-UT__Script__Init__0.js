tw.local.claimantDetails = new tw.object.listOf.claimantDetails();
tw.local.claimantDetails[0]= new tw.object.claimantDetails();
tw.local.claimantDetails[0].claimantName="Eric, Thompson";
tw.local.claimantDetails[0].policyNumber="4000250";
tw.local.claimantDetails[0].approvalType="Y";
tw.local.claimantDetails[0].approverLevel = new tw.object.NameValuePair();
tw.local.claimantDetails[0].paymentStatus="Disbursement in Progress";
tw.local.claimantDetails[0].disburseBenefitCreated="N";

tw.local.claimantDetails[1]= new tw.object.claimantDetails();
tw.local.claimantDetails[1].claimantName="Kate, Anderson";
tw.local.claimantDetails[1].policyNumber="4000250";
tw.local.claimantDetails[1].approvalType="Y";
tw.local.claimantDetails[1].approverLevel = new tw.object.NameValuePair();
tw.local.claimantDetails[1].paymentStatus="Disbursement in Progress";
tw.local.claimantDetails[1].disburseBenefitCreated="Y";
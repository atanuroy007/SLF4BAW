tw.local.policyList[tw.local.policyList.listLength]=tw.local.addPolicy;
tw.local.addPolicy=" ";
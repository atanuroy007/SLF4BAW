if(tw.local.taskName=="Reinsurance Claim"){
    tw.local.reinsuranceTaskList=tw.local.retainedReinsuranceTaskList;
}
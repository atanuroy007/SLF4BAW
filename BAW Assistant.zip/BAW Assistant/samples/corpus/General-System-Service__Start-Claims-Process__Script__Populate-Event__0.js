tw.local.incomingEvent.businessData.cases = new tw.object.listOf.Case();
tw.local.incomingEvent.businessData.cases[0] = new tw.object.Case();
tw.local.incomingEvent.businessData.cases[0].policyNumber = tw.local.policyNumber;
tw.local.incomingEvent.businessData.cases[0].proposedInsured = new tw.object.listOf.ProposedInsured();

tw.local.incomingEvent.documentData.noteInfo = new tw.object.Note();
tw.local.incomingEvent.documentData.noteInfo.text= tw.local.notes;
tw.local.incomingEvent.documentData.noteInfo.createdBy = "System";

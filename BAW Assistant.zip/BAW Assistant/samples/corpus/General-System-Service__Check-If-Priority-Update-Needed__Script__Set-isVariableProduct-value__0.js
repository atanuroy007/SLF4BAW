if(tw.local.variablePolicies != null && tw.local.variablePolicies.listLength > 0){
    tw.local.Claims.isVariableProduct = true;
}
else 
    tw.local.Claims.isVariableProduct = false;
    
tw.local.Claims.save();
var today = new Date();

if(tw.local.followupDate != null){
    if(tw.local.previousDate == null ){
        if(SameDate(today,tw.local.followupDate ) == false){
            tw.local.followupDate.setHours(4);
            tw.local.followupDate.setMinutes(0);
            tw.local.errorMessage = "";
            tw.local.previousDate = tw.local.followupDate;       
        }
        else{       
             var time = today.getMinutes();
             tw.local.followupDate.setHours(today.getHours());  
             time = time + 31;
             tw.local.followupDate.setMinutes(time);
             tw.local.errorMessage = "";
             tw.local.previousDate = tw.local.followupDate;
        }
    }
    else{
        if(SameDate(tw.local.previousDate, tw.local.followupDate) == false){
            if(SameDate(today, tw.local.followupDate)){
               var time = today.getMinutes();
               tw.local.followupDate.setHours(today.getHours());  
               time = time + 31;
               tw.local.followupDate.setMinutes(time);
               tw.local.errorMessage = ""; 
               tw.local.previousDate = tw.local.followupDate;
            }
            else{
                tw.local.followupDate.setHours(4);
                tw.local.followupDate.setMinutes(0);
                tw.local.errorMessage = "";
                tw.local.previousDate = tw.local.followupDate;
            }             
        }
    }
}

function SameDate(startDate,endDate)
{
    var sDate = startDate.getMonth().toString() + startDate.getDate().toString() + startDate.getFullYear().toString();
    var eDate = endDate.getMonth().toString() + endDate.getDate().toString() + endDate.getFullYear().toString();
    if(sDate == eDate){
        return true;
    }
    else{
        return false;
    }
}
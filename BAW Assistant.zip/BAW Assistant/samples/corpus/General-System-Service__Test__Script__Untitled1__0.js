tw.local.test= new tw.object.Test();

tw.local.test.load(tw.local.key);

tw.local.test.test1="xyz";
tw.local.test.test2="abc";
tw.local.test.save();




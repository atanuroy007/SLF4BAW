tw.local.policyList=new tw.object.listOf.String();
tw.local.addPolicy="";
tw.local.error="";
if(tw.local.saveButton==true){
    tw.local.message="Setup Claim task has been created";
}
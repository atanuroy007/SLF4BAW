var allPaid=1;

for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
    if(tw.local.claims.claimantsDetails[i].paymentStatus!="Paid"){
        allPaid=0;
        break;
    }
}

if(allPaid==1){
  tw.local.claims.isLastDisbursementTask=true;
}

tw.local.claims.save();
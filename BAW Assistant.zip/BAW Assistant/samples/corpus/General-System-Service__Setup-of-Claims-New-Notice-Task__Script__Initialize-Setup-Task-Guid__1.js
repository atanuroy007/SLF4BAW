
/*if(tw.local.claims.process.worklistData.productName.search('VUL')){
tw.local.taskPriorityExamineClaims = 'Highest';
}else{
tw.local.taskPriorityExamineClaims ='Low';
}*/

if(tw.local.claims.isVariableProduct == true){
    tw.local.taskPriorityExamineClaims = 'High';
}else{
    tw.local.taskPriorityExamineClaims ='Low';
}

tw.local.claims.setupTaskGuid=tw.local.taskGuid;
tw.local.claims.save();
tw.system.coachValidation = new tw.object.CoachValidation();
tw.system.coachValidation.validationErrors = new tw.object.listOf.CoachValidationError();

if(tw.local.addPolicyButton==true){
    if (tw.local.addPolicy == ""){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addPolicy", "You must enter a policy number");
    }
    else if(tw.local.addPolicy.search("^[0-9]+$")){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addPolicy", "You must enter a valid number");
    }
    else if(tw.local.addPolicy.length < 7){
        tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addPolicy", "You must enter a policy number that is 7 characters long");
    }
    
    for(var i=0;i<tw.local.policyList.listLength;i++){
        if(tw.local.addPolicy==tw.local.policyList[i]){
            tw.system.addCoachValidationError(tw.system.coachValidation, "tw.local.addPolicy", "You cannot enter one policy number more than once");
        }
    }   
}
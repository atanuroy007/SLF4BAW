tw.local.externalProcessData.assignedTeamCode=43;
tw.local.reinsuranceClaimDetails.worklistData.assignedTeam=43;
tw.local.externalProcessData.transControlId=77795;
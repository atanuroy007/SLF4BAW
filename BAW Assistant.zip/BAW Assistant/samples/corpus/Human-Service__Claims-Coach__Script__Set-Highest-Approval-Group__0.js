tw.local.claimantsSelectedForApproval= new tw.object.listOf.claimantDetails();

var iterator=0;

for(var i =0;i<tw.local.claimantDetails.listAllSelected.listLength;i++){
    if(tw.local.claimantDetails.listAllSelected[i].approvalType=="Yes"){
        tw.local.claimantsSelectedForApproval[iterator]=tw.local.claimantDetails.listAllSelected[i];
        iterator++;
    }
 }
    
for(var i =0;i<tw.local.claimantDetails.listAllSelected.listLength;i++){
        for(var j=0;j<tw.local.claimantDetails.listLength;j++){
            if(tw.local.claimantDetails.listAllSelected[i].claimantName==tw.local.claimantDetails[j].claimantName && tw.local.claimantDetails.listAllSelected[i].policyNumber==tw.local.claimantDetails[j].policyNumber
             && tw.local.claimantDetails[j].approvalType=="No"){
                tw.local.claimantDetails[j].paymentStatus="Disbursement in Progress";
            }
        }
        }
 
 for(var i =0;i<tw.local.claimantsSelectedForApproval.listLength;i++){
        for(var j=0;j<tw.local.claimantDetails.listLength;j++){
            if(tw.local.claimantsSelectedForApproval[i].claimantName==tw.local.claimantDetails[j].claimantName && tw.local.claimantsSelectedForApproval[i].policyNumber==tw.local.claimantDetails[j].policyNumber){
                tw.local.claimantDetails[j].paymentStatus="Approval in Progress";
            }
        }
     }
 
var approvalGroupsHashMap=[0,0,0,0,0];

for(var i = 0; i< tw.local.claimantsSelectedForApproval.listLength;i++){
   if(tw.local.claimantsSelectedForApproval[i].approverLevel.name=="Director"){
      approvalGroupsHashMap[0]++;
      break;
   }    
   else if(tw.local.claimantsSelectedForApproval[i].approverLevel.name=="Assistant Claim Director"){
       approvalGroupsHashMap[1]++;
   }    
   else if(tw.local.claimantsSelectedForApproval[i].approverLevel.name=="Sr. Claim Acct Manager"){
        approvalGroupsHashMap[2]++;
   }
   else if(tw.local.claimantsSelectedForApproval[i].approverLevel.name=="Life Claim Analyst"){
       approvalGroupsHashMap[3]++;   
   }
   else {
      approvalGroupsHashMap[4]++;
   }      
}
 
for(var i=0;i<approvalGroupsHashMap.length;i++){
   if(approvalGroupsHashMap[i]!=0){
      if(i==0){
          tw.local.approvalSelected.name="Director";
          tw.local.approvalSelected.value=tw.resource.SecurityGroups.lifeAdminDirector;
      }
      else if(i==1){
          tw.local.approvalSelected.name="Assistant Claim Director";
          tw.local.approvalSelected.value=tw.resource.SecurityGroups.lifeAdminAssistantClaimDirector;
      }
      else if(i==2){
           tw.local.approvalSelected.name="Sr. Claim Acct Manager";
           tw.local.approvalSelected.value=tw.resource.SecurityGroups.lifeAdminSrClaimAcctManager;
      }
      else if(i==3){
          tw.local.approvalSelected.name="Life Claim Analyst";
          tw.local.approvalSelected.value=tw.resource.SecurityGroups.lifeAdminLifeClaimAnalyst;
      }
      else {
          tw.local.approvalSelected.name="Assistant Claim Analyst/Examiner";
          tw.local.approvalSelected.value=tw.resource.SecurityGroups.lifeAdminAssistantClaimAnalystOrExaminer;
      }
   break;
   }
}





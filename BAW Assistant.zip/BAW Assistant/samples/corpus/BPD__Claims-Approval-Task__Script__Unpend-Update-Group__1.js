var myTask = tw.system.findTaskByID(tw.local.lastTask);
myTask.reassignBackToRole();
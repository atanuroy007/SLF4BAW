tw.local.Claims = new tw.object.Claims();
tw.local.Claims.process = new tw.object.Process();
tw.local.Claims.process.worklistData = new tw.object.WorklistData();
tw.local.Claims.process.worklistData.productName = 'PFLEX';
tw.local.Claims.isVariableProduct = false;
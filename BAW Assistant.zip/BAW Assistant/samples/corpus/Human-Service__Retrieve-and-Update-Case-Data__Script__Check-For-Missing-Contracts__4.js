if(tw.local.caseInfoResponse != null){
    if(tw.local.caseInfoResponse.missingPolicyNumbers != null){
        if(tw.local.caseInfoResponse.missingPolicyNumbers.listLength > 0){
            tw.local.missingPolicies = true;
            tw.local.errorMsg = "The following policy number: " + tw.local.caseInfoResponse.missingPolicyNumbers[0] + " does not exist on the mainframe.  Please resolve with business and hit ignore to complete instance.";
        }
    }
}
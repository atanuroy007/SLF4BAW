if(tw.epv.LDI_Common.enableTraceLevelLogging == "true")
   PFGBPM.INDBPM.Log.info(tw.system.currentProcessInstanceID + ": Update Current Task Subject - Build New Task Subject - End");
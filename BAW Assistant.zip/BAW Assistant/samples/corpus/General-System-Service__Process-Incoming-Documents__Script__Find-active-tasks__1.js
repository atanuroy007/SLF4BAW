tw.local.taskCount=tw.system.currentProcessInstance.tasks.length;
tw.local.taskGuidCount=0;
tw.local.taskGuid = new tw.object.listOf.String();
tw.local.unpendTask=false;
tw.local.counter=0;
for(var i=0;i<tw.system.currentProcessInstance.tasks.length;i++){
    tw.local.taskSubject=tw.system.currentProcessInstance.tasks[i].subject;
    if (tw.local.taskSubject != null && tw.local.taskSubject != ""){
        var subject = tw.local.taskSubject.split("|");
        var j=0;
        tw.local.taskName = subject[j++];
        tw.local.taskState = subject[j];
    }
    if(tw.local.taskState=="Pend" && (tw.local.taskName==tw.resource.TaskNames.ClaimsSetUp || tw.local.taskName==tw.resource.TaskNames.ClaimsExamine || tw.local.taskName==tw.resource.TaskNames.FinalizeClaims || tw.local.taskName==tw.resource.TaskNames.ClaimsApprovalReject)){
        tw.local.unpendTask=true;
        if(tw.local.taskName==tw.resource.TaskNames.ClaimsSetUp){
            tw.local.taskGuid[tw.local.taskGuidCount]=tw.local.claims.setupTaskGuid;
            tw.local.taskGuidCount++;
        }
        if(tw.local.taskName==tw.resource.TaskNames.ClaimsExamine){
            tw.local.taskGuid[tw.local.taskGuidCount]=tw.local.claims.examineTaskGuid;  
            tw.local.taskGuidCount++;
        }
        if(tw.local.taskName==tw.resource.TaskNames.FinalizeClaims){
            tw.local.taskGuid[tw.local.taskGuidCount]=tw.local.claims.finalizeTaskGuid;
            tw.local.taskGuidCount++;
        }
        if(tw.local.taskName==tw.resource.TaskNames.ClaimsApprovalReject){
            for(var j=0;j<tw.local.claims.approvalRejectTaskGuidMap.listLength;j++){
                if(tw.local.claims.approvalRejectTaskGuidMap[j].name==tw.system.currentProcessInstance.tasks[i].id){
                      tw.local.taskGuid[tw.local.taskGuidCount]=tw.local.claims.approvalRejectTaskGuidMap[j].value;
                      tw.local.taskGuidCount++;       
                }
            }
        }
    }
}
var labelElement = this.context.element.getElementsByTagName("label")[0];
var spanViewElement = this.context.element.querySelector(".dateTimePicker.readonly");
var spanDivElement = this.context.element.querySelector(".dateTimePickerReadonlyDiv");

var dateValue = this.context.binding && ((this.context.binding.get("value") instanceof Date) || 
			 (this.context.binding.get("value") === null))? this.context.binding.get("value") : null;
this._prevDateVal = !!dateValue ? dateValue.getTime():null;			 
var baseTextDirection = this.context.options._metadata.baseTextDirection && this.context.options._metadata.baseTextDirection.get("value") ? this.context.options._metadata.baseTextDirection.get("value") : utilities.BiDi.BASE_TEXT_DIRECTION._default;
var generalPrefTextDirection = this.context.bpm.system.baseTextDirection;

var nlsMsgs = utilities.initLocalizedMessages(this.context);

spanViewElement.innerHTML = dateValue ? this._formatDate(dateValue) : "&nbsp;";
utilities.BiDi.applyTextDir(spanDivElement, spanDivElement.innerHTML, baseTextDirection, generalPrefTextDirection);

if (labelElement != undefined && this.context.options._metadata.label != undefined && this.context.options._metadata.label.get("value") != "") {
	labelElement.innerHTML = this.context.htmlEscape(this.context.options._metadata.label.get("value"));
	utilities.BiDi.applyTextDir(labelElement, labelElement.innerHTML, baseTextDirection, generalPrefTextDirection);
}

if (labelElement != undefined && this.context.options._metadata.helpText && this.context.options._metadata.helpText.get("value") != "") {
	labelElement.title = this.context.options._metadata.helpText.get("value");
}

var img = this.context.element.querySelector(".coachValidationDiv img");
img.src = require.toUrl("dojo/resources/blank.gif");

this.nlsMsgs = utilities.initLocalizedMessages(this.context);
img.setAttribute("alt", this.nlsMsgs["ErrorIcon_text"]);

this.updateStyle = function() {
	var contentElem = this.context.element.querySelector("#" + this.context.element.getAttribute("id") + " > div.BPMDateTimePicker");
	if (!!contentElem) {
	    var doesStretch = this.context.getStyle() ? (this.context.getStyle().width != null || this.context.getStyle().minWidth != null) : null;
    	if(doesStretch) {
    		domClass.add(contentElem, "BPMCVHorzStretch");
    	} else {
    		domClass.remove(contentElem, "BPMCVHorzStretch");
    	}
    	
    	if (doesStretch && this.context.options.includeTimePicker && this.context.options.includeTimePicker.get("value") == true) {
    		domClass.remove(contentElem, "BPMNoTimePicker");
    	} else {
    		domClass.add(contentElem, "BPMNoTimePicker");
    	}
	}
}

this.context.bind("style", this.updateStyle, this);

//save the original DOM in case we need to re-create the widget
this._originalDOM = this.context.element.innerHTML;
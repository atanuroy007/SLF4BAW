tw.local.errorMessage="";

if(tw.local.claimantDetails.listSelected==null){
    tw.local.errorMessage="You must have select at least one claimant to proceed";
}
for(var i=0; i<tw.local.claimantDetails.listAllSelected.listLength; i++){
    if(tw.local.claimantDetails.listAllSelected[i].approvalType==null || tw.local.claimantDetails.listAllSelected[i].approvalType==""){
        tw.local.errorMessage="You would have to select a value in Approval Needed column to proceed";    
    }
    if(tw.local.claimantDetails.listAllSelected[i].approvalType=="Yes"){
       if(tw.local.claimantDetails.listAllSelected[i].approverLevel.value==null || tw.local.claimantDetails.listAllSelected[i].approverLevel.value==""){
            tw.local.errorMessage="You would have to select an approver level to proceed";    
       }
    }
    if(tw.local.claimantDetails.listAllSelected[i].paymentStatus=="Approval in Progress" || tw.local.claimantDetails.listAllSelected[i].paymentStatus=="Disbursement in Progress"
    || tw.local.claimantDetails.listAllSelected[i].paymentStatus=="Paid" || tw.local.claimantDetails.listAllSelected[i].paymentStatus=="Not Approved"){  
              tw.local.errorMessage="Payment for this claimant is in Progress or in Paid status"; 
       }
       
}
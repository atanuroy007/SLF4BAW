/*tw.local.claims.keyData=new tw.object.listOf.String();
for(var i=0;i<tw.local.claims.claimantsDetails.listLength;i++){
    tw.local.claims.keyData[i]=tw.local.claims.claimantsDetails[i].metadata("key");
} */
tw.local.sentToApprovalUCA=false;
for(var i =0;i< tw.local.claims.claimantsDetails.listAllSelected.listLength;i++){
    if(tw.local.claims.claimantsDetails.listAllSelected[i].approvalType=="Yes"){
       tw.local.sentToApprovalUCA=true;
       break;
    }
}



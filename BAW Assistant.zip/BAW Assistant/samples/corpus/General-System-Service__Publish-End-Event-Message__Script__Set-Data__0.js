if(tw.local.claims.transactionStatus == tw.resource.TransactionStatuses.ClosedOut){
    tw.local.eventCode = tw.resource.EventCodes.LAServiceTransactionClosedOut;
}else if(tw.local.claims.transactionStatus == tw.resource.TransactionStatuses.Completed){
    tw.local.eventCode = tw.resource.EventCodes.LAServiceTransactionCompleted;
}else if(tw.local.claims.transactionStatus == tw.resource.TransactionStatuses.Deleted){
    tw.local.eventCode=tw.resource.EventCodes.LAServiceTransactionDeleted;
}
tw.local.policyList = new tw.object.listOf.String();
for(var i = 0;i < tw.local.externalProcessData.cases.listLength;i++){
    if(tw.local.externalProcessData.cases[i].currentCaseIndicator == true){
        tw.local.policyList[tw.local.policyList.listLength] = tw.local.externalProcessData.cases[i].policyNumber;
    }
}

tw.local.processAppCode="10";



tw.local.taskName = tw.resource.TaskNames.ClaimsExamine;   
tw.local.taskAssignmentExpression = "ROLE:" + tw.local.claims.examineGroupAssigned;
tw.local.taskDueDate = tw.system.currentProcessInstance.dueDate;
tw.local.taskDueDate.setDate(tw.local.taskDueDate.getDate() + 200);
tw.local.taskPriority = 200;

//set initial follow up date


//set task state variable to ready
tw.local.stateReady = tw.resource.TaskStates.TaskPend;

// Task Subject Values
tw.local.task = new tw.object.Task();
tw.local.task.taskSubject = tw.local.taskName;
tw.local.task.taskState = tw.resource.TaskStates.TaskPend;

tw.local.task.taskEligibleGroup = tw.local.claims.examineGroupAssigned;
tw.local.task.taskStateDateTime = new TWDate();
tw.local.taskCode= tw.resource.TaskCodes.ClaimsExamine;
tw.local.task.taskUnpendDateTime= tw.local.followUpDate;

tw.local.followUpDateExamineClaim=tw.local.followUpDate;

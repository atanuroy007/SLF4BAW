# BAW Assistant

A coding assistant that ships as a WebSphere application and feels like part of
IBM Process Designer. The developer writes the code; the assistant reviews it
live, draws findings in Designer's own editor gutter, and checks artifact-level
standards against a 91-row review checklist.

**It never authors artifacts.** Everything it does is read-only.

Built for LSEG.

---

## 1. What it does today

Two paths were set out at the start, in the owner's words:

1. **Realtime validation and developer assistance** — the current focus. Later,
   an AI chat interface inside Designer, like Claude Code in VS Code.
2. **A whole-application review** — every artifact checked together, at a point
   in time. **There is no `.twx` export.** Decided by the owner 2026-08-30: the
   review reads the live artifacts over REST at a container ref, which is
   either a named snapshot of a branch or track, or the tip of one. Not built
   yet, but every reader is already DOM-free and every read already takes a
   containerRef, so nothing stands in its way.

Everything below is path 1. Nothing in the engine forecloses path 2 — see
[§7 Design decisions](#7-design-decisions-that-are-locked).

### Live linting inside Designer

- A hub page at `https://localhost:9443/assistant/` opens Process Designer via
  `window.open`, then docks a panel inside it.
- The panel auto-validates on **open, change and save**. There is no button to
  press.
- Buffer findings are drawn as annotations in Designer's own editor gutter,
  alongside IBM's markers, in roughly 25 ms for a 491-line buffer.
- IBM's own JavaScript validator is **harvested** into the panel, not
  duplicated. Its findings are shown last and visibly separate, because they
  are not our judgement and do not cite a house standard.
- A watchdog re-applies our annotations, because the Designer's own validator
  writes into the same annotation model and wipes ours on every edit.

### Rules

**175 rules** in `BawAssistant.war/WEB-INF/rules/house-rules.json`:

| Kind | Count | What it is |
|---|---|---|
| `buffer` | 57 | Regex over the code surface. Produces a gutter annotation with a line. |
| `artifact` | 50 | Structural checks over the artifact model (variable counts, step counts, naming, per-type settings). No line number. |
| `manual` | 67 | Checklist rows a machine cannot settle. Surfaced as review prompts, never as findings. |

By lifecycle: **19 active policy, 155 draft**. 107 automated rules carry their
own worked examples and are verified against them on every build.

The signature limit is **15 input and 15 output variables**, settled by the
owner on 2026-08-30 against the checklist and IBM's IDA threshold, which agree;
the internal standards' stricter 5 is carried as an advisory draft. Script
blocks stay at 100 lines, with 300 critical.

Every rule also declares **when** it can be evaluated. `scope: ["develop",
"snapshot"]` is 140 of them, because a full application review runs everything
the panel runs; the 11 marked `["snapshot"]` need another artifact, the whole
application, or a second moment, and no work on the panel will make them
answerable there. Five of those twelve are two-moment questions that
`/compare.jsp` already answers.

The artifact rules cover five types. Seven judge the signature and step count
of `SERVICEFLOW`, `CaseProcess` and `COACHFLOW`; eight added on 2026-08-30 read
the per-type `settings` — coach-view header flags, UCA event configuration,
business-object annotations. All eight are drafts, measured against 1,719 real
artifact models before they were written: see
`knowledge/rule-packs/artifact-rules-2026-08-30.md`. `RESTService`,
`AppSettings` and `Team` still have no rules, and the note says why.

Eight more implement checklist rows the owner asked to have measured,
including the EPV size, team-exposure and value-limit checks - see
`knowledge/rule-packs/guided-rules-2026-08-30.md`, which also records that
**EPVs were never unreadable**: the HTTP 500 belongs to `envVarSet`, a
different artifact that no checklist row asks about.

Seven more rules came from **IBM's own IDA checkstyle catalogue** (129 rules,
triaged on 2026-08-30): LiveConnect calls, thread sleeps, SQL built by
concatenation, two script-length thresholds, unconnected steps and default
variable names. Reading it also exposed defects in two rules already shipping -
one of them active policy. Both the triage of all 129 and the evidence are in
`knowledge/rule-packs/ida-checkstyle-2026-08-30.md`.

Every finding carries provenance: the rule id, the checklist cell it came from
(`General!B6`, `UI!B24`), whether it is policy or still a draft proposal, and
the rationale — *why* the standard exists, shown above *what to do about it*.

### The review checklist

All 91 rows of the owner's review checklist are carried, including the 67 that
cannot be automated. Those appear in the panel as a collapsible review block
under the findings, sorted Critical → High → Medium → Low, each citing its
priority, impacted area, primary reviewer and spreadsheet cell.

The checklist's own vocabulary is kept verbatim — `impactedArea`, `priority`,
`primaryReviewer`, `checkText` are the checklist's field names, not ours.

Questions asked per artifact type (after duplicate collapsing, see §3):

| Artifact type | Review questions | Answered by the engine |
|---|---|---|
| CoachView | 37 | 49 |
| CaseProcess | 35 | 56 |
| COACHFLOW | 26 | 56 |
| SERVICEFLOW | 22 | 56 |
| AppSettings | 18 | 49 |
| *(unfiltered)* | 66 | — |

### Rule Studio

- `/tester.jsp` — author a rule against a live artifact and see it annotate the
  real gutter.
- `/rules.jsp` — browse, edit, verify and export rules.

### Safety properties

- The regex engine is **bounded**: a catastrophic pattern is abandoned after
  250 ms and reports itself, naming the rule rather than blaming the
  developer's code.
- A rule whose regex does not compile fails the build rather than being
  silently skipped — a typo must not remove a check without an error.
- The clean control sample must produce **zero** findings. A rule that fires on
  correct code is worse than no rule, because it teaches developers to ignore
  the gutter.

---

## 2. Layout

```
BAW Assistant\
├── BawAssistantEAR.ear\           THE PRODUCT — exploded EAR
│   ├── BawAssistant.war\
│   │   ├── index.jsp              hub / launcher
│   │   ├── review.jsp             whole-application review
│   │   ├── rules.jsp  tester.jsp  probe.jsp  compare.jsp
│   │   ├── css\app.css
│   │   ├── js\
│   │   │   ├── hub.js             hub UI + the docked Designer panel
│   │   │   ├── bridge.js          all Designer DOM and REST access
│   │   │   ├── findings.js        severity order, filtering, grouping
│   │   │   ├── review.js          the whole-application review
│   │   │   ├── app.js  rules.js  tester.js  compare.js
│   │   └── WEB-INF\
│   │       ├── rules\house-rules.json     THE RULES (175)
│   │       └── classes\com\bawassistant\  compiled by build.ps1
│   ├── META-INF\application.xml   pins context root /assistant
│   └── src\
│       ├── main\java\com\bawassistant\    9 classes, the engine
│       └── test\java\com\bawassistant\    SelfTest, Verify, Emit
├── samples\
│   ├── probe-all-rules.js         must fire (build asserts ≥15 findings)
│   └── probe-all-rules-fixed.js   MUST return 0 — the false-positive gate
├── knowledge\                     provenance, not used at runtime
│   ├── review-checklist\          the source workbook extract + normalised rows
│   ├── artifact-catalog\
│   └── rule-packs\
├── tools\harvest-corpus.js       pull an application's committed code over REST
├── test\                          bridge model tests + the Playwright suite
├── build.ps1                      compile, verify, test, package
├── deploy-assistant.ps1           copy into installedApps (see §6 — has a gap)
└── PROJECT.md                     this file
```

### The engine, class by class

| Class | Responsibility |
|---|---|
| `ApiServlet` | The whole HTTP surface. Routes `/api/*`. |
| `RuleStore` | Loads rules from the WAR + draft overlay; reports the summary. |
| `Rule` | One rule: kind, pattern, lifecycle, checklist metadata, examples. |
| `BufferLinter` | Regex over code, with comment/string masking and a time budget. |
| `ArtifactChecker` | Structural rules over the artifact model. |
| `RuleVerifier` | Runs every rule against its own `fires`/`quiet` examples. |
| `DraftStore` | Persists draft rules outside the WAR; refuses to write policy. |
| `Finding` | One result, with provenance. |
| `Json` | Hand-rolled JSON. WebSphere ships no JSON API and we take no jars. |

---

## 3. Changes made in this session

Three defects, all found by testing against the live server rather than by
reading code. All three are fixed, deployed and verified in a browser.

### 3.1 The review checklist was suppressed exactly when it mattered

`renderPanel` in `hub.js` returned early when there were no findings, before
ever reaching `renderChecklist`. The guard was written for the "no findings"
case, so the review block was hidden **only on clean code** — the one state
where a developer is most likely to read a green panel as a passed review.
That is precisely the misreading the block exists to prevent.

Proven live rather than argued: on a clean artifact the hub fetched
`/api/checklist?type=CoachView` → 200 with 38 prompts, and then drew none of
them. The endpoint had been verified before; the rendering never had.

Fixed by making the empty notice and the findings list *alternatives*, with the
checklist rendered after either.

### 3.2 The hub miscounted its own rules

The headline read **"123 rules (116 buffer, 7 artifact)"**. The real breakdown
is 49 buffer, 7 artifact, 67 manual. `RuleStore.summary()` carried
`else { buffer++; }`, written before the `manual` kind existed, so all 67
review prompts were folded into the buffer count — and the number that says
*the engine cannot settle this review on its own* never appeared at all.

Now counted separately and surfaced as
**"123 rules (49 buffer, 7 artifact, 67 for review)"**.

### 3.3 One review question was asked twice, on every artifact type

The panel showed a row with no priority, no impacted area and no reviewer,
dangling at the bottom of the list under a bare `UCA!B7`.

The cause was in the source workbook, not the code. The UCA sheet's header row
defines Category/Priority/Impacted Area/Primary Reviewer in columns C–F, and
row 7 holds only a serial number and a question — a stray paste of an EPV
question onto the UCA sheet. The complete version already exists at
`Variables & EPVs!B10`.

Both copies carry `appliesTo: []`, meaning unrestricted, so **every reviewer met
the same question twice on every artifact type**, once complete and once bare.
Across all 67 manual rows this was the only duplicate.

Fixed without fabricating the missing metadata and without deleting a row from
the customer's checklist — both would have edited a governance artifact behind
the owner's back. Instead the collapse happens in `/api/checklist`, the point
where the engine decides *what a person is asked*; being asked the same thing
twice is not two checks. The fuller row wins and the discarded row's cell is
returned in a new `alsoAt` field, which the panel appends:

```
Number of fields should not exceed 30 in one EPV
High · Functionality · Self · Variables & EPVs!B10, UCA!B7
```

The rule store still carries all 67 rows, so the `.twx` report path of §1 sees
exactly what it saw before, and the self-test invariant still reads 67. Counts
dropped by exactly one per artifact type, and **no row is left without a
priority** — that bare row was the only one.

### 3.4 A process note worth keeping

The first probe after the third deploy reported the fix had not worked. It was
wrong: it had raced the application restart by about a minute. It was only
caught by checking the deployed class timestamp and the server log instead of
believing the result. **Confirm the servlet is live before drawing conclusions
from behaviour** — `/api/status` or the class mtime is the cheap check.

---

## 4. History

| Commit | What |
|---|---|
| `ff61f91` | Initial: assistant, rule engine, knowledge base |
| `c9789bb` | `build.ps1`; stop tracking compiled classes |
| `13a308f` | Defensive-coding rules, and the guard window they needed |
| `6c3d614` | Surface the Designer's own JavaScript validation in the panel |
| `67814c3` | Poll the Designer's validator instead of reading it once |
| `0facab9` | Rules verify themselves; bound the regex engine; add `/api/try` |
| `f3379cd` | The rule tester; stop the launcher navigating itself away |
| `3fd6b52` | Draft rules persist; policy stays in the WAR |
| `8178b06` | The rule manager; stop conflating draft with writable |
| `6f0bb70` | Artifact rules verify themselves too |
| `9b3ba56` | 18 draft rules across UI, performance, reliability, security |
| `96f5155` | Carry all 91 checklist rows; adopt the checklist's vocabulary |
| `78358c4` | Show the review checklist against the artifact on screen |
| `91176f5`, `8ff4701` | Handoff rewrites |
| *uncommitted* | §3.1–3.3 above (`hub.js`, `ApiServlet.java`, `RuleStore.java`) |

---

## 5. Build

`build.ps1` is the only supported way to build. It exists to stop five things:

1. **Java 6 bytecode.** WAS 8.5.5 runs Java 6 by default with Java 8 optional.
   Wrong bytecode fails at *class load* — not at build, not at deploy, but the
   first time a servlet is touched. Every class is checked for major version 52.
2. **Shipping a broken rule.** A rule whose regex will not compile is skipped
   silently by the engine, so a typo removes a check with no error.
3. **Shipping a rule that fires on correct code.** The clean control must return
   zero findings.
4. **A rule that quietly stopped doing what its author promised.** Every rule
   runs against its own examples.
5. **A stale WAR.** Classes under `BawAssistant.war` are recopied every build.

```powershell
powershell -ExecutionPolicy Bypass -File .\build.ps1
```

Expected tail: `202/202 checks passed`, `verified 107  failing 0`,
`probe sample: 51 findings`, `clean control: 0 findings`, and step 5b green
for **both** front-end suites.

Step 5b runs `testridge-model.test.js` and `testindings.test.js`. The
second is gated for a different reason from the first: `js/findings.js`
decides severity order, filtering and counting for the docked panel **and**
the whole-application review, so a mistake there is wrong twice and in public,
and its severity order has to keep agreeing with `Rule.severityRank`. Node is
not a build requirement — if it is absent the build says so and carries on,
because the Java gates are what protect the deployed artifact.

Requirements, both external to this folder:

| | Path |
|---|---|
| JDK 8 | `C:\Program Files\Java\jdk1.8.0_202` (`-Jdk` to override) |
| WAS stubs | `C:\WebSphere Runtime Stubs\v8.5\dev` (`-Stubs` to override) |

`--release` is a JDK 9+ flag; this builds with `-source 1.8 -target 1.8`.

---

## 6. Deploy

> **Fixed — the deploy story is now honest.** For the history: the script
> copied an explicit file list with **no `WEB-INF\classes` entry**, while the
> build's closing message told you to run it "because Java classes changed".
> A Java fix could look deployed and silently not be.
>
> Now: `build.ps1` hashes the classes it replaces and prints what the change
> actually needs — the copy script for a static-only build, the admin console
> for a Java one. `deploy-assistant.ps1` compares its own classes against the
> deployed ones and **refuses with a non-zero exit** rather than leaving a
> stale servlet unmentioned; `-IncludeJava` copies them for a throwaway
> node-local update, with the ND resync caveat printed.
>
> **`WEB-INF\web.xml` can never be deployed by file copy.** WebSphere merges
> descriptors at *install* time into `web_merged.xml`; a descriptor copied into
> the exploded tree afterwards is not read. Security constraints and role
> declarations only take effect through a full-EAR install.
>
> Admin console path: *Applications → WebSphere enterprise applications →
> BawAssistant → Update → Replace the entire application →
> `BawAssistantEAR-deploy.ear` → Save → synchronise nodes → Start.*

### Security roles — map these at install, or the app 401s everyone

The application declares two roles. After **any** full-EAR install:
*Applications → WebSphere enterprise applications → BawAssistant → Security
role to user/group mapping.*

| Role | Map to | Grants |
|---|---|---|
| `assistant-user` | All Authenticated | lint, read rules, read the checklist |
| `assistant-author` | All Authenticated *(interim)* | save and delete draft rules |

`assistant-author` mapped to All Authenticated is the agreed interim: it closes
anonymous access — the critical half — but does not yet separate authors from
readers. Rebinding it to a real WebSphere group is a **console-only** change,
no rebuild and no redeploy, which is why the role is declared now while the
group is undecided. Do **not** leave it unmapped: `isUserInRole` would be false
for everyone and the Rule Studio would refuse every author with a 403.

### Confirming what is actually running

```bash
curl -sk -u admin:admin https://localhost:9443/assistant/api/status
```

`build.id` must match the id `build.ps1` printed. This is the cheap check that
the classes on the server are the ones just built — a probe once raced an
application restart and reported a working fix as broken (§3.4). The same
response carries `mayAuthor`, so a role mapping can be verified without
attempting a write.

For a static-only change (JS, CSS, JSP, rules):

```powershell
powershell -ExecutionPolicy Bypass -File .\deploy-assistant.ps1
```

Needs an **elevated** shell — `installedApps` is under `C:\Program Files (x86)`.

**Always verify against the live server afterwards.** Testing has found a real
bug every single time it has been done.

```bash
curl -sk -u admin:admin https://localhost:9443/assistant/api/status
```

ND caveat: the master copy lives in the deployment manager's config repository
and is expanded to the node on sync. A direct edit to the node survives normal
use, but a full node resync can revert it.

---

## 7. Design decisions that are locked

- **The EAR is the product.** `twxexplorer` (in the old folder) is a separate
  offline tool and is not part of it.
- **Policy rules ship in the WAR; drafts persist in an overlay** outside it, at
  `…\Node1Profile\bawAssistantRules\`, which survives redeploy. Promotion is
  export → commit → redeploy, and that redeploy *is* the governance gate, not
  an obstacle. Enforced in code: a save is forced to `draft`, and a WAR id is
  refused.
- **Rules carry their own examples** (`fires` / `quiet`), verified by the build.
  Three rules were written and withdrawn for firing on correct code before this
  existed.
- **The checklist's vocabulary wins.** Its field names are kept verbatim.
- **Zero third-party jars.** WebSphere ships no JSON API, hence `Json.java`.
- **The whole-application review reads live artifacts, never a `.twx` export.**
  Decided by the owner 2026-08-30. The container ref is a named snapshot or the
  tip of a branch or track, and a snapshot ref behaves exactly like a branch ref
  everywhere (§11), so one code path serves both. This is also why §3.3
  collapsed duplicates at the endpoint rather than in the rule store.
- **The assistant never authors artifacts — with one bounded exception.**
  `/api/fix` proposes a repair; it does not perform one. The server returns
  `{line, before, after}` and has no path to an artifact. The developer sees
  the exact before and after, presses Apply, and the edit lands in **their
  editor buffer** as if typed.

  > **The Designer autosaves, so an applied fix DOES reach the artifact.**
  > Verified live: applying the `debugger` repair to `AR Demo View` moved the
  > committed model from commitSeq 22 to 23 within seconds, with no one
  > pressing Save. An earlier draft of this note said the edit stays "unsaved,
  > so Designer's save pipeline remains the authority" — the pipeline *is* the
  > authority, and it fires on its own. Treat Apply as a change to the
  > artifact, not to a scratch buffer. It is still undoable in the editor, and
  > still a commit rather than a snapshot, but it is not a private edit.
  Four gates hold the boundary, and none of them is advisory:
  only `enforcement: auto-fixable` **and** `lifecycle: active` rules qualify
  (a draft is a proposal about the standard and must never edit anyone's
  code); a rule claiming auto-fixable without a usable `fix` fails the build
  rather than shipping a dead button; the offer needs two clicks, one to see
  the diff and one to apply it; and each fix is applied alone, followed by a
  re-lint, so no edit has to reason about the offsets another one moved.
- **Ask before redeploying** — it needs elevation and often a Stop/Start.

---

## 8. Pending / not built

Ordered roughly by weight.

### Blocking or risky

1. ~~**`deploy-assistant.ps1` cannot deploy Java.**~~ **Fixed** — see §6. The
   build now says what the change actually needs and the deploy script refuses
   rather than silently skipping classes. A build stamp in `/api/status` makes
   "is my fix live?" one curl.
2. **42 draft rules, now measured against a real application.** Harvesting a
   Life Admin Claims app gave a corpus of **287 surfaces / 266,245 characters**
   (227x the old sample), and 13 of the 42 fired. Results and the
   rule-by-rule reading are in
   `knowledge/rule-packs/quietness-2026-08-29.md`: 3 are ready to promote, 4
   have specific defects to fix first - `HOUSE.CODE.LOOSE_EQUALITY` alone
   fires 475 times, largely on the `!= null` idiom - and several more are loud
   but arguably correct, which is a standards decision rather than a bug.
   Tooling: `tools/harvest-corpus.js` then `com.bawassistant.Corpus`.
   **Still nothing promoted, and never in bulk.**
3. ~~**Authorisation is an open hook.**~~ **Mostly fixed.** The application was
   in fact worse than this said: with no descriptor, WebSphere never challenged
   anything, so an **unauthenticated** POST to `/api/rules/save` returned 200
   and the rule entered the running set for everyone — verified live before the
   fix. `WEB-INF\web.xml` now authenticates every request and `mayAuthor`
   denies by default. **Remaining:** `assistant-author` is mapped to All
   Authenticated, so any *authenticated* user can still author. Binding it to a
   real WebSphere group is the outstanding half, and is a console-only change.

### Features not built

4. ~~**`bridge.js` discards most of the artifact model.**~~ **Fixed.** It now
   reads every artifact type through one generic endpoint, keyed on the
   response's own `domainProperty`, and keeps service settings, coach-view
   header flags, UCA event configuration, business-object annotations and the
   committed code surfaces alongside `variables[]` and `components[]`. The
   readers are DOM-free, so the `.twx` report path can reuse them unchanged.
   The shapes are documented in
   `knowledge/artifact-catalog/artifact-model-map.md` and pinned by
   `test/bridge-model.test.js` against real captured payloads.
   Items 7 and 8 are now unblocked.
5. ~~**`/api/fix`**~~ **Built.** Proposes a repair, shows the diff, and applies
   it to the developer's buffer on request — never to an artifact, never
   without being asked. Only **2 rules** currently declare a fix
   (`HOUSE.CODE.DEBUGGER`, `HOUSE.CODE.CONSOLE`), both `removeLine`, so the
   next step for this feature is widening the auto-fixable set: several rules
   have an obvious mechanical rewrite (`PARSEINT_RADIX`, `LOOSE_EQUALITY`
   `==`→`===`, `SELF_ASSIGNMENT` delete-the-line, `REL.EMPTY_IF`).
6. **The AI / chat path.** Blocked on an open question: whether a WebSphere
   servlet can make a server-to-server call to an approved model endpoint.
   Copilot is approved at LSEG, but that is a *licence*, not an API.
7. ~~**Artifact rules beyond `variables` / `components`**~~ **Built.** Eight
   draft rules now read the per-type `settings`, covering `BusinessObject`,
   `UCA`, `CoachView` and `COACHFLOW` — four types that had no rule of any kind
   before. Every one was measured against 1,719 real artifact models *before*
   it was written, and the counts held exactly when the engine ran them:
   `knowledge/rule-packs/artifact-rules-2026-08-30.md`. Nothing promoted.

   It needed a **six-line engine change**, contrary to the plan's "no engine
   change" note: `settings` is an object, and `ArtifactChecker` could read a
   top-level array or a top-level *number*, so it was unreachable. Proved with
   three `/api/try` probes against the running server before anything was
   edited. `any:` and `count:` now read an object as a collection of one row, so
   settings rules use the same predicates as every other rule. Note the trap the
   probes turned up: `field:` coerces a boolean to `0`, so a boolean read that
   way is true and false at once.

   **Still no rules for `RESTService`, `AppSettings` or `Team`.** The first two
   are under-sampled (0 and 3 in the corpus). `Team` is worse — see §11.
8. ~~**The migration-risk classifier**~~ **Built** as `/compare.jsp`. Lists
   every process app, then the snapshots taken from its branch, and compares
   any two moments: artifacts added, removed and changed, with the findings a
   change introduced and the findings it fixed, ranked by what it broke. Works
   because a snapshot ref behaves exactly like a branch ref. Client-side and
   read-only. Verified live against CAPOC - 14 artifacts each side, 2 correctly
   identified as changed.
9. ~~**The whole-application review**~~ **BUILT** — path 2 of §1, as
   `/review.jsp` plus `POST /api/review`. Pick a process app **or a toolkit**,
   pick the track or a snapshot, press Analyse. The browser sweeps through
   `bridge.js`'s readers and posts batches to the servlet, which runs every
   automated rule and returns findings tagged with the artifact they came
   from; the client merges and groups by rule, after IBM's IDA report.
   Batching is not optional — the body cap is 2 MB and the largest measured
   application is 2,041,023 characters.

   Verified two ways before deploying: 117 code surfaces and 362 artifact
   findings over Test PA from the review's own path, and the identical numbers
   from `com.bawassistant.Corpus` over the same harvest.

   Three things it reports that no rule could: duplicated code (a property of
   a SET — `Corpus.java` states why that can never be a rule), the artifacts
   the readers could not parse, and the checklist rows no machine settles. The
   last two exist because a report of automated findings alone reads as a
   passed review.

   *The original entry, kept for the record:* **No `.twx` export**: it
   reads live at a container ref, a named snapshot or the tip of a branch or
   track. `tools/harvest-corpus.js` already performs exactly that sweep and
   `com.bawassistant.Corpus` already runs every rule over the result, so what is
   missing is the product surface, not the capability. 23 catalogued practices
   and 41 of IBM's IDA rules can be answered by nothing else.
10. **Telemetry.**

### Smaller

11. ~~`BawAssistantEAR.ear/README.md` is stale~~ — fixed while creating this
    folder. It described the app as "no Java, no build", true when it was a
    Tier A probe and not true now. Rewritten; the probe documentation it
    carried is kept, since `probe.jsp` still ships.
12. `envVarSet` is unreachable: its poId returns **HTTP 500**. Every other
    artifact type is readable.
13. ~~The three fixes in §3 are **uncommitted**.~~ **Fixed** — this folder is
    now a git repository; commit `7376840` carries the product as deployed,
    including all three.

---

## 9. Plan

**Immediately next:** enrich the artifact model in `bridge.js` (item 4). The
approach that has worked on this project is to probe the live REST payloads for
each artifact type *first* and design the model against what is actually there,
rather than designing from the documentation and discovering the shape later.
Items 7 and 8 unlock behind it.

Then `/api/fix` (item 5), which is self-contained.

The AI path (item 6) cannot be scheduled until the server-to-server question is
answered; it is a procurement/architecture question, not an engineering one.

Running alongside all of it: **targeted promotion of draft rules** (item 2),
one at a time, each measured against a real application before it becomes
policy.

---

## 10. Environment

| | |
|---|---|
| WebSphere | ND cell `PCCell1`, `Node1Profile`, server `SingleClusterMember1` |
| Deployed at | `C:\Program Files (x86)\IBM\WebSphere\AppServer\profiles\Node1Profile\installedApps\PCCell1\BawAssistant.ear\` |
| Draft store | `…\Node1Profile\bawAssistantRules\` (survives redeploy) |
| Runtime Java | IBM Java 8, bytecode major 52 |
| Hub | `https://localhost:9443/assistant/` |
| Credentials | `admin` / `admin` |
| Test branch (Main) | `2063.595f5dc8-e7e0-469e-845d-26497db1f58a` |
| Test branch (Track2) | `2063.69bb0c1e-03c8-4753-b2fd-610fc6653e86` |
| Process app | Coding Assistant PoC (`CAPOC`) |

REST is reachable with `curl -sk -u admin:admin` — no browser needed for probes.

Playwright attaches over CDP on 9222. Launch Chrome with a **dedicated
`--user-data-dir`** and the anti-occlusion flags, and shut it down **by profile
directory, never by process name** — a name-wide kill closes the user's own
browser.

---

## 11. Findings that cost the most to learn

Do not re-derive these.

- **`/rest/bpm/wle/pd/v1/asset/{poId}` is generic.** The endpoint name is
  ignored; the poId picks the model and `domainProperty` says what came back.
  UCA, business object, team and app settings are all reachable. An earlier
  assessment that they were not was wrong.
- **A snapshot ref (`2064.…`) works as a `containerRef`**, so the current track
  can be diffed against what was actually deployed. Tracks and snapshots both.
- **A client-side human service nests its flow** under
  `extensionElements.userTaskImplementation[0].flowElement`, not at
  `rootElement[0]`. Code written for service flows finds zero steps, silently.
- **`incoming` / `outgoing` are absent when empty**, not empty. That is how you
  detect an unconnected node. Same for variable defaults and coach-view
  handlers.
- **Service flow code surfaces are NOT inside `[data-test-editor]`.** They live
  in the Properties panel (`#editorContainer_bottom`), a sibling. The ancestor
  chain runs `#uniqName_N → #propertiesPaneDiv → #editorContainer_bottom →
  #editorContainer → #mainContainer` and passes through no `[data-test-editor]`
  at all. Scoping to the editor found zero surfaces and Watch silently did
  nothing. A coach view, by contrast, keeps its nine surfaces *inside* its
  editor element.
- **Tab-hidden is not section-hidden.** On Pre & post all three surfaces report
  their section displayed; use `offsetParent` to find the one on screen.
- **Editors accumulate in the DOM.** AppSettings, CaseProcess and CoachView can
  all be present at once. Always take the visible one — never `.last()` blindly
  and never the first match.
- **`window.open(url, name)` targets the window CARRYING that name** —
  including the launcher itself, since a window keeps its name across
  navigations.
- **The Designer's own validator writes into the same annotation model** and
  wipes ours on each edit. Hence the watchdog. Its findings are harvested.
- **`common.name` does not exist for a service flow.** Identity comes from
  `dijit.byId('editorDropdown')`, which carries `<branchRef>-<poId>` and the
  name.
- **Dojo trees ignore synthetic events.** Driving Designer from a test harness
  needs real mouse input; a dispatched `click` selects nothing and a dispatched
  `dblclick` opens nothing. The assistant's own panel, using plain
  `addEventListener`, responds to synthetic events normally.
- **An unmapped security role gives 403, not 401 — and it locks out everyone.**
  After the Phase 1 install, `admin:admin` got **403 on every path** while an
  anonymous request correctly got 401. Authentication was working; the roles
  simply had no mapping, which the console install wizard makes easy to click
  past. Confirmed from the server's own configuration rather than inferred:
  `config\cells\PCCell1\applications\BawAssistant.ear\deployments\BawAssistant\
  deployment.xml` had **no `authorizationTable` element at all**. That file is
  the fastest way to answer "are the roles actually mapped?" — faster than the
  console. The fix is console-only, no redeploy: *Security role to user/group
  mapping* → both roles → "All authenticated in application's realm".
- **LTPA SSO satisfies the constraint, so BASIC never prompts a developer.**
  Verified: an `LtpaToken2` cookie obtained by logging in to BAW alone returns
  **200** from `/assistant/` and `/assistant/api/status` with no credentials
  supplied. Adding BASIC auth therefore costs the developer nothing — the
  challenge only ever appears to a caller with no BAW session, such as `curl`.
- **The Designer autosaves within seconds of an edit.** Applying a repair to a
  buffer moved the committed model from commitSeq 22 to 23 with nobody pressing
  Save, and a later Ctrl+S took it to 24. Anything that writes to a buffer -
  including a test - is writing to the artifact a moment later, so a test that
  edits real code must restore it and confirm the restoration **from REST**,
  not from the editor. The buffer showed the restored text while the committed
  model still held the edit; only the REST read settled it.
- **Selecting another step while the Script tab is open rebuilds ONLY the
  script editor.** `flow-element-id` and `general-name` leave the document
  entirely - not blank, absent - so `selectedNode()` returns null and the
  assistant can no longer say WHICH step the code belongs to, even though it is
  still linting the right buffer. The first switch after opening a step looks
  fine because the General tab was rendered on the way in; it is the second and
  every later switch that loses the identity. What does change reliably is the
  editor's widget id, because the Designer builds a fresh Orion instance per
  node - which is why `surfaceSignature()` keys on it. Anything driving the
  Designer must wait on that widget id, never on `flow-element-id`. Verified
  2026-08-29 while writing the Playwright suite, which now pins the behaviour.
- **The hub page is throttled whenever it is not the visible page**, and the
  hub is where the 500 ms poll lives. Measured: a `setInterval(500)` in the hub
  fired at **0.98/second** instead of 2/second while its tab was hidden - and
  Chrome tightens this further to once a minute after about five minutes
  hidden. Because a surface switch needs two consecutive matching signatures
  before it re-binds, the panel can sit on the previous script for a couple of
  seconds, and much longer if the hub has been buried for a while. It catches
  up on its own; nothing is broken. If validation seems not to fire after
  switching script tasks, bring the hub window forward, or press Validate in
  the docked panel, which runs in the Designer and is never throttled.
  Diagnosed live 2026-08-29 after it looked like a regression: `sense()`,
  `surfaceSignature()` and the watcher were all correct throughout, and the
  hub had zero JavaScript errors for the whole session.
- **One REST endpoint serves every artifact type.**
  `/rest/bpm/wle/pd/v1/asset/{poId}` ignores the name in its path; the poId
  picks the model and the response's `data.domainProperty` names the key the
  model arrived under. Verified across ten artifacts covering all seven editor
  types. Read the readers off `domainProperty`, not off the editor on screen -
  it is the server saying what it sent rather than the client guessing.
- **A coach view has no `definitions` key at all**, so BPMN parsing of it
  yields nothing. Its model is `header` + `inlineScript` + `layout`, and its
  `header.loadJSFunction` / `unloadJSFunction` are two committed code surfaces
  the editor never shows beside the inline script.
- **An enumerated type is not a business object, but it arrives as one.** Both
  come back under `domainProperty: "schema"`; an enumeration is a `simpleType`
  with a `restriction.enumeration` and carries **no `complexType` at all**.
  Reading `complexType[0]` alone therefore produced a business object with no
  name and zero attributes — and the zero was reported as committed fact, which
  is finding F2 in a second artifact type. Found on 2026-08-30 by reading the
  lines behind a rule's hits: 2 of the 4 artifacts a "business object has no
  attributes" rule flagged across the corpus were enumerations. Confirmed live
  from `/rest/bpm/wle/pd/v1/asset/{poId}`, not inferred. The reader now marks
  `settings.isEnumeration`, keeps the name, and says attributes do not apply.
- **A data object is not a step, and it is never connected.**
  `flowElement[]` mixes activities, events, gateways, **data objects** and
  `sequenceFlow` connections. The reader drops sequence flows and kept data
  objects, so `HOUSE.FLOW.TOO_MANY_STEPS` - active policy - was counting them:
  it fired on 44% of the 1,239 flow models in the corpus and on 20% once data
  objects were excluded. There are 6,537 of them across those models, about
  five per flow, so a service with six real steps and five data objects read as
  eleven and tripped a limit of ten. All 6,537 also report `connected: false`
  and **not one reports true**, because a data object has no incoming or
  outgoing by design - which is why an unconnected-step rule fires on 85% of
  flows until it excludes them. Found 2026-08-30 while triaging IBM's IDA
  checkstyle catalogue.
- **A silent rule is not necessarily a quiet rule.** `HOUSE.SQL.PRODUCT_TABLE`
  reported zero hits on two corpora and was read as "the corpus contains
  nothing it looks for". The corpus contained 157 references to internal `LSW_`
  / `BPM_` tables and the rule found 18. Its pattern required the table name to
  sit against the SQL keyword, and every real query qualifies the table with a
  schema - `from <#=tw.local.db2SchemaQualifier#>.BPM_PRCS_CNTR`, or
  `"LEFT JOIN " + procdbSchema + ".LSW_TASK"`. Before trusting a silence,
  grep the corpus for what the rule is *supposed* to find and compare.
- **An EPV is not an envVarSet, and it reads perfectly well.** Five checklist
  rows were recorded as blocked because "envVarSet returns HTTP 500". That
  conflated two artifacts: the 500 belongs to the environment variable *set*,
  which no checklist row asks about, while an **exposed process variable**
  returns its whole model - `extensionElements.epv[0].epvVars[]` with each
  variable's name, default, type and documentation, and `participantRef` for
  the team it is exposed to. Probed live 2026-08-30 across all 31 EPVs in three
  applications. What discriminates a resource root is the **extensionElements
  key** - `epv`, `team`, `trackinggroup`, `userAttributeDefinition` - never the
  declaredType, which is the same for all four. That is also the fix for the
  Team misclassification below.
- **`declaredType === 'resource'` is not enough to call something a Team.**
  `derivedEditorType` returns `Team` for any root with that declaredType, which
  across the measured corpus swept in 31 EPVs, 1 TrackingGroup and 1
  UserAttributeDefinition alongside 27 real teams. Those 33 are *exactly* the 33
  models reading `hasMembers: false`, while all 27 real teams have members — so
  a "team has no members" rule would have fired 33 times and been wrong every
  time. Not fixed; fix the classifier before writing any Team rule.
- **`build.ps1` says "Java changed" per build, not per deploy.** It hashes the
  WAR's classes before and after the copy, so a *second* build of the same
  change reports "No Java change in this build - static files only" while the
  running server still has the old bytecode. Trust the class hash against
  `installedApps`, not the build's closing advice, when deciding whether a
  change needs the admin-console path.
- **A CaseProcess returns three root elements** - the process, its interface
  and a globalUserTask. Select by `declaredType === 'process'`; index 0 is
  correct only by luck.
- **`flowElement[]` mixes steps with `sequenceFlow` connections.** The probe
  service flow holds 14 elements of which 5 are sequence flows, so counting
  them inflates every step-count rule by roughly a third.
- **`declaredType` arrives as a full class name**
  (`com.ibm.bpmsdk.model.bpmn20.ibmext.TFormTask`). Shorten it, or every rule
  matching a step type carries the package prefix.
- **WebSphere generated a `web.xml` at install time, and it is
  `metadata-complete="true"`.** The source WAR has no `web.xml` at all, but the
  deployed one at `installedApps\…\BawAssistant.war\WEB-INF\web.xml` declares
  `AssistantApi` → `/api/*` explicitly, frozen from the `@WebServlet`
  annotation. Annotations are therefore **not** scanned at runtime; that
  descriptor is what routes the API today. Two consequences: a servlet added by
  annotation alone would not be mapped after a reinstall, and any security
  constraint must ship in a source `web.xml` that re-declares the servlet and
  its mapping (or deliberately omits `metadata-complete`). Verified 2026-08-29
  by reading the deployed descriptor.
- **A process is marked by `bpdExtension`, and nothing else is.** The reader
  classified a flow as a `CaseProcess` only when the payload carried a
  `globalUserTask` root beside the process - that is an INLINE user task, so
  every process without one was typed `SERVICEFLOW`. Measured on Test PA: all
  **4 BPDs and 10 of the 24 case processes** were misclassified. That is how
  process rules came to be applied to service flows, and it would equally have
  stopped them applying to real processes the moment the scope was tightened -
  so the classifier had to be fixed FIRST, or the fix would have looked like a
  fix while switching the rules off. `extensionElements.bpdExtension` is where
  the process settings live (`atRiskCalcEnabled`, `autoTrackingEnabled`,
  `optimizeExecForLatency`), so asking for it is the same question as "is this
  a process". Verified across BPD, case process, service flow and integration
  service payloads: present on the first two, absent on the second two.
  **A BPD and a case process are not separable from the payload** - both are
  converged processes carrying `isConvergedProcess`, a `caseExtension` and a
  `bpdExtension`. Only the asset listing tells them apart, and `readInventory`
  keeps that as `listedAs`.
- **A service flow HAS a `laneSet`.** Lanes therefore do not discriminate a
  process from a service flow, and a lane rule scoped to service flows fires
  on real ones - 8 of them on Test PA before the scope was corrected.
- **`appliesTo` had no gate, so scope could not be tested.** `RuleVerifier`
  treated an example whose type was out of scope as a broken example, which
  meant a quiet example could not express "this rule does not apply to that
  type" - the single most useful thing a quiet example can pin. Nothing in the
  build could hold a rule's scope, and 14 process rules shipped scoped to
  `SERVICEFLOW` and `COACHFLOW`. An out-of-scope example in `quiet` now passes
  and says why; in `fires` it is still an authoring error.
- **`parseAsset` alone cannot resolve lane teams; only `readModel` can.**
  `readModel` awaits `ensureAcronym` and `ensureTeams` before parsing, and the
  team behind a lane is what decides whether the lane is the SYSTEM lane.
  `harvest-corpus.js` called `parseAsset` directly, so every process it ever
  harvested carried `systemLaneCount: 0` - and with it
  `maxSequentialSystemActivities: 0`, `systemTasksNotDeletedOnCompletion: 0`
  and an understated `maxScriptSystemAlternation`, while `mixedLanes` was
  OVER-stated. Five rules therefore measured as silent on a corpus when they
  were merely unmeasurable, which is the same failure as
  `SQL.PRODUCT_TABLE`, arriving through the tooling instead of the pattern.
  Measured: **all 28 processes in Test PA differed**, and the whole-application
  review disagreed with a corpus run by 8 findings until the tool was fixed to
  read through `readModel`. Anything measured from a harvest before 2026-08-30
  understates lane-dependent rules. The counts in
  `knowledge/rule-packs/guided-rules-2026-08-30.md` were taken another way and
  are non-zero, so they are unaffected.
- **The listing name is not the editor type, and the review learned it twice.**
  A model carries both: `type` is the asset listing's display name
  ("Integration Service", "Human Service", "BPD") and `editorType` is what the
  payload says it is. Every rule's `appliesTo` is written in the editor
  vocabulary, so sending `type` matches nothing - silently. `review.js` did
  exactly that on its first live run and reported 313 artifact findings where
  the same sweep judged headlessly reported 370, with 9 heritage services, 4
  BPDs and 11 assorted services filed under types no rule has heard of.
  `harvest-corpus.js` carries a comment about hitting this first. Send
  `editorType || type`.
- **A `notWhen` guard was re-scanning the whole line, and a generated line can
  be the whole file.** `isGuarded` scoped the guard to `lineText`, which on
  hand-written code is tens of characters and on generated code is everything.
  A 48 KB single-line service script in Test PA made
  `HOUSE.CFG.HARDCODED_PATH` - **active policy** - cost 232 ms against a
  250 ms budget, of which the pattern itself was **1.2 ms** and the guard 231:
  nine matches, each re-scanning 48 KB. Exceeding that budget makes
  `BufferLinter` DROP the rule's findings for that buffer and emit one
  `category: "engine"` notice instead, so the symptom was not slowness - it was
  findings silently going missing on exactly the files most likely to hide
  something, and only when the server was busy enough to tip over. It showed up
  as a whole-application review reporting 130, 131 or 132 buffer findings on
  identical input.
  The guard now looks 400 characters either side of the match, which is what
  "context" means. **170.7 ms to 5.3 ms, with every finding on four real
  corpora unchanged** - 107 rules, byte-identical output. Nested quantifiers
  were the obvious suspect and were not the cause: making the inner `+`
  possessive changed nothing measurable.
- **A coach carries TWO kinds of event handler and they are not the same
  thing.** *Lifecycle* handlers belong to the coach view itself and live on
  `header` as `loadJSFunction`, `viewJSFunction`, `unloadJSFunction` and the
  rest - the bpmext contract, where implementation legitimately belongs and
  length is normal. *Inline* handlers are configured on one instance of a view
  dropped onto a page ("On load", "On change", "On icon click") and live in
  that layout item's `configData`; the standard is that they call a function,
  wherever the implementation lives. Conflating them produces a rule that is
  wrong on one of the two whatever threshold it picks.
  The reader saw almost none of this before 2026-08-30: only `loadJSFunction`
  and `unloadJSFunction`, so `viewJSFunction` was missed outright and every
  inline handler was invisible. Measured on Test PA: **16 inline handlers
  holding 4,214 characters**, three of them 36 to 41 lines, none of which any
  rule could see - and a `debugger` sitting in one of them that the panel
  reported as clean. Harvesting the same application went from 118 code
  surfaces to 138.
- **A CSHS keeps its coaches' layouts at**
  `rootElement[process].extensionElements.userTaskImplementation[0]
  .flowElement[n].formDefinition.coachDefinition.layout` - the same `layout`
  shape a coach view uses, so one scanner reads both. `layoutItem` nests, and a
  handler three levels down is still a handler.
- **`optionName` beginning with `event` is not enough to call it a handler.**
  `eventName` and `eventValue` are ordinary config options carrying strings,
  and both appear in the measured corpus. The handlers are `event` followed by
  the event constant in upper case - `eventON_CHANGE`, `eventON_ICONCLICK` -
  so the test is `/^event[A-Z][A-Z0-9_]*$/`, not a prefix.
- **An inline event handler's editor carries `data-test-attr="jseditor"`
  exactly - no name in front of it.** `discoverSurfaces` looked for
  `[data-test-attr$=".jseditor"]`, which needs a dot-prefixed name, so every
  inline handler was invisible to the LIVE path: the panel reported "no
  surface" while a 36-line On load handler sat on screen, and a `debugger` two
  lines into another went unreported. The row above the editor carries
  `data-test-attr="jseditor_row"` and its first cell holds the label.
  **Key them on the LABEL, never the widget id.** The id is a Dojo
  `uniqName_N_M` and the enclosing `<uuid>_titleBarNode_pane` is regenerated
  whenever the Designer rebuilds the properties panel - two probe runs minutes
  apart produced different ids and different uuids for the same three
  handlers. The label is what the developer reads and it is stable.
  Verified live against "Sent to Admin": discovery found `event:Title
  formula`, `event:On load`, `event:On icon click`, and reading through dijit
  returned **1,251 characters**, the same length the committed model holds for
  `eventON_LOAD`.
- **A coach component shows every event handler at once.** Title formula, On
  load and On icon click are all on screen together, so "first displayed"
  picks one arbitrarily and lints the wrong buffer while looking like it
  works - the Pre & post failure arriving from another direction. `sense()`
  now prefers the surface containing the caret.
- **Java processes `\uXXXX` escapes in the source stream**, before lexing. A
  `"\u0000"` written into a `.java` file becomes a real NUL byte in the source,
  not a string escape.

﻿<#
    Copy the BAW Assistant build into the exploded application on WebSphere.

    Run in an ELEVATED PowerShell - installedApps lives under
    C:\Program Files (x86) and is not writable otherwise.

        powershell -ExecutionPolicy Bypass -File .\deploy-assistant.ps1

    This is a content-only update: JSPs, CSS, JS and the rules file.

    WHAT THIS SCRIPT CANNOT DO
    --------------------------
    1. Java classes. It copies an explicit file list, and for a long time that
       list silently omitted WEB-INF\classes while the build told you to run
       this script "because Java classes changed". A fix could therefore look
       deployed and not be. The script now CHECKS, and refuses rather than
       misleading you; -IncludeJava copies them if you really want a node-local
       update. The durable path is the admin console.

    2. WEB-INF\web.xml, ever. WebSphere merges descriptors at INSTALL time into
       web_merged.xml; a descriptor copied into the exploded tree afterwards is
       simply not read. Security constraints and role declarations therefore
       only take effect through a full-EAR install.

    WebSphere generated WEB-INF\ibm-web-ext.xml, ibm-web-bnd.xml, web_merged.xml
    and the MANIFESTs at install time; they are deployment metadata, not ours,
    and are never touched here.

    ND caveat: the master copy of the application lives in the deployment
    manager's config repository and is expanded to the node on sync. A direct
    edit to the node survives normal use, but a full node resync can revert it.
    For anything you want to persist, use the admin console instead:
        Applications -> WebSphere enterprise applications -> BawAssistant
        -> Update -> Replace the entire application -> BawAssistantEAR-deploy.ear
        -> Save -> synchronise nodes -> Start

    ROLE MAPPING - required at install, and easy to miss
    ----------------------------------------------------
    The application declares two security roles. After ANY full-EAR install,
    map both, or the application will 401 every user including you:
        Applications -> WebSphere enterprise applications -> BawAssistant
        -> Security role to user/group mapping
            assistant-user    -> All Authenticated
            assistant-author  -> All Authenticated   (interim)

    assistant-author is the interim position agreed with the owner: it closes
    anonymous access, but does not yet separate authors from readers. Rebinding
    it to a real WebSphere group later is a console-only change - no rebuild,
    no redeploy. Do NOT leave it unmapped: isUserInRole would then be false for
    everyone and the Rule Studio would refuse every author with a 403.
#>

[CmdletBinding()]
param(
    [string] $Source = (Join-Path $PSScriptRoot 'BawAssistantEAR.ear\BawAssistant.war'),
    [string] $Target = 'C:\Program Files (x86)\IBM\WebSphere\AppServer\profiles\Node1Profile\installedApps\PCCell1\BawAssistant.ear\BawAssistant.war',
    [switch] $Backup,
    [switch] $IncludeJava
)

$ErrorActionPreference = 'Stop'

function Fail($msg) { Write-Host "  ERROR  $msg" -ForegroundColor Red; exit 1 }

Write-Host "BAW Assistant - content update" -ForegroundColor Cyan
Write-Host "  source: $Source"
Write-Host "  target: $Target"
Write-Host ""

if (-not (Test-Path $Source)) { Fail "source not found" }
if (-not (Test-Path $Target)) { Fail "target not found - is the application installed?" }

# Elevation check: fail loudly rather than half-copying.
$id = [Security.Principal.WindowsIdentity]::GetCurrent()
if (-not (New-Object Security.Principal.WindowsPrincipal $id).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Fail "not elevated. Re-run this from an Administrator PowerShell."
}

# An explicit list, not a wildcard: WEB-INF also holds WebSphere-generated
# descriptors that are deployment metadata, not ours. Add new files here or
# they silently never reach the server.
$files = @('index.jsp', 'tester.jsp', 'probe.jsp',
           'css\app.css',
           'rules.jsp', 'compare.jsp', 'review.jsp',
           'js\app.js', 'js\bridge.js', 'js\findings.js', 'js\hub.js',
           'js\tester.js', 'js\rules.js', 'js\compare.js', 'js\review.js',
           'WEB-INF\rules\house-rules.json')

# A new page needs BOTH its .jsp and its .js added above. Forgetting one ships
# a page that loads and does nothing, with no error anywhere - the failure this
# explicit list exists to make visible, and the one it can still cause.

if ($Backup) {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $bak = Join-Path $env:TEMP "baw-assistant-backup-$stamp"
    New-Item -ItemType Directory -Path $bak -Force | Out-Null
    foreach ($f in $files) {
        $existing = Join-Path $Target $f
        if (Test-Path $existing) {
            $dest = Join-Path $bak $f
            New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null
            Copy-Item $existing $dest -Force
        }
    }
    Write-Host "  backed up the previous build to $bak" -ForegroundColor DarkGray
    Write-Host ""
}

$copied = 0
foreach ($f in $files) {
    $s = Join-Path $Source $f
    if (-not (Test-Path $s)) { Write-Host "  skip    $f (not in source)" -ForegroundColor DarkGray; continue }
    $d = Join-Path $Target $f
    $dir = Split-Path $d -Parent
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Copy-Item $s $d -Force
    Write-Host ("  copied  {0,-18} {1,7} bytes" -f $f, (Get-Item $d).Length) -ForegroundColor Green
    $copied++
}

Write-Host ""
Write-Host "  $copied static file(s) updated." -ForegroundColor Cyan

# ------------------------------------------------------------- Java classes
#
# The gap this closes: the copy list above has never included WEB-INF\classes,
# so a Java change could be built, "deployed" with this script, restarted, and
# still be running the old bytecode - with nothing anywhere saying so.
$srcClasses = Join-Path $Source 'WEB-INF\classes\com\bawassistant'
$dstClasses = Join-Path $Target 'WEB-INF\classes\com\bawassistant'
$stale = @()
if ((Test-Path $srcClasses) -and (Test-Path $dstClasses)) {
    Get-ChildItem $srcClasses -Filter *.class | ForEach-Object {
        $peer = Join-Path $dstClasses $_.Name
        if (-not (Test-Path $peer)) { $stale += $_.Name }
        elseif ((Get-FileHash $_.FullName -Algorithm MD5).Hash -ne
                (Get-FileHash $peer     -Algorithm MD5).Hash) { $stale += $_.Name }
    }
}

if ($stale.Count -eq 0) {
    Write-Host "  java: in sync with the deployed classes." -ForegroundColor DarkGray
} elseif ($IncludeJava) {
    foreach ($n in $stale) {
        Copy-Item (Join-Path $srcClasses $n) (Join-Path $dstClasses $n) -Force
        Write-Host "  copied  $n" -ForegroundColor Green
    }
    $stamp = Join-Path $srcClasses 'build-info.properties'
    if (Test-Path $stamp) { Copy-Item $stamp $dstClasses -Force }
    Write-Host ""
    Write-Host "  $($stale.Count) class(es) copied into the NODE." -ForegroundColor Yellow
    Write-Host "  This is a node-local edit: the deployment manager's config repository" -ForegroundColor Yellow
    Write-Host "  still holds the old application, so a full node resync will revert it." -ForegroundColor Yellow
    Write-Host "  You MUST Stop/Start the application - new classes are not hot-loaded." -ForegroundColor Yellow
} else {
    Write-Host ""
    Write-Host "  STOP - $($stale.Count) Java class(es) differ from what is deployed:" -ForegroundColor Red
    $stale | ForEach-Object { Write-Host "      $_" -ForegroundColor Red }
    Write-Host "  This script has NOT shipped them. Static files above are updated;" -ForegroundColor Red
    Write-Host "  the servlet on the server is still the old one." -ForegroundColor Red
    Write-Host ""
    Write-Host "  Durable fix - admin console, full EAR:" -ForegroundColor Cyan
    Write-Host "    Applications -> WebSphere enterprise applications -> BawAssistant"
    Write-Host "    -> Update -> Replace the entire application -> BawAssistantEAR-deploy.ear"
    Write-Host "    -> Save -> synchronise nodes -> Start"
    Write-Host "    (also the ONLY way to ship WEB-INF\web.xml - see this script's header)"
    Write-Host "  Or, for a throwaway node-local update:  -IncludeJava" -ForegroundColor DarkGray
}

$webinf = Join-Path $Target 'WEB-INF'
if (Test-Path $webinf) {
    $n = (Get-ChildItem $webinf -File).Count
    Write-Host "  WEB-INF descriptors left untouched ($n file(s)) - they are install-time only." -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "Next:" -ForegroundColor Cyan
Write-Host "  1. Static-only change: hard-refresh the browser - JS/CSS is served from"
Write-Host "     disk and JSPs recompile. A Java change needs Stop then Start."
Write-Host "  2. Open  https://localhost:9443/assistant/"
Write-Host "  3. Confirm what is actually running:"
Write-Host "       curl -sk -u admin:admin https://localhost:9443/assistant/api/status"
Write-Host "     Compare build.id against the id printed by build.ps1."
Write-Host "  4. The old diagnostic probe is at /assistant/probe.jsp"

if ($stale.Count -gt 0 -and -not $IncludeJava) { exit 1 }

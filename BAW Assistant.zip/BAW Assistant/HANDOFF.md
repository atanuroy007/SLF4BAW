# Handoff — 2026-08-31

Written at the end of the session that built Phases 7 and 8. Read
`IMPLEMENTATION-PLAN.md` §0 first; this is the delta since it was last
rewritten, plus the things that cost time and should not cost it twice.

---

## State, verified not assumed

| | |
|---|---|
| Working tree | clean, 12 commits this session, `999c9e0` at HEAD |
| Build gate | **202/202**, `verified 108 failing 0`, probe 51, clean control 0 |
| Rules | **175** — 19 active, 156 draft |
| Front-end suites | `bridge-model` 83/83, `findings` 41/41 |
| Designer suite | 35 pass (`01-api`, `02-designer`) |
| Review page suite | 8 pass (`03-review`) |
| Coach events suite | **`04-coach-events` — never run green; needs the deploy below** |
| Live server | build `20260831-080027` |
| Built | build `20260831-090156` |

### The one thing outstanding to deploy

**`js/bridge.js` only.** Static, so `deploy-assistant.ps1` from an elevated
shell, **no Stop/Start**. Java is byte-identical to the server; verified by
hashing `WEB-INF/classes` against `installedApps`, not by trusting the build's
closing advice.

It carries the inline-event-handler surface discovery and the caret-preference
fix. `test/designer/04-coach-events.spec.js` asserts against the *deployed*
bridge and will fail until it lands. **First job of the next session: deploy
it, then run `npm run test:designer` and expect 48 checks green.**

---

## What was built

**Phase 7 — design system and panel UX.** Carbon's design language hand-rolled
(no library: non-negotiable 5, and `PANEL_CSS` is injected into the Designer's
own document). Four collapsible groups, one-line rows that expand, severity and
category filters, a font control. `knowledge/design/carbon-tokens.md` is the
single source and the tiebreak. New `js/findings.js` holds severity order,
filtering, counting and grouping, shared by the panel and the review so the two
cannot disagree about what a finding means.

**Phase 8 — the whole-application review.** `review.jsp` plus
`POST /api/review`. The browser sweeps through `bridge.js`'s readers and posts
batches; the servlet judges. Laid out after IBM's IDA report, one row per
symptom expanding to the artifacts it fired on. Measured on Test PA: 218
artifacts, 138 code surfaces, ~500 findings in ~50 rules, **12 seconds** in a
browser. Evidence in
`knowledge/rule-packs/whole-application-review-2026-08-30.md`.

**Seven defects found on the way**, each recorded in PROJECT.md §11:

1. The review sent the listing name instead of `editorType` — 313 findings
   where 370 were real.
2. Process rules applied to service flows: the classifier called a process a
   `SERVICEFLOW` unless it had an inline user task (all 4 BPDs, 10 of 24 case
   processes), *and* 14 rules were scoped too widely. **121 false positives
   removed.** A process is `extensionElements.bpdExtension`.
3. `RuleVerifier` could not express "out of scope", so nothing in the build
   could hold a rule's scope. It can now.
4. `harvest-corpus.js` called `parseAsset` directly, so it never resolved lane
   teams: every harvested process read `systemLaneCount: 0` and five rules
   measured as silent when they were unmeasurable. **All 28 processes in Test
   PA differed.**
5. `HOUSE.CFG.HARDCODED_PATH` (active policy) was **losing findings** on
   generated code — a `notWhen` guard re-scanned a 48 KB single-line file once
   per match. 170.7 ms → 5.3 ms, output byte-identical across 107 rules and
   four corpora.
6. Almost none of a coach's code was read: only `loadJSFunction` and
   `unloadJSFunction`. 16 inline handlers holding 4,214 characters were
   invisible. New rule `HOUSE.UI.INLINE_EVENT_HANDLER_LONG`.
7. The panel could not see an inline handler live: those editors carry
   `data-test-attr="jseditor"` exactly, not `<name>.jseditor`.

---

## Remaining work, in the order I would take it

### Stage 1 — close out this session's work (small, do first)

1. **Deploy `js/bridge.js`**, then `npm run test:designer` → expect 48 green.
2. **Re-measure the corpora.** Every harvest before 2026-08-30 understated
   lane-dependent rules (defect 4). `samples/corpus`, `corpus-app3` and
   `corpus-app4` should be re-harvested and the five lane rules re-read. This
   changes the evidence base for promotion, so it comes before Stage 2.
3. **Fix the review page's own advice.** It says a large application "takes a
   few minutes"; 218 artifacts took 12 seconds. Unverified above 218 — measure
   against the 957-artifact application before rewording.

### Stage 2 — the promotion decisions (yours, not the engine's)

These need a standards call. I can bring measured evidence for each; the
decision is the owner's.

4. **Promote a first batch** (plan item 5). 156 of 175 rules are drafts and
   nothing has been promoted since the original four. Read the LINES, never the
   count — that has found a defect in a shipping rule five times, twice in this
   session alone. Never in bulk.
5. **The three loud rules** (item 2): `LOOSE_EQUALITY` (1,624 hits on one
   application), `NULL.LIST_INDEX` (1,634), `NULL.TW_LOCAL_CHAIN` (2–141).
   Correct, not noisy. Promoting means accepting a backlog.
6. **Four unsettled thresholds** (item 7): business object attributes,
   components per process, searchable variables, the EPV limit. Table in
   `knowledge/rule-packs/baw-best-practices-catalogue.md` §M.

### Stage 3 — the remaining engineering

7. **Unused-artifact detection** (catalogue B11, I8), deliberately deferred
   from Phase 8. `calledElement` is a real poId and `null` genuinely means
   unimplemented, but a coach flow references a view by `viewUUID`, a UCA by
   its attached service, a team by `teamService`. An incomplete graph calls
   live artifacts dead. **Needs its own measurement pass before anyone sees
   it.**
8. **A health score**, calibrated against the three real corpora rather than
   invented. Deliberately left out so far.
9. **The two rules blocked on one fact** (item 6). *Prefer Service (No Task)*:
   I found `extensionElements.activityType` carrying `["ServiceTask"]` vs
   `["UserTask"]` on Test PA — that is **neither** of the two candidates the
   plan names, and needs one confirming probe. *Team filter service is simple*
   is now answerable, because the review holds the whole application.
10. **Rules that have never fired** (item 8) are unproven rather than proven
    safe. `node tools/open-work.js` and `node tools/answer-sheet.js` regenerate
    what is outstanding.
11. **Toolkit dependency depth** (I1–I5). No dependency endpoint found yet.

### Not scheduled

- **Bind `assistant-author` to a real WebSphere group.** Console-only, no
  rebuild. Until then any *authenticated* user can author rules. The owner
  deferred this on 2026-08-31; it remains the only outstanding security item.
- **The AI path** — still procurement, not engineering.

---

## Things that cost time this session

**`Select-Object -First N` kills `build.ps1` mid-run.** It terminates the
PowerShell pipeline early, so the build died after the self-test and **never
packaged the EAR** — twice. Exit code 255 was the only sign, and I dismissed
it. The owner then deployed a stale artefact. Use:

```powershell
$o = & powershell -ExecutionPolicy Bypass -File .\build.ps1 2>&1
$o | Select-String -Pattern "checks passed|verified |FAIL|build stamp"
```

**Verify the EAR's contents, not the build log.** Unpack it and grep for the
change you just made.

**`build.ps1` reports "Java changed" per BUILD, not per deploy** (§11). Hash
`WEB-INF/classes` against `installedApps` to decide what a deploy needs.

**Bash heredocs mangle `\n` inside Python string literals.** Writing Java or
JS through `python - <<'PY'` turns `"\\n"` into a real newline and produces an
unclosed string literal. Use `String.fromCharCode(10)`, `(char) 10`, or an
index-based splice. Cost four failed builds.

**The self-test log is UTF-16.** `grep` finds nothing in it; read it with
`io.open(..., encoding='utf-16')`.

**Playwright:** an `<option>` is never "visible"; `selectOption`'s `label`
takes a string, not a pattern; and the artifact library has an **"Events"**
category that steals an unscoped click meant for a component's Events tab.

---

## Ground rules that did not change

`build.ps1` is the only build. Ask before every deploy. Test against the live
server. Every new rule ships as a draft with `fires` **and** `quiet` examples.
Measure before promoting, and read the lines a rule matched. Never commit
`samples/corpus*/` or `ref/`. Test PA
(`2063.54dfabb5-c3d4-43aa-8e8a-5f64b0437fd0`) is the shape reference;
*Sample Process With All* raises exactly 16 findings.

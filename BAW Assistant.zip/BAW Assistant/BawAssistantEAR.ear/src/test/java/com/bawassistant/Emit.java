package com.bawassistant;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Prints "ruleId:line" for one file, so the Java engine's output can be diffed
 * against the Python engine's. Two rule engines exist because the real-time
 * product and the offline audit tool are different products; keeping them
 * honest needs a comparison, not an assumption.
 */
public final class Emit {
    public static void main(String[] args) throws Exception {
        List<Rule> rules = new ArrayList<Rule>();
        Map<String, Object> doc = Json.parseObject(read(args[0]));
        for (Object o : Json.arr(doc.get("rules"))) {
            Rule r = Rule.from(Json.obj(o));
            if (r.error == null) { rules.add(r); }
        }
        String code = read(args[1]);
        String lang = args.length > 2 ? args[2] : "javascript";
        for (Finding f : BufferLinter.lint(code, lang, rules, "warning")) {
            System.out.println(f.ruleId + ":" + f.line);
        }
    }
    private static String read(String p) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(p), "UTF-8"));
        StringBuilder sb = new StringBuilder(); String l;
        while ((l = r.readLine()) != null) { sb.append(l).append('\n'); }
        r.close(); return sb.toString();
    }
}

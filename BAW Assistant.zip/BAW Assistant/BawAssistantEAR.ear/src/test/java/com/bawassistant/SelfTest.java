package com.bawassistant;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Verification for the rule engine, runnable without a servlet container.
 *
 *   javac -cp j2ee.jar -d out  src/main/java/com/bawassistant/*.java \
 *                              src/test/java/com/bawassistant/SelfTest.java
 *   java  -cp out  com.bawassistant.SelfTest  path/to/house-rules.json
 *
 * The two checks that matter most are the ones that were bugs before they were
 * features: a rule must not fire on commented-out code, and a string containing
 * "//" must not be mistaken for a comment.
 */
public final class SelfTest {

    private static int checks;
    private static int failed;

    public static void main(String[] args) throws Exception {
        String path = (args.length > 0) ? args[0]
                : "BawAssistant.war/WEB-INF/rules/house-rules.json";

        System.out.println("BAW Assistant rule engine - self test");
        List<Rule> rules = loadRules(path);
        System.out.println("  loaded " + rules.size() + " rules from " + path);

        testJson();
        testDetection(rules);
        testCommentsDoNotFire(rules);
        testStringIsNotAComment(rules);
        testSuppression(rules);
        testSeverityFilter(rules);
        testLanguageScoping(rules);
        testEdgeCases(rules);
        testCollapse(rules);
        testArtifactRules(rules);
        testHardening(rules);
        testFixes(rules);
        testLatency(rules);

        System.out.println();
        System.out.println("  " + (checks - failed) + "/" + checks + " checks passed");
        if (failed > 0) {
            System.out.println("  " + failed + " FAILED");
            System.exit(1);
        }
        System.out.println("  all checks passed");
    }

    // ---------------------------------------------------------------- cases

    private static final String DEFECTIVE =
            "function InitThing(bpmext, utilities, domClass) {\n"
          + "    var endpoint = \"http://api.example.com/v1\";\n"
          + "    // row.innerHTML = \"<b>\" + name;\n"
          + "    /* var pwd = \"leaked\"; */\n"
          + "    row.innerHTML = \"<strong>\" + stage.assignee;\n"
          + "    setTimeout(function () { render(); }, 300);\n"
          + "    console.log(\"debug\");\n"
          + "    debugger;\n"
          + "    try { risky(); } catch (e) {}\n"
          + "    var password = \"hunter22\";\n"
          + "}";

    private static void testJson() {
        System.out.println("\njson");
        Object v = Json.parse("{\"a\":[1,2.5,true,null,\"x\\ny\"],\"b\":{\"c\":\"d\"}}");
        Map<String, Object> m = Json.obj(v);
        check("parses nested structures", m != null && m.size() == 2);
        check("escapes survive", "x\ny".equals(Json.arr(m.get("a")).get(4)));
        check("whole numbers write without .0",
                Json.write(Double.valueOf(12)).equals("12"));
        String round = Json.write(v);
        check("round trips", Json.write(Json.parse(round)).equals(round));
        boolean threw = false;
        try { Json.parse("{\"a\":}"); } catch (Json.JsonException e) { threw = true; }
        check("malformed input throws", threw);
        check("quotes are escaped on write",
                Json.write("he said \"hi\"").equals("\"he said \\\"hi\\\"\""));
    }

    private static void testDetection(List<Rule> rules) {
        System.out.println("\ndetection");
        List<Finding> f = BufferLinter.lint(DEFECTIVE, "javascript", rules, "warning");
        List<String> ids = ids(f);
        for (String want : new String[] {
                "HOUSE.SEC.INNERHTML_CONCAT", "HOUSE.SEC.HARDCODED_CREDENTIALS",
                "HOUSE.CODE.DEBUGGER", "HOUSE.CODE.EMPTY_CATCH",
                "HOUSE.LIFE.UNTRACKED_TIMEOUT", "HOUSE.CFG.HARDCODED_CONFIG" }) {
            check("detects " + want, ids.contains(want));
        }
        boolean positioned = true;
        for (Finding x : f) {
            if (x.line <= 0 || x.snippet.isEmpty()) { positioned = false; }
        }
        check("every finding has a line and a snippet", positioned);
        check("credential is critical",
                "critical".equals(severityOf(f, "HOUSE.SEC.HARDCODED_CREDENTIALS")));
    }

    private static void testCommentsDoNotFire(List<Rule> rules) {
        System.out.println("\ncomments must not fire");
        List<Finding> f = BufferLinter.lint(DEFECTIVE, "javascript", rules, "warning");
        boolean line3 = false;
        boolean line4 = false;
        boolean line5 = false;
        for (Finding x : f) {
            if (x.line == 3) { line3 = true; }
            if (x.line == 4) { line4 = true; }
            if (x.line == 5) { line5 = true; }
        }
        check("line-commented innerHTML ignored", !line3);
        check("block-commented credential ignored", !line4);
        check("the real innerHTML on line 5 still fires", line5);
    }

    private static void testStringIsNotAComment(List<Rule> rules) {
        System.out.println("\nstring literals survive masking");
        String masked = BufferLinter.maskComments(
                "var u = \"http://x.com/a\"; // gone\nvar v = 1;", "javascript");
        check("url inside a string survives", masked.contains("http://x.com/a"));
        check("trailing comment is masked", !masked.contains("gone"));
        String src = "var u = \"http://x.com\"; // c\nvar v = 1;";
        check("masking preserves length",
                BufferLinter.maskComments(src, "javascript").length() == src.length());
        check("masking preserves newlines",
                count(BufferLinter.maskComments(src, "javascript"), '\n') == count(src, '\n'));
    }

    private static void testSuppression(List<Rule> rules) {
        System.out.println("\nsuppression");
        List<Finding> f = BufferLinter.lint(
                "// baw-lint-disable-next-line HOUSE.CODE.DEBUGGER\ndebugger;\ndebugger;\n",
                "javascript", rules, "warning");
        int n = 0;
        int line = 0;
        for (Finding x : f) {
            if ("HOUSE.CODE.DEBUGGER".equals(x.ruleId)) { n++; line = x.line; }
        }
        check("disable-next-line suppresses exactly one", n == 1);
        check("the survivor is line 3", line == 3);

        List<Finding> g = BufferLinter.lint(
                "// baw-lint-disable HOUSE.CODE.DEBUGGER\ndebugger;\n",
                "javascript", rules, "warning");
        check("file-level disable suppresses all",
                !ids(g).contains("HOUSE.CODE.DEBUGGER"));
    }

    private static void testSeverityFilter(List<Rule> rules) {
        System.out.println("\nseverity filter");
        List<Finding> all = BufferLinter.lint(DEFECTIVE, "javascript", rules, "warning");
        List<Finding> maj = BufferLinter.lint(DEFECTIVE, "javascript", rules, "major");
        check("major filter returns fewer (" + maj.size() + " vs " + all.size() + ")",
                maj.size() < all.size());
        boolean onlyMajor = true;
        for (Finding x : maj) {
            if (!"critical".equals(x.severity) && !"major".equals(x.severity)) {
                onlyMajor = false;
            }
        }
        check("major filter excludes minor and warning", onlyMajor);
    }

    private static void testLanguageScoping(List<Rule> rules) {
        System.out.println("\nlanguage scoping");
        check("javascript rules skip css",
                BufferLinter.lint("a { color: red; }", "css", rules, "warning").isEmpty());
        check("javascript rules skip html",
                BufferLinter.lint("<div onclick=\"go()\"></div>", "html", rules, "warning").isEmpty());
    }

    private static void testEdgeCases(List<Rule> rules) {
        System.out.println("\nedge cases (must not throw)");
        String[][] cases = {
            { "empty string", "" },
            { "only newlines", "\n\n\n" },
            { "no trailing newline", "debugger;" },
            { "unterminated string", "var s = \"oops;\ndebugger;" },
            { "unterminated block comment", "/* never closed\ndebugger;" },
            { "unicode", "var s = '日本語';\ndebugger;" },
        };
        for (String[] c : cases) {
            try {
                BufferLinter.lint(c[1], "javascript", rules, "warning");
                check(c[0], true);
            } catch (RuntimeException e) {
                check(c[0] + " -> threw " + e, false);
            }
        }
    }

    private static void testCollapse(List<Rule> rules) {
        System.out.println("\ncollapse repeats");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 12; i++) { sb.append("debugger;\n"); }
        List<Finding> raw = BufferLinter.lint(sb.toString(), "javascript", rules, "warning");
        List<Finding> col = BufferLinter.collapse(raw);
        check("raw keeps every occurrence (" + raw.size() + ")", raw.size() == 12);
        check("collapsed is one row", col.size() == 1);
        check("carries the count", col.get(0).occurrences == 12);
        check("reports the first line", col.get(0).line == 1);
        check("message says how many", col.get(0).message.contains("12"));
    }

    private static void testArtifactRules(List<Rule> rules) {
        System.out.println("\nartifact rules");

        Map<String, Object> wide = artifact("SERVICEFLOW", "Wide Service", 16, 2, false, 4);
        List<String> ids = ids(ArtifactChecker.check(wide, rules, "warning"));
        check("16 inputs is flagged", ids.contains("HOUSE.SIG.TOO_MANY_INPUTS"));
        check("2 outputs is not flagged", !ids.contains("HOUSE.SIG.TOO_MANY_OUTPUTS"));

        /* "Clean" now means "raises no POLICY finding".
         *
         * Draft rules are advisory by construction - HOUSE.SIG.PREFER_FIVE_INPUTS
         * fires at six inputs on purpose, because the checklist asks for fewer
         * than ten and preferably around five. Asserting a bare isEmpty() here
         * would mean no advisory rule could ever be added without a test
         * failure, which is the opposite of what the draft tier is for. */
        Map<String, Object> ok = artifact("SERVICEFLOW", "Tidy Service", 3, 2, false, 5);
        check("a tidy service raises no policy finding",
                active(ArtifactChecker.check(ok, rules, "warning")).isEmpty());

        /* The signature limit is 15, settled by the owner on 2026-08-30.
           Ten steps remains the flow limit, which is a different rule. */
        Map<String, Object> boundary = artifact("SERVICEFLOW", "Exactly Fifteen", 15, 15, false, 10);
        check("exactly at the limit passes (> not >=)",
                active(ArtifactChecker.check(boundary, rules, "warning")).isEmpty());
        check("the advisory five-input rule still fires at fifteen",
                ids(ArtifactChecker.check(boundary, rules, "warning"))
                        .contains("HOUSE.SIG.PREFER_FIVE_INPUTS"));

        Map<String, Object> defaulted = artifact("SERVICEFLOW", "Defaulted", 3, 1, true, 4);
        List<Finding> df = ArtifactChecker.check(defaulted, rules, "warning");
        check("input default is flagged", ids(df).contains("HOUSE.SIG.INPUT_HAS_DEFAULT"));

        Map<String, Object> big = artifact("SERVICEFLOW", "Sprawling", 2, 1, false, 25);
        List<Finding> bf = ArtifactChecker.check(big, rules, "warning");
        check("25 steps is flagged", ids(bf).contains("HOUSE.FLOW.TOO_MANY_STEPS"));
        check("message carries the measured number",
                messageOf(bf, "HOUSE.FLOW.TOO_MANY_STEPS").contains("25"));
        check("message carries the limit",
                messageOf(bf, "HOUSE.FLOW.TOO_MANY_STEPS").contains("10"));
        check("artifact findings carry no line", bf.get(0).line == 0);

        Map<String, Object> wrongType = artifact("CoachView", "A View", 12, 12, true, 25);
        check("rules skip artifact types they do not apply to",
                ArtifactChecker.check(wrongType, rules, "warning").isEmpty());

        subjects(rules);
        guardWindow();
        review(rules);
        naming(rules);
        settings(rules);
        provenance(rules);
        newBufferRules(rules);
        defensiveRules(rules);
        examples(rules);
        prompts(rules);
        regexBudget();
    }

    /* WHICH part of the artifact a finding is about.
     *
     * An artifact finding carries no line, so before this the developer got
     * "a gateway has an outgoing path with no condition" on a process with
     * eleven gateways and no way to tell which. The checker now keeps the rows
     * its predicate actually selected.
     *
     * The trap guarded here is the opposite failure: naming rows that are NOT
     * the problem. A rule of the form "fewer than N of these exist" is
     * violated by what is missing, so listing what is present would point the
     * developer at innocent steps with full confidence.
     */
    private static void subjects(List<Rule> rules) {
        System.out.println();
        System.out.println("finding subjects");

        Map<String, Object> big = artifact("SERVICEFLOW", "Sprawling", 2, 1, false, 25);
        Finding steps = find(ArtifactChecker.check(big, rules, "warning"),
                "HOUSE.FLOW.TOO_MANY_STEPS");
        check("a step-count finding names the steps it counted",
                steps != null && !steps.subjects.isEmpty());
        check("the names are the artifact's own",
                steps != null && steps.subjects.get(0).startsWith("Step "));
        check("the list is capped rather than reprinting the whole artifact",
                steps != null && steps.subjects.size() <= 8);

        Map<String, Object> defaulted = artifact("SERVICEFLOW", "Defaulted", 3, 1, true, 4);
        Finding def = find(ArtifactChecker.check(defaulted, rules, "warning"),
                "HOUSE.SIG.INPUT_HAS_DEFAULT");
        check("an `any` rule names the row that matched",
                def != null && def.subjects.contains("in0"));
        check("and names ONLY the row that matched",
                def != null && def.subjects.size() == 1);

        /* A rule that counts rows but is violated by their ABSENCE must name
           nothing. Built here rather than borrowed from the rule file so the
           test keeps meaning if that rule is ever retired. */
        Map<String, Object> few = new LinkedHashMap<String, Object>();
        few.put("type", "SERVICEFLOW");
        few.put("name", "Sparse");
        List<Object> comps = new ArrayList<Object>();
        Map<String, Object> only = new LinkedHashMap<String, Object>();
        only.put("name", "The One Step");
        only.put("type", "scriptTask");
        comps.add(only);
        few.put("components", comps);
        few.put("variables", new ArrayList<Object>());

        Map<String, Object> condition = new LinkedHashMap<String, Object>();
        condition.put("count", "components");
        condition.put("op", "<");
        condition.put("value", Double.valueOf(2));
        Map<String, Object> raw = new LinkedHashMap<String, Object>();
        raw.put("id", "TEST.TOO_FEW");
        raw.put("kind", "artifact");
        raw.put("name", "too few");
        raw.put("message", "too few steps");
        raw.put("appliesTo", java.util.Arrays.asList("SERVICEFLOW"));
        raw.put("check", condition);
        List<Rule> only1 = new ArrayList<Rule>();
        only1.add(Rule.from(raw));
        List<Finding> got = ArtifactChecker.check(few, only1, "warning");
        check("a rule violated by absence still fires", got.size() == 1);
        check("but it names nothing - the rows present are not the problem",
                got.get(0).subjects.isEmpty());

        /* A settings row is anonymous, so a graph rule could name nothing -
           and settings is where every graph fact lives. The readers publish a
           <field>Names list beside each count and the checker picks it up
           through the field the predicate already names. */
        Map<String, Object> proc = new LinkedHashMap<String, Object>();
        proc.put("type", "CaseProcess");
        proc.put("name", "Named Graph");
        proc.put("components", new ArrayList<Object>());
        proc.put("variables", new ArrayList<Object>());
        Map<String, Object> st = new LinkedHashMap<String, Object>();
        st.put("gatewayConditionsIncomplete", Double.valueOf(2));
        List<Object> gw = new ArrayList<Object>();
        gw.add("Approval decision");
        gw.add("Route by amount");
        st.put("gatewayConditionsIncompleteNames", gw);
        proc.put("settings", st);
        Finding gate = find(ArtifactChecker.check(proc, rules, "warning"),
                "HOUSE.PROC.GATEWAY_CONDITION_INCOMPLETE");
        check("a settings rule names the elements the reader counted",
                gate != null && gate.subjects.contains("Approval decision")
                             && gate.subjects.contains("Route by amount"));

        /* Without the companion list there is nothing to name, and inventing
           one would be worse than silence. */
        Map<String, Object> bare = new LinkedHashMap<String, Object>();
        bare.put("type", "CaseProcess");
        bare.put("name", "Unnamed Graph");
        bare.put("components", new ArrayList<Object>());
        bare.put("variables", new ArrayList<Object>());
        Map<String, Object> st2 = new LinkedHashMap<String, Object>();
        st2.put("gatewayConditionsIncomplete", Double.valueOf(1));
        bare.put("settings", st2);
        Finding noNames = find(ArtifactChecker.check(bare, rules, "warning"),
                "HOUSE.PROC.GATEWAY_CONDITION_INCOMPLETE");
        check("with no companion list it still fires", noNames != null);
        check("and names nothing rather than inventing one",
                noNames != null && noNames.subjects.isEmpty());
    }

    /* The whole-application review's engine half.
     *
     * Not the endpoint itself - that needs a servlet container - but the two
     * properties the endpoint depends on and nothing else pins: that a review
     * only runs snapshot-scoped rules, and that every finding it produces can
     * be traced back to an artifact. At application scale a finding without
     * that is unusable: "loose equality" four hundred times says nothing about
     * which of nine hundred artifacts to open.
     */
    /* A guard looks NEAR the match, not along the whole line.
     *
     * On hand-written code a line is tens of characters and the two are the
     * same thing. On generated code one line can be the whole file, and then a
     * guard re-scans it once per match: measured at 232 ms for nine matches on
     * a 48 KB single-line service script, against a 250 ms budget of which the
     * pattern itself was 1.2 ms. Exceeding that budget DROPS the rule's
     * findings for the buffer, so the cost was never slowness - it was
     * findings quietly going missing on exactly the files most likely to hide
     * something. Bounding the window took it to 5.3 ms with every finding on
     * four real corpora unchanged.
     */
    private static void guardWindow() {
        System.out.println();
        System.out.println("guard window");

        StringBuilder filler = new StringBuilder();
        for (int i = 0; i < 2000; i++) { filler.append("var x").append(i).append("=1; "); }

        Map<String, Object> raw = new LinkedHashMap<String, Object>();
        raw.put("id", "TEST.GUARD");
        raw.put("kind", "buffer");
        raw.put("name", "guarded");
        raw.put("message", "found");
        raw.put("pattern", "NEEDLE");
        raw.put("notWhen", "EXCUSE");
        List<Rule> only = new ArrayList<Rule>();
        only.add(Rule.from(raw));

        /* Adjacent excuse: still suppressed. */
        String near = "EXCUSE NEEDLE";
        check("a guard beside the match still suppresses it",
                BufferLinter.lint(near, "javascript", only, "info").isEmpty());

        /* Excuse 12,000 characters away on the SAME line: no longer suppressed,
           which is the point. Something that far away is not context. */
        String far = "EXCUSE " + filler + " NEEDLE";
        check("a guard far away on a very long line no longer suppresses",
                BufferLinter.lint(far, "javascript", only, "info").size() == 1);

        /* Short lines are unaffected, which is every hand-written buffer. */
        String shortLine = "EXCUSE var a = 1; NEEDLE";
        check("a short line behaves exactly as before",
                BufferLinter.lint(shortLine, "javascript", only, "info").isEmpty());

        /* The property that made this worth fixing: cost must not scale with
           how the code happens to be LAID OUT.
         *
         * Asserted as a ratio rather than a wall-clock figure. The same
           matches, the same guard, the same buffer length - the only
           difference is whether it arrives as one line or many. Before the
           window, the one-line form re-scanned the whole buffer per match and
           was orders of magnitude slower; a fixed millisecond threshold would
           instead measure whatever machine happens to run the build. */
        StringBuilder oneLine = new StringBuilder();
        StringBuilder manyLines = new StringBuilder();
        for (int i = 0; i < 40; i++) {
            oneLine.append("var p").append(i).append(" = NEEDLE; ").append(filler);
            manyLines.append("var p").append(i).append(" = NEEDLE; ")
                     .append(filler).append((char) 10);
        }
        double flat = best(only, oneLine.toString());
        double broken = best(only, manyLines.toString());
        check("the same code on one line costs about the same as on many ("
                + Math.round(flat) + " ms vs " + Math.round(broken) + " ms)",
                flat < Math.max(20.0, broken * 8));
    }

    /** Best of three, so one scheduling hiccup cannot fail a timing check. */
    private static double best(List<Rule> rules, String code) {
        double ms = Double.MAX_VALUE;
        for (int i = 0; i < 3; i++) {
            long t0 = System.nanoTime();
            BufferLinter.lint(code, "javascript", rules, "info");
            ms = Math.min(ms, (System.nanoTime() - t0) / 1000000.0);
        }
        return ms;
    }

    private static void review(List<Rule> rules) {
        System.out.println();
        System.out.println("whole-application review");

        int snapshotScoped = 0;
        int developOnly = 0;
        for (Rule r : rules) {
            if (r.scope.contains(Rule.SCOPE_SNAPSHOT)) { snapshotScoped++; }
            else { developOnly++; }
        }
        check("every rule declares a scope the review can filter on",
                snapshotScoped + developOnly == rules.size());
        /* Today nothing is develop-only, so the filter excludes nothing. It
           exists because `scope` is otherwise a field nothing reads, and a
           develop-only rule added later must not silently start judging
           committed applications. */
        check("no rule is develop-only today, so the review runs them all",
                developOnly == 0);

        Map<String, Object> proc = artifact("SERVICEFLOW", "Sprawling", 2, 1, false, 25);
        List<Finding> found = ArtifactChecker.check(proc, rules, "warning");
        check("a review-scale check still produces findings", !found.isEmpty());
        check("an artifact finding carries no source position, so the client can "
                + "tell it from a buffer one", found.get(0).line == 0);
    }

    private static Finding find(List<Finding> found, String ruleId) {
        for (Finding f : found) {
            if (ruleId.equals(f.ruleId)) { return f; }
        }
        return null;
    }

    /* ----------------------------------------------- rules verify themselves */

    private static void examples(List<Rule> rules) {
        System.out.println("\nrule examples");

        int withExamples = 0;
        int verified = 0;
        List<String> failing = new ArrayList<String>();
        for (RuleVerifier.Result r : RuleVerifier.verifyAll(rules)) {
            withExamples++;
            if (r.verified()) { verified++; } else { failing.add(r.ruleId); }
        }
        /* Both kinds now, not just buffer: an artifact example is the model
           written as JSON, so there is no longer a class of rule that is
           exempt from proving itself. */
        check("every automated rule carries examples", withExamples == countRules(rules));
        check("all " + withExamples + " verify against their own examples",
                failing.isEmpty());
        if (!failing.isEmpty()) {
            System.out.println("         " + failing);
        }

        /* A rule with only positive examples must NOT count as verified. Proving
           a pattern catches the defect is the easy half; the quiet list is what
           stops it catching everything else. */
        Map<String, Object> raw = new LinkedHashMap<String, Object>();
        raw.put("id", "TEST.ONE_SIDED");
        raw.put("kind", "buffer");
        raw.put("pattern", "debugger");
        Map<String, Object> ex = new LinkedHashMap<String, Object>();
        ex.put("fires", java.util.Arrays.asList("debugger;"));
        raw.put("examples", ex);
        RuleVerifier.Result oneSided = RuleVerifier.verify(Rule.from(raw));
        check("a rule with no quiet examples is not verified", !oneSided.verified());
        check("its positive example still passes", oneSided.failed() == 0);

        /* And a rule whose promise is wrong must fail, not quietly pass. */
        ex.put("quiet", java.util.Arrays.asList("debugger;"));   // same snippet, contradictory
        RuleVerifier.Result contradictory = RuleVerifier.verify(Rule.from(raw));
        check("a contradictory example fails", contradictory.failed() == 1);
    }

    private static int countRules(List<Rule> rules) {
        int n = 0;
        for (Rule r : rules) {
            /* Prompts are decided by a person, so they are not counted here. */
            if (r.error == null && r.isAutomated()) { n++; }
        }
        return n;
    }

    /* ------------------------------------------------------ review prompts */

    private static void prompts(List<Rule> rules) {
        System.out.println("\nreview prompts");

        int manual = 0;
        for (Rule r : rules) {
            if (Rule.KIND_MANUAL.equals(r.kind)) { manual++; }
        }
        check("the checklist's unautomatable rows are carried (" + manual + ")",
                manual > 0);

        /* The invariant that matters. A prompt is a question for a person; if
           one ever reached the gutter it would be an unfixable finding, and a
           developer cannot dismiss what the tool will not stop saying. */
        String anything = "var x = 1;\ndebugger;\nfor (;;) {}\n";
        for (Finding f : BufferLinter.lint(anything, "javascript", rules, "warning")) {
            for (Rule r : rules) {
                if (r.id.equals(f.ruleId) && Rule.KIND_MANUAL.equals(r.kind)) {
                    check("a prompt must never become a buffer finding", false);
                    return;
                }
            }
        }
        check("no prompt reaches the buffer linter", true);

        Map<String, Object> art = artifact("SERVICEFLOW", "Anything", 12, 12, true, 25);
        for (Finding f : ArtifactChecker.check(art, rules, "warning")) {
            for (Rule r : rules) {
                if (r.id.equals(f.ruleId) && Rule.KIND_MANUAL.equals(r.kind)) {
                    check("a prompt must never become an artifact finding", false);
                    return;
                }
            }
        }
        check("no prompt reaches the artifact checker", true);

        /* Prompts carry the checklist's own words, which is the whole reason
           they exist - a paraphrase would let the tool and the reviewer drift. */
        Rule sample = null;
        for (Rule r : rules) {
            if (Rule.KIND_MANUAL.equals(r.kind)) { sample = r; break; }
        }
        check("a prompt keeps the checklist wording",
                sample != null && !sample.checkText.isEmpty());
        check("a prompt names who signs it off",
                sample != null && !sample.primaryReviewer.isEmpty());
        check("a prompt says why it matters",
                sample != null && !sample.impactedArea.isEmpty());
    }

    /* ------------------------------------------------------- regex watchdog */

    private static void regexBudget() {
        System.out.println("\nregex budget");

        Map<String, Object> raw = new LinkedHashMap<String, Object>();
        raw.put("id", "TEST.CATASTROPHIC");
        raw.put("kind", "buffer");
        raw.put("pattern", "(a+)+$");     // exponential backtracking, the classic
        raw.put("message", "boom");
        List<Rule> only = new ArrayList<Rule>();
        only.add(Rule.from(raw));

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 200; i++) { sb.append('a'); }
        sb.append('!');                   // no match, so every path is explored

        long t0 = System.currentTimeMillis();
        List<Finding> f = BufferLinter.lint(sb.toString(), "javascript", only, "info");
        long ms = System.currentTimeMillis() - t0;

        /* Without the watchdog this does not finish in any useful time - the
           test would hang rather than fail, which is why the bound is asserted
           explicitly. */
        check("a catastrophic pattern is abandoned (" + ms + " ms)", ms < 2000);
        check("it reports itself rather than failing silently",
                f.size() == 1 && "engine".equals(f.get(0).category));
        check("the report names the rule, not the developer's code",
                f.size() == 1 && "TEST.CATASTROPHIC".equals(f.get(0).ruleId)
                        && f.get(0).line == 0);
    }

    /* ------------------------------------------------ defensive coding */

    /**
     * The guard window is the point of these, so every one is tested twice:
     * unguarded must fire, and guarded ON A PRECEDING LINE must not. The
     * second half is what a line-scoped notWhen could not do, and it is the
     * reason an earlier version of the null rule had to be withdrawn.
     */
    private static void defensiveRules(List<Rule> rules) {
        System.out.println("\ndefensive coding rules");

        fires(rules, "HOUSE.NULL.TW_LOCAL_CHAIN",
                "var n = tw.local.customer.name.trim();");
        quiet(rules, "HOUSE.NULL.TW_LOCAL_CHAIN",
                "if (tw.local.customer !== null) {\n"
              + "    var n = tw.local.customer.name.trim();\n"
              + "}");
        /* The guard must name THIS object. An unrelated check above is not a
           guard, and must not silence the finding. */
        fires(rules, "HOUSE.NULL.TW_LOCAL_CHAIN",
                "if (tw.local.somethingElse !== null) {\n"
              + "    var n = tw.local.customer.name.trim();\n"
              + "}");

        fires(rules, "HOUSE.NULL.LIST_ITERATION",
                "for (var i = 0; i < tw.local.orders.listLength; i++) { go(i); }");
        quiet(rules, "HOUSE.NULL.LIST_ITERATION",
                "if (tw.local.orders && tw.local.orders.listLength > 0) {\n"
              + "    for (var i = 0; i < tw.local.orders.listLength; i++) { go(i); }\n"
              + "}");

        fires(rules, "HOUSE.NULL.LIST_INDEX", "var a = tw.local.orders[0];");
        quiet(rules, "HOUSE.NULL.LIST_INDEX",
                "if (tw.local.orders.listLength > 0) {\n"
              + "    var a = tw.local.orders[0];\n"
              + "}");

        fires(rules, "HOUSE.LOOP.OFF_BY_ONE",
                "for (var i = 0; i <= tw.local.orders.listLength; i++) { go(i); }");
        quiet(rules, "HOUSE.LOOP.OFF_BY_ONE",
                "for (var i = 0; i < tw.local.orders.listLength; i++) { go(i); }");

        fires(rules, "HOUSE.CODE.ASSIGN_IN_CONDITION", "if (status = \"OPEN\") { go(); }");
        quiet(rules, "HOUSE.CODE.ASSIGN_IN_CONDITION", "if (status === \"OPEN\") { go(); }");

        fires(rules, "HOUSE.CODE.NAN_COMPARE", "if (score == NaN) { stop(); }");
        quiet(rules, "HOUSE.CODE.NAN_COMPARE", "if (isNaN(score)) { stop(); }");

        fires(rules, "HOUSE.CODE.PARSEINT_RADIX", "var q = parseInt(raw);");
        quiet(rules, "HOUSE.CODE.PARSEINT_RADIX", "var q = parseInt(raw, 10);");

        /* A guard too far above must not count - four lines is the window. */
        fires(rules, "HOUSE.NULL.TW_LOCAL_CHAIN",
                "if (tw.local.customer !== null) { noop(); }\n\n\n\n\n\n"
              + "var n = tw.local.customer.name.trim();");
    }

    /* ------------------------------------------------------------- naming */

    private static void naming(List<Rule> rules) {
        System.out.println("\nnaming rules");

        Map<String, Object> bad = artifact("SERVICEFLOW", "Naming", 2, 1, false, 2);
        rename(bad, "variables", 0, "Customer_Name");
        rename(bad, "components", 0, "Script task 3");
        List<String> ids = ids(ArtifactChecker.check(bad, rules, "warning"));
        check("non-camelCase variable is flagged",
                ids.contains("HOUSE.NAME.VARIABLE_CONVENTION"));
        check("default step name is flagged",
                ids.contains("HOUSE.NAME.DEFAULT_STEP_NAME"));

        Map<String, Object> good = artifact("SERVICEFLOW", "Naming", 2, 1, false, 2);
        rename(good, "components", 0, "Fetch customer record");
        rename(good, "components", 1, "Validate address");
        List<String> gids = ids(ArtifactChecker.check(good, rules, "warning"));
        check("camelCase variable is not flagged",
                !gids.contains("HOUSE.NAME.VARIABLE_CONVENTION"));
        check("a named step is not flagged",
                !gids.contains("HOUSE.NAME.DEFAULT_STEP_NAME"));
    }

    @SuppressWarnings("unchecked")
    private static void rename(Map<String, Object> artifact, String collection,
                               int index, String name) {
        List<Object> rows = (List<Object>) artifact.get(collection);
        ((Map<String, Object>) rows.get(index)).put("name", name);
    }


    /* ----------------------------------------------------------- settings */

    /**
     * The per-artifact-type rules, which read the model's <b>settings</b>.
     *
     * settings is an object, not an array - the one collection on the artifact
     * model that is not a list. ArtifactChecker reads it as a collection of
     * exactly one row, which is what lets these rules use the same
     * where-predicates as every other rule. Before that, a rule naming
     * settings matched nothing and reported nothing, so it looked correct and
     * silent rather than broken - which is why the behaviour is pinned here.
     */
    private static void settings(List<Rule> rules) {
        System.out.println("\nper-type settings rules");

        Map<String, Object> off = typed("UCA", "Nightly Sweep");
        setting(off, "eventType", "Timer");
        setting(off, "implementationType", "Service");
        setting(off, "isEnabled", Boolean.FALSE);
        List<String> offIds = ids(ArtifactChecker.check(off, rules, "warning"));
        check("a settings flag is read at all", offIds.contains("HOUSE.UCA.DISABLED"));
        check("a UCA with an implementation is not flagged for missing one",
                !offIds.contains("HOUSE.UCA.NO_IMPLEMENTATION"));

        Map<String, Object> on = typed("UCA", "Nightly Sweep");
        setting(on, "eventType", "Timer");
        setting(on, "implementationType", "Service");
        setting(on, "isEnabled", Boolean.TRUE);
        /* Specific, not a bare isEmpty: this artifact is a TIMER UCA, and a
           later rule legitimately has something to say about that. Asserting
           silence overall would mean no new rule could ever be added without
           breaking a test that was never about it. */
        List<String> onIds = ids(ArtifactChecker.check(on, rules, "warning"));
        check("an enabled UCA raises no disabled finding",
                !onIds.contains("HOUSE.UCA.DISABLED"));
        check("and no missing-implementation finding",
                !onIds.contains("HOUSE.UCA.NO_IMPLEMENTATION"));

        /* A missing key is not a false one. `isFalse` alone is satisfied by
           absence, so HOUSE.UCA.DISABLED guards it with `exists` - without
           that guard this rule would fire on every UCA whose settings a
           future reader did not populate. */
        Map<String, Object> unknown = typed("UCA", "Nightly Sweep");
        setting(unknown, "eventType", "Timer");
        setting(unknown, "implementationType", "Service");
        check("an absent flag does not satisfy isFalse",
                !ids(ArtifactChecker.check(unknown, rules, "warning"))
                        .contains("HOUSE.UCA.DISABLED"));

        Map<String, Object> unwired = typed("UCA", "Order Arrived");
        setting(unwired, "eventType", "Message");
        setting(unwired, "isEnabled", Boolean.TRUE);
        check("a UCA wired to nothing is flagged",
                ids(ArtifactChecker.check(unwired, rules, "warning"))
                        .contains("HOUSE.UCA.NO_IMPLEMENTATION"));

        /* Absence stays distinct from emptiness: an artifact carrying no
           settings at all must raise nothing, not everything. */
        Map<String, Object> bare = typed("UCA", "No Settings");
        bare.remove("settings");
        check("an artifact with no settings raises nothing",
                ArtifactChecker.check(bare, rules, "warning").isEmpty());

        Map<String, Object> undescribed = typed("CoachView", "Approval Panel");
        setting(undescribed, "firesBoundaryEvent", Boolean.TRUE);
        setting(undescribed, "hasDescription", Boolean.FALSE);
        List<String> viewIds = ids(ArtifactChecker.check(undescribed, rules, "warning"));
        check("a boundary event with no description is flagged",
                viewIds.contains("HOUSE.VIEW.BOUNDARY_EVENT_UNDOCUMENTED"));

        Map<String, Object> described = typed("CoachView", "Approval Panel");
        setting(described, "firesBoundaryEvent", Boolean.TRUE);
        setting(described, "hasDescription", Boolean.TRUE);
        check("a described view is quiet",
                ArtifactChecker.check(described, rules, "warning").isEmpty());

        /* Two conditions over the same one-row collection must both hold. */
        Map<String, Object> plain = typed("CoachView", "Approval Panel");
        setting(plain, "firesBoundaryEvent", Boolean.FALSE);
        setting(plain, "hasDescription", Boolean.FALSE);
        List<String> plainIds = ids(ArtifactChecker.check(plain, rules, "warning"));
        check("no boundary event means no boundary-event finding",
                !plainIds.contains("HOUSE.VIEW.BOUNDARY_EVENT_UNDOCUMENTED"));
        check("but the missing description is still reported",
                plainIds.contains("HOUSE.VIEW.NO_DESCRIPTION"));

        Map<String, Object> url = typed("COACHFLOW", "Claim Entry");
        setting(url, "exposedAs", "URL");
        check("a URL-exposed human service is flagged",
                ids(ArtifactChecker.check(url, rules, "warning"))
                        .contains("HOUSE.FLOW.EXPOSED_TO_URL"));

        Map<String, Object> unexposed = typed("COACHFLOW", "Claim Entry");
        setting(unexposed, "exposedAs", "NotExposed");
        check("an unexposed human service is not",
                !ids(ArtifactChecker.check(unexposed, rules, "warning"))
                        .contains("HOUSE.FLOW.EXPOSED_TO_URL"));

        /* Business object rules read variables[], which needed no engine
           change - they are here because no rule covered the type before. */
        check("21 attributes is flagged",
                ids(ArtifactChecker.check(businessObject(21), rules, "warning"))
                        .contains("HOUSE.BO.TOO_MANY_ATTRIBUTES"));
        check("exactly 20 passes (> not >=)",
                !ids(ArtifactChecker.check(businessObject(20), rules, "warning"))
                        .contains("HOUSE.BO.TOO_MANY_ATTRIBUTES"));

        Map<String, Object> named = businessObject(2);
        rename(named, "variables", 0, "Customer_Id");
        check("a non-camelCase attribute is flagged",
                ids(ArtifactChecker.check(named, rules, "warning"))
                        .contains("HOUSE.BO.ATTRIBUTE_CONVENTION"));


        /* `any: "artifact"` reaches the artifact's own fields. Before it, a
           rule could not test an artifact's name or type at all: `field:`
           compares numbers, and every where-predicate ran against a row of
           some collection. UI!B18 - is the coach view named after a reserved
           word - is the checklist row that needed it. */
        Map<String, Object> keywordNamed = typed("CoachView", "class");
        check("a rule can test the artifact's own name",
                ids(ArtifactChecker.check(keywordNamed, rules, "warning"))
                        .contains("HOUSE.VIEW.RESERVED_NAME"));
        check("an ordinary name is left alone",
                !ids(ArtifactChecker.check(typed("CoachView", "Claim Summary"), rules, "warning"))
                        .contains("HOUSE.VIEW.RESERVED_NAME"));
        check("and a name merely CONTAINING a keyword is left alone",
                !ids(ArtifactChecker.check(typed("CoachView", "Classification Panel"), rules, "warning"))
                        .contains("HOUSE.VIEW.RESERVED_NAME"));

        /* A real key of that name still wins, so nothing existing changes
           meaning if a model ever carries one. */
        Map<String, Object> shadow = typed("CoachView", "class");
        shadow.put("artifact", new ArrayList<Object>());
        check("a real \"artifact\" key takes precedence over the artifact itself",
                !ids(ArtifactChecker.check(shadow, rules, "warning"))
                        .contains("HOUSE.VIEW.RESERVED_NAME"));

        /* Numeric comparison on a row's own field, as distinct from op/value
           which compares the aggregate. */
        check("a value over the limit is flagged",
                ids(ArtifactChecker.check(epv(300), rules, "warning"))
                        .contains("HOUSE.EPV.VALUE_TOO_LONG"));
        check("exactly at the limit passes (gt not gte)",
                !ids(ArtifactChecker.check(epv(255), rules, "warning"))
                        .contains("HOUSE.EPV.VALUE_TOO_LONG"));
        check("a non-numeric field never satisfies a numeric predicate",
                !ids(ArtifactChecker.check(epvText(), rules, "warning"))
                        .contains("HOUSE.EPV.VALUE_TOO_LONG"));

        /* surfaces[] is reachable by a where-predicate. It was in the posted
           artifact all along and no rule had ever read it. */
        Map<String, Object> pre = typed("SERVICEFLOW", "Has A Pre Assignment");
        pre.put("surfaces", surfaces("preAssignmentScript"));
        check("a pre-assignment script is found through surfaces[]",
                ids(ArtifactChecker.check(pre, rules, "warning"))
                        .contains("HOUSE.CODE.ASSIGNMENT_SCRIPT"));
        Map<String, Object> plainScript = typed("SERVICEFLOW", "Ordinary");
        plainScript.put("surfaces", surfaces("Script"));
        check("an ordinary script surface is not",
                !ids(ArtifactChecker.check(plainScript, rules, "warning"))
                        .contains("HOUSE.CODE.ASSIGNMENT_SCRIPT"));

        /* The owner ruled that processes are exempt: a process may
           legitimately carry a disconnected activity. */
        Map<String, Object> orphanProcess = typed("CaseProcess", "Has An Orphan");
        orphanProcess.put("components", oneOrphan());
        check("a process is exempt from the unconnected-step rule",
                !ids(ArtifactChecker.check(orphanProcess, rules, "warning"))
                        .contains("HOUSE.FLOW.UNCONNECTED_STEP"));
        /* The panel reads steps from the live diagram, where readComponents
           emits {name, type} and no connectivity at all. A bare isFalse is
           satisfied by an absent key, so before the exists guard this rule
           reported every step of every artifact as unconnected. */
        Map<String, Object> live = typed("SERVICEFLOW", "Read From The Diagram");
        live.put("components", diagramComponents());
        check("a diagram-read step reports no connectivity, so nothing is claimed",
                !ids(ArtifactChecker.check(live, rules, "warning"))
                        .contains("HOUSE.FLOW.UNCONNECTED_STEP"));
        Map<String, Object> orphanService = typed("SERVICEFLOW", "Has An Orphan");
        orphanService.put("components", oneOrphan());
        check("a service is not",
                ids(ArtifactChecker.check(orphanService, rules, "warning"))
                        .contains("HOUSE.FLOW.UNCONNECTED_STEP"));
        /* count over an object is one row, not zero. Pinned with a rule built
           here rather than a shipped one, so the engine behaviour is tested
           even if no house rule happens to count settings. */
        Map<String, Object> raw = new LinkedHashMap<String, Object>();
        raw.put("id", "TEST.COUNT_SETTINGS");
        raw.put("kind", "artifact");
        raw.put("severity", "minor");
        raw.put("message", "counted {value}");
        Map<String, Object> cond = new LinkedHashMap<String, Object>();
        cond.put("count", "settings");
        cond.put("op", "==");
        cond.put("value", Double.valueOf(1));
        raw.put("check", cond);
        List<Rule> one = new ArrayList<Rule>();
        one.add(Rule.from(raw));
        check("an object counts as exactly one row",
                messageOf(ArtifactChecker.check(on, one, "warning"),
                        "TEST.COUNT_SETTINGS").contains("1"));
    }


    /** An EPV whose single variable holds a value of the given length. */
    private static Map<String, Object> epv(int valueLength) {
        Map<String, Object> a = typed("EPV", "Constants");
        Map<String, Object> v = new LinkedHashMap<String, Object>();
        v.put("name", "someConstant");
        v.put("category", "EPV");
        v.put("valueLength", Double.valueOf(valueLength));
        List<Object> vars = new ArrayList<Object>();
        vars.add(v);
        a.put("variables", vars);
        setting(a, "isEpv", Boolean.TRUE);
        setting(a, "exposedToTeam", Boolean.TRUE);
        return a;
    }

    /** The same, with a non-numeric length - which must satisfy nothing. */
    private static Map<String, Object> epvText() {
        Map<String, Object> a = epv(1);
        @SuppressWarnings("unchecked")
        List<Object> vars = (List<Object>) a.get("variables");
        @SuppressWarnings("unchecked")
        Map<String, Object> v = (Map<String, Object>) vars.get(0);
        v.put("valueLength", "three hundred");
        return a;
    }

    private static List<Object> surfaces(String surface) {
        Map<String, Object> s = new LinkedHashMap<String, Object>();
        s.put("surface", surface);
        s.put("name", "A surface");
        s.put("code", "tw.local.x = 1;");
        List<Object> out = new ArrayList<Object>();
        out.add(s);
        return out;
    }

    /** What readComponents produces from the live diagram: no connectivity. */
    private static List<Object> diagramComponents() {
        List<Object> out = new ArrayList<Object>();
        for (int i = 1; i <= 3; i++) {
            Map<String, Object> c = new LinkedHashMap<String, Object>();
            c.put("name", "Step " + i);
            c.put("type", "Activity");
            out.add(c);
        }
        return out;
    }

    private static List<Object> oneOrphan() {
        List<Object> out = new ArrayList<Object>();
        Map<String, Object> wired = new LinkedHashMap<String, Object>();
        wired.put("name", "Do the work");
        wired.put("type", "scriptTask");
        wired.put("connected", Boolean.TRUE);
        out.add(wired);
        Map<String, Object> orphan = new LinkedHashMap<String, Object>();
        orphan.put("name", "Left over");
        orphan.put("type", "scriptTask");
        orphan.put("connected", Boolean.FALSE);
        out.add(orphan);
        return out;
    }
    /** An artifact of a given type with an empty settings object. */
    private static Map<String, Object> typed(String type, String name) {
        Map<String, Object> a = new LinkedHashMap<String, Object>();
        a.put("type", type);
        a.put("name", name);
        a.put("variables", new ArrayList<Object>());
        a.put("components", new ArrayList<Object>());
        a.put("settings", new LinkedHashMap<String, Object>());
        return a;
    }

    @SuppressWarnings("unchecked")
    private static void setting(Map<String, Object> artifact, String key, Object value) {
        ((Map<String, Object>) artifact.get("settings")).put(key, value);
    }

    /** A business object with n attributes, named the way a real one is. */
    private static Map<String, Object> businessObject(int attributes) {
        Map<String, Object> a = typed("BusinessObject", "Policy Record");
        List<Object> vars = new ArrayList<Object>();
        for (int i = 1; i <= attributes; i++) {
            Map<String, Object> v = new LinkedHashMap<String, Object>();
            v.put("name", "field" + i);
            v.put("category", "Attribute");
            v.put("hasDefault", Boolean.FALSE);
            vars.add(v);
        }
        a.put("variables", vars);
        return a;
    }

    /* --------------------------------------------------------- provenance */

    private static void provenance(List<Rule> rules) {
        System.out.println("\nprovenance and lifecycle");

        /* scope says WHEN a rule can be evaluated. Almost every rule is both,
           because a full application review runs everything the panel runs;
           what carries information is the rule that only a whole-application
           review can answer. It has to survive export, or promoting a draft
           would silently drop the classification. */
        Rule scoped = ruleById(rules, "HOUSE.REVIEW.GENERAL_17");
        check("a snapshot-only prompt says so",
                scoped != null && scoped.scope.size() == 1
                        && scoped.scope.contains(Rule.SCOPE_SNAPSHOT));
        Rule everyday = ruleById(rules, "HOUSE.CODE.DEBUGGER");
        check("an ordinary rule runs in both",
                everyday != null && everyday.scope.size() == 2);
        check("a rule with no scope defaults to both",
                Rule.from(new LinkedHashMap<String, Object>() {{
                    put("id", "TEST.NO_SCOPE"); put("kind", "buffer");
                    put("pattern", "x"); }}).scope.size() == 2);
        check("scope survives export",
                scoped != null
                        && String.valueOf(scoped.export().get("scope")).contains("snapshot")
                        && !String.valueOf(scoped.export().get("scope")).contains("develop"));
        Rule inputs = ruleById(rules, "HOUSE.SIG.TOO_MANY_INPUTS");
        check("an existing rule cites its checklist cell",
                inputs != null && inputs.source != null
                        && "General!B22".equals(inputs.source.get("locator")));
        check("an existing rule carries a rationale",
                inputs != null && !inputs.rationale.isEmpty());
        check("existing rules are active policy", inputs != null && inputs.isActive());

        Rule fresh = ruleById(rules, "HOUSE.SQL.PRODUCT_TABLE");
        check("a new rule ships as draft",
                fresh != null && Rule.LIFECYCLE_DRAFT.equals(fresh.lifecycle));
        check("a draft rule is never auto-fixable",
                fresh != null && !fresh.autoFixable
                        && !Rule.ENFORCE_AUTO_FIXABLE.equals(fresh.enforcement));

        Rule dbg = ruleById(rules, "HOUSE.CODE.DEBUGGER");
        check("an active fixable rule is marked auto-fixable",
                dbg != null && Rule.ENFORCE_AUTO_FIXABLE.equals(dbg.enforcement));

        Finding f = Finding.of(inputs, "x");
        check("a finding carries the rationale through", !f.rationale.isEmpty());
        check("a finding carries the source through", f.source != null);
        check("toMap exposes the locator",
                f.toMap().containsKey("source") && f.toMap().containsKey("lifecycle"));
    }

    private static Rule ruleById(List<Rule> rules, String id) {
        for (Rule r : rules) {
            if (r.id.equals(id)) { return r; }
        }
        return null;
    }

    /* --------------------------------------------------- new buffer rules */

    private static void newBufferRules(List<Rule> rules) {
        System.out.println("\nnew buffer rules");

        fires(rules, "HOUSE.NULL.COACH_CONTEXT",
                "var x = this.context.options.data.get(\"value\").items;");
        quiet(rules, "HOUSE.NULL.COACH_CONTEXT",
                "var d = this.context.options.data.get(\"value\");\nif (d) { var x = d.items; }");

        fires(rules, "HOUSE.SQL.PRODUCT_TABLE",
                "var q = \"select taskId from LSW_TASK where x = 1\";");
        quiet(rules, "HOUSE.SQL.PRODUCT_TABLE",
                "var q = \"select id from MY_CLAIM_VIEW\";");

        fires(rules, "HOUSE.LOOP.UNBOUNDED", "while (true) { poll(); }");
        quiet(rules, "HOUSE.LOOP.UNBOUNDED", "while (i < items.listLength) { i++; }");

        fires(rules, "HOUSE.CODE.COMMENTED_CODE", "// var old = tw.local.thing;");
        quiet(rules, "HOUSE.CODE.COMMENTED_CODE", "// explains why the next line exists");

        fires(rules, "HOUSE.UI.WINDOW_BINDING", "window.myCache = {};");
        quiet(rules, "HOUSE.UI.WINDOW_BINDING", "var myCache = {};");

        fires(rules, "HOUSE.UI.NON_AMD_LOAD",
                "var s = document.createElement('script');");
        quiet(rules, "HOUSE.UI.NON_AMD_LOAD", "var s = document.createElement('div');");

        fires(rules, "HOUSE.SEC.LOG_SENSITIVE",
                "console.log('user password is ' + pwd);");
        quiet(rules, "HOUSE.SEC.LOG_SENSITIVE",
                "console.log('correlation id ' + tw.local.correlationId);");

        fires(rules, "HOUSE.PERF.EPV_IN_LOOP",
                "for (var i = 0; i < n; i++) { var u = tw.epv.Config.url; }");
        quiet(rules, "HOUSE.PERF.EPV_IN_LOOP",
                "var u = tw.epv.Config.url;\nfor (var i = 0; i < n; i++) { call(u); }");

        fires(rules, "HOUSE.CODE.DEEP_PATH",
                "var v = tw.local.a.b.c.d;");
        quiet(rules, "HOUSE.CODE.DEEP_PATH", "var v = tw.local.a.b;");

        fires(rules, "HOUSE.CODE.LOOSE_EQUALITY", "if (a == b) { go(); }");
        quiet(rules, "HOUSE.CODE.LOOSE_EQUALITY", "if (a === b) { go(); }");

        fires(rules, "HOUSE.CODE.DANGEROUS_EVAL", "var o = eval(raw);");
        quiet(rules, "HOUSE.CODE.DANGEROUS_EVAL", "var o = JSON.parse(raw);");

        fires(rules, "HOUSE.DATE.RAW_ARITHMETIC",
                "var due = new Date().getTime() + 86400000;");

        /* UI!B21 asks for exceptions to be logged. The console rule must not
           contradict the checklist it is derived from. */
        quiet(rules, "HOUSE.CODE.CONSOLE",
                "try { go(); } catch (e) {\nconsole.error(e);\n}");
        fires(rules, "HOUSE.CODE.CONSOLE", "console.log(\"here\");");

        /* Widened beyond innerHTML. */
        fires(rules, "HOUSE.SEC.INNERHTML_CONCAT",
                "el.outerHTML = \"<b>\" + tw.local.name + \"</b>\";");
        fires(rules, "HOUSE.SEC.INNERHTML_CONCAT", "document.write(x);");

        /* Parity with the offline pack. */
        fires(rules, "HOUSE.CFG.HARDCODED_URL",
                "var c = \"jdbc:oracle:thin:@dbhost:1521/orcl\";");
        fires(rules, "HOUSE.CFG.HARDCODED_PATH", "var h = \"10.20.30.40\";");
    }

    private static void fires(List<Rule> rules, String id, String code) {
        check(id + " fires",
                ids(BufferLinter.lint(code, "javascript", rules, "warning")).contains(id));
    }

    private static void quiet(List<Rule> rules, String id, String code) {
        check(id + " stays quiet",
                !ids(BufferLinter.lint(code, "javascript", rules, "warning")).contains(id));
    }

    private static void testLatency(List<Rule> rules) {
        System.out.println("\nlatency (budget 100 ms)");
        StringBuilder sb = new StringBuilder(DEFECTIVE);
        for (int i = 0; i < 480; i++) {
            sb.append("\n    var x").append(i).append(" = compute(").append(i)
              .append("); if (x").append(i).append(" > 0) { total += x").append(i).append("; }");
        }
        String big = sb.toString();
        for (int i = 0; i < 5; i++) {          // warm the JIT
            BufferLinter.lint(big, "javascript", rules, "warning");
        }

        /* Best of three batches, not the average of one.
         *
         * This gate failed twice on a loaded machine - 126 ms and 262 ms -
         * while the same classes measured 27 ms and 55 ms standalone. A gate
         * that fails at random is worse than a slightly generous one, because
         * it teaches people to re-run the build instead of reading it, which
         * is the same trust erosion a noisy rule causes in the gutter. The
         * best of several batches asks what the engine CAN do rather than what
         * the machine happened to allow, which is what the budget is about. */
        double ms = Double.MAX_VALUE;
        for (int batch = 0; batch < 3; batch++) {
            long started = System.nanoTime();
            int runs = 20;
            for (int i = 0; i < runs; i++) {
                BufferLinter.lint(big, "javascript", rules, "warning");
            }
            double taken = (System.nanoTime() - started) / 1_000_000.0 / runs;
            if (taken < ms) { ms = taken; }
        }
        int lines = count(big, '\n') + 1;
        check(lines + "-line buffer lints in " + round(ms) + " ms (best of 3)", ms < 100.0);
    }

    // -------------------------------------------------------------- helpers

    private static Map<String, Object> artifact(String type, String name, int inputs,
                                                int outputs, boolean inputDefault,
                                                int steps) {
        List<Object> vars = new ArrayList<Object>();
        for (int i = 0; i < inputs; i++) {
            Map<String, Object> v = new LinkedHashMap<String, Object>();
            v.put("name", "in" + i);
            v.put("category", "Input");
            v.put("hasDefault", Boolean.valueOf(inputDefault && i == 0));
            vars.add(v);
        }
        for (int i = 0; i < outputs; i++) {
            Map<String, Object> v = new LinkedHashMap<String, Object>();
            v.put("name", "out" + i);
            v.put("category", "Output");
            v.put("hasDefault", Boolean.FALSE);
            vars.add(v);
        }
        // Private variables must never count toward a signature limit.
        Map<String, Object> priv = new LinkedHashMap<String, Object>();
        priv.put("name", "scratch");
        priv.put("category", "Private");
        priv.put("hasDefault", Boolean.TRUE);
        vars.add(priv);

        List<Object> comps = new ArrayList<Object>();
        for (int i = 0; i < steps; i++) {
            Map<String, Object> c = new LinkedHashMap<String, Object>();
            c.put("name", "Step " + i);
            c.put("type", "scriptTask");
            comps.add(c);
        }
        Map<String, Object> a = new LinkedHashMap<String, Object>();
        a.put("type", type);
        a.put("name", name);
        a.put("variables", vars);
        a.put("components", comps);
        return a;
    }

    private static List<Rule> loadRules(String path) throws Exception {
        FileInputStream in = new FileInputStream(path);
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) { sb.append(line).append('\n'); }
        r.close();
        Map<String, Object> doc = Json.parseObject(sb.toString());
        List<Rule> out = new ArrayList<Rule>();
        for (Object o : Json.arr(doc.get("rules"))) {
            Rule rule = Rule.from(Json.obj(o));
            if (rule.error != null) {
                System.out.println("  !! " + rule.id + ": " + rule.error);
                failed++;
                checks++;
            } else {
                out.add(rule);
            }
        }
        return out;
    }

    /** Findings from rules that are policy, not proposals. */
    private static List<Finding> active(List<Finding> f) {
        List<Finding> out = new ArrayList<Finding>();
        for (Finding x : f) {
            if (Rule.LIFECYCLE_ACTIVE.equals(x.lifecycle)) { out.add(x); }
        }
        return out;
    }

    private static List<String> ids(List<Finding> f) {
        List<String> out = new ArrayList<String>();
        for (Finding x : f) { out.add(x.ruleId); }
        return out;
    }

    private static String severityOf(List<Finding> f, String id) {
        for (Finding x : f) { if (id.equals(x.ruleId)) { return x.severity; } }
        return "(absent)";
    }

    private static String messageOf(List<Finding> f, String id) {
        for (Finding x : f) { if (id.equals(x.ruleId)) { return x.message; } }
        return "";
    }

    private static int count(String s, char c) {
        int n = 0;
        for (int i = 0; i < s.length(); i++) { if (s.charAt(i) == c) { n++; } }
        return n;
    }

    private static String round(double d) {
        return String.valueOf(Math.round(d * 10) / 10.0);
    }

    /**
     * The repair path. It proposes; it never applies.
     */
    private static void testFixes(List<Rule> rules) {
        System.out.println("\nrepairs");

        String code = "var a = 1;\ndebugger;\nvar b = 2;\n";
        List<Map<String, Object>> plan = Fixer.plan(code, "javascript", rules, null);
        check("a debugger statement is offered a repair", plan.size() >= 1);

        Map<String, Object> first = null;
        for (Map<String, Object> f : plan) {
            if ("HOUSE.CODE.DEBUGGER".equals(f.get("ruleId"))) { first = f; }
        }
        check("the repair names the rule that asked for it", first != null);
        if (first != null) {
            check("it points at the right line",
                    Integer.valueOf(2).equals(first.get("line")));
            check("it shows the line as it stands",
                    "debugger;".equals(first.get("before")));
            /* null after, not empty string: the line goes away rather than
               being replaced by a blank one. */
            check("removeLine proposes deletion, not a blank line",
                    first.get("after") == null);
        }

        /* The replace action, which rewrites a line rather than deleting it. */
        List<Map<String, Object>> radix = Fixer.plan(
                "var q = parseInt(raw);\n", "javascript", rules, null);
        Map<String, Object> fixRadix = null;
        for (Map<String, Object> f : radix) {
            if ("HOUSE.CODE.PARSEINT_RADIX".equals(f.get("ruleId"))) { fixRadix = f; }
        }
        check("parseInt without a radix is offered a rewrite", fixRadix != null);
        if (fixRadix != null) {
            check("and the rewrite adds the radix, keeping the argument",
                    "var q = parseInt(raw, 10);".equals(fixRadix.get("after")));
        }

        /* A self assignment is removed by replacing it with nothing, rather
           than by deleting the whole line: the line may hold another statement,
           and deleting it would take that with it. */
        List<Map<String, Object>> selfAssign = Fixer.plan(
                "doWork(); paymentMeth = paymentMeth;\n", "javascript", rules, null);
        Map<String, Object> fixSelf = null;
        for (Map<String, Object> f : selfAssign) {
            if ("HOUSE.REL.SELF_ASSIGNMENT".equals(f.get("ruleId"))) { fixSelf = f; }
        }
        check("a self assignment is offered a repair", fixSelf != null);
        if (fixSelf != null) {
            check("and the repair keeps the rest of the line",
                    String.valueOf(fixSelf.get("after")).contains("doWork();"));
            check("while removing the assignment itself",
                    !String.valueOf(fixSelf.get("after")).contains("paymentMeth ="));
        }

        /* The message names the variable. It used to say " is assigned to
           itself" - {1} refers to the second capture group and the pattern has
           only one, so the name silently vanished. */
        List<Finding> named = BufferLinter.lint(
                "paymentMeth = paymentMeth;\n", "javascript", rules, "warning");
        boolean namesIt = false;
        for (Finding f : named) {
            if ("HOUSE.REL.SELF_ASSIGNMENT".equals(f.ruleId)
                    && f.message.startsWith("paymentMeth")) { namesIt = true; }
        }
        check("the self-assignment message names the variable", namesIt);

        /* CRLF, which is how BAW actually stores these buffers.
         *
         * Splitting on a newline leaves a carriage return on every line, while
         * Orion's getLineEnd excludes the delimiter. The proposal therefore
         * carried a CR the editor did not, the staleness check saw a
         * difference that was not real, and every repair was silently refused.
         * Found by applying a fix in the live Designer and watching nothing
         * happen; no unit test would have caught it, because both halves were
         * individually correct. */
        List<Map<String, Object>> crlf = Fixer.plan(
                "var a = 1;\r\ndebugger;\r\nvar b = 2;\r\n", "javascript", rules, null);
        boolean clean = !crlf.isEmpty();
        for (Map<String, Object> f : crlf) {
            String b = String.valueOf(f.get("before"));
            if (b.indexOf('\r') >= 0) { clean = false; }
        }
        check("a CRLF buffer proposes lines without the carriage return", clean);

        /* The gate that matters. A draft is a proposal about what the standard
           SHOULD be; it must never be able to edit a developer's code. */
        Map<String, Object> raw = new LinkedHashMap<String, Object>();
        raw.put("id", "TEST.DRAFT.FIXABLE");
        raw.put("kind", "buffer");
        raw.put("pattern", "^[ \\t]*debugger[ \\t]*;?[ \\t]*$");
        raw.put("message", "x");
        raw.put("lifecycle", "draft");
        raw.put("enforcement", "auto-fixable");
        Map<String, Object> fix = new LinkedHashMap<String, Object>();
        fix.put("action", "removeLine");
        raw.put("fix", fix);
        Rule draft = Rule.from(raw);
        check("a draft is forced off auto-fixable at load",
                !Rule.ENFORCE_AUTO_FIXABLE.equals(draft.enforcement));
        check("and is not fixable", !draft.isFixable());

        List<Rule> onlyDraft = new ArrayList<Rule>();
        onlyDraft.add(draft);
        check("so a draft proposes no repair at all",
                Fixer.plan(code, "javascript", onlyDraft, null).isEmpty());

        /* A rule claiming auto-fixable with no fix is a button that cannot
           work, so it fails the build rather than shipping. */
        Map<String, Object> noFix = new LinkedHashMap<String, Object>();
        noFix.put("id", "TEST.FIXABLE.NOFIX");
        noFix.put("kind", "buffer");
        noFix.put("pattern", "debugger");
        noFix.put("message", "x");
        noFix.put("enforcement", "auto-fixable");
        check("auto-fixable without a fix breaks the rule",
                Rule.from(noFix).error != null);

        /* Nothing the fixer does may touch the code it was handed. */
        String untouched = "var a = 1;\ndebugger;\nvar b = 2;\n";
        Fixer.plan(untouched, "javascript", rules, null);
        check("planning a repair does not modify the buffer",
                untouched.equals("var a = 1;\ndebugger;\nvar b = 2;\n"));
    }

    /**
     * The Phase 3 hardening batch. Every case here failed before its fix.
     */
    private static void testHardening(List<Rule> rules) {
        System.out.println("\nhardening");

        /* F4. A quote inside a regex literal used to open string state that
           never closed, so every comment BELOW it stayed unmasked and rules
           fired on commented-out code - a false positive, which is the kind
           that gets a linter switched off. */
        String regexThenComment = "var re = /['\"]/;\n"
                                + "// debugger;\n";
        String masked = BufferLinter.maskComments(regexThenComment, "javascript");
        check("a quote in a regex literal does not unmask later comments",
                !masked.contains("debugger"));
        check("and no rule fires in the comment below it",
                !ids(BufferLinter.lint(regexThenComment, "javascript", rules, "warning"))
                        .contains("HOUSE.CODE.DEBUGGER"));

        /* The same reset contains an unterminated string to its own line -
           the ordinary state while a developer is mid-keystroke. */
        check("an unterminated string does not unmask the next line",
                !BufferLinter.maskComments("var s = \"oops;\n// debugger;\n",
                        "javascript").contains("debugger"));

        /* A backtick DOES legitimately span lines, so it must still mask. */
        check("a template literal still spans lines",
                BufferLinter.maskComments("var t = `a\nb`; // gone\n",
                        "javascript").contains("a\nb"));

        /* F10. A directive inside a STRING is not a directive. */
        check("a disable directive inside a string does not suppress",
                ids(BufferLinter.lint(
                        "var s = \"baw-lint-disable HOUSE.CODE.DEBUGGER\";\ndebugger;\n",
                        "javascript", rules, "warning"))
                        .contains("HOUSE.CODE.DEBUGGER"));

        /* ...while a real one in a comment still does. */
        check("a real directive in a comment still suppresses",
                !ids(BufferLinter.lint(
                        "// baw-lint-disable HOUSE.CODE.DEBUGGER\ndebugger;\n",
                        "javascript", rules, "warning"))
                        .contains("HOUSE.CODE.DEBUGGER"));

        /* An apostrophe in a comment must not open a string and swallow the
           rest of the file - the mirror of the bug above. */
        check("an apostrophe in a comment does not open a string",
                BufferLinter.maskStrings("// don't do this\nvar x = 1;\n",
                        "javascript").contains("var x = 1;"));

        /* F5. A broken regex in an artifact rule must break the RULE rather
           than being ignored at match time - the failure the build gate exists
           to stop, which until now only ever covered buffer rules. */
        Map<String, Object> where = new LinkedHashMap<String, Object>();
        where.put("field", "name");
        where.put("matches", "([unclosed");
        Map<String, Object> cond = new LinkedHashMap<String, Object>();
        cond.put("count", "variables");
        cond.put("where", where);
        Map<String, Object> artifactRule = new LinkedHashMap<String, Object>();
        artifactRule.put("id", "TEST.BAD.ARTIFACT.REGEX");
        artifactRule.put("kind", "artifact");
        artifactRule.put("message", "x");
        artifactRule.put("check", cond);
        check("a broken artifact regex breaks the rule instead of vanishing",
                Rule.from(artifactRule).error != null);

        /* ...and a sound one still loads. */
        where.put("matches", "^tw\\.");
        check("a sound artifact regex still loads",
                Rule.from(artifactRule).error == null);

        /* F6. A malformed unicode escape is an error by the CALLER, so it has
           to arrive as JsonException - a 400 - not as NumberFormatException,
           which escaped the servlet handler and surfaced as a 500. */
        boolean jsonEx = false;
        try {
            Json.parse("\"\\uZZZZ\"");
        } catch (Json.JsonException e) {
            jsonEx = true;
        } catch (RuntimeException e) {
            jsonEx = false;   /* NumberFormatException - the defect */
        }
        check("a malformed unicode escape raises JsonException, not a 500", jsonEx);
        check("a valid unicode escape still decodes",
                "A".equals(Json.parse("\"\\u0041\"")));
    }

    private static void check(String label, boolean ok) {
        checks++;
        if (!ok) { failed++; }
        System.out.println("  [" + (ok ? "ok" : "FAIL") + "] " + label);
    }
}

package com.bawassistant;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * How loudly does each rule fire against real code?
 *
 * A rule that passes its own examples is proved CORRECT, not QUIET, and
 * quietness is what decides whether a rule can become policy. The owner's own
 * precedent is a rule that produced 94,074 findings before it was targeted and
 * 144 afterwards; nothing in the build would have caught that, because the
 * rule passed its examples the whole time.
 *
 * So this runs every rule over a directory of harvested production code and
 * reports the fire rate. It is a measuring instrument, not a gate: a high rate
 * may mean a noisy rule or genuinely poor code, and only a person reading the
 * findings can tell which. The 42 automated drafts are listed first because
 * they are the ones awaiting that judgement.
 *
 *   java -cp out com.bawassistant.Corpus house-rules.json samples/corpus
 *
 * Never shipped: this lives in src/test and build.ps1 keeps it out of the WAR.
 */
public final class Corpus {

    private static final class Stat {
        final Rule rule;
        int files;
        int hits;
        String firstAt = "";
        Stat(Rule r) { this.rule = r; }
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.out.println("usage: Corpus <rules.json> <corpus-dir> [ruleId]");
            System.out.println("  with a ruleId, prints the lines it actually fired on -");
            System.out.println("  a fire count decides nothing on its own.");
            System.exit(2);
        }
        List<Rule> rules = new ArrayList<Rule>();
        Map<String, Object> doc = Json.parseObject(read(new File(args[0])));
        for (Object o : Json.arr(doc.get("rules"))) {
            Rule r = Rule.from(Json.obj(o));
            if (r.error == null) { rules.add(r); }
        }

        List<File> files = new ArrayList<File>();
        collect(new File(args[1]), files);
        Collections.sort(files, new Comparator<File>() {
            public int compare(File a, File b) { return a.getName().compareTo(b.getName()); }
        });

        Map<String, Stat> stats = new LinkedHashMap<String, Stat>();
        for (Rule r : rules) {
            if (Rule.KIND_BUFFER.equals(r.kind)) { stats.put(r.id, new Stat(r)); }
        }

        /* Asked about one rule: show what it actually matched.
         *
         * A count says how loud a rule is and nothing about whether it is
         * RIGHT. 475 findings might be a rule that has to be rewritten, or an
         * application that genuinely does the thing 475 times, and the only way
         * to tell is to read the lines. Promotion is a judgement, so this
         * prints the evidence the judgement needs. */
        if (args.length > 2) {
            sample(args[2], rules, files);
            return;
        }

        long chars = 0;
        int lines = 0;
        for (File f : files) {
            String code = read(f);
            chars += code.length();
            lines += code.split("\n", -1).length;

            /* One lint per file. Hits count every occurrence, because that is
               what a developer actually sees in the gutter; files-hit counts
               each file once, so one pathological file cannot masquerade as a
               problem spread across the whole application. */
            java.util.Set<String> firedHere = new java.util.HashSet<String>();
            for (Finding finding : BufferLinter.lint(
                    code, languageOf(f.getName()), rules, "warning")) {
                Stat s = stats.get(finding.ruleId);
                if (s == null) { continue; }   /* the engine's own budget report */
                s.hits++;
                firedHere.add(finding.ruleId);
                if (s.firstAt.isEmpty()) {
                    s.firstAt = f.getName() + ":" + finding.line;
                }
            }
            for (String id : firedHere) {
                stats.get(id).files++;
            }
        }

        System.out.println("corpus: " + files.size() + " file(s), " + lines
                + " lines, " + chars + " characters");
        System.out.println();

        duplicates(files);

        List<Stat> drafts = new ArrayList<Stat>();
        List<Stat> active = new ArrayList<Stat>();
        List<Stat> silent = new ArrayList<Stat>();
        for (Stat s : stats.values()) {
            if (s.hits == 0) { silent.add(s); continue; }
            if (s.rule.isActive()) { active.add(s); } else { drafts.add(s); }
        }
        Comparator<Stat> loudest = new Comparator<Stat>() {
            public int compare(Stat a, Stat b) { return b.hits - a.hits; }
        };
        Collections.sort(drafts, loudest);
        Collections.sort(active, loudest);

        report("DRAFTS that fired - the promotion decisions", drafts);
        report("POLICY that fired - already binding", active);

        artifactRules(rules, new File(new File(args[1]), "models.json"));

        System.out.println("SILENT on this corpus: " + silent.size() + " rule(s)");
        System.out.println("  Silence is not evidence of quietness - it may mean the corpus");
        System.out.println("  contains nothing the rule looks for. Judge these on a corpus");
        System.out.println("  that exercises them, not on this one.");
        StringBuilder ids = new StringBuilder();
        for (Stat s : silent) {
            if (ids.length() > 0) { ids.append(", "); }
            ids.append(s.rule.id);
        }
        wrap("    ", ids.toString());
    }

    /**
     * The artifact rules, against the structural models the harvest saved.
     *
     * These judge variable counts, step counts and settings rather than text,
     * so a corpus of code files cannot exercise them at all - they were the
     * one group of automated rules with no evidence behind them either way.
     */
    private static void artifactRules(List<Rule> rules, File modelsFile) throws Exception {
        if (!modelsFile.isFile()) {
            System.out.println("ARTIFACT rules: models.json not found - re-harvest to");
            System.out.println("  measure them (the harvester writes it alongside the code).");
            System.out.println();
            return;
        }
        Map<String, Object> doc = Json.parseObject(read(modelsFile));
        List<Object> models = Json.arr(doc.get("models"));
        if (models == null) { models = new ArrayList<Object>(); }

        Map<String, Integer> hits = new LinkedHashMap<String, Integer>();
        Map<String, String> firstAt = new LinkedHashMap<String, String>();
        for (Rule r : rules) {
            if (Rule.KIND_ARTIFACT.equals(r.kind)) { hits.put(r.id, Integer.valueOf(0)); }
        }

        for (Object o : models) {
            Map<String, Object> artifact = Json.obj(o);
            if (artifact == null) { continue; }
            for (Finding f : ArtifactChecker.check(artifact, rules, "warning")) {
                Integer n = hits.get(f.ruleId);
                if (n == null) { continue; }
                hits.put(f.ruleId, Integer.valueOf(n.intValue() + 1));
                if (!firstAt.containsKey(f.ruleId)) {
                    firstAt.put(f.ruleId, Json.str(artifact, "type", "?") + " / "
                            + Json.str(artifact, "name", "?") + " - " + f.message);
                }
            }
        }

        System.out.println("ARTIFACT rules over " + models.size() + " model(s):");
        System.out.println(String.format("  %-44s %6s  %s", "rule", "hits", "first example"));
        for (Map.Entry<String, Integer> e : hits.entrySet()) {
            String at = firstAt.containsKey(e.getKey()) ? firstAt.get(e.getKey()) : "(never fired)";
            if (at.length() > 78) { at = at.substring(0, 78) + "..."; }
            System.out.println(String.format("  %-44s %6d  %s",
                    e.getKey(), e.getValue().intValue(), at));
        }
        System.out.println();
    }

    /**
     * Code that appears more than once, byte for byte.
     *
     * This deliberately is NOT a house rule, and the reason is worth stating.
     * Every rule kind the engine has judges ONE thing in isolation: a buffer
     * rule sees one code surface, an artifact rule sees one artifact's model.
     * Duplication is a property of a SET of artifacts, so no regex over a
     * single buffer and no condition over a single model can ever find it -
     * expressing it as a rule would mean inventing a kind that lies about what
     * it can see. It belongs here, at the level that holds the whole
     * application, and later in the pre-deployment report for the same reason.
     *
     * It matters for measurement as well as for the customer: three identical
     * copies of a control triple every finding inside it, so a rule can look
     * three times noisier than it is.
     */
    private static void duplicates(List<File> files) throws Exception {
        Map<String, List<String>> byContent = new LinkedHashMap<String, List<String>>();
        for (File f : files) {
            String code = read(f);
            /* Whitespace-normalised, so a reformat does not hide a copy, but
               nothing cleverer than that - near-duplicate detection is a
               different and much larger question. */
            String key = code.replaceAll("\\s+", " ").trim();
            if (key.isEmpty()) { continue; }
            List<String> group = byContent.get(key);
            if (group == null) {
                group = new ArrayList<String>();
                byContent.put(key, group);
            }
            group.add(f.getName());
        }

        List<List<String>> dupes = new ArrayList<List<String>>();
        int duplicatedFiles = 0;
        for (List<String> group : byContent.values()) {
            if (group.size() > 1) {
                dupes.add(group);
                duplicatedFiles += group.size() - 1;
            }
        }
        if (dupes.isEmpty()) {
            System.out.println("DUPLICATE code: none");
            System.out.println();
            return;
        }
        Collections.sort(dupes, new Comparator<List<String>>() {
            public int compare(List<String> a, List<String> b) { return b.size() - a.size(); }
        });

        System.out.println("DUPLICATE code: " + dupes.size() + " block(s) copied, "
                + duplicatedFiles + " redundant surface(s)");
        System.out.println("  Findings inside a copied block are counted once per copy, so");
        System.out.println("  these inflate every rate above.");
        int shown = 0;
        for (List<String> group : dupes) {
            if (shown++ >= 12) {
                System.out.println("    ... and " + (dupes.size() - 12) + " more");
                break;
            }
            System.out.println("    x" + group.size() + "  " + join(group, "  =  "));
        }
        System.out.println();
    }

    private static String join(List<String> parts, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) { sb.append(sep); }
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    /** Up to 25 lines one rule fired on, with the source text. */
    private static void sample(String ruleId, List<Rule> rules, List<File> files)
            throws Exception {
        Rule target = null;
        for (Rule r : rules) {
            if (r.id.equals(ruleId)) { target = r; break; }
        }
        if (target == null) {
            System.out.println("no rule with id " + ruleId);
            return;
        }
        System.out.println(target.id + "  [" + target.lifecycle + "]  " + target.name);
        if (target.rationale != null && !target.rationale.isEmpty()) {
            wrap("  ", target.rationale);
        }
        System.out.println();

        int shown = 0;
        int total = 0;
        for (File f : files) {
            String code = read(f);
            String[] lines = code.split("\n", -1);
            for (Finding finding : BufferLinter.lint(
                    code, languageOf(f.getName()), rules, "warning")) {
                if (!ruleId.equals(finding.ruleId)) { continue; }
                total++;
                if (shown >= 25) { continue; }
                String text = (finding.line >= 1 && finding.line <= lines.length)
                        ? lines[finding.line - 1].trim() : "";
                if (text.length() > 96) { text = text.substring(0, 96) + "..."; }
                System.out.println("  " + f.getName() + ":" + finding.line);
                System.out.println("      " + text);
                shown++;
            }
        }
        System.out.println();
        System.out.println("  " + total + " occurrence(s); showing " + shown);
    }

    private static void report(String title, List<Stat> rows) {
        System.out.println(title + ":");
        if (rows.isEmpty()) {
            System.out.println("  (none)");
            System.out.println();
            return;
        }
        System.out.println(String.format("  %-44s %6s %6s  %s",
                "rule", "hits", "files", "first example"));
        for (Stat s : rows) {
            System.out.println(String.format("  %-44s %6d %6d  %s",
                    s.rule.id, s.hits, s.files, s.firstAt));
        }
        System.out.println();
    }

    private static void wrap(String indent, String text) {
        int width = 72;
        while (text.length() > width) {
            int cut = text.lastIndexOf(", ", width);
            if (cut < 0) { cut = width; }
            System.out.println(indent + text.substring(0, cut));
            text = text.substring(Math.min(cut + 2, text.length()));
        }
        if (!text.isEmpty()) { System.out.println(indent + text); }
    }

    private static void collect(File dir, List<File> out) {
        File[] kids = dir.listFiles();
        if (kids == null) { return; }
        for (File f : kids) {
            if (f.isDirectory()) { collect(f, out); }
            else if (isCode(f.getName())) { out.add(f); }
        }
    }

    private static boolean isCode(String name) {
        String n = name.toLowerCase();
        return n.endsWith(".js") || n.endsWith(".css") || n.endsWith(".html");
    }

    private static String languageOf(String name) {
        String n = name.toLowerCase();
        if (n.endsWith(".css")) { return "css"; }
        if (n.endsWith(".html")) { return "html"; }
        return "javascript";
    }

    private static String read(File f) throws Exception {
        BufferedReader r = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), "UTF-8"));
        try {
            StringBuilder sb = new StringBuilder();
            String l;
            while ((l = r.readLine()) != null) { sb.append(l).append('\n'); }
            return sb.toString();
        } finally { r.close(); }
    }
}

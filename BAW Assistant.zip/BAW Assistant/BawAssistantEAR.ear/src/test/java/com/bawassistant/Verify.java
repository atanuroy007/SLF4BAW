package com.bawassistant;
import java.io.*; import java.util.*;
public class Verify {
  public static void main(String[] a) throws Exception {
    StringBuilder sb = new StringBuilder(); 
    BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(a[0]), "UTF-8"));
    for (String l; (l = r.readLine()) != null; ) sb.append(l).append('\n');
    r.close();
    List<Rule> rules = new ArrayList<Rule>();
    for (Object o : Json.arr(Json.parseObject(sb.toString()).get("rules"))) {
      Rule x = Rule.from(Json.obj(o));
      if (x.error == null) rules.add(x); else System.out.println("BROKEN " + x.id + ": " + x.error);
    }
    int ok = 0, bad = 0, unverified = 0;
    for (RuleVerifier.Result res : RuleVerifier.verifyAll(rules)) {
      if (res.error != null) { System.out.println("ERROR  " + res.ruleId + ": " + res.error); bad++; continue; }
      if (res.failed() > 0) {
        bad++;
        System.out.println("FAIL   " + res.ruleId);
        for (RuleVerifier.Case c : res.cases) if (!c.passed())
          System.out.println("         expected " + (c.shouldFire?"fires":"quiet")
            + " but " + (c.didFire?"fired":"did not fire")
            + (c.note!=null? "  ["+c.note+"]":"")
            + "   >>> " + c.snippet.replace("\n"," / "));
      } else if (!res.verified()) { unverified++; System.out.println("THIN   " + res.ruleId + " (needs both fires and quiet)"); }
      else ok++;
    }
    System.out.println();
    System.out.println("verified " + ok + "   failing " + bad + "   incomplete " + unverified);
    if (bad > 0) System.exit(1);
  }
}

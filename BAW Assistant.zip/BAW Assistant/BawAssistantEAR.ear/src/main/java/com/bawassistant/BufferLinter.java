package com.bawassistant;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Scans one code buffer and produces line-accurate findings.
 *
 * This runs on every debounced keystroke, so it operates on a string and never
 * fetches anything. A linter that pauses is a linter that gets switched off.
 *
 * Ported from the Python engine, including two behaviours that were each a bug
 * before they were a feature:
 *
 *   1. Comment masking is string-aware. Masking naively turns
 *      {@code var u = "http://x"} into a comment at the {@code //} and hides the
 *      rest of the line.
 *   2. A finding is anchored on the first non-blank character of its match. A
 *      rule written with a leading {@code \s*} otherwise matches from the
 *      *previous* line, reports the wrong line number, and silently defeats
 *      per-line suppression.
 */
public final class BufferLinter {

    private static final Pattern DISABLE_NEXT =
            Pattern.compile("baw-lint-disable-next-line\\s+([\\w.,\\s]+)");
    private static final Pattern DISABLE_FILE =
            Pattern.compile("baw-lint-disable\\s+([\\w.,\\s]+)");

    private static final int MAX_FINDINGS = 200;

    private BufferLinter() { }

    /** How long any single rule may spend matching before it is abandoned. */
    static final long MATCH_BUDGET_MS = 250;

    /** Raised when a pattern exceeds its budget. Not an error in the buffer. */
    static final class RegexBudgetExceeded extends RuntimeException {
        private static final long serialVersionUID = 1L;
    }

    /**
     * A CharSequence that refuses to be read once its deadline has passed.
     *
     * Java's regex engine has no timeout, and a pattern like <code>(a+)+$</code>
     * against a long non-matching line backtracks for effectively ever. Today
     * every pattern is one we wrote and reviewed; the moment rules can be
     * authored through a UI that stops being true, and one bad pattern would
     * take a request thread with it - on a linter that runs every 500 ms, for
     * every developer with the panel open.
     *
     * The engine calls charAt in its inner loop, so throwing from there is the
     * one reliable way to interrupt it. Checking the clock on every call would
     * itself be costly, so it is checked once per CHECK_EVERY reads: enough to
     * bound the damage, cheap enough not to matter.
     */
    static final class Deadline implements CharSequence {
        private static final int CHECK_EVERY = 2048;
        private final CharSequence inner;
        private final long expiresAt;
        private int reads;

        Deadline(CharSequence inner, long budgetMs) {
            this.inner = inner;
            this.expiresAt = System.currentTimeMillis() + budgetMs;
        }
        public int length() { return inner.length(); }
        public char charAt(int index) {
            if (++reads >= CHECK_EVERY) {
                reads = 0;
                if (System.currentTimeMillis() > expiresAt) {
                    throw new RegexBudgetExceeded();
                }
            }
            return inner.charAt(index);
        }
        public CharSequence subSequence(int start, int end) {
            return inner.subSequence(start, end);
        }
        public String toString() { return inner.toString(); }
    }

    /**
     * Is this match already guarded, and therefore not a finding?
     *
     * The plain case tests `notWhen` against the matched line, which is all most
     * rules need. Null-check rules need more, and the reason is worth stating,
     * because a rule that got this wrong was written and then thrown away:
     *
     *     if (tw.local.customer !== null) {
     *         var n = tw.local.customer.name.trim();     <- match is HERE
     *     }
     *
     * The guard is on the line above, so a line-scoped test cannot see it, and
     * the rule fires on the exact shape the review checklist asks developers to
     * write. A linter that flags correct code is worse than no linter, because
     * it teaches people to stop reading the gutter.
     *
     * So a rule may declare `guardLines: N` to widen the test to the N lines
     * before the match. On its own that would be far too blunt - any unrelated
     * `if` above would silence a genuine finding - so the pattern may also carry
     * {1}, {2}.. placeholders, which are replaced with the LITERAL text of that
     * capture group before the test runs. The guard therefore has to mention the
     * very expression that was matched:
     *
     *     "pattern":    "\\b(tw\\.local\\.[\\w$.]+)\\.trim\\("
     *     "notWhen":    "(?:if|&&|\\|\\|)[^\\n]*{1}"
     *     "guardLines": 3
     *
     * Quoted with \Q..\E so dots in a variable path stay literal.
     */
    /**
     * How much of a line a guard may look at, either side of the match.
     *
     * A guard asks "is THIS occurrence excused by its context", and context
     * means nearby. Scoping it to the whole line is the same thing on hand
     * written code, where a line is tens of characters - and something else
     * entirely on generated code, where one line can be the whole file.
     *
     * Measured: a 48 KB single-line service script in Test PA made
     * HOUSE.CFG.HARDCODED_PATH cost 232 ms, against a 250 ms budget, of which
     * the pattern itself was 1.2 ms and the guard 231. Nine matches, each
     * re-scanning 48 KB. Exceeding the budget DROPS that rule's findings for
     * the buffer, so the cost was not slowness - it was findings quietly going
     * missing on exactly the files most likely to hide something.
     *
     * 400 characters is far wider than any guard token this rule set uses and
     * makes the cost independent of how the code happens to be laid out.
     */
    static final int GUARD_WINDOW = 400;

    static String near(String line, int at) {
        if (line.length() <= GUARD_WINDOW * 2) { return line; }
        int from = Math.max(0, at - GUARD_WINDOW);
        int to = Math.min(line.length(), at + GUARD_WINDOW);
        return line.substring(from, to);
    }

    static boolean isGuarded(Rule rule, Matcher m, String haystack, String[] lines,
                             int[] lineStarts, int idx, String lineText) {
        if (rule.notWhen == null) { return false; }

        if (rule.guardLines <= 0) {
            return rule.notWhen.matcher(near(lineText, m.start() - lineStarts[idx]))
                    .find();
        }

        int from = Math.max(0, idx - rule.guardLines);
        int start = lineStarts[from];
        int end = Math.min(haystack.length(),
                (idx + 1 < lineStarts.length) ? lineStarts[idx + 1] : haystack.length());
        String window = haystack.substring(start, end);

        String src = rule.notWhen.pattern();
        if (src.indexOf('{') >= 0) {
            for (int g = 1; g <= m.groupCount(); g++) {
                String token = "{" + g + "}";
                if (src.indexOf(token) < 0) { continue; }
                String captured = m.group(g);
                /* A group that did not participate cannot be guarded against;
                   an empty literal would match everywhere and silence the rule. */
                if (captured == null || captured.isEmpty()) { return false; }
                src = src.replace(token, Pattern.quote(captured));
            }
            try {
                return Pattern.compile(src).matcher(window).find();
            } catch (PatternSyntaxException e) {
                return false;   /* never let a bad guard silence a rule */
            }
        }
        return rule.notWhen.matcher(window).find();
    }

    public static List<Finding> lint(String code, String language,
                                     List<Rule> rules, String minSeverity) {
        List<Finding> out = new ArrayList<Finding>();
        if (code == null || code.isEmpty() || rules == null) {
            return out;
        }
        if (language == null || language.isEmpty()) {
            language = "javascript";
        }

        String masked = maskComments(code, language);
        String[] lines = code.split("\n", -1);
        int[] lineStarts = lineStarts(code);

        Set<String> fileOff = new HashSet<String>();
        Map<Integer, Set<String>> lineOff = new LinkedHashMap<Integer, Set<String>>();
        /* Directives are read from a buffer whose STRING bodies are
           blanked, never from the raw lines. Otherwise
               var s = "\"baw-lint-disable HOUSE.CODE.DEBUGGER\"";
           turns that rule off for the whole file. Comments must SURVIVE
           this pass, because that is where the directives live, which is
           why it is the mirror image of maskComments and not the same
           mask reused. */
        collectSuppressions(maskStrings(code, language).split("\\n", -1),
                fileOff, lineOff);

        int threshold = Rule.severityRank(minSeverity);
        Set<String> seen = new HashSet<String>();

        for (Rule rule : rules) {
            if (!rule.enabled || rule.error != null) { continue; }
            if (!Rule.KIND_BUFFER.equals(rule.kind)) { continue; }
            if (!rule.applies(language)) { continue; }
            if (fileOff.contains(rule.id)) { continue; }
            if (Rule.severityRank(rule.severity) > threshold) { continue; }

            String haystack = rule.scanComments ? code : masked;
            /* Each rule gets its own budget, so one runaway pattern costs its
               own time and is dropped - it does not stop the rules after it. */
            Matcher m = rule.pattern.matcher(new Deadline(haystack, MATCH_BUDGET_MS));
            try {
            while (m.find()) {
                int offset = firstNonBlank(haystack, m.start(), m.end());
                int idx = lineOf(lineStarts, offset);
                int lineNo = idx + 1;

                Set<String> off = lineOff.get(Integer.valueOf(lineNo));
                if (off != null && off.contains(rule.id)) { continue; }

                String lineText = idx < lines.length ? lines[idx] : "";
                if (isGuarded(rule, m, haystack, lines, lineStarts, idx, lineText)) {
                    continue;
                }

                int col = offset - lineStarts[idx] + 1;
                String key = rule.id + ":" + lineNo + ":" + col;
                if (!seen.add(key)) { continue; }

                Finding f = Finding.of(rule, format(rule.message, m));
                f.line = lineNo;
                f.column = col;
                f.endColumn = col + Math.max(1, m.end() - offset);
                f.snippet = trimTo(lineText.trim(), 200);
                out.add(f);

                if (out.size() >= MAX_FINDINGS) { break; }
            }
            } catch (RegexBudgetExceeded e) {
                /* Drop this rule's findings for this buffer and carry on. Being
                   silent would hide a rule that has stopped working, so it is
                   reported as a finding of its own - against the rule, not the
                   developer's code. */
                Finding f = new Finding();
                f.ruleId = rule.id;
                f.ruleName = rule.name;
                f.category = "engine";
                f.severity = "warning";
                f.enforcement = Rule.ENFORCE_ADVISORY;
                f.message = "rule skipped: its pattern exceeded "
                          + MATCH_BUDGET_MS + " ms on this buffer";
                f.remediation = "The expression backtracks too heavily. Avoid nested "
                          + "quantifiers such as (a+)+ and prefer a bounded character class.";
                f.line = 0;
                out.add(f);
            }
            if (out.size() >= MAX_FINDINGS) { break; }
        }

        Collections.sort(out, new Comparator<Finding>() {
            public int compare(Finding a, Finding b) {
                if (a.line != b.line) { return a.line - b.line; }
                if (a.column != b.column) { return a.column - b.column; }
                return Rule.severityRank(a.severity) - Rule.severityRank(b.severity);
            }
        });
        return out;
    }

    /**
     * One row per rule per buffer, carrying an occurrence count.
     *
     * Inline annotation wants every occurrence - each offending line really is a
     * defect. A findings <i>list</i> does not: one artifact in the reference
     * corpus swallows errors in 52 places, and 52 identical rows is the kind of
     * noise that gets a linter turned off. Squiggle on all of them, list once.
     */
    public static List<Finding> collapse(List<Finding> findings) {
        Map<String, Finding> byRule = new LinkedHashMap<String, Finding>();
        for (Finding f : findings) {
            Finding first = byRule.get(f.ruleId);
            if (first == null) {
                f.occurrences = 1;
                byRule.put(f.ruleId, f);
            } else {
                first.occurrences++;
                if (f.line < first.line) {
                    first.line = f.line;
                    first.column = f.column;
                    first.snippet = f.snippet;
                }
            }
        }
        List<Finding> out = new ArrayList<Finding>(byRule.values());
        for (Finding f : out) {
            if (f.occurrences > 1) {
                f.message = f.message + "  (×" + f.occurrences + " in this block)";
            }
        }
        return out;
    }

    // ---------------------------------------------------------- internals

    /**
     * Blank out comment bodies while preserving every character position, so
     * line and column arithmetic stays valid.
     *
     * String literals are tracked, which is the whole point: without it,
     * {@code "http://example.com"} reads as the start of a line comment and
     * everything after it on that line disappears. Regex literals are not
     * tracked - telling {@code /} as division from {@code /} as a regex needs a
     * real parser, and the failure mode here is a missed finding rather than a
     * false one.
     */
    static String maskComments(String text, String language) {
        boolean html = "html".equals(language);
        boolean css = "css".equals(language);
        String opener = html ? "<!--" : "/*";
        String closer = html ? "-->" : "*/";
        String lineComment = (html || css) ? null : "//";

        char[] out = text.toCharArray();
        int i = 0;
        int n = text.length();
        char quote = 0;

        while (i < n) {
            char c = text.charAt(i);

            if (quote != 0) {
                /* A backslash escape first, so a line continuation inside a
                   string is still honoured before the newline rule below. */
                if (c == '\\') { i += 2; continue; }
                if (c == quote) { quote = 0; i++; continue; }
                /* An unterminated ' or " string does NOT reach the next line.
                 *
                 * Without this, a single quote inside a regex literal -
                 * /['"]/ is ordinary code - opened a string that never
                 * closed, so every comment BELOW it stayed unmasked and rules
                 * fired on commented-out code. The class note above called
                 * that failure "a missed finding rather than a false one"; it
                 * was the other way round, and a false positive is what gets
                 * a linter switched off. The same reset contains an
                 * unterminated string typed mid-edit to the line it is on.
                 * Backticks legitimately span lines, so they are exempt. */
                if (c == '\n' && quote != '`') { quote = 0; i++; continue; }
                i++;
                continue;
            }

            if (!html && (c == '"' || c == '\'' || c == '`')) {
                quote = c;
                i++;
                continue;
            }

            if (lineComment != null && text.startsWith(lineComment, i)) {
                while (i < n && text.charAt(i) != '\n') { out[i++] = ' '; }
                continue;
            }

            if (text.startsWith(opener, i)) {
                int end = text.indexOf(closer, i + opener.length());
                end = (end < 0) ? n : end + closer.length();
                for (int j = i; j < end; j++) {
                    if (out[j] != '\n') { out[j] = ' '; }
                }
                i = end;
                continue;
            }

            i++;
        }
        return new String(out);
    }

    /**
     * Blank out string BODIES while leaving comments intact - the mirror of
     * {@link #maskComments}.
     *
     * Used only for reading suppression directives. It has to understand
     * comments even though it preserves them: an apostrophe in
     * {@code // don't do this} would otherwise open a string and swallow the
     * rest of the file, which is the very bug this pass exists to avoid on
     * the other side.
     */
    static String maskStrings(String text, String language) {
        boolean html = "html".equals(language);
        boolean css = "css".equals(language);
        String opener = html ? "<!--" : "/*";
        String closer = html ? "-->" : "*/";
        String lineComment = (html || css) ? null : "//";

        char[] out = text.toCharArray();
        int i = 0;
        int n = text.length();
        char quote = 0;

        while (i < n) {
            char c = text.charAt(i);

            if (quote != 0) {
                if (c == '\\') { i += 2; continue; }
                if (c == quote) { quote = 0; i++; continue; }
                if (c == '\n' && quote != '`') { quote = 0; i++; continue; }
                out[i] = ' ';
                i++;
                continue;
            }

            /* Comments pass through untouched - they carry the directives. */
            if (lineComment != null && text.startsWith(lineComment, i)) {
                while (i < n && text.charAt(i) != '\n') { i++; }
                continue;
            }
            if (text.startsWith(opener, i)) {
                int end = text.indexOf(closer, i + opener.length());
                i = (end < 0) ? n : end + closer.length();
                continue;
            }

            if (!html && (c == '"' || c == '\'' || c == '`')) {
                quote = c;
            }
            i++;
        }
        return new String(out);
    }

    private static void collectSuppressions(String[] lines, Set<String> fileOff,
                                            Map<Integer, Set<String>> lineOff) {
        for (int i = 0; i < lines.length; i++) {
            Matcher m = DISABLE_NEXT.matcher(lines[i]);
            if (m.find()) {
                Integer target = Integer.valueOf(i + 2);   // the *next* line
                Set<String> set = lineOff.get(target);
                if (set == null) {
                    set = new HashSet<String>();
                    lineOff.put(target, set);
                }
                addIds(set, m.group(1));
                continue;
            }
            m = DISABLE_FILE.matcher(lines[i]);
            if (m.find()) {
                addIds(fileOff, m.group(1));
            }
        }
    }

    private static void addIds(Set<String> into, String raw) {
        for (String token : raw.replace(',', ' ').trim().split("\\s+")) {
            if (!token.isEmpty()) { into.add(token); }
        }
    }

    private static int[] lineStarts(String text) {
        List<Integer> starts = new ArrayList<Integer>();
        starts.add(Integer.valueOf(0));
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                starts.add(Integer.valueOf(i + 1));
            }
        }
        int[] out = new int[starts.size()];
        for (int i = 0; i < out.length; i++) {
            out[i] = starts.get(i).intValue();
        }
        return out;
    }

    private static int lineOf(int[] starts, int offset) {
        int lo = 0;
        int hi = starts.length - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) >>> 1;
            if (starts[mid] <= offset) { lo = mid; } else { hi = mid - 1; }
        }
        return lo;
    }

    /** Skip a leading run of whitespace inside the match - see the class note. */
    private static int firstNonBlank(String s, int start, int end) {
        int i = start;
        while (i < end) {
            char c = s.charAt(i);
            if (c != ' ' && c != '\t' && c != '\r' && c != '\n') { return i; }
            i++;
        }
        return start;
    }

    /** Substitute {0}, {1}... with the match's capture groups. */
    static String format(String template, Matcher m) {
        if (template == null || template.indexOf('{') < 0) {
            return template == null ? "" : template;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < template.length(); i++) {
            char c = template.charAt(i);
            if (c != '{') { sb.append(c); continue; }
            int close = template.indexOf('}', i);
            if (close < 0) { sb.append(c); continue; }
            String token = template.substring(i + 1, close);
            int group;
            try {
                group = Integer.parseInt(token);
            } catch (NumberFormatException e) {
                sb.append(c);
                continue;
            }
            // {0} is the first capture group, matching the Python rules, not
            // Java's group(0) which is the whole match.
            String value = "";
            if (group + 1 <= m.groupCount()) {
                String g = m.group(group + 1);
                value = (g == null) ? "" : g;
            }
            sb.append(value);
            i = close;
        }
        return sb.toString();
    }

    private static String trimTo(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }
}

package com.bawassistant;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;

/**
 * Works out what a repair would look like. It never performs one.
 *
 * This is the first thing in the product that produces an edit to a
 * developer's code, so the boundaries are drawn tightly and on purpose:
 *
 *   1. It returns a proposal - line, before, after - and nothing else. The
 *      server has no way to write to an artifact and never will; the developer
 *      applies the change in their own editor, and saves it themselves through
 *      Designer, so IBM's save pipeline and validators stay in charge.
 *   2. Only ACTIVE policy rules that declare a fix are eligible. A draft is a
 *      proposal about what the standard should be, and a proposal must not be
 *      able to rewrite anybody's code.
 *   3. One line at a time. Applying several edits to one buffer means tracking
 *      how each shifts the offsets of the next, and a mistake there corrupts
 *      code rather than merely annoying someone. The caller applies one fix,
 *      re-lints, and asks again - which costs a few milliseconds and removes
 *      the entire class of error.
 */
public final class Fixer {

    private Fixer() { }

    /**
     * Proposals for a buffer, in line order.
     *
     * @param onlyRuleIds when non-empty, restricts the offer to those rules.
     */
    public static List<Map<String, Object>> plan(String code, String language,
                                                 List<Rule> rules,
                                                 Collection<String> onlyRuleIds) {
        List<Map<String, Object>> out = new ArrayList<Map<String, Object>>();
        if (code == null || code.isEmpty() || rules == null) { return out; }

        List<Rule> fixable = new ArrayList<Rule>();
        for (Rule r : rules) {
            if (!r.isFixable()) { continue; }
            if (onlyRuleIds != null && !onlyRuleIds.isEmpty()
                    && !onlyRuleIds.contains(r.id)) { continue; }
            fixable.add(r);
        }
        if (fixable.isEmpty()) { return out; }

        /* Lint with the fixable rules alone. Their findings carry the line, and
           the line is all a repair needs. "info" so severity filtering cannot
           quietly hide something the developer asked to fix. */
        List<Finding> found = BufferLinter.lint(code, language, fixable, "info");
        String[] lines = code.split("\n", -1);

        for (Finding f : found) {
            if (f.line < 1 || f.line > lines.length) { continue; }
            Rule rule = ruleFor(fixable, f.ruleId);
            if (rule == null) { continue; }

            /* Drop the carriage return before anything else.
             *
             * BAW stores these buffers with CRLF, so splitting on a newline
             * leaves a trailing CR on every line. Orion's getLineEnd EXCLUDES
             * the line delimiter, so the editor reported the line without it
             * while this reported it with - and the staleness check that
             * guards against repairing a line the developer has since edited
             * saw a difference that was not real, and refused every fix.
             * Verified live: the first end-to-end Apply silently did nothing.
             */
            String before = stripCr(lines[f.line - 1]);
            String after = apply(rule, before);
            if (after != null && after.equals(before)) {
                /* The fix would change nothing. Offering it would be a button
                   that appears to work and does not. */
                continue;
            }

            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("ruleId", rule.id);
            m.put("ruleName", rule.name);
            m.put("message", f.message);
            m.put("line", Integer.valueOf(f.line));
            m.put("before", before);
            /* null after means: remove the line entirely. Distinct from an
               empty string, which would leave a blank line behind. */
            m.put("after", after);
            m.put("action", Json.str(rule.fix, "action", ""));
            out.add(m);
        }
        return out;
    }

    /** A line without its trailing carriage return, if it had one. */
    static String stripCr(String line) {
        if (line == null || line.isEmpty()) { return line; }
        return (line.charAt(line.length() - 1) == '\r')
                ? line.substring(0, line.length() - 1) : line;
    }

    private static Rule ruleFor(List<Rule> rules, String id) {
        for (Rule r : rules) {
            if (r.id.equals(id)) { return r; }
        }
        return null;
    }

    /** The repaired line, or null when the line should go away. */
    private static String apply(Rule rule, String line) {
        String action = Json.str(rule.fix, "action", "");
        if ("removeLine".equals(action)) {
            return null;
        }
        if ("replace".equals(action)) {
            String with = Json.str(rule.fix, "with", "");
            try {
                Matcher m = rule.pattern.matcher(line);
                return stripCr(m.replaceAll(with));
            } catch (RuntimeException e) {
                /* A replacement that refers to a group the pattern does not
                   have throws here. Offering nothing is the safe answer. */
                return line;
            }
        }
        return line;
    }
}

package com.bawassistant;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal JSON parser and writer.
 *
 * WebSphere 8.5 ships no JSON API - there is nothing usable in j2ee.jar,
 * was_public.jar or the plugins - and the whole point of this application is
 * that it deploys with zero third-party jars. So this is hand-rolled: a
 * recursive-descent parser over the JSON grammar, and a writer that escapes
 * correctly.
 *
 * Values map to: Map&lt;String,Object&gt;, List&lt;Object&gt;, String, Double,
 * Boolean, null. Numbers are always Double - JSON has one number type, and
 * pretending otherwise invites integer/decimal bugs at the boundary.
 */
public final class Json {

    private Json() { }

    // ------------------------------------------------------------- parsing

    public static Object parse(String text) {
        if (text == null) {
            throw new JsonException("no input");
        }
        Parser p = new Parser(text);
        p.skipWhitespace();
        Object value = p.readValue();
        p.skipWhitespace();
        if (!p.atEnd()) {
            throw new JsonException("trailing content at offset " + p.pos);
        }
        return value;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String text) {
        Object v = parse(text);
        if (!(v instanceof Map)) {
            throw new JsonException("expected a JSON object");
        }
        return (Map<String, Object>) v;
    }

    /** Thrown for any malformed input. Callers turn this into a 400. */
    public static class JsonException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        public JsonException(String message) { super(message); }
    }

    private static final class Parser {
        private final String s;
        private int pos;

        Parser(String s) { this.s = s; this.pos = 0; }

        boolean atEnd() { return pos >= s.length(); }

        void skipWhitespace() {
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r') {
                    pos++;
                } else {
                    break;
                }
            }
        }

        Object readValue() {
            if (atEnd()) {
                throw new JsonException("unexpected end of input");
            }
            char c = s.charAt(pos);
            switch (c) {
                case '{': return readObject();
                case '[': return readArray();
                case '"': return readString();
                case 't': return readLiteral("true", Boolean.TRUE);
                case 'f': return readLiteral("false", Boolean.FALSE);
                case 'n': return readLiteral("null", null);
                default:  return readNumber();
            }
        }

        Map<String, Object> readObject() {
            // LinkedHashMap: rule files are read by humans, so key order matters
            // when anything is written back out.
            Map<String, Object> out = new LinkedHashMap<String, Object>();
            expect('{');
            skipWhitespace();
            if (peek() == '}') { pos++; return out; }
            while (true) {
                skipWhitespace();
                String key = readString();
                skipWhitespace();
                expect(':');
                skipWhitespace();
                out.put(key, readValue());
                skipWhitespace();
                char c = next();
                if (c == '}') { return out; }
                if (c != ',') {
                    throw new JsonException("expected , or } at offset " + (pos - 1));
                }
            }
        }

        List<Object> readArray() {
            List<Object> out = new ArrayList<Object>();
            expect('[');
            skipWhitespace();
            if (peek() == ']') { pos++; return out; }
            while (true) {
                skipWhitespace();
                out.add(readValue());
                skipWhitespace();
                char c = next();
                if (c == ']') { return out; }
                if (c != ',') {
                    throw new JsonException("expected , or ] at offset " + (pos - 1));
                }
            }
        }

        String readString() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (true) {
                if (atEnd()) {
                    throw new JsonException("unterminated string");
                }
                char c = s.charAt(pos++);
                if (c == '"') { return sb.toString(); }
                if (c != '\\') { sb.append(c); continue; }

                if (atEnd()) { throw new JsonException("unterminated escape"); }
                char e = s.charAt(pos++);
                switch (e) {
                    case '"':  sb.append('"');  break;
                    case '\\': sb.append('\\'); break;
                    case '/':  sb.append('/');  break;
                    case 'b':  sb.append('\b'); break;
                    case 'f':  sb.append('\f'); break;
                    case 'n':  sb.append('\n'); break;
                    case 'r':  sb.append('\r'); break;
                    case 't':  sb.append('\t'); break;
                    case 'u':
                        if (pos + 4 > s.length()) {
                            throw new JsonException("truncated \\u escape");
                        }
                        /* Validate before parsing. Integer.parseInt throws
                           NumberFormatException, which is NOT a JsonException, so it
                           escaped the servlet's handler and a malformed escape came
                           back as a 500 - a server fault reported for what is
                           entirely a caller's malformed input. */
                        String hex = s.substring(pos, pos + 4);
                        for (int h = 0; h < 4; h++) {
                            char hc = hex.charAt(h);
                            boolean digit = (hc >= '0' && hc <= '9')
                                    || (hc >= 'a' && hc <= 'f')
                                    || (hc >= 'A' && hc <= 'F');
                            if (!digit) {
                                throw new JsonException("bad \\u escape: \\u" + hex);
                            }
                        }
                        sb.append((char) Integer.parseInt(hex, 16));
                        pos += 4;
                        break;
                    default:
                        throw new JsonException("bad escape \\" + e);
                }
            }
        }

        Double readNumber() {
            int start = pos;
            if (peek() == '-') { pos++; }
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if ((c >= '0' && c <= '9') || c == '.' || c == 'e' || c == 'E'
                        || c == '+' || c == '-') {
                    pos++;
                } else {
                    break;
                }
            }
            if (start == pos) {
                throw new JsonException("unexpected character '" + s.charAt(pos)
                        + "' at offset " + pos);
            }
            try {
                return Double.valueOf(s.substring(start, pos));
            } catch (NumberFormatException e) {
                throw new JsonException("bad number at offset " + start);
            }
        }

        Object readLiteral(String word, Object value) {
            if (!s.startsWith(word, pos)) {
                throw new JsonException("bad literal at offset " + pos);
            }
            pos += word.length();
            return value;
        }

        char peek() { return atEnd() ? '\0' : s.charAt(pos); }

        char next() {
            if (atEnd()) { throw new JsonException("unexpected end of input"); }
            return s.charAt(pos++);
        }

        void expect(char c) {
            if (atEnd() || s.charAt(pos) != c) {
                throw new JsonException("expected '" + c + "' at offset " + pos);
            }
            pos++;
        }
    }

    // ------------------------------------------------------------- writing

    public static String write(Object value) {
        StringBuilder sb = new StringBuilder();
        writeValue(sb, value);
        return sb.toString();
    }

    private static void writeValue(StringBuilder sb, Object v) {
        if (v == null) {
            sb.append("null");
        } else if (v instanceof String) {
            writeString(sb, (String) v);
        } else if (v instanceof Boolean) {
            sb.append(v.toString());
        } else if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            // Emit whole numbers without a trailing .0 - a line number of "12.0"
            // reads as a bug even when it is not.
            if (d == Math.rint(d) && !Double.isInfinite(d) && Math.abs(d) < 1e15) {
                sb.append(Long.toString((long) d));
            } else {
                sb.append(Double.toString(d));
            }
        } else if (v instanceof Map) {
            sb.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
                if (!first) { sb.append(','); }
                first = false;
                writeString(sb, String.valueOf(e.getKey()));
                sb.append(':');
                writeValue(sb, e.getValue());
            }
            sb.append('}');
        } else if (v instanceof Iterable) {
            sb.append('[');
            boolean first = true;
            for (Object o : (Iterable<?>) v) {
                if (!first) { sb.append(','); }
                first = false;
                writeValue(sb, o);
            }
            sb.append(']');
        } else {
            writeString(sb, String.valueOf(v));
        }
    }

    private static void writeString(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':  sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                case '\t': sb.append("\\t");  break;
                case '\b': sb.append("\\b");  break;
                case '\f': sb.append("\\f");  break;
                default:
                    // Escape controls and U+2028/2029: the response is consumed
                    // by JavaScript, where those two terminate a line.
                    if (c < 0x20 || c == ' ' || c == ' ') {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
    }

    // ------------------------------------------------------------- helpers

    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Object v) {
        return v instanceof Map ? (Map<String, Object>) v : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> arr(Object v) {
        return v instanceof List ? (List<Object>) v : null;
    }

    public static String str(Map<String, Object> m, String key, String fallback) {
        if (m == null) { return fallback; }
        Object v = m.get(key);
        return v instanceof String ? (String) v : fallback;
    }

    public static double num(Map<String, Object> m, String key, double fallback) {
        if (m == null) { return fallback; }
        Object v = m.get(key);
        return v instanceof Number ? ((Number) v).doubleValue() : fallback;
    }

    public static boolean bool(Map<String, Object> m, String key, boolean fallback) {
        if (m == null) { return fallback; }
        Object v = m.get(key);
        return v instanceof Boolean ? ((Boolean) v).booleanValue() : fallback;
    }

    public static List<String> strings(Map<String, Object> m, String key) {
        List<String> out = new ArrayList<String>();
        if (m == null) { return out; }
        List<Object> a = arr(m.get(key));
        if (a == null) { return out; }
        for (Object o : a) {
            if (o instanceof String) { out.add((String) o); }
        }
        return out;
    }
}

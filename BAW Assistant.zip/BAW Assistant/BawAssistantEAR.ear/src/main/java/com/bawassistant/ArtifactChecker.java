package com.bawassistant;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Evaluates artifact rules against the artifact the developer is building.
 *
 * The condition language is deliberately small. It has to express the standards
 * teams actually write - "no more than fifteen inputs", "no defaults on inputs",
 * "no more than ten steps" - and nothing more. A richer language would be a
 * second thing to learn and a second thing to get wrong.
 *
 * <pre>
 * "check": {
 *   "count": "variables",
 *   "where": { "field": "category", "eq": "Input" },
 *   "op":    "&gt;",
 *   "value": 10
 * }
 * </pre>
 *
 * Where-predicates compose with and / or / not, and test a row's field with
 * eq / ne / in / exists / isTrue / isFalse / matches / notMatches for text and
 * gt / gte / lt / lte for numbers. The expected artifact shape is:
 * <pre>
 * { "type": "SERVICEFLOW", "name": "...",
 *   "variables":  [ {"name","category","hasDefault","typeName","isList"} ],
 *   "components": [ {"name","type"} ],
 *   "settings":   { per-type flags, read as one row - see rows() } }
 * </pre>
 */
public final class ArtifactChecker {

    private ArtifactChecker() { }

    /**
     * Compiled conditions, interned by their source.
     *
     * These used to be compiled inside the row loop, so a rule with a regex
     * recompiled it once per variable per request. The set is small, bounded
     * by the rule file, and every entry is validated at load by
     * {@link Rule#checkPatternError}.
     */
    private static final ConcurrentHashMap<String, Pattern> COMPILED
            = new ConcurrentHashMap<String, Pattern>();

    static Pattern compile(String regex) {
        Pattern p = COMPILED.get(regex);
        if (p == null) {
            p = Pattern.compile(regex);   /* PatternSyntaxException is the caller's */
            COMPILED.put(regex, p);
        }
        return p;
    }

    /**
     * Match with the same time budget the buffer linter enforces.
     *
     * Artifact inputs are short - names, types - so this is unlikely to bite,
     * but a rule store that anyone may write to is not the place to leave an
     * unbounded backtracking engine on a request thread. A rule that exceeds
     * its budget reports no match rather than hanging the request.
     */
    private static boolean findWithin(Pattern p, String subject) {
        try {
            return p.matcher(new BufferLinter.Deadline(
                    subject, BufferLinter.MATCH_BUDGET_MS)).find();
        } catch (BufferLinter.RegexBudgetExceeded e) {
            return false;
        }
    }

    /**
     * The rows a collection name resolves to.
     *
     * A collection is normally an array - variables, components. The artifact
     * model also carries <b>settings</b>, which is a single object rather than
     * a list: coach-view header flags, UCA event configuration, business-object
     * annotations. Treating that object as a collection of exactly one row is
     * what lets a settings rule use the same where-predicates as every other
     * rule, instead of a second condition language for the one shape that is
     * not a list.
     *
     * <pre>
     * "check": { "any": "settings",
     *            "where": { "field": "isEnabled", "isFalse": true } }
     * </pre>
     *
     * Returns null when the name resolves to neither, which keeps an absent
     * key distinct from an empty one - absence is the signal on this model,
     * never an error.
     */
    private static List<Object> rows(Object value) {
        List<Object> list = Json.arr(value);
        if (list != null) { return list; }
        Map<String, Object> single = Json.obj(value);
        if (single != null) {
            List<Object> one = new ArrayList<Object>(1);
            one.add(single);
            return one;
        }
        return null;
    }

    /**
     * What a violated rule found: the aggregate the message quotes, and the
     * rows that produced it.
     *
     * The aggregate alone makes an artifact finding almost unactionable on a
     * real service - "a gateway has an outgoing path with no condition" on a
     * process with eleven gateways sends the developer hunting. The subjects
     * are the names of the rows that actually matched, so the panel can say
     * WHICH gateway without every rule having to rewrite its message.
     */
    static final class Match {
        final double value;
        final List<String> subjects;
        Match(double value, List<String> subjects) {
            this.value = value;
            this.subjects = subjects;
        }
    }

    /** How many names one finding will carry. Past this the list stops being
     *  a pointer and starts being the report. */
    private static final int MAX_SUBJECTS = 8;

    private static void collect(List<String> into, Map<String, Object> row) {
        collect(into, row, null);
    }

    private static void add(List<String> into, String name) {
        if (into.size() >= MAX_SUBJECTS) { return; }
        if (name == null || name.isEmpty()) { return; }
        if (!into.contains(name)) { into.add(name); }
    }

    /**
     * @param field the row field the predicate tested, or null.
     *
     * A variable or component row names itself. A SETTINGS row is a single
     * anonymous object, so there is nothing to name - and settings is where
     * every graph fact lives, which is exactly where "which one?" is hardest
     * to answer by hand. "A gateway has an outgoing path with no condition" on
     * a process with eleven gateways is barely actionable.
     *
     * So the readers publish a `<field>Names` list beside each count they
     * gather, and a rule picks it up through the field its own predicate
     * already names. No rule changes its check, its message or its examples to
     * gain this.
     */
    private static void collect(List<String> into, Map<String, Object> row, String field) {
        String name = Json.str(row, "name", "");
        if (!name.isEmpty()) { add(into, name); return; }
        if (field == null || field.isEmpty()) { return; }
        List<Object> named = Json.arr(row.get(field + "Names"));
        if (named == null) { return; }
        for (Object o : named) {
            if (o != null) { add(into, String.valueOf(o)); }
        }
    }

    /**
     * The row field a predicate tests, for looking up its companion names.
     *
     * A composite predicate names more than one field. The first is taken and
     * the rest ignored: it is the subject of the rule in every composite the
     * rule set actually contains, and guessing further would be worse than
     * naming nothing.
     */
    private static String testedField(Map<String, Object> where) {
        if (where == null) { return null; }
        String field = Json.str(where, "field", "");
        if (!field.isEmpty()) { return field; }
        for (String key : new String[] { "and", "or" }) {
            List<Object> parts = Json.arr(where.get(key));
            if (parts == null) { continue; }
            for (Object o : parts) {
                String f = testedField(Json.obj(o));
                if (f != null) { return f; }
            }
        }
        return testedField(Json.obj(where.get("not")));
    }

    public static List<Finding> check(Map<String, Object> artifact, List<Rule> rules,
                                      String minSeverity) {
        List<Finding> out = new ArrayList<Finding>();
        if (artifact == null || rules == null) {
            return out;
        }
        String type = Json.str(artifact, "type", "");
        int threshold = Rule.severityRank(minSeverity);

        for (Rule rule : rules) {
            if (!rule.enabled || rule.error != null) { continue; }
            if (!Rule.KIND_ARTIFACT.equals(rule.kind)) { continue; }
            if (!rule.applies(type)) { continue; }
            if (Rule.severityRank(rule.severity) > threshold) { continue; }

            Match hit = evaluate(rule.check, artifact);
            if (hit == null) { continue; }   // condition not met

            Finding f = Finding.of(rule,
                    substitute(rule.message, rule.check, Double.valueOf(hit.value)));
            f.line = 0;   // artifact-level: no source position
            f.subjects = hit.subjects;
            out.add(f);
        }
        return out;
    }

    /**
     * Returns the aggregate value when the rule is violated, or null when it is
     * satisfied. Returning the value rather than a boolean is what lets the
     * message say "14 input variables" instead of "too many input variables".
     */
    private static Match evaluate(Map<String, Object> check, Map<String, Object> artifact) {
        if (check == null) { return null; }

        String collection = Json.str(check, "count", "");
        String anyOf = Json.str(check, "any", "");
        Map<String, Object> where = Json.obj(check.get("where"));

        if (!anyOf.isEmpty()) {
            /* "artifact" names the artifact itself, so a rule can test its
               own name or type - neither of which any predicate could reach
               before, because `field:` compares numbers only. A real key of
               that name still wins, so nothing existing changes meaning. */
            Object target = artifact.get(anyOf);
            if (target == null && "artifact".equals(anyOf)) { target = artifact; }
            List<Object> items = rows(target);
            if (items == null) { return null; }
            /* Every matching row, not the first. "any" decides whether the rule
               fires; the developer still has to fix all of them. */
            List<String> subjects = new ArrayList<String>();
            String field = testedField(where);
            int hits = 0;
            for (Object o : items) {
                Map<String, Object> row = Json.obj(o);
                if (row != null && matches(where, row)) {
                    hits++;
                    collect(subjects, row, field);
                }
            }
            return hits > 0 ? new Match(1, subjects) : null;
        }

        if (!collection.isEmpty()) {
            List<Object> items = rows(artifact.get(collection));
            List<String> subjects = new ArrayList<String>();
            String field = testedField(where);
            double n = 0;
            if (items != null) {
                for (Object o : items) {
                    Map<String, Object> row = Json.obj(o);
                    if (row != null && matches(where, row)) {
                        n++;
                        collect(subjects, row, field);
                    }
                }
            }
            String op = Json.str(check, "op", ">");
            double limit = Json.num(check, "value", 0);
            /* Only name the rows when the predicate SELECTED them. A rule of
               the form "fewer than two of these exist" is violated by rows
               that are missing, and listing the ones that are present would
               point at the wrong things. */
            boolean selecting = ">".equals(op) || ">=".equals(op);
            return compare(n, op, limit)
                    ? new Match(n, selecting ? subjects : new ArrayList<String>())
                    : null;
        }

        // Direct field comparison on the artifact itself.
        String field = Json.str(check, "field", "");
        if (!field.isEmpty()) {
            Object raw = artifact.get(field);
            double n = (raw instanceof Number) ? ((Number) raw).doubleValue() : 0;
            String op = Json.str(check, "op", ">");
            double limit = Json.num(check, "value", 0);
            /* A field test is about the artifact itself, so there is no row to
               name. An empty list, never a guess. */
            return compare(n, op, limit)
                    ? new Match(n, new ArrayList<String>()) : null;
        }
        return null;
    }

    /** null predicate means "every row". */
    private static boolean matches(Map<String, Object> where, Map<String, Object> row) {
        if (where == null) { return true; }

        List<Object> and = Json.arr(where.get("and"));
        if (and != null) {
            for (Object o : and) {
                if (!matches(Json.obj(o), row)) { return false; }
            }
            return true;
        }
        List<Object> or = Json.arr(where.get("or"));
        if (or != null) {
            for (Object o : or) {
                if (matches(Json.obj(o), row)) { return true; }
            }
            return false;
        }
        Map<String, Object> not = Json.obj(where.get("not"));
        if (not != null) {
            return !matches(not, row);
        }

        String field = Json.str(where, "field", "");
        if (field.isEmpty()) { return true; }
        Object actual = row.get(field);

        if (where.containsKey("isTrue")) {
            return truthy(actual);
        }
        if (where.containsKey("isFalse")) {
            return !truthy(actual);
        }
        if (where.containsKey("exists")) {
            return actual != null && !"".equals(actual);
        }
        if (where.containsKey("eq")) {
            return String.valueOf(actual).equalsIgnoreCase(
                    String.valueOf(where.get("eq")));
        }
        if (where.containsKey("ne")) {
            return !String.valueOf(actual).equalsIgnoreCase(
                    String.valueOf(where.get("ne")));
        }
        /* Numeric comparison on a row's field.
         *
         * `op`/`value` compare the AGGREGATE - how many rows matched. These
         * compare one row's own number, which is what a rule like "an EPV
         * value longer than 255 characters" needs: the threshold stays in the
         * rule rather than being baked into the reader. A non-numeric field
         * never satisfies one of these, rather than counting as zero. */
        if (where.containsKey("gt") || where.containsKey("gte")
                || where.containsKey("lt") || where.containsKey("lte")) {
            if (!(actual instanceof Number)) { return false; }
            double n = ((Number) actual).doubleValue();
            if (where.containsKey("gt"))  { return n >  Json.num(where, "gt", 0); }
            if (where.containsKey("gte")) { return n >= Json.num(where, "gte", 0); }
            if (where.containsKey("lt"))  { return n <  Json.num(where, "lt", 0); }
            return n <= Json.num(where, "lte", 0);
        }
        if (where.containsKey("in")) {
            List<Object> options = Json.arr(where.get("in"));
            if (options == null) { return false; }
            for (Object o : options) {
                if (String.valueOf(actual).equalsIgnoreCase(String.valueOf(o))) {
                    return true;
                }
            }
            return false;
        }
        /* A pattern here is already compiled and validated at load, so a
           broken one never reaches this point - it failed the build. The
           catch remains for a rule constructed in memory by /api/try. */
        if (where.containsKey("matches")) {
            try {
                return actual != null && findWithin(
                        compile(String.valueOf(where.get("matches"))),
                        String.valueOf(actual));
            } catch (PatternSyntaxException e) {
                return false;   // a broken pattern must not fabricate a finding
            }
        }
        if (where.containsKey("notMatches")) {
            try {
                return actual == null || !findWithin(
                        compile(String.valueOf(where.get("notMatches"))),
                        String.valueOf(actual));
            } catch (PatternSyntaxException e) {
                return false;
            }
        }
        return true;
    }

    private static boolean truthy(Object v) {
        if (v == null) { return false; }
        if (v instanceof Boolean) { return ((Boolean) v).booleanValue(); }
        if (v instanceof Number) { return ((Number) v).doubleValue() != 0; }
        String s = String.valueOf(v);
        return !(s.isEmpty() || s.equalsIgnoreCase("false") || s.equals("0"));
    }

    private static boolean compare(double actual, String op, double limit) {
        if (">".equals(op))  { return actual > limit; }
        if (">=".equals(op)) { return actual >= limit; }
        if ("<".equals(op))  { return actual < limit; }
        if ("<=".equals(op)) { return actual <= limit; }
        if ("==".equals(op) || "=".equals(op)) { return actual == limit; }
        if ("!=".equals(op)) { return actual != limit; }
        return false;
    }

    /** {value} is the aggregate, {limit} the threshold the rule declared. */
    static String substitute(String template, Map<String, Object> check, Double value) {
        if (template == null) { return ""; }
        String limit = String.valueOf((long) Json.num(check, "value", 0));
        String actual = String.valueOf(value.longValue());
        return template.replace("{value}", actual).replace("{limit}", limit);
    }
}

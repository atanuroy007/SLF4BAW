package com.bawassistant;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * One house rule, of either kind.
 *
 * <b>buffer</b> rules match a regular expression against the code the developer
 * is typing and carry a line number, so they can be drawn in the editor gutter.
 *
 * <b>artifact</b> rules evaluate a small condition over the artifact's own model
 * - its variables, its steps - and have no source position.
 *
 * Both live in the same file so a standard reads as one thing regardless of how
 * it happens to be checked.
 */
public final class Rule {

    public static final String KIND_BUFFER = "buffer";
    public static final String KIND_ARTIFACT = "artifact";

    /**
     * A standard that cannot be decided by a machine.
     *
     * "Is the parent business process diagram readable and clear?" is a real
     * requirement and a real thing reviewers check. No pattern decides it.
     * Leaving it out of the rule set would make the assistant quietly disagree
     * with the checklist about what the standards ARE, so it is carried here
     * and surfaced as a prompt: shown against the artifact it applies to,
     * attributed to its checklist row, and never reported as a finding.
     */
    public static final String KIND_MANUAL = "manual";

    /**
     * When a rule can be evaluated.
     *
     * <b>develop</b> - answerable from the one artifact open in Designer: its
     * code surfaces and its own model. The panel evaluates these live.
     * <b>snapshot</b> - evaluated when a whole application is reviewed at a
     * point in time.
     *
     * Almost every rule is both, because a full review runs everything the
     * panel runs. The distinction that carries information is the rule that
     * is <b>snapshot only</b>: it needs another artifact, the whole
     * application, or a second moment, and no amount of work on the panel
     * will make it answerable there. Recording it now means the
     * pre-deployment report knows what it owns before it is written.
     */
    public static final String SCOPE_DEVELOP = "develop";
    public static final String SCOPE_SNAPSHOT = "snapshot";

    public static final String LIFECYCLE_ACTIVE = "active";
    public static final String LIFECYCLE_DRAFT = "draft";

    public static final String ENFORCE_ERROR = "error";
    public static final String ENFORCE_MANUAL = "manual";
    public static final String ENFORCE_ADVISORY = "advisory";
    public static final String ENFORCE_AUTO_FIXABLE = "auto-fixable";

    public final String id;
    public final String kind;
    public final String name;
    public final String severity;
    public final String category;
    public final String message;
    public final String remediation;
    public final boolean enabled;
    public final boolean autoFixable;

    /**
     * Why the rule exists, as distinct from what to do about it.
     *
     * The review checklist these rules come from separates the two, and so does
     * the finding panel: a developer who understands why a standard exists
     * argues with it far less than one handed only an instruction.
     */
    public final String rationale;

    /**
     * Where the standard came from - {sourceId, locator, authorityStatus}.
     *
     * `locator` is the checklist cell, e.g. "General!B7". Taken from
     * review_checklist_items.json, which is the only authoritative mapping: the
     * artifact catalogue's citations were spot-checked against it and several
     * are wrong. Null for rules that are ours rather than the checklist's.
     */
    public final Map<String, Object> source;

    /**
     * "active" or "draft".
     *
     * A draft rule runs and renders, but is not policy: it is shown subordinate
     * and is never offered for auto-fix. This mirrors the knowledge base, where
     * 13 of 14 rules are drafts awaiting SME approval, and gives new rules a
     * place to live while they earn trust.
     */
    public final String lifecycle;

    /**
     * How binding the finding is: "error", "manual", "advisory", "auto-fixable".
     *
     * Deliberately a separate axis from severity. Severity is how bad the defect
     * is; enforcement is what the tool may do about it. Only "auto-fixable"
     * may ever be applied without showing a diff first - which is the gate a
     * future /api/fix needs, so it is recorded now rather than retrofitted.
     */
    public final String enforcement;

    /** When this rule can run: "develop", "snapshot", or both. Never empty. */
    public final List<String> scope;

    /** Languages (buffer) or artifact types (artifact). Empty means "any". */
    public final List<String> appliesTo;

    // buffer
    public final Pattern pattern;
    public final Pattern notWhen;
    public final boolean scanComments;

    /**
     * How many lines ABOVE the match `notWhen` may look at.
     *
     * 0 keeps the original behaviour - the guard is tested against the matched
     * line only. A positive value widens it, which is what a null-check rule
     * needs, because the guard normally sits on the line before the access.
     * See BufferLinter.isGuarded for why a wider window needs the {n} capture
     * placeholders to stay precise.
     */
    public final int guardLines;

    /**
     * Snippets this rule must flag, and snippets it must NOT.
     *
     * Three rules were written and withdrawn during development because they
     * fired on correct code - including a null check that flagged the exact
     * guard the review checklist tells developers to write. Every one was caught
     * by a hand-written control, never by the author.
     *
     * So the examples travel WITH the rule. `quiet` is the half that matters and
     * the half authors skip: it is where false positives are caught, and false
     * positives are what get a linter switched off. A rule cannot be promoted
     * out of draft until it has at least one of each and all of them pass.
     */
    public final List<String> firesOn;
    public final List<String> quietOn;

    /* ---- the review checklist's own vocabulary, kept rather than translated.
     *
     * The checklist grades work on two axes the engine had no place for:
     * WHY it matters (impactedArea - Best Practice, Performance,
     * Maintainability, Migration, Functionality, Extensibility, Suggestion) and
     * HOW URGENT it is (priority - Critical/High/Medium/Low). Severity is the
     * engine's own scale and maps onto priority but is not the same thing.
     *
     * primaryReviewer says which of the three sign-off stages a check needs:
     * Self, Self & Peer, or Self & Peer & SME. A finding that knows this can
     * say "this one needs SME sign-off" instead of leaving someone to look it
     * up in the spreadsheet.
     *
     * checkText is the row's original wording, kept verbatim so a developer can
     * match what the tool says to what the reviewer will ask. */
    public final String checkText;
    public final String impactedArea;
    public final String priority;
    public final String primaryReviewer;

    // artifact
    public final Map<String, Object> check;

    /**
     * How to repair what this rule found, when that is mechanical.
     *
     * {@code {action: "removeLine"}} deletes the matched line;
     * {@code {action: "replace", with: "..."}} rewrites it, where the
     * replacement may use $1 for the pattern's capture groups.
     *
     * Null for the overwhelming majority of rules, and that is the point:
     * a standard a machine can restate is rare, and pretending otherwise is
     * how a tool starts making edits nobody asked for.
     */
    public final Map<String, Object> fix;

    /** Set when the rule could not be compiled; such a rule is skipped, loudly. */
    public final String error;

    private Rule(String id, String kind, String name, String severity, String category,
                 String message, String remediation, boolean enabled, boolean autoFixable,
                 String rationale, Map<String, Object> source, String lifecycle,
                 String enforcement,
                 List<String> appliesTo, List<String> scope,
                 Pattern pattern, Pattern notWhen,
                 boolean scanComments, int guardLines,
                 List<String> firesOn, List<String> quietOn,
                 String checkText, String impactedArea, String priority,
                 String primaryReviewer,
                 Map<String, Object> check, Map<String, Object> fix, String error) {
        this.id = id;
        this.kind = kind;
        this.name = name;
        this.severity = severity;
        this.category = category;
        this.message = message;
        this.remediation = remediation;
        this.enabled = enabled;
        this.autoFixable = autoFixable;
        this.rationale = rationale;
        this.source = source;
        this.lifecycle = lifecycle;
        this.enforcement = enforcement;
        this.appliesTo = appliesTo;
        this.scope = scope;
        this.pattern = pattern;
        this.notWhen = notWhen;
        this.scanComments = scanComments;
        this.guardLines = guardLines;
        this.firesOn = firesOn;
        this.quietOn = quietOn;
        this.checkText = checkText;
        this.impactedArea = impactedArea;
        this.priority = priority;
        this.primaryReviewer = primaryReviewer;
        this.check = check;
        this.fix = fix;
        this.error = error;
    }

    public static Rule from(Map<String, Object> raw) {
        String id = Json.str(raw, "id", "");
        if (id.isEmpty()) {
            return broken("(missing id)", "rule has no id");
        }
        String kind = Json.str(raw, "kind", KIND_BUFFER);
        String name = Json.str(raw, "name", id);
        String severity = normalizeSeverity(Json.str(raw, "severity", "warning"));
        String category = Json.str(raw, "category", "custom");
        String message = Json.str(raw, "message", name);
        String remediation = Json.str(raw, "remediation", "");
        boolean enabled = Json.bool(raw, "enabled", true);
        boolean autoFixable = Json.bool(raw, "autoFixable", false);
        List<String> appliesTo = Json.strings(raw, "appliesTo");
        /* Absent means both, which is what almost every rule is. A rule that
           only a whole-application review can answer has to say so. */
        List<String> scope = Json.strings(raw, "scope");
        if (scope.isEmpty()) {
            scope = new java.util.ArrayList<String>();
            scope.add(SCOPE_DEVELOP);
            scope.add(SCOPE_SNAPSHOT);
        }
        boolean scanComments = Json.bool(raw, "scanComments", false);
        Map<String, Object> ex = Json.obj(raw.get("examples"));
        List<String> firesOn = (ex == null) ? java.util.Collections.<String>emptyList()
                                            : Json.strings(ex, "fires");
        List<String> quietOn = (ex == null) ? java.util.Collections.<String>emptyList()
                                            : Json.strings(ex, "quiet");

        String checkText = Json.str(raw, "checkText", "");
        String impactedArea = Json.str(raw, "impactedArea", "");
        String priority = Json.str(raw, "priority", "");
        String primaryReviewer = Json.str(raw, "primaryReviewer", "");

        int guardLines = (int) Json.num(raw, "guardLines", 0);
        if (guardLines < 0) { guardLines = 0; }
        if (guardLines > 20) { guardLines = 20; }   /* bound the scan cost */

        String rationale = Json.str(raw, "rationale", "");
        Map<String, Object> source = Json.obj(raw.get("source"));
        String lifecycle = normalizeLifecycle(Json.str(raw, "lifecycle", "active"));
        /* A draft rule can never be auto-applied, whatever the file claims. The
           gate belongs here rather than in the client, so no caller can skip it. */
        String enforcement = normalizeEnforcement(
                Json.str(raw, "enforcement", ""), autoFixable, lifecycle);
        if (LIFECYCLE_DRAFT.equals(lifecycle)) {
            autoFixable = false;
        }

        Pattern pattern = null;
        Pattern notWhen = null;
        Map<String, Object> check = null;

        if (KIND_MANUAL.equals(kind)) {
            /* Nothing to compile. A prompt needs wording and nothing else -
               demanding a pattern would only invite a fake one. */
            if (checkText.isEmpty() && message.equals(name)) {
                return broken(id, "manual rule has no checkText");
            }
        } else if (KIND_ARTIFACT.equals(kind)) {
            check = Json.obj(raw.get("check"));
            if (check == null) {
                return broken(id, "artifact rule has no check");
            }
            /* Compile the condition's regexes NOW, not per row per request.
             *
             * A bad matches/notMatches used to be caught inside
             * ArtifactChecker, where PatternSyntaxException returned false -
             * so a typo removed the check with no error anywhere. That is
             * exactly what the build's second gate exists to stop, and it
             * only ever applied to buffer rules. Failing here makes an
             * artifact rule fail the build like any other broken rule. */
            String bad = checkPatternError(check);
            if (bad != null) {
                return broken(id, bad);
            }
        } else {
            kind = KIND_BUFFER;
            String p = Json.str(raw, "pattern", "");
            if (p.isEmpty()) {
                return broken(id, "buffer rule has no pattern");
            }
            try {
                pattern = Pattern.compile(p, Pattern.MULTILINE);
            } catch (PatternSyntaxException e) {
                return broken(id, "bad pattern: " + e.getDescription());
            }
            String nw = Json.str(raw, "notWhen", "");
            if (!nw.isEmpty()) {
                try {
                    notWhen = Pattern.compile(nw);
                } catch (PatternSyntaxException e) {
                    // A broken guard must not silence the rule, but it must be
                    // visible - a rule that quietly over-reports is worse than
                    // one that fails loudly.
                    return broken(id, "bad notWhen: " + e.getDescription());
                }
            }
        }

        Map<String, Object> fix = Json.obj(raw.get("fix"));
        /* A rule that advertises auto-fixable and cannot say HOW is a
           promise the panel would offer and the engine could not keep, so
           it fails the build rather than shipping a dead button. */
        if (ENFORCE_AUTO_FIXABLE.equals(enforcement)) {
            String bad = fixError(fix);
            if (bad != null) { return broken(id, bad); }
        }

        return new Rule(id, kind, name, severity, category, message, remediation,
                enabled, autoFixable, rationale, source, lifecycle, enforcement,
                appliesTo, scope, pattern, notWhen, scanComments, guardLines,
                firesOn, quietOn, checkText, impactedArea, priority,
                primaryReviewer, check, fix, null);
    }

    private static Rule broken(String id, String why) {
        return new Rule(id, KIND_BUFFER, id, "warning", "custom", "", "",
                false, false, "", null, LIFECYCLE_ACTIVE, ENFORCE_MANUAL,
                java.util.Collections.<String>emptyList(),
                java.util.Collections.<String>emptyList(),
                null, null, false, 0,
                java.util.Collections.<String>emptyList(),
                java.util.Collections.<String>emptyList(),
                "", "", "", "", null, null, why);
    }

    /**
     * Walk an artifact rule's condition and compile every regex in it.
     *
     * Returns the first problem found, or null when the whole tree compiles.
     * Compiled patterns are interned by {@link ArtifactChecker}, so this also
     * removes the per-row compile that used to happen on every request.
     */
    static String checkPatternError(Map<String, Object> node) {
        if (node == null) { return null; }

        for (String key : new String[] { "matches", "notMatches" }) {
            Object v = node.get(key);
            if (v == null) { continue; }
            try {
                ArtifactChecker.compile(String.valueOf(v));
            } catch (PatternSyntaxException e) {
                return "bad " + key + ": " + e.getDescription();
            }
        }

        /* where, and the and/or/not that compose it, all nest the same way. */
        String nested = checkPatternError(Json.obj(node.get("where")));
        if (nested != null) { return nested; }
        nested = checkPatternError(Json.obj(node.get("not")));
        if (nested != null) { return nested; }

        for (String key : new String[] { "and", "or" }) {
            List<Object> branch = Json.arr(node.get(key));
            if (branch == null) { continue; }
            for (Object o : branch) {
                nested = checkPatternError(Json.obj(o));
                if (nested != null) { return nested; }
            }
        }
        return null;
    }

    /** null when the fix is usable, otherwise why it is not. */
    static String fixError(Map<String, Object> fix) {
        if (fix == null) { return "auto-fixable rule has no fix"; }
        String action = Json.str(fix, "action", "");
        if ("removeLine".equals(action)) { return null; }
        if ("replace".equals(action)) {
            return fix.get("with") instanceof String ? null
                    : "fix action 'replace' needs a 'with' string";
        }
        return "unknown fix action '" + action + "'";
    }

    /**
     * May the assistant offer to repair this automatically?
     *
     * Draft rules are excluded deliberately and in two places - here and in
     * normalizeEnforcement - because a proposal nobody has approved must not
     * be able to edit a developer's code.
     */
    public boolean isFixable() {
        return ENFORCE_AUTO_FIXABLE.equals(enforcement) && isActive()
                && fix != null && fixError(fix) == null;
    }

    /** Does this rule apply to the given language or artifact type? */
    public boolean applies(String subject) {
        if (appliesTo.isEmpty()) {
            return true;   // unrestricted
        }
        for (String s : appliesTo) {
            if (s.equalsIgnoreCase(subject)) {
                return true;
            }
        }
        return false;
    }

    public static String normalizeLifecycle(String s) {
        if (s != null && LIFECYCLE_DRAFT.equalsIgnoreCase(s.trim())) {
            return LIFECYCLE_DRAFT;
        }
        return LIFECYCLE_ACTIVE;
    }

    /** True when the engine decides this rule, rather than a person. */
    public boolean isAutomated() {
        return KIND_BUFFER.equals(kind) || KIND_ARTIFACT.equals(kind);
    }

    /** Has this rule earned the right to be promoted out of draft? */
    public boolean isVerifiable() {
        return !firesOn.isEmpty() && !quietOn.isEmpty();
    }

    /** True when the rule is policy rather than a proposal. */
    public boolean isActive() {
        return LIFECYCLE_ACTIVE.equals(lifecycle);
    }

    /**
     * Enforcement, defaulted from what the rule already told us.
     *
     * An unstated enforcement is inferred rather than guessed at random: a
     * fixable active rule is "auto-fixable", anything else is "manual", which
     * is the conservative answer. A draft is never auto-fixable regardless of
     * what the file asks for - that is the whole point of the draft tier.
     */
    public static String normalizeEnforcement(String s, boolean autoFixable,
                                              String lifecycle) {
        String v = (s == null) ? "" : s.trim().toLowerCase();
        if (!v.equals(ENFORCE_ERROR) && !v.equals(ENFORCE_MANUAL)
                && !v.equals(ENFORCE_ADVISORY) && !v.equals(ENFORCE_AUTO_FIXABLE)) {
            v = (autoFixable && LIFECYCLE_ACTIVE.equals(lifecycle))
                    ? ENFORCE_AUTO_FIXABLE : ENFORCE_MANUAL;
        }
        if (ENFORCE_AUTO_FIXABLE.equals(v) && LIFECYCLE_DRAFT.equals(lifecycle)) {
            v = ENFORCE_MANUAL;
        }
        return v;
    }

    public static String normalizeSeverity(String s) {
        if (s == null) { return "warning"; }
        String v = s.trim().toLowerCase();
        if (v.equals("critical") || v.equals("major") || v.equals("minor")
                || v.equals("warning")) {
            return v;
        }
        return "warning";
    }

    /** Lower is worse. Used for filtering by a minimum severity. */
    public static int severityRank(String s) {
        String v = normalizeSeverity(s);
        if (v.equals("critical")) { return 0; }
        if (v.equals("major"))    { return 1; }
        if (v.equals("minor"))    { return 2; }
        return 3;
    }

    /**
     * The rule as it would be written back to house-rules.json.
     *
     * Distinct from describe(), which is a summary for the browser and
     * deliberately omits the pattern. An export that lost the patterns would
     * look plausible and destroy the rule set, so everything needed to
     * reconstruct the rule is here - and the lifecycle is emitted as it stands,
     * so nothing is promoted to policy by the act of exporting.
     */
    public Map<String, Object> export() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("id", id);
        m.put("kind", kind);
        m.put("name", name);
        m.put("category", category);
        m.put("severity", severity);
        m.put("lifecycle", lifecycle);
        m.put("enforcement", enforcement);
        if (!enabled) { m.put("enabled", Boolean.FALSE); }
        if (autoFixable) { m.put("autoFixable", Boolean.TRUE); }
        if (!appliesTo.isEmpty()) { m.put("appliesTo", appliesTo); }
        m.put("scope", scope);

        if (KIND_MANUAL.equals(kind)) {
            /* nothing to emit - a prompt is its wording */
        } else if (KIND_ARTIFACT.equals(kind)) {
            if (check != null) { m.put("check", check); }
        } else {
            if (pattern != null) { m.put("pattern", pattern.pattern()); }
            if (notWhen != null) { m.put("notWhen", notWhen.pattern()); }
            if (guardLines > 0) { m.put("guardLines", Integer.valueOf(guardLines)); }
            if (scanComments) { m.put("scanComments", Boolean.TRUE); }
        }

        m.put("message", message);
        if (!checkText.isEmpty()) { m.put("checkText", checkText); }
        if (!impactedArea.isEmpty()) { m.put("impactedArea", impactedArea); }
        if (!priority.isEmpty()) { m.put("priority", priority); }
        if (!primaryReviewer.isEmpty()) { m.put("primaryReviewer", primaryReviewer); }
        if (!rationale.isEmpty()) { m.put("rationale", rationale); }
        if (remediation != null && !remediation.isEmpty()) { m.put("remediation", remediation); }
        if (source != null) { m.put("source", source); }
        if (fix != null) { m.put("fix", fix); }
        if (!firesOn.isEmpty() || !quietOn.isEmpty()) {
            Map<String, Object> ex = new LinkedHashMap<String, Object>();
            ex.put("fires", firesOn);
            ex.put("quiet", quietOn);
            m.put("examples", ex);
        }
        return m;
    }

    public Map<String, Object> describe() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("id", id);
        m.put("kind", kind);
        m.put("name", name);
        m.put("severity", severity);
        m.put("category", category);
        m.put("enabled", Boolean.valueOf(enabled));
        m.put("autoFixable", Boolean.valueOf(autoFixable));
        m.put("appliesTo", appliesTo);
        m.put("scope", scope);
        m.put("lifecycle", lifecycle);
        m.put("enforcement", enforcement);
        m.put("exampleCount", Integer.valueOf(firesOn.size() + quietOn.size()));
        m.put("automated", Boolean.valueOf(isAutomated()));
        m.put("fixable", Boolean.valueOf(isFixable()));
        if (!checkText.isEmpty()) { m.put("checkText", checkText); }
        if (!impactedArea.isEmpty()) { m.put("impactedArea", impactedArea); }
        if (!priority.isEmpty()) { m.put("priority", priority); }
        if (!primaryReviewer.isEmpty()) { m.put("primaryReviewer", primaryReviewer); }

        if (remediation != null && !remediation.isEmpty()) {
            m.put("remediation", remediation);
        }
        if (rationale != null && !rationale.isEmpty()) {
            m.put("rationale", rationale);
        }
        if (source != null) {
            m.put("source", source);
        }
        if (error != null) {
            m.put("error", error);
        }
        return m;
    }
}

package com.bawassistant;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * One thing worth telling the developer.
 *
 * Buffer findings carry a source position and become a marker in the editor
 * gutter. Artifact findings do not - they are about the artifact as a whole -
 * and line 0 is how the client tells them apart.
 */
public final class Finding {

    public String ruleId = "";
    public String ruleName = "";
    public String category = "";
    public String severity = "warning";
    public String message = "";
    public String remediation = "";
    public boolean autoFixable;

    /** Why the standard exists. Rendered above the remediation, not instead of it. */
    public String rationale = "";

    /** {sourceId, locator, authorityStatus} - the checklist cell this came from. */
    public Map<String, Object> source;

    /** "active" or "draft". A draft is shown, but it is not policy. */
    public String lifecycle = Rule.LIFECYCLE_ACTIVE;

    /** "error" | "manual" | "advisory" | "auto-fixable". Separate axis from severity. */
    public String enforcement = Rule.ENFORCE_MANUAL;

    /**
     * WHICH parts of the artifact this is about - step, gateway or variable
     * names, in the artifact's own vocabulary.
     *
     * An artifact finding carries no line, so without this a message like "a
     * gateway has an outgoing path with no condition" sends the developer
     * hunting through every gateway on the process. Empty whenever the rule
     * judged the artifact as a whole rather than any row of it, which is a
     * real answer and not a missing one.
     */
    public java.util.List<String> subjects = java.util.Collections.emptyList();

    /** 1-based. 0 means "no position" - an artifact-level finding. */
    public int line;
    public int column;
    public int endColumn;
    public String snippet = "";

    /** How many times this rule fired in the same block, once collapsed. */
    public int occurrences = 1;

    public static Finding of(Rule rule, String message) {
        Finding f = new Finding();
        f.ruleId = rule.id;
        f.ruleName = rule.name;
        f.category = rule.category;
        f.severity = rule.severity;
        f.remediation = rule.remediation;
        f.autoFixable = rule.autoFixable;
        f.rationale = rule.rationale;
        f.source = rule.source;
        f.lifecycle = rule.lifecycle;
        f.enforcement = rule.enforcement;
        f.message = message;
        return f;
    }

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("ruleId", ruleId);
        m.put("ruleName", ruleName);
        m.put("category", category);
        m.put("severity", severity);
        m.put("message", message);
        m.put("line", Integer.valueOf(line));
        m.put("column", Integer.valueOf(column));
        m.put("endColumn", Integer.valueOf(endColumn));
        m.put("snippet", snippet);
        m.put("autoFixable", Boolean.valueOf(autoFixable));
        m.put("occurrences", Integer.valueOf(occurrences));
        m.put("lifecycle", lifecycle);
        m.put("enforcement", enforcement);
        if (subjects != null && !subjects.isEmpty()) {
            m.put("subjects", subjects);
        }
        if (remediation != null && !remediation.isEmpty()) {
            m.put("remediation", remediation);
        }
        if (rationale != null && !rationale.isEmpty()) {
            m.put("rationale", rationale);
        }
        if (source != null) {
            m.put("source", source);
        }
        return m;
    }
}

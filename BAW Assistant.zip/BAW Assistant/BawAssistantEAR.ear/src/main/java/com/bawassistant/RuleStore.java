package com.bawassistant;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;

/**
 * The rule set, from two places.
 *
 * <b>Policy</b> comes from {@code /WEB-INF/rules/} inside the WAR: versioned
 * alongside the code, diffable, and changed only by a redeploy.
 *
 * <b>Drafts</b> come from {@link DraftStore}, a directory outside the WAR that
 * the authoring UI can write. They run and report exactly like policy rules but
 * are never binding and never auto-applied, and promoting one means exporting
 * the JSON and redeploying - which is the governance gate, not a workaround.
 *
 * Policy always wins. A draft that shadows a policy id is refused at save time
 * and ignored here if one appears by hand, because a rule that silently
 * overrode reviewed policy would make the WAR stop meaning anything.
 */
public final class RuleStore {

    private static final String RULES_DIR = "/WEB-INF/rules/";

    private static volatile List<Rule> cached;
    private static volatile List<String> problems;
    private static volatile String loadedFrom = "";

    private RuleStore() { }

    public static List<Rule> rules(ServletContext ctx) {
        List<Rule> local = cached;
        if (local == null) {
            synchronized (RuleStore.class) {
                if (cached == null) {
                    load(ctx);
                }
                local = cached;
            }
        }
        return local;
    }

    /** Discard the cache; the next call re-reads. Used by the reload endpoint. */
    public static void invalidate() {
        synchronized (RuleStore.class) {
            cached = null;
            problems = null;
        }
    }

    public static List<String> problems(ServletContext ctx) {
        rules(ctx);
        return problems == null ? new ArrayList<String>() : problems;
    }

    public static String source() {
        return loadedFrom;
    }

    /** Ids that came from the WAR. Drafts may not use them. */
    private static volatile List<String> policyIds = new ArrayList<String>();

    public static List<String> policyIds(ServletContext ctx) {
        rules(ctx);
        return policyIds;
    }

    private static void load(ServletContext ctx) {
        List<Rule> loaded = new ArrayList<Rule>();
        List<String> errors = new ArrayList<String>();
        List<String> files = new ArrayList<String>();

        Set<String> paths = null;
        try {
            paths = ctx.getResourcePaths(RULES_DIR);
        } catch (Exception e) {                       // NOPMD - context may be odd
            errors.add("cannot list " + RULES_DIR + ": " + e);
        }

        if (paths == null || paths.isEmpty()) {
            errors.add("no rule files found in " + RULES_DIR);
        } else {
            List<String> sorted = new ArrayList<String>(paths);
            java.util.Collections.sort(sorted);
            for (String path : sorted) {
                if (!path.toLowerCase().endsWith(".json")) { continue; }
                try {
                    String text = read(ctx, path);
                    Map<String, Object> doc = Json.parseObject(text);
                    List<Object> raw = Json.arr(doc.get("rules"));
                    if (raw == null) {
                        errors.add(path + ": no \"rules\" array");
                        continue;
                    }
                    int ok = 0;
                    for (Object o : raw) {
                        Map<String, Object> rm = Json.obj(o);
                        if (rm == null) { continue; }
                        Rule rule = Rule.from(rm);
                        if (rule.error != null) {
                            // A broken rule is skipped but never silent - a rule
                            // that vanishes quietly is worse than one that fails.
                            errors.add(path + " / " + rule.id + ": " + rule.error);
                            continue;
                        }
                        loaded.add(rule);
                        ok++;
                    }
                    files.add(path + " (" + ok + ")");
                } catch (Json.JsonException e) {
                    errors.add(path + ": " + e.getMessage());
                } catch (IOException e) {
                    errors.add(path + ": " + e);
                }
            }
        }

        List<String> ids = new ArrayList<String>();
        for (Rule r : loaded) { ids.add(r.id); }
        policyIds = ids;

        /* Drafts last, and only those that do not shadow policy. */
        int drafts = 0;
        for (Rule d : DraftStore.load(errors)) {
            if (ids.contains(d.id)) {
                errors.add("draft " + d.id + " shadows a policy rule and was ignored");
                continue;
            }
            loaded.add(d);
            drafts++;
        }
        if (drafts > 0) {
            files.add(DraftStore.dir().getName() + "/ (" + drafts + " draft)");
        }

        cached = loaded;
        problems = errors;

        /* Verify once, here, rather than per request.
         *
         * The rule browser asked the verifier to re-run every rule that
         * carries examples on EVERY page load, and each example is entitled
         * to the linter's 250 ms budget. Normally that is milliseconds; with
         * one pathological pattern in the draft overlay it is seconds, on a
         * request thread. A verdict cannot change without the rule changing,
         * and a rule cannot change without passing through here. */
        Map<String, RuleVerifier.Result> vs
                = new LinkedHashMap<String, RuleVerifier.Result>();
        for (Rule r : loaded) {
            if (!r.isAutomated()) { continue; }
            if (r.firesOn.isEmpty() && r.quietOn.isEmpty()) { continue; }
            vs.put(r.id, RuleVerifier.verify(r));
        }
        verdicts = vs;
        loadedFrom = files.isEmpty() ? "(none)" : join(files, ", ");
    }

    /** Verdicts computed at load. Empty for a rule that carries no examples. */
    private static volatile Map<String, RuleVerifier.Result> verdicts
            = new LinkedHashMap<String, RuleVerifier.Result>();

    /**
     * This rule's verdict, from the cache.
     *
     * Falls back to verifying on the spot for a rule the store has never seen
     * - a candidate from /api/try is not in the store at all - so the caller
     * never has to care which kind it is holding.
     */
    public static RuleVerifier.Result verdict(ServletContext ctx, Rule r) {
        rules(ctx);
        RuleVerifier.Result v = verdicts.get(r.id);
        return (v != null) ? v : RuleVerifier.verify(r);
    }

    private static String read(ServletContext ctx, String path) throws IOException {
        InputStream in = ctx.getResourceAsStream(path);
        if (in == null) {
            throw new IOException("not readable");
        }
        BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        try {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append('\n');
            }
            return sb.toString();
        } finally {
            try { r.close(); } catch (IOException ignored) { /* closing */ }
        }
    }

    private static String join(List<String> parts, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) { sb.append(sep); }
            sb.append(parts.get(i));
        }
        return sb.toString();
    }

    /** Counts by kind and severity, for the status endpoint. */
    public static Map<String, Object> summary(ServletContext ctx) {
        List<Rule> all = rules(ctx);
        int buffer = 0;
        int artifact = 0;
        /* Manual rows are neither buffer nor artifact.
         *
         * They used to fall into the else and be counted as buffer, so the hub
         * reported 116 buffer rules where there are 49, and the 67 checks a
         * person has to answer did not appear in the headline at all - the one
         * number that says the engine cannot settle the review on its own. */
        int manual = 0;
        Map<String, Object> bySeverity = new LinkedHashMap<String, Object>();
        for (Rule r : all) {
            if (Rule.KIND_ARTIFACT.equals(r.kind)) { artifact++; }
            else if (Rule.KIND_MANUAL.equals(r.kind)) { manual++; }
            else { buffer++; }
            Object n = bySeverity.get(r.severity);
            bySeverity.put(r.severity,
                    Integer.valueOf((n instanceof Integer ? ((Integer) n).intValue() : 0) + 1));
        }
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("total", Integer.valueOf(all.size()));
        m.put("buffer", Integer.valueOf(buffer));
        m.put("artifact", Integer.valueOf(artifact));
        m.put("manual", Integer.valueOf(manual));
        m.put("bySeverity", bySeverity);
        m.put("source", loadedFrom);
        m.put("draftDir", DraftStore.where());
        m.put("draftWritable", Boolean.valueOf(DraftStore.writable()));
        m.put("problems", problems == null ? new ArrayList<String>() : problems);
        return m;
    }
}

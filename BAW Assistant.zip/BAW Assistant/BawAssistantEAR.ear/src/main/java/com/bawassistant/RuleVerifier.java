package com.bawassistant;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Runs a rule against its own examples.
 *
 * Three rules were written and then withdrawn during development because they
 * fired on correct code. The worst was a null check that flagged the exact guard
 * the review checklist tells developers to write - it would have taught people
 * that the gutter is wrong, which is how a linter gets switched off.
 *
 * Every one of them was caught by a hand-written control that happened to exist,
 * not by the person who wrote the rule. This makes that check part of the rule
 * instead of part of someone's diligence: a rule declares what it must flag and
 * what it must leave alone, and anything can ask whether it still does.
 *
 * The <b>quiet</b> half is the one that matters and the one authors skip. It is
 * cheap to write a pattern that catches the defect; the work is proving it does
 * not catch anything else.
 */
public final class RuleVerifier {

    private RuleVerifier() { }

    /** One example, and whether the rule behaved as the author promised. */
    public static final class Case {
        public final String snippet;
        public final boolean shouldFire;
        public final boolean didFire;
        public final String note;
        /** A note that EXPLAINS a pass rather than reporting a problem. */
        public final boolean explained;

        Case(String snippet, boolean shouldFire, boolean didFire, String note) {
            this(snippet, shouldFire, didFire, note, false);
        }
        Case(String snippet, boolean shouldFire, boolean didFire, String note,
             boolean explained) {
            this.snippet = snippet;
            this.shouldFire = shouldFire;
            this.didFire = didFire;
            this.note = note;
            this.explained = explained;
        }
        /* A note normally means the example could not be run at all, which is
           a failure however the flags line up. The one exception is a quiet
           example that is out of the rule's scope: the note is the answer, not
           an obstacle. */
        public boolean passed() {
            return shouldFire == didFire && (note == null || explained);
        }

        public Map<String, Object> toMap() {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("snippet", snippet);
            m.put("expected", shouldFire ? "fires" : "quiet");
            m.put("actual", didFire ? "fires" : "quiet");
            m.put("passed", Boolean.valueOf(passed()));
            if (note != null) { m.put("note", note); }
            return m;
        }
    }

    /** The verdict for one rule. */
    public static final class Result {
        public final String ruleId;
        public final List<Case> cases = new ArrayList<Case>();
        public String error;

        Result(String ruleId) { this.ruleId = ruleId; }

        public int failed() {
            int n = 0;
            for (Case c : cases) { if (!c.passed()) { n++; } }
            return n;
        }
        /** Verified means: it has both kinds of example, and every one passes. */
        public boolean verified() {
            if (error != null || cases.isEmpty()) { return false; }
            boolean fires = false;
            boolean quiet = false;
            for (Case c : cases) {
                if (c.shouldFire) { fires = true; } else { quiet = true; }
            }
            return fires && quiet && failed() == 0;
        }

        public Map<String, Object> toMap() {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("ruleId", ruleId);
            m.put("verified", Boolean.valueOf(verified()));
            m.put("failed", Integer.valueOf(failed()));
            List<Object> cs = new ArrayList<Object>();
            for (Case c : cases) { cs.add(c.toMap()); }
            m.put("cases", cs);
            if (error != null) { m.put("error", error); }
            return m;
        }
    }

    /**
     * Verify one rule.
     *
     * The rule is tested <b>alone</b>, not against the whole rule set: the
     * question is whether THIS rule behaves, and running the others would let a
     * different rule's finding disguise a failure here.
     */
    public static Result verify(Rule rule) {
        Result r = new Result(rule.id);
        if (rule.error != null) {
            r.error = rule.error;
            return r;
        }
        /* Artifact rules take a model rather than a snippet, so their examples
           are the model itself written as JSON. Keeping both kinds in the same
           array of strings means one schema, one editor field and one build
           gate - the only difference is how the string is read. */

        List<Rule> only = new ArrayList<Rule>(1);
        only.add(rule);

        for (int i = 0; i < rule.firesOn.size(); i++) {
            r.cases.add(run(only, rule, rule.firesOn.get(i), true));
        }
        for (int i = 0; i < rule.quietOn.size(); i++) {
            r.cases.add(run(only, rule, rule.quietOn.get(i), false));
        }
        return r;
    }

    private static Case run(List<Rule> only, Rule rule, String snippet, boolean shouldFire) {
        String note = null;
        boolean fired = false;
        try {
            List<Finding> found;
            if (Rule.KIND_ARTIFACT.equals(rule.kind)) {
                Map<String, Object> artifact;
                try {
                    artifact = Json.parseObject(snippet);
                } catch (Json.JsonException e) {
                    return new Case(snippet, shouldFire, false,
                            "example is not a valid artifact model: " + e.getMessage());
                }
                /* An artifact rule that lists no appliesTo runs against
                   anything; one that does needs the example to say which type
                   it is.
                 *
                 * Out of scope in a FIRES example is an authoring mistake: the
                 * rule cannot fire on a type it does not apply to, and the
                 * example would look broken for a reason that has nothing to
                 * do with the rule.
                 *
                 * Out of scope in a QUIET example is the opposite - it is the
                 * single most useful thing a quiet example can pin. "Not
                 * applicable to this type" is a legitimate way to be silent,
                 * and until now it could not be expressed, so nothing in the
                 * build could hold a rule's SCOPE. That gap shipped 14 process
                 * rules scoped to SERVICEFLOW and COACHFLOW, which put lane,
                 * Portal-subject and at-risk findings on service flows that
                 * have none of those things - 46 false positives from one rule
                 * alone on the Test PA sample. A quiet example naming an
                 * out-of-scope type now passes, and says so. */
                String exampleType = Json.str(artifact, "type", "");
                if (!rule.appliesTo.isEmpty() && !rule.applies(exampleType)) {
                    if (shouldFire) {
                        return new Case(snippet, shouldFire, false,
                                "example has type '" + exampleType
                                + "', which this rule does not apply to");
                    }
                    return new Case(snippet, shouldFire, false,
                            "correctly silent: '" + exampleType
                            + "' is out of this rule's scope", true);
                }
                found = ArtifactChecker.check(artifact, only, "info");
            } else {
                /* "info" so a rule of any severity is visible - filtering here
                   would make a low-severity rule look broken. */
                found = BufferLinter.lint(snippet, language(rule), only, "info");
            }
            for (Finding f : found) {
                if (rule.id.equals(f.ruleId)) {
                    /* The engine reports a runaway pattern as a finding against
                       the rule itself; that is a failure, not a match. */
                    if ("engine".equals(f.category)) {
                        note = f.message;
                    } else {
                        fired = true;
                    }
                }
            }
        } catch (RuntimeException e) {
            note = "threw: " + e;
        }
        return new Case(snippet, shouldFire, fired, note);
    }

    /** Examples are written in the first language the rule applies to. */
    private static String language(Rule rule) {
        return rule.appliesTo.isEmpty() ? "javascript" : rule.appliesTo.get(0);
    }

    /** Verify every rule that carries examples, of either kind. */
    public static List<Result> verifyAll(List<Rule> rules) {
        List<Result> out = new ArrayList<Result>();
        for (Rule r : rules) {
            /* A prompt has nothing to verify: a person decides it, and
               inventing examples would only make it look automated. */
            if (!r.isAutomated()) { continue; }
            if (r.firesOn.isEmpty() && r.quietOn.isEmpty()) { continue; }
            out.add(verify(r));
        }
        return out;
    }
}

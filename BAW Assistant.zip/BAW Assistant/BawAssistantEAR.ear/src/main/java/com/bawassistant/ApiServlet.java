package com.bawassistant;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * The assistant's API. One servlet, routed by path - three servlets for three
 * endpoints is ceremony without benefit.
 *
 * <pre>
 *   GET  /api/status          what the assistant can do right now
 *   GET  /api/rules           every loaded rule, for the rule browser
 *   POST /api/rules/reload    drop the cache and re-read WEB-INF/rules
 *   POST /api/lint            {code, language, minSeverity} -&gt; findings
 *   POST /api/check           {artifact, minSeverity}       -&gt; findings
 *   POST /api/review          {artifacts[], minSeverity}    -&gt; findings + counts
 * </pre>
 *
 * Same-origin by construction: this ships inside the same WAR as the hub, so
 * there is no CORS, and the Designer's own CSP ({@code connect-src 'self'}) is
 * satisfied without argument.
 *
 * Annotation-mapped - Servlet 3.0, no web.xml entry needed.
 */
@WebServlet(name = "AssistantApi", urlPatterns = { "/api/*" })
public class ApiServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    private static final int MAX_BODY_CHARS = 2 * 1024 * 1024;

    /**
     * The role that may author rules, declared in WEB-INF/web.xml.
     *
     * Declaring it there is what makes isUserInRole answer at all - an
     * undeclared role is false for everyone, whatever the group mapping says.
     */
    static final String ROLE_AUTHOR = "assistant-author";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String path = route(req);
        if ("/status".equals(path) || "/".equals(path) || path.isEmpty()) {
            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("ok", Boolean.TRUE);
            out.put("lint", Boolean.TRUE);        // never depends on anything external
            out.put("user", req.getRemoteUser());
            /* Answers "may I author?" without making the caller attempt a
               write to find out - and, after a role remapping, says whether
               the console change actually took effect. */
            out.put("mayAuthor", Boolean.valueOf(mayAuthor(req)));
            out.put("contextPath", req.getContextPath());
            /* Which build is actually serving this request.
             *
             * A probe once raced an application restart and reported a working
             * fix as broken. Comparing this against the build log is the cheap
             * check that the classes on the server are the ones just built. */
            out.put("build", buildInfo());
            out.put("rules", RuleStore.summary(getServletContext()));
            send(resp, 200, out);
            return;
        }
        if ("/rules".equals(path)) {
            List<Object> described = new ArrayList<Object>();
            List<String> inWar = RuleStore.policyIds(getServletContext());
            for (Rule r : RuleStore.rules(getServletContext())) {
                Map<String, Object> d = r.describe();
                /* Editable here means the draft store holds it. Most drafts ship
                   in the WAR and are read-only, so lifecycle alone would mislead
                   the list exactly as it misled the editor. */
                d.put("editable", Boolean.valueOf(!inWar.contains(r.id)));
                /* Whether a draft has earned promotion is the single most
                   useful column in the list, and computing it here saves the
                   manager a second round trip per rule. */
                if (Rule.KIND_BUFFER.equals(r.kind)
                        && (!r.firesOn.isEmpty() || !r.quietOn.isEmpty())) {
                    RuleVerifier.Result v = RuleStore.verdict(getServletContext(), r);
                    d.put("verified", Boolean.valueOf(v.verified()));
                    d.put("examplesFailing", Integer.valueOf(v.failed()));
                }
                described.add(d);
            }
            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("rules", described);
            out.put("problems", RuleStore.problems(getServletContext()));
            out.put("source", RuleStore.source());
            send(resp, 200, out);
            return;
        }
        /* What the review checklist asks of this artifact type.
         *
         * The assistant answers some of the checklist mechanically and cannot
         * answer the rest. Showing only the first half would leave a developer
         * believing a green panel means a passed review, when two thirds of the
         * list was never asked. So both halves are reported: how many checks
         * the engine settles for this type, and every one it does not.
         */
        if ("/checklist".equals(path)) {
            String type = req.getParameter("type");
            if (type == null) { type = ""; }

            /* One question is one check, even when the workbook asks it twice.
             *
             * The checklist repeats "Number of fields should not exceed 30 in
             * one EPV" on the UCA sheet, where the author filled in the serial
             * number and the question and left Category, Priority, Impacted
             * Area and Primary Reviewer blank. Both copies are unrestricted, so
             * a reviewer met the same question twice on EVERY artifact type -
             * once complete, once bare and sorted to the bottom for want of a
             * priority.
             *
             * The store still carries all 67 rows; what is collapsed here is
             * what a person is ASKED, and being asked the same thing twice is
             * not two checks. The fuller row wins and the discarded row's cell
             * is kept beside it in alsoAt, so the gap in the source stays
             * visible instead of being silently papered over. */
            Map<String, Map<String, Object>> asked
                    = new LinkedHashMap<String, Map<String, Object>>();
            int automated = 0;
            for (Rule r : RuleStore.rules(getServletContext())) {
                /* A buffer rule's appliesTo names a language, not an artifact
                   type, so it applies wherever there is code - counting it
                   against the type would be meaningless either way. */
                if (Rule.KIND_BUFFER.equals(r.kind)) { automated++; continue; }
                if (!type.isEmpty() && !r.applies(type)) { continue; }
                if (Rule.KIND_MANUAL.equals(r.kind)) {
                    Map<String, Object> row = r.describe();
                    /* Identity is the question itself. A row with no wording
                       cannot be matched to anything, so it keeps its own key
                       rather than collapsing every such row into one. */
                    String q = r.checkText.trim();
                    String key = q.isEmpty() ? ("<no wording> " + r.id)
                                             : q.toLowerCase();
                    Map<String, Object> prior = asked.get(key);
                    if (prior == null) {
                        asked.put(key, row);
                    } else if (completeness(row) > completeness(prior)) {
                        carryCell(row, prior);
                        asked.put(key, row);
                    } else {
                        carryCell(prior, row);
                    }
                } else {
                    automated++;
                }
            }
            List<Object> prompts = new ArrayList<Object>(asked.values());
            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("artifactType", type);
            out.put("automated", Integer.valueOf(automated));
            out.put("forReview", Integer.valueOf(prompts.size()));
            out.put("prompts", prompts);
            send(resp, 200, out);
            return;
        }

        /* One rule, in full.
         *
         * /api/rules returns describe(), a summary that deliberately omits the
         * pattern - it is for a browser list, and shipping every regex to every
         * page load is waste. The manager needs the whole definition to edit it,
         * so it asks for one at a time. */
        if (path.startsWith("/rules/") && path.length() > 7) {
            String id = path.substring(7);
            for (Rule r : RuleStore.rules(getServletContext())) {
                if (r.id.equals(id)) {
                    Map<String, Object> out = new LinkedHashMap<String, Object>();
                    out.put("rule", r.export());
                    /* Editable means the draft store can hold it, which is
                       NOT the same as lifecycle:draft - most drafts ship in the
                       WAR and are as read-only as policy. Offering Save on one
                       the server will refuse is worse than not offering it. */
                    out.put("editable", Boolean.valueOf(
                            !RuleStore.policyIds(getServletContext()).contains(r.id)));
                    out.put("inWar", Boolean.valueOf(
                            RuleStore.policyIds(getServletContext()).contains(r.id)));
                    out.put("examples", RuleStore.verdict(getServletContext(), r).toMap());
                    send(resp, 200, out);
                    return;
                }
            }
            error(resp, 404, "no rule with id " + id);
            return;
        }

        error(resp, 404, "no such endpoint: " + path);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String path = route(req);

        /* Verify every rule that carries examples. Used by the build gate and
           by the manager to show which drafts have earned promotion. */
        if ("/rules/verify".equals(path)) {
            List<Object> results = new ArrayList<Object>();
            int failed = 0;
            int verified = 0;
            for (RuleVerifier.Result r : RuleVerifier.verifyAll(
                    RuleStore.rules(getServletContext()))) {
                results.add(r.toMap());
                if (r.failed() > 0 || r.error != null) { failed++; }
                if (r.verified()) { verified++; }
            }
            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("results", results);
            out.put("withExamples", Integer.valueOf(results.size()));
            out.put("verified", Integer.valueOf(verified));
            out.put("failing", Integer.valueOf(failed));
            send(resp, 200, out);
            return;
        }

        if ("/rules/reload".equals(path)) {
            RuleStore.invalidate();
            send(resp, 200, RuleStore.summary(getServletContext()));
            return;
        }

        Map<String, Object> body;
        try {
            body = Json.parseObject(readBody(req));
        } catch (Json.JsonException e) {
            error(resp, 400, "malformed JSON: " + e.getMessage());
            return;
        } catch (IllegalStateException e) {
            error(resp, 413, e.getMessage());
            return;
        }

        String minSeverity = Json.str(body, "minSeverity", "warning");
        List<Rule> rules = RuleStore.rules(getServletContext());

        if ("/lint".equals(path)) {
            String code = Json.str(body, "code", "");
            String language = Json.str(body, "language", "javascript");
            long started = System.nanoTime();
            List<Finding> found = BufferLinter.lint(code, language, rules, minSeverity);
            double ms = (System.nanoTime() - started) / 1_000_000.0;

            boolean collapse = Json.bool(body, "collapse", false);
            List<Finding> shown = collapse ? BufferLinter.collapse(found) : found;

            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("findings", toList(shown));
            out.put("summary", summarize(found));
            out.put("elapsedMs", Double.valueOf(Math.round(ms * 10) / 10.0));
            send(resp, 200, out);
            return;
        }

        if ("/check".equals(path)) {
            Map<String, Object> artifact = Json.obj(body.get("artifact"));
            if (artifact == null) {
                error(resp, 400, "body needs an \"artifact\" object");
                return;
            }
            List<Finding> found = ArtifactChecker.check(artifact, rules, minSeverity);
            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("findings", toList(found));
            out.put("summary", summarize(found));
            out.put("artifactType", Json.str(artifact, "type", ""));
            out.put("artifactName", Json.str(artifact, "name", ""));
            send(resp, 200, out);
            return;
        }

        /* Review a BATCH of artifacts at a container ref.
         *
         * This is the whole-application review's engine half. The sweep itself
         * runs in the BROWSER, through bridge.js's readers, for two reasons
         * that are not preferences:
         *
         *   - those readers are two thousand lines keyed on the payload's own
         *     domainProperty, and harvest-corpus.js already imports them
         *     rather than reimplementing them precisely so a second copy
         *     cannot drift. A Java reimplementation would be that copy.
         *   - the browser holds the LTPA session. This servlet holds no BAW
         *     credentials, and making the review depend on server-to-server
         *     calls would put it behind the same open question that blocks
         *     the AI path.
         *
         * So the client reads, batches, and posts here. Stateless and purely
         * per-batch: the client merges. That is deliberate - the alternative
         * is server-side accumulation keyed by some session id, which is state
         * to leak, expire and get wrong for no gain.
         *
         * Batching is not optional. MAX_BODY_CHARS is 2 MB and the largest
         * harvested application is 2,041,023 characters of code before JSON
         * escaping, so no single request can carry an application.
         */
        if ("/review".equals(path)) {
            List<Object> artifacts = Json.arr(body.get("artifacts"));
            if (artifacts == null) {
                error(resp, 400, "body needs an \"artifacts\" array");
                return;
            }

            /* A review reads a SNAPSHOT or a branch tip, never the editor
               buffer, so only rules that declare snapshot scope apply. Every
               rule in the file today declares both, so this excludes nothing
               yet - it is here because `scope` is otherwise a field nothing
               reads, and a develop-only rule added later must not silently
               start judging committed applications. */
            List<Rule> scoped = new ArrayList<Rule>(rules.size());
            for (Rule r : rules) {
                if (r.scope.contains(Rule.SCOPE_SNAPSHOT)) { scoped.add(r); }
            }

            List<Object> out = new ArrayList<Object>();
            Map<String, Object> byType = new LinkedHashMap<String, Object>();
            int surfaceCount = 0;
            long characters = 0;

            for (Object o : artifacts) {
                Map<String, Object> artifact = Json.obj(o);
                if (artifact == null) { continue; }
                String type = Json.str(artifact, "type", "");
                String name = Json.str(artifact, "name", "");
                String poId = Json.str(artifact, "poId", "");

                Object seen = byType.get(type);
                byType.put(type, Integer.valueOf(
                        (seen instanceof Integer ? ((Integer) seen).intValue() : 0) + 1));

                for (Finding f : ArtifactChecker.check(artifact, scoped, minSeverity)) {
                    out.add(identify(f, type, name, poId, null, null));
                }

                for (Object so : Json.arr(artifact.get("surfaces"))) {
                    Map<String, Object> surface = Json.obj(so);
                    if (surface == null) { continue; }
                    String code = Json.str(surface, "code", "");
                    if (code.isEmpty()) { continue; }
                    surfaceCount++;
                    characters += code.length();
                    String language = Json.str(surface, "language", "javascript");
                    String where = Json.str(surface, "surface", "");
                    /* The step the code belongs to. A service flow has one
                       Script surface per step, so without this every finding
                       in the application says only "Script". */
                    String node = Json.str(surface, "node", "");
                    for (Finding f : BufferLinter.lint(code, language, scoped, minSeverity)) {
                        out.add(identify(f, type, name, poId, where, node));
                    }
                }
            }

            Map<String, Object> scanned = new LinkedHashMap<String, Object>();
            scanned.put("artifacts", Integer.valueOf(artifacts.size()));
            scanned.put("surfaces", Integer.valueOf(surfaceCount));
            scanned.put("characters", Long.valueOf(characters));
            scanned.put("byType", byType);

            Map<String, Object> result = new LinkedHashMap<String, Object>();
            result.put("findings", out);
            result.put("scanned", scanned);
            /* How many rules could have fired, so the report can say what it
               asked as well as what it found. */
            result.put("rulesRun", Integer.valueOf(automated(scoped)));
            send(resp, 200, result);
            return;
        }

        /* Try one rule that has not been saved.
         *
         * The whole point of the tester: paste or edit a rule, run it against
         * the buffer the developer is actually looking at, and see where it
         * lands - before it is stored anywhere or seen by anyone else.
         *
         * Nothing here touches the rule store. The candidate is compiled,
         * used, and discarded, so a broken pattern cannot affect another
         * request. Its examples are run in the same call, because "does it
         * catch the defect" and "does it leave correct code alone" are the
         * same question asked twice and neither is useful alone.
         */
        if ("/try".equals(path)) {
            Map<String, Object> raw = Json.obj(body.get("rule"));
            if (raw == null) {
                error(resp, 400, "body needs a \"rule\" object");
                return;
            }
            Rule candidate = Rule.from(raw);

            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("ruleId", candidate.id);
            if (candidate.error != null) {
                /* A rule that will not compile is the common case while typing,
                   so it is a 200 with an error field, not a 400. The UI wants to
                   show the message under the field, not handle a failure. */
                out.put("ok", Boolean.FALSE);
                out.put("error", candidate.error);
                send(resp, 200, out);
                return;
            }
            out.put("ok", Boolean.TRUE);

            List<Rule> only = new ArrayList<Rule>(1);
            only.add(candidate);

            if (Rule.KIND_ARTIFACT.equals(candidate.kind)) {
                Map<String, Object> artifact = Json.obj(body.get("artifact"));
                if (artifact != null) {
                    out.put("findings", toList(
                            ArtifactChecker.check(artifact, only, "info")));
                }
            } else {
                String code = Json.str(body, "code", "");
                String language = Json.str(body, "language", "javascript");
                if (!code.isEmpty()) {
                    long started = System.nanoTime();
                    List<Finding> found = BufferLinter.lint(code, language, only, "info");
                    out.put("findings", toList(found));
                    out.put("elapsedMs", Double.valueOf(
                            Math.round((System.nanoTime() - started) / 100000.0) / 10.0));
                }
            }

            RuleVerifier.Result verdict = RuleVerifier.verify(candidate);
            out.put("examples", verdict.toMap());
            out.put("promotable", Boolean.valueOf(verdict.verified()));
            send(resp, 200, out);
            return;
        }

        /* What a repair would look like. It does not perform one.
         *
         * The response is a proposal per finding - line, before, after - which
         * the developer applies in their own editor and saves through Designer.
         * Nothing here writes to an artifact, which keeps the product's oldest
         * promise intact: the assistant reads, the developer writes.
         *
         * Only active policy rules that declare a fix are eligible; a draft
         * must never be able to edit anyone's code. That gate lives in
         * Rule.isFixable so no caller can route around it.
         */
        if ("/fix".equals(path)) {
            String code = Json.str(body, "code", "");
            String language = Json.str(body, "language", "javascript");
            List<String> only = Json.strings(body, "ruleIds");

            List<Map<String, Object>> fixes =
                    Fixer.plan(code, language, rules, only);

            Map<String, Object> out = new LinkedHashMap<String, Object>();
            out.put("fixes", fixes);
            out.put("count", Integer.valueOf(fixes.size()));
            send(resp, 200, out);
            return;
        }

        /* Save a draft.
         *
         * Draft only, enforced in DraftStore rather than here: a client that
         * sends lifecycle "active" is confused or hostile, and either way the
         * rule is written as a draft or not at all. Promotion is export,
         * commit, redeploy - deliberately not something an HTTP call can do.
         */
        if ("/rules/save".equals(path)) {
            Map<String, Object> raw = Json.obj(body.get("rule"));
            if (raw == null) {
                error(resp, 400, "body needs a \"rule\" object");
                return;
            }
            String wanted = Json.str(raw, "id", "");
            if (!mayAuthor(req)) {
                audit(req, "save", wanted, "denied");
                error(resp, 403, "not permitted to author rules");
                return;
            }
            try {
                Rule saved = DraftStore.save(raw,
                        RuleStore.policyIds(getServletContext()), req.getRemoteUser());
                RuleStore.invalidate();
                audit(req, "save", saved.id, "ok");
                Map<String, Object> out = new LinkedHashMap<String, Object>();
                out.put("saved", saved.id);
                out.put("rule", saved.describe());
                out.put("examples", RuleVerifier.verify(saved).toMap());
                out.put("rules", RuleStore.summary(getServletContext()));
                send(resp, 200, out);
            } catch (DraftStore.Refused e) {
                audit(req, "save", wanted, "refused: " + e.getMessage());
                error(resp, 409, e.getMessage());
            } catch (java.io.IOException e) {
                audit(req, "save", wanted, "failed: " + e.getMessage());
                error(resp, 500, "could not save: " + e.getMessage());
            }
            return;
        }

        if ("/rules/delete".equals(path)) {
            String id = Json.str(body, "id", "");
            if (!mayAuthor(req)) {
                audit(req, "delete", id, "denied");
                error(resp, 403, "not permitted to author rules");
                return;
            }
            try {
                boolean gone = DraftStore.delete(id,
                        RuleStore.policyIds(getServletContext()));
                RuleStore.invalidate();
                /* "absent" rather than "ok" when nothing was there to remove:
                   the request succeeded, but nothing changed, and a log that
                   says otherwise would invent a deletion that never happened. */
                audit(req, "delete", id, gone ? "ok" : "absent");
                Map<String, Object> out = new LinkedHashMap<String, Object>();
                out.put("deleted", Boolean.valueOf(gone));
                out.put("rules", RuleStore.summary(getServletContext()));
                send(resp, 200, out);
            } catch (DraftStore.Refused e) {
                audit(req, "delete", id, "refused: " + e.getMessage());
                error(resp, 409, e.getMessage());
            }
            return;
        }

        /* The whole set as one file, ready to commit.
         *
         * This is how a draft becomes policy: export, review the diff, commit,
         * redeploy. Drafts are emitted with their lifecycle intact so nothing
         * is promoted by accident - flipping it to active is a deliberate edit
         * a human makes and a reviewer sees. */
        if ("/rules/export".equals(path)) {
            List<Object> all = new ArrayList<Object>();
            for (Rule r : RuleStore.rules(getServletContext())) {
                all.add(r.export());
            }
            Map<String, Object> doc = new LinkedHashMap<String, Object>();
            doc.put("name", "BAW Assistant house rules");
            doc.put("version", Integer.valueOf(2));
            doc.put("exportedAt", Long.valueOf(System.currentTimeMillis()));
            doc.put("exportedBy", req.getRemoteUser());
            doc.put("rules", all);
            send(resp, 200, doc);
            return;
        }

        error(resp, 404, "no such endpoint: " + path);
    }

    /**
     * May this user author rules?
     *
     * A saved draft takes effect for every developer immediately, so this is
     * not a developer-level action.
     *
     * <b>An unset property now DENIES.</b> It used to return true, on the
     * reasoning that the group had not been decided and an open hook was
     * better than an absent one. That reasoning depended on the container
     * authenticating the caller first, and it did not: the WAR shipped without
     * a descriptor, so WebSphere never challenged anything, and an
     * unauthenticated POST to /api/rules/save was verified to return 200 and
     * enter the running rule set for every developer. Open-by-default was not
     * a hook, it was the hole.
     *
     * With WEB-INF/web.xml in place the caller is always authenticated, and
     * the question is only which of them may author. The default answer is the
     * declared {@link #ROLE_AUTHOR} role; the property remains as an override
     * for a site that maps a differently named role.
     */
    private static boolean mayAuthor(HttpServletRequest req) {
        String role = System.getProperty("baw.assistant.author.role", "");
        if (role.isEmpty()) { role = ROLE_AUTHOR; }
        try {
            return req.isUserInRole(role);
        } catch (RuntimeException e) {
            /* No security context at all - the application was installed
               without the roles mapped. Refusing is the safe answer, and the
               audit line below says why the author was turned away. */
            return false;
        }
    }

    /**
     * One line per authoring attempt, to SystemOut.log.
     *
     * Rules change what every developer sees in their editor, so "who changed
     * the rules, and when" has to be answerable after the fact. Denials are
     * recorded as well as successes: a run of them is either a misconfigured
     * role mapping or someone probing, and both are worth seeing.
     *
     * Deliberately System.out rather than a logging framework - the
     * application takes no third-party jars, and SystemOut.log is where a
     * WebSphere administrator already looks.
     */
    private static void audit(HttpServletRequest req, String action, String ruleId,
                              String outcome) {
        SimpleDateFormat iso = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        iso.setTimeZone(TimeZone.getTimeZone("UTC"));
        String user = req.getRemoteUser();
        System.out.println("[BAW-ASSISTANT-AUDIT] " + iso.format(new Date())
                + " action=" + action
                + " rule=" + (ruleId == null || ruleId.isEmpty() ? "(none)" : ruleId)
                + " user=" + (user == null ? "(unauthenticated)" : user)
                + " from=" + req.getRemoteAddr()
                + " outcome=" + outcome);
    }

    /**
     * Which build is serving this request, from a file build.ps1 writes.
     *
     * Read once and cached: the answer cannot change without a class reload,
     * and a reload gets a fresh static anyway.
     */
    private static volatile Map<String, Object> buildInfo;

    private static Map<String, Object> buildInfo() {
        Map<String, Object> cached = buildInfo;
        if (cached != null) { return cached; }

        Map<String, Object> m = new LinkedHashMap<String, Object>();
        InputStream in = ApiServlet.class.getResourceAsStream("build-info.properties");
        if (in == null) {
            /* Built before this file existed, or packaged by hand. Say so
               rather than reporting a reassuring blank. */
            m.put("id", "unknown");
            m.put("note", "no build-info.properties on the classpath");
        } else {
            try {
                Properties p = new Properties();
                p.load(in);
                m.put("id", p.getProperty("buildId", "unknown"));
                m.put("at", p.getProperty("built", ""));
            } catch (IOException e) {
                m.put("id", "unreadable");
                m.put("note", e.toString());
            } finally {
                try { in.close(); } catch (IOException ignored) { /* closing */ }
            }
        }
        buildInfo = m;
        return m;
    }

    // ------------------------------------------------------------ helpers

    private static String route(HttpServletRequest req) {
        String p = req.getPathInfo();
        return (p == null) ? "" : p;
    }

    private static String readBody(HttpServletRequest req) throws IOException {
        req.setCharacterEncoding("UTF-8");
        BufferedReader r = req.getReader();
        StringBuilder sb = new StringBuilder();
        char[] buf = new char[8192];
        int n;
        while ((n = r.read(buf)) > 0) {
            sb.append(buf, 0, n);
            if (sb.length() > MAX_BODY_CHARS) {
                // A coach view script is kilobytes. Anything at this size is a
                // mistake, and reading it all costs the server nothing good.
                throw new IllegalStateException("request body too large");
            }
        }
        return sb.toString();
    }

    /**
     * One finding, told where it came from.
     *
     * An application-scale report is unreadable without this: "loose equality"
     * repeated four hundred times says nothing about which of nine hundred
     * artifacts to open. `surface` and `node` are null for an artifact-level
     * finding, which is also how the client tells the two apart - the same
     * distinction line 0 already carries.
     */
    private static Map<String, Object> identify(Finding f, String type, String name,
                                                String poId, String surface, String node) {
        Map<String, Object> m = f.toMap();
        m.put("artifactType", type);
        m.put("artifact", name);
        if (poId != null && !poId.isEmpty()) { m.put("poId", poId); }
        if (surface != null && !surface.isEmpty()) { m.put("surface", surface); }
        if (node != null && !node.isEmpty()) { m.put("node", node); }
        return m;
    }

    private static int automated(List<Rule> rules) {
        int n = 0;
        for (Rule r : rules) {
            if (r.isAutomated() && r.enabled && r.error == null) { n++; }
        }
        return n;
    }

    private static List<Object> toList(List<Finding> findings) {
        List<Object> out = new ArrayList<Object>(findings.size());
        for (Finding f : findings) {
            out.add(f.toMap());
        }
        return out;
    }

    private static Map<String, Object> summarize(List<Finding> findings) {
        int critical = 0;
        int major = 0;
        int minor = 0;
        int warning = 0;
        for (Finding f : findings) {
            if ("critical".equals(f.severity))    { critical++; }
            else if ("major".equals(f.severity))  { major++; }
            else if ("minor".equals(f.severity))  { minor++; }
            else                                  { warning++; }
        }
        Map<String, Object> counts = new LinkedHashMap<String, Object>();
        counts.put("critical", Integer.valueOf(critical));
        counts.put("major", Integer.valueOf(major));
        counts.put("minor", Integer.valueOf(minor));
        counts.put("warning", Integer.valueOf(warning));

        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("total", Integer.valueOf(findings.size()));
        m.put("counts", counts);
        // What would be drawn in the gutter, as opposed to listed in the panel.
        m.put("inline", Integer.valueOf(critical + major));
        return m;
    }

    private static void send(HttpServletResponse resp, int status, Object body)
            throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        PrintWriter out = resp.getWriter();
        out.print(Json.write(body));
        out.flush();
    }

    private static void error(HttpServletResponse resp, int status, String detail)
            throws IOException {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("ok", Boolean.FALSE);
        m.put("detail", detail);
        send(resp, status, m);
    }

    /* How much of the checklist's own metadata a row actually carries.
     *
     * describe() omits these keys when the cell is blank, so a null here means
     * the workbook left it empty rather than that the value was lost. */
    private static int completeness(Map<String, Object> row) {
        int n = 0;
        if (row.get("priority") != null) { n++; }
        if (row.get("impactedArea") != null) { n++; }
        if (row.get("primaryReviewer") != null) { n++; }
        return n;
    }

    /* Keep a collapsed duplicate's checklist cell beside the row that survived.
     *
     * The source map belongs to the Rule and is shared across every request, so
     * it is read and never written - the extra cells go in a fresh alsoAt list
     * on the response row instead. */
    @SuppressWarnings("unchecked")
    private static void carryCell(Map<String, Object> keep, Map<String, Object> drop) {
        List<Object> also = (keep.get("alsoAt") instanceof List)
                ? (List<Object>) keep.get("alsoAt")
                : null;
        if (also == null) {
            also = new ArrayList<Object>();
            keep.put("alsoAt", also);
        }
        Object src = drop.get("source");
        if (src instanceof Map) {
            Object loc = ((Map<String, Object>) src).get("locator");
            if (loc != null && !loc.toString().isEmpty() && !also.contains(loc)) {
                also.add(loc);
            }
        }
        /* A row collapsed earlier may already carry cells of its own. */
        if (drop.get("alsoAt") instanceof List) {
            for (Object loc : (List<Object>) drop.get("alsoAt")) {
                if (!also.contains(loc)) { also.add(loc); }
            }
        }
    }
}

package com.bawassistant;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Where draft rules live between "I wrote it" and "it is policy".
 *
 * The locked principle is that rules ship inside the WAR: versioned alongside
 * the code, diffable, attributable to a person. Authoring through a UI does not
 * change that - it splits it.
 *
 * <b>Policy rules stay in the WAR and are not writable here.</b> A draft is a
 * proposal; it saves instantly and takes effect for everyone, which is what
 * makes iteration bearable. Promoting one means exporting the JSON, committing
 * it and redeploying, and that redeploy IS the governance gate rather than an
 * obstacle around it: it is the moment a standard acquires an author, a review
 * and a date.
 *
 * Two consequences follow, and both are enforced rather than documented:
 * anything written here is forced to {@code lifecycle: draft}, and a rule id
 * that already exists as policy in the WAR is refused outright.
 *
 * <b>One file per rule.</b> Two people editing different rules never conflict,
 * and a corrupt file costs one rule rather than the whole set.
 *
 * <b>The directory sits outside the WAR</b>, because a redeploy replaces the
 * application directory and would erase it. On WebSphere ND the node filesystem
 * is not the master copy either, so a full node resync can revert it - which is
 * one more reason promotion, not the overlay, is where anything permanent goes.
 */
public final class DraftStore {

    /** Override with -Dbaw.assistant.rules.dir=... */
    public static final String DIR_PROPERTY = "baw.assistant.rules.dir";

    private static volatile File resolved;
    private static volatile String resolvedNote = "";

    private DraftStore() { }

    /**
     * Where drafts are kept, and why there.
     *
     * user.install.root is the WebSphere profile directory, which survives an
     * application redeploy and is per-profile rather than shared across a cell.
     * The temp fallback exists so a developer running outside WAS still gets a
     * working store rather than an exception - it is reported, not hidden,
     * because drafts in a temp directory will not survive a restart.
     */
    public static File dir() {
        File d = resolved;
        if (d != null) { return d; }
        synchronized (DraftStore.class) {
            if (resolved != null) { return resolved; }

            String explicit = System.getProperty(DIR_PROPERTY);
            String note;
            File candidate;
            if (explicit != null && !explicit.trim().isEmpty()) {
                candidate = new File(explicit.trim());
                note = DIR_PROPERTY;
            } else {
                String profile = System.getProperty("user.install.root");
                if (profile != null && !profile.trim().isEmpty()) {
                    candidate = new File(profile.trim(), "bawAssistantRules");
                    note = "user.install.root";
                } else {
                    candidate = new File(System.getProperty("java.io.tmpdir"),
                            "bawAssistantRules");
                    note = "java.io.tmpdir - drafts will NOT survive a restart";
                }
            }
            if (!candidate.isDirectory() && !candidate.mkdirs()) {
                note = note + " (could not create - drafts cannot be saved)";
            }
            resolved = candidate;
            resolvedNote = note;
            return candidate;
        }
    }

    public static String where() {
        dir();
        return dir().getAbsolutePath() + "  [" + resolvedNote + "]";
    }

    public static boolean writable() {
        File d = dir();
        return d.isDirectory() && d.canWrite();
    }

    /* ------------------------------------------------------------- reading */

    /** Every draft on disk, with any that failed to parse reported separately. */
    public static List<Rule> load(List<String> problemsOut) {
        List<Rule> out = new ArrayList<Rule>();
        File d = dir();
        File[] files = d.listFiles();
        if (files == null) { return out; }
        Arrays.sort(files);
        for (int i = 0; i < files.length; i++) {
            File f = files[i];
            if (!f.isFile() || !f.getName().toLowerCase().endsWith(".json")) { continue; }
            try {
                Map<String, Object> raw = Json.parseObject(read(f));
                Rule r = Rule.from(raw);
                if (r.error != null) {
                    problemsOut.add("draft " + f.getName() + ": " + r.error);
                    continue;
                }
                if (!Rule.LIFECYCLE_DRAFT.equals(r.lifecycle)) {
                    /* Should be impossible - save() forces it - but a file can
                       be edited by hand, and a non-draft here would quietly
                       become policy that no redeploy ever reviewed. */
                    problemsOut.add("draft " + f.getName() + ": not lifecycle draft, ignored");
                    continue;
                }
                out.add(r);
            } catch (Json.JsonException e) {
                problemsOut.add("draft " + f.getName() + ": " + e.getMessage());
            } catch (IOException e) {
                problemsOut.add("draft " + f.getName() + ": " + e);
            }
        }
        return out;
    }

    /* ------------------------------------------------------------- writing */

    /** Thrown when a write is not allowed. The message is shown to the author. */
    public static final class Refused extends Exception {
        private static final long serialVersionUID = 1L;
        Refused(String why) { super(why); }
    }

    /**
     * Save one draft.
     *
     * @param policyIds ids that exist in the WAR, which may not be shadowed.
     */
    public static Rule save(Map<String, Object> raw, List<String> policyIds, String author)
            throws Refused, IOException {
        String id = Json.str(raw, "id", "").trim();
        if (id.isEmpty()) {
            throw new Refused("the rule needs an id");
        }
        if (!id.matches("[A-Za-z0-9_.-]{3,80}")) {
            /* The id becomes a filename. Anything else is a path-traversal
               waiting to happen, and ids are typed by hand. */
            throw new Refused("id may contain only letters, digits, dot, dash and "
                    + "underscore, 3-80 characters");
        }
        if (policyIds.contains(id)) {
            throw new Refused("'" + id + "' ships in the WAR. Rules there change "
                    + "by editing WEB-INF/rules and redeploying - whatever their "
                    + "lifecycle - so save this under a new id instead.");
        }
        if (!writable()) {
            throw new Refused("the draft directory is not writable: " + where());
        }

        /* Force the tier rather than trusting the payload. A client that sends
           lifecycle:"active" is either confused or hostile; either way the
           answer is the same. */
        Map<String, Object> copy = new LinkedHashMap<String, Object>(raw);
        copy.put("lifecycle", Rule.LIFECYCLE_DRAFT);
        copy.remove("autoFixable");        // drafts are never auto-applied
        copy.put("savedBy", author == null ? "" : author);
        copy.put("savedAt", Long.valueOf(System.currentTimeMillis()));

        Rule compiled = Rule.from(copy);
        if (compiled.error != null) {
            throw new Refused(compiled.error);
        }

        File tmp = new File(dir(), id + ".json.tmp");
        File dest = new File(dir(), id + ".json");
        write(tmp, Json.write(copy));
        /* Write then rename, so a reader never sees half a file. renameTo will
           not replace on some platforms, hence the delete first. */
        if (dest.exists() && !dest.delete()) {
            throw new IOException("could not replace " + dest.getName());
        }
        if (!tmp.renameTo(dest)) {
            throw new IOException("could not save " + dest.getName());
        }
        return compiled;
    }

    public static boolean delete(String id, List<String> policyIds) throws Refused {
        if (policyIds.contains(id)) {
            throw new Refused("'" + id + "' is a policy rule and is not stored here");
        }
        if (!id.matches("[A-Za-z0-9_.-]{3,80}")) {
            throw new Refused("bad id");
        }
        File f = new File(dir(), id + ".json");
        return f.isFile() && f.delete();
    }

    /* --------------------------------------------------------------- io */

    private static String read(File f) throws IOException {
        BufferedReader r = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), "UTF-8"));
        try {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) { sb.append(line).append('\n'); }
            return sb.toString();
        } finally {
            try { r.close(); } catch (IOException ignored) { /* closing */ }
        }
    }

    private static void write(File f, String text) throws IOException {
        Writer w = new OutputStreamWriter(new FileOutputStream(f), "UTF-8");
        try {
            w.write(text);
        } finally {
            try { w.close(); } catch (IOException ignored) { /* closing */ }
        }
    }
}

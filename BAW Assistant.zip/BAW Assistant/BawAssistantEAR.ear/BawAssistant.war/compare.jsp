<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BAW Assistant - Compare</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css" />
    <%--
      A JSP for one reason: client JavaScript cannot know its own context root.
      Everything below is static. See the baw-websphere-webapp skill.
    --%>
    <script>
        var config = {
            contextPath: '${pageContext.request.contextPath}',
            remoteUser:  '${pageContext.request.remoteUser}'
        };
    </script>
</head>
<body>
    <a class="skip" href="#main">Skip to main content</a>
    <header class="shell">
        <a class="shell-brand" href="${pageContext.request.contextPath}/">
            <b>BAW</b><span>Assistant</span>
        </a>
        <nav class="shell-nav" aria-label="Tools">
            <a href="${pageContext.request.contextPath}/">Live</a>
            <a href="${pageContext.request.contextPath}/review.jsp">Review</a>
            <a href="${pageContext.request.contextPath}/compare.jsp" aria-current="page">Compare</a>
            <a href="${pageContext.request.contextPath}/rules.jsp">Rules</a>
            <a href="${pageContext.request.contextPath}/tester.jsp">Tester</a>
            <a href="${pageContext.request.contextPath}/probe.jsp">Probe</a>
        </nav>
        <div class="shell-meta">${pageContext.request.remoteUser}</div>
    </header>

    <header class="masthead">
        <div class="wrap wide">
            <nav class="crumbs" aria-label="Breadcrumb">
                <a href="${pageContext.request.contextPath}/">Assistant</a>
                <span class="sep">/</span>
                <span aria-current="page">Compare snapshots</span>
            </nav>
            <div class="eyebrow">Snapshot comparison</div>
            <h1>What changed, and what it costs</h1>
            <p class="lede">
                Compare a track against a snapshot - or two snapshots against each
                other - and see which artifacts moved, what findings that
                introduced, and what it fixed. Read-only, like everything else
                here.
            </p>
        </div>
    </header>

    <main class="wrap wide" id="main">
        <section class="panel">
            <div class="panel-head">
                <h2>Choose</h2>
                <span id="status" class="status">loading applications...</span>
            </div>
            <div class="row">
                <label class="lbl" for="app">Application</label>
                <select id="app" class="input"><option>loading...</option></select>
            </div>
            <div class="row">
                <label class="lbl" for="base">Baseline</label>
                <select id="base" class="input"></select>
                <label class="lbl" for="target">Compared with</label>
                <select id="target" class="input"></select>
            </div>
            <div class="row">
                <button id="run" class="btn primary" disabled>Compare</button>
                <span id="progress" class="muted"></span>
            </div>
            <p class="muted" style="margin-top:10px">
                The baseline is usually the snapshot that was deployed; the
                comparison is usually the track you are working on. Reading two
                whole applications takes a moment - every artifact is fetched
                once per side.
            </p>
        </section>

        <section class="panel" id="summaryPanel" style="display:none">
            <div class="panel-head"><h2>Summary</h2></div>
            <dl id="summary" class="env"></dl>
        </section>

        <section class="panel" id="resultsPanel" style="display:none">
            <div class="panel-head">
                <h2>Artifacts</h2>
                <span id="resultCount" class="status"></span>
            </div>
            <div id="results" class="checks"></div>
        </section>

    
        <footer class="foot">
            <span>BAW Assistant</span>
            <span class="sep">&middot;</span>
            <a href="${pageContext.request.contextPath}/">Back to live linting</a>
        </footer>
    </main>

    <script src="${pageContext.request.contextPath}/js/bridge.js"></script>
    <script src="${pageContext.request.contextPath}/js/compare.js"></script>
</body>
</html>

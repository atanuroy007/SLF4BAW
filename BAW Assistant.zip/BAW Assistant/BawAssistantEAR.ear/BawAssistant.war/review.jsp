<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BAW Assistant - Application review</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css" />
    <script>
        var config = {
            contextPath: '${pageContext.request.contextPath}',
            remoteUser:  '${pageContext.request.remoteUser}'
        };
    </script>
</head>
<body class="app">
    <a class="skip" href="#main">Skip to main content</a>
    <header class="shell">
        <a class="shell-brand" href="${pageContext.request.contextPath}/">
            <b>BAW</b><span>Assistant</span>
        </a>
        <nav class="shell-nav" aria-label="Tools">
            <a href="${pageContext.request.contextPath}/">Live</a>
            <a href="${pageContext.request.contextPath}/review.jsp" aria-current="page">Review</a>
            <a href="${pageContext.request.contextPath}/compare.jsp">Compare</a>
            <a href="${pageContext.request.contextPath}/rules.jsp">Rules</a>
            <a href="${pageContext.request.contextPath}/tester.jsp">Tester</a>
            <a href="${pageContext.request.contextPath}/probe.jsp">Probe</a>
        </nav>
        <div class="shell-meta">${pageContext.request.remoteUser}</div>
    </header>

    <%--
      A CONSOLE, not a report.

      This page was a 10,154px scrolling document: choose, then summary, then
      inventory, then 55 to 172 findings, then duplication, then the checklist.
      That is the shape of a printout and the wrong shape for the job. A
      reviewer triages several hundred findings and decides what matters, and a
      document makes them scroll between the number, the finding and the
      evidence, losing their place at every step.

      So: one screen that does not scroll, with three regions that scroll
      independently - the facets that narrow, the list that is narrowed, and
      the detail of whatever is selected. Everything else - the summary, the
      inventory, the duplication, the questions no machine settles - becomes a
      VIEW rather than another thousand pixels below the fold.

      Nothing about the sweep changed. run(), judge() and duplicates() are
      untouched; this is the presentation of what they already produce.
    --%>
    <main class="console" id="main">
        <%-- The chooser carries the visible H1 until it collapses, and
             after that the screen had no H1 and started at H3. --%>
        <h1 class="sr-only">Application review</h1>

        <section class="setup" id="setup">
            <div class="setup-in">
                <h1>Review a whole application</h1>
                <p class="lede">
                    Pick a process app or a toolkit, choose the track you are working
                    on or a snapshot that was deployed, and press Analyse. Every
                    artifact is read live over REST at that container ref and put
                    through every automated rule. Read-only: nothing is exported,
                    nothing is written.
                </p>
                <div class="setup-row">
                    <span class="field">
                        <label for="kind">Kind</label>
                        <select id="kind" class="input">
                            <option value="app">Process app</option>
                            <option value="toolkit">Toolkit</option>
                        </select>
                    </span>
                    <span class="field grow">
                        <label for="container">Name</label>
                        <select id="container" class="input"><option>loading...</option></select>
                    </span>
                    <span class="field grow">
                        <label for="ref">Read at</label>
                        <select id="ref" class="input"></select>
                    </span>
                    <button id="run" class="btn primary lg" disabled>Analyse</button>
                </div>
                <div class="progress" id="bar" style="display:none"><i></i></div>
                <p class="muted setup-hint" id="hint">
                    Each artifact is a separate read. Measured at about
                    <strong>twelve seconds for 218 artifacts</strong>; a very large
                    application has not been timed yet.
                </p>
                <span id="status" class="status" aria-live="polite">loading applications...</span>
            </div>
        </section>

        <div class="topbar" id="topbar" style="display:none">
            <span class="topbar-what" id="what"></span>
            <span id="scanned" class="topbar-scanned" aria-live="polite"></span>
            <span class="cmd-sp"></span>
            <button id="exportCsv" class="btn sm" type="button">Export CSV</button>
            <button id="printReport" class="btn sm" type="button">Print</button>
            <button id="again" class="btn sm" type="button">Re-analyse</button>
        </div>

        <div class="views" id="views" role="tablist" aria-label="Report views" style="display:none">
            <button class="view" type="button" role="tab" data-view="findings" aria-controls="workFindings"
                    aria-selected="true">Findings <span class="n" id="vFindings"></span></button>
            <button class="view" type="button" role="tab" data-view="overview" aria-controls="workOverview"
                    aria-selected="false">Overview</button>
            <button class="view" type="button" role="tab" data-view="artifacts" aria-controls="workArtifacts"
                    aria-selected="false">Artifacts <span class="n" id="vArtifacts"></span></button>
            <button class="view" type="button" role="tab" data-view="dup" aria-controls="workDup"
                    aria-selected="false">Duplication <span class="n" id="vDup"></span></button>
            <button class="view" type="button" role="tab" data-view="manual" aria-controls="workManual"
                    aria-selected="false">Checklist <span class="n" id="vManual"></span></button>
        </div>

        <div class="console-body" id="workFindings" role="tabpanel" tabindex="0"
             aria-label="Findings" style="display:none">

            <aside class="facets" aria-label="Filters">
                <div class="facet-search">
                    <label class="sr-only" for="qSymptom">Search symptoms</label>
                    <input id="qSymptom" class="input" type="search" placeholder="Search symptom" />
                    <label class="sr-only" for="qArtifact">Search artifacts</label>
                    <input id="qArtifact" class="input" type="search" placeholder="Search artifact" />
                </div>

                <div class="facet-h">Severity</div>
                <div class="tabs" id="tabs" role="group" aria-label="Filter by severity"></div>

                <div class="facet-h">Category</div>
                <div class="chips" id="chips"></div>

                <div class="facet-h">View</div>
                <div class="facet-controls">
                    <span class="facet">
                        <label for="groupBy">Group by</label>
                        <select id="groupBy">
                            <option value="rule">Rule</option>
                            <option value="artifact">Artifact</option>
                        </select>
                    </span>
                    <span class="facet">
                        <label for="sortBy">Sort</label>
                        <select id="sortBy">
                            <option value="severity">Worst first</option>
                            <option value="count">Most findings</option>
                            <option value="name">Name</option>
                        </select>
                    </span>
                    <button id="reset" class="btn sm" type="button">Clear filters</button>
                </div>
            </aside>

            <section class="listpane" aria-label="Findings">
                <div class="listpane-head">
                    <span id="shown" class="cmd-count" aria-live="polite"></span>
                    <span class="cmd-sp"></span>
                    <span class="kbd-hint" id="colHint" aria-hidden="true">findings / artifacts</span>
                    <span class="kbd-hint" aria-hidden="true">&uarr;&darr; to move</span>
                </div>
                <div id="findings" class="rows" tabindex="0" role="listbox" aria-label="Findings"></div>
            </section>

            <%-- The evidence, beside the list instead of underneath the row. An
                 accordion made the reader lose their place in a list of 55
                 every time they opened one. --%>
            <aside class="detailpane" id="detail" aria-live="polite" aria-label="Detail"></aside>
        </div>

        <div class="pane" id="workOverview" role="tabpanel" tabindex="0"
             aria-label="Overview" style="display:none">
            <div class="pane-in">
                <h2 class="pane-h">Findings by severity</h2>
                <div class="tiles" id="tiles"></div>
                <h2 class="pane-h">By category</h2>
                <div class="tiles" id="categories"></div>
            </div>
        </div>

        <div class="pane" id="workArtifacts" role="tabpanel" tabindex="0"
             aria-label="Artifacts" style="display:none">
            <div class="pane-in">
                <h2 class="pane-h">What was read <span id="invCount" class="muted"></span></h2>
                <div class="inv" id="inventory"></div>
                <details class="fold" id="unreadableFold" style="display:none">
                    <summary id="unreadableSummary"></summary>
                    <div class="inv" id="unreadable"></div>
                    <p class="muted">
                        These are listed by the server but the readers do not
                        recognise their model, so no rule ran against them. They are
                        named here rather than left out, because a report that omits
                        what it could not read presents a partial sweep as a
                        complete one.
                    </p>
                </details>
            </div>
        </div>

        <div class="pane" id="workDup" role="tabpanel" tabindex="0"
             aria-label="Dup" style="display:none">
            <div class="pane-in">
                <h2 class="pane-h">Duplicated code <span id="dupCount" class="muted"></span></h2>
                <div id="dupes"></div>
                <p class="muted">
                    Identical code, whitespace aside, in more than one place. This is
                    not a rule and could not be: every rule kind judges one thing in
                    isolation, and duplication is a property of a set. It also
                    distorts every other count here - three copies of a control
                    triple every finding inside it.
                </p>
            </div>
        </div>

        <div class="pane" id="workManual" role="tabpanel" tabindex="0"
             aria-label="Manual" style="display:none">
            <div class="pane-in">
                <h2 class="pane-h">What the engine did not ask
                    <span id="manualCount" class="muted"></span></h2>
                <p class="muted" style="margin-top:0;max-width:78ch">
                    The checklist rows no machine settles. Each question appears
                    once, however many artifact types ask it, with the types it
                    covers beside it - the workbook's General rows apply to
                    everything, and listing them per type turns 67 questions into
                    430 rows. Without this a report of automated findings alone
                    reads as a passed review.
                </p>
                <div id="manual"></div>
            </div>
        </div>
    </main>

    <script src="${pageContext.request.contextPath}/js/bridge.js"></script>
    <%-- findings.js before review.js: the report reads window.BawFindings for
         severity order, filtering and grouping - the same module the docked
         panel uses, so the two cannot disagree about what a finding means. --%>
    <script src="${pageContext.request.contextPath}/js/findings.js"></script>
    <script src="${pageContext.request.contextPath}/js/review.js"></script>
</body>
</html>

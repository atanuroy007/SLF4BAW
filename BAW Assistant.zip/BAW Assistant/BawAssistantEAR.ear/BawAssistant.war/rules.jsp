<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Rule Manager</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css" />
    <%--
      Same JSP-for-one-reason as the other pages: client JavaScript cannot know
      its own context root.
    --%>
    <script>
        var config = {
            contextPath: '${pageContext.request.contextPath}',
            remoteUser:  '${pageContext.request.remoteUser}'
        };
    </script>
    <style>
        /* Manager-only layout. Everything shared lives in app.css, and every
           value here comes from knowledge/design/carbon-tokens.md through the
           custom properties app.css defines - so this block follows the theme
           into dark mode instead of staying light. */
        /* The LIST gets the larger share. It was 2fr against the editor's 3fr,
           so browsing 175 rules happened in the narrower half of the page while
           an empty "New rule" box held the wider one. */
        .rm { display: grid; grid-template-columns: minmax(380px, 3fr) minmax(0, 2fr); gap: var(--s5); align-items: start; }
        @media (max-width: 900px) { .rm { grid-template-columns: 1fr; } }

        .rm-filters { margin-bottom: var(--s4); }
        .rm-search { margin-bottom: var(--s3); }
        .rm-search input { width: 100%; }
        .rm-facets { display: flex; flex-wrap: wrap; gap: var(--s4); }
        .facet { display: inline-flex; align-items: center; gap: var(--s2); }
        .facet label { font-size: 12px; color: var(--ink-3); }
        .rm-filters select, .rm-filters input {
            font: inherit; font-size: 12px; padding: var(--s2) var(--s3);
            border: 0; border-bottom: 1px solid var(--line-strong); border-radius: 0;
            background: var(--surface-2); color: var(--ink);
        }
        .rm-filters select:focus, .rm-filters input:focus {
            outline: 2px solid var(--accent); outline-offset: -2px;
        }

        .rm-list {
            max-height: 68vh; overflow: auto;
            border: 1px solid var(--line); border-radius: 0;
        }
        .rm-row {
            padding: var(--s3) var(--s4); border-bottom: 1px solid var(--line);
            cursor: pointer; border-left: 3px solid transparent;
        }
        .rm-row:last-child { border-bottom: 0; }
        .rm-row:hover { background: var(--hover); }
        .rm-row.sel { background: var(--surface-2); border-left-color: var(--accent); }
        /* Severity in the ENGINE's rank order - critical, major, minor,
           warning - so this agrees with the panel and with
           Rule.severityRank. It used to give critical and major the same red
           and colour warning louder than minor. */
        .rm-row.critical { border-left-color: var(--sev-critical); }
        .rm-row.major    { border-left-color: var(--sev-major-ink); }
        .rm-row.minor    { border-left-color: var(--sev-minor-ink); }
        .rm-row.warning  { border-left-color: var(--sev-warning); }
        .rm-row.sel.critical, .rm-row.sel.major,
        .rm-row.sel.minor, .rm-row.sel.warning { border-left-color: var(--accent); }

        .rm-id { font-family: var(--mono); font-size: 12px; }
        .rm-meta {
            font-family: var(--mono);
            font-size: 12px; color: var(--ink-3); margin-top: var(--s1);
        }
        /* Carbon draws a tag as a pill - the one radius in the product. */
        .rm-tag {
            display: inline-block; font-size: 12px; letter-spacing: .02em;
            padding: 0 var(--s3); border-radius: 12px; margin-right: var(--s2);
            border: 1px solid transparent;
        }
        .rm-tag.draft  { background: var(--surface-2); color: var(--ink-2);
                         border-color: var(--line-strong); }
        .rm-tag.policy { background: var(--accent); color: #fff; }
        .rm-tag.ok     { background: var(--surface-2); color: var(--pass);
                         border-color: var(--pass); }
        .rm-tag.bad    { background: var(--surface-2); color: var(--fail);
                         border-color: var(--fail); }

        .rm-form label {
            display: block; font-family: var(--sans);
            font-size: 12px; letter-spacing: .02em;
            color: var(--ink-3); margin: var(--s4) 0 var(--s2);
        }
        .rm-form input, .rm-form select, .rm-form textarea {
            width: 100%; font: inherit; font-size: 13px;
            padding: var(--s3) var(--s4);
            border: 0; border-bottom: 1px solid var(--line-strong); border-radius: 0;
            box-sizing: border-box; background: var(--surface-2); color: var(--ink);
        }
        .rm-form input:focus, .rm-form select:focus, .rm-form textarea:focus {
            outline: 2px solid var(--accent); outline-offset: -2px;
        }
        .rm-form textarea {
            font-family: var(--mono); font-size: 12px;
            resize: vertical; line-height: 1.5;
        }
        .rm-form input:disabled, .rm-form textarea:disabled, .rm-form select:disabled {
            background: var(--bg); color: var(--ink-3);
            border-bottom-style: dotted;
        }
        .rm-two { display: flex; gap: var(--s3); }
        .rm-two > div { flex: 1; }
        .rm-actions { display: flex; gap: var(--s3); flex-wrap: wrap; margin-top: var(--s4); }
    </style>
</head>
<body>
    <a class="skip" href="#main">Skip to main content</a>
    <header class="shell">
        <a class="shell-brand" href="${pageContext.request.contextPath}/">
            <b>BAW</b><span>Assistant</span>
        </a>
        <nav class="shell-nav" aria-label="Tools">
            <a href="${pageContext.request.contextPath}/">Live</a>
            <a href="${pageContext.request.contextPath}/review.jsp">Review</a>
            <a href="${pageContext.request.contextPath}/compare.jsp">Compare</a>
            <a href="${pageContext.request.contextPath}/rules.jsp" aria-current="page">Rules</a>
            <a href="${pageContext.request.contextPath}/tester.jsp">Tester</a>
            <a href="${pageContext.request.contextPath}/probe.jsp">Probe</a>
        </nav>
        <div class="shell-meta">${pageContext.request.remoteUser}</div>
    </header>

    <header class="masthead">
        <div class="wrap wide">
            <nav class="crumbs" aria-label="Breadcrumb">
                <a href="${pageContext.request.contextPath}/">Assistant</a>
                <span class="sep">/</span>
                <span aria-current="page">Rule manager</span>
            </nav>
            <div class="eyebrow">Rule manager</div>
            <h1>Every rule, and whether it has earned its place</h1>
            <p class="lede">
                Browse and edit the rule set away from any one artifact. Policy rules
                are read-only here &mdash; they change by editing the WAR and
                redeploying, which is what makes them reviewable. Drafts can be
                written, and become policy by export, commit and redeploy.
            </p>
        </div>
    </header>

    <main class="wrap wide" id="main">
        <div id="summary" class="status">Loading rules&hellip;</div>

        <div class="rm">
            <div class="panel">
                <div class="panel-head"><h2>Rules</h2><span id="count" class="muted"></span></div>
                <%-- Search on its own row, then the three axes labelled.
                     They were four controls wrapping into each other with the
                     search box squeezed to about twelve characters - on a page
                     whose whole job is finding one rule among 175. Every
                     control keeps its id, so rules.js is untouched. --%>
                <div class="rm-filters">
                    <div class="rm-search">
                        <label class="sr-only" for="q">Search rules</label>
                        <input id="q" type="text" autocomplete="off" spellcheck="false"
                               placeholder="Search id, name or checklist cell" />
                    </div>
                    <div class="rm-facets">
                        <span class="facet">
                            <label for="fKind">Kind</label>
                            <select id="fKind">
                                <option value="">any</option>
                                <option value="buffer">buffer</option>
                                <option value="artifact">artifact</option>
                            </select>
                        </span>
                        <span class="facet">
                            <label for="fLife">Tier</label>
                            <select id="fLife">
                                <option value="">any</option>
                                <option value="active">policy</option>
                                <option value="draft">draft</option>
                            </select>
                        </span>
                        <span class="facet">
                            <label for="fSev">Severity</label>
                            <select id="fSev">
                                <option value="">any</option>
                                <option value="critical">critical</option>
                                <option value="major">major</option>
                                <option value="minor">minor</option>
                                <option value="warning">warning</option>
                            </select>
                        </span>
                    </div>
                </div>
                <div id="list" class="rm-list"></div>
            </div>

            <div class="panel">
                <div class="panel-head">
                    <h2 id="editorTitle">New rule</h2>
                    <span id="editorState" class="muted"></span>
                </div>
                <div id="editor" class="rm-form"></div>
                <div id="verdict"></div>
            </div>
        </div>

    
        <footer class="foot">
            <span>BAW Assistant</span>
            <span class="sep">&middot;</span>
            <a href="${pageContext.request.contextPath}/">Back to live linting</a>
        </footer>
    </main>

    <script src="${pageContext.request.contextPath}/js/rules.js"></script>
</body>
</html>

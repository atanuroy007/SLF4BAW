<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BAW Assistant</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css" />
    <%--
      A JSP for one reason: client JavaScript cannot know its own context root.
      Everything below is static. See the baw-websphere-webapp skill.
    --%>
    <script>
        var config = {
            contextPath: '${pageContext.request.contextPath}',
            remoteUser:  '${pageContext.request.remoteUser}',
            serverName:  '${pageContext.request.serverName}',
            serverPort:  '${pageContext.request.serverPort}'
        };
    </script>
</head>
<body>
    <a class="skip" href="#main">Skip to main content</a>
    <header class="shell">
        <a class="shell-brand" href="${pageContext.request.contextPath}/">
            <b>BAW</b><span>Assistant</span>
        </a>
        <nav class="shell-nav" aria-label="Tools">
            <a href="${pageContext.request.contextPath}/" aria-current="page">Live</a>
            <a href="${pageContext.request.contextPath}/review.jsp">Review</a>
            <a href="${pageContext.request.contextPath}/compare.jsp">Compare</a>
            <a href="${pageContext.request.contextPath}/rules.jsp">Rules</a>
            <a href="${pageContext.request.contextPath}/tester.jsp">Tester</a>
            <a href="${pageContext.request.contextPath}/probe.jsp">Probe</a>
        </nav>
        <div class="shell-meta">${pageContext.request.remoteUser}</div>
    </header>

    <header class="masthead">
        <div class="wrap work">
            <h1>Review as you type, in your own editor</h1>
            <p class="lede">
                Open Process Designer from here. The assistant reads the surface you
                are editing, lints it, and draws the findings in Designer's own
                gutter. It never writes to an artifact.
            </p>
        </div>
    </header>

    <main class="wrap work" id="main">
      <div class="workspace">
       <div class="col-main">
        <section class="panel">
            <div class="panel-head">
                <h2>Connect</h2>
                <span id="brainStatus" class="status">checking...</span>
            </div>
            <%-- A real label, not a placeholder. A placeholder disappears the
                 moment someone types, so a field labelled only by one is
                 unlabelled exactly when the value needs checking - and this
                 value is a GUID nobody remembers. --%>
            <div class="row" style="align-items:flex-end">
                <div class="field">
                    <label for="branchRef">Container reference</label>
                    <input id="branchRef" class="input" placeholder="2063.abc-123..."
                           spellcheck="false" autocomplete="off"
                           aria-describedby="refHelp" />
                    <span class="helper" id="refHelp">
                        The <code>2063.&lt;guid&gt;</code> from Designer's own URL. A
                        snapshot ref works here too.
                    </span>
                </div>
                <button id="launch" class="btn primary lg">Open Designer</button>
            </div>

            <%-- Development plumbing, folded away. It was sitting at the same
                 weight as the one field that matters, on the page a developer
                 opens every morning. --%>
            <details class="fold" style="margin-top:var(--s5)">
                <summary>Advanced</summary>
                <div class="row">
                    <div class="field">
                        <label for="brainUrl">Rule engine API</label>
                        <input id="brainUrl" class="input"
                               placeholder="same origin (leave blank)"
                               aria-describedby="apiHelp" />
                        <span class="helper" id="apiHelp">
                            Only needed to point at an engine on another server during
                            development. Leave blank in normal use.
                        </span>
                    </div>
                </div>
            </details>
        </section>

        <section class="panel">
            <div class="panel-head">
                <h2>Live</h2>
                <div class="row" style="margin:0">
                    <button id="watch" class="btn primary" disabled>Watch</button>
                    <button id="stop" class="btn" disabled>Stop</button>
                    <button id="lintOnce" class="btn" disabled
                            title="Re-read the artifact and re-lint the open script, ignoring any cache">Validate now</button>
                    <button id="dock" class="btn" disabled>Re-dock panel</button>
                </div>
            </div>
            <div id="status" class="status">Open Designer to start linting.</div>
            <%-- Why the buttons above are dead. A disabled control with no
                 stated reason is a dead end: the developer cannot tell whether
                 the feature is broken, unavailable, or waiting on them. --%>
            <p class="muted" id="liveHint" style="margin-top:var(--s4);font-size:13px">
                These become available once Designer is open. <strong>Watch</strong> lints
                the code surface you are editing as you type and draws findings in
                Designer's own gutter; artifact checks &mdash; signature size, step
                count &mdash; run on their own as soon as an artifact is open.
            </p>
            <dl id="ctx" class="env" style="margin-top:12px"></dl>
        </section>

        <section class="panel">
            <%-- "Show" lives here, beside what it filters. It used to sit in
                 Connect, two panels away from the list it governs, which read
                 as a connection setting rather than a view control. --%>
            <div class="panel-head">
                <h2>Findings</h2>
                <label class="lbl" for="minSev">Show</label>
                <select id="minSev" class="input" style="max-width:180px;flex:none;min-width:0">
                    <option value="critical">critical only</option>
                    <option value="major">major and above</option>
                    <option value="minor">minor and above</option>
                    <option value="warning">everything</option>
                </select>
            </div>
            <div id="findings" class="checks">
                <%-- A worked example, not a placeholder. The characteristic
                     thing this product does is draw a finding against a line
                     of code in Designer's own gutter, and the page said so in
                     prose while showing an empty box. This is what one looks
                     like; hub.js replaces the whole of #findings as soon as
                     there are real ones. --%>
                <div class="example" aria-hidden="true">
                    <div class="example-h">What a finding looks like</div>
                    <div class="example-code">
                        <span class="ln">31</span>
                        <span class="mark critical"></span>
                        <code>var pwd = "S3cr3t!";</code>
                    </div>
                    <div class="check critical">
                        <div class="check-head">
                            <span class="pill critical">CRITICAL</span>
                            <strong>Line 31</strong>
                            <span>Literal credential assigned to pwd</span>
                        </div>
                        <div class="why">A literal credential is readable by
                            anyone with Designer access and travels into every
                            snapshot. Move it to an environment variable set and
                            rotate the value that was committed.</div>
                    </div>
                </div>
            </div>
        </section>
       </div>

       <%-- The other tools, beside the work rather than under it. The shell
            above is the global navigation; this says what each one is FOR,
            which a one-word nav item cannot. Sticky, so it is still there when
            the findings list has grown past a screen. --%>
       <aside class="col-side" aria-labelledby="tools-h">
           <div class="side-h" id="tools-h">Review more than one file</div>
           <div class="tiles-side">
               <a class="tile-link compact" href="${pageContext.request.contextPath}/review.jsp">
                   <h3>Review an application</h3>
                   <p>Every artifact at a track or snapshot, through every automated
                      rule. Around twelve seconds for a couple of hundred.</p>
                   <span class="go">Analyse</span>
               </a>
               <a class="tile-link compact" href="${pageContext.request.contextPath}/compare.jsp">
                   <h3>Compare snapshots</h3>
                   <p>What moved, what it introduced and what it fixed, ranked by
                      what it broke.</p>
                   <span class="go">Compare</span>
               </a>
               <a class="tile-link compact" href="${pageContext.request.contextPath}/rules.jsp">
                   <h3>Rule manager</h3>
                   <p>Every rule and whether it has earned its place. Policy is
                      read-only; drafts can be written.</p>
                   <span class="go">Browse</span>
               </a>
               <a class="tile-link compact" href="${pageContext.request.contextPath}/tester.jsp">
                   <h3>Rule tester</h3>
                   <p>Try a rule against a live artifact before it becomes policy.</p>
                   <span class="go">Try one</span>
               </a>
               <a class="tile-link compact" href="${pageContext.request.contextPath}/probe.jsp">
                   <h3>Co-deployment probe</h3>
                   <p>Seven checks proving the assistant can live beside Designer
                      on this server.</p>
                   <span class="go">Run checks</span>
               </a>
           </div>
       </aside>
      </div>

        <footer class="foot">
            <span>BAW Assistant</span>
            <span class="sep">&middot;</span>
            <span>Read-only, except a repair you explicitly apply</span>
            <span class="sep">&middot;</span>
            <span class="mono">${pageContext.request.serverName}:${pageContext.request.serverPort}</span>
        </footer>
    </main>

    <script src="${pageContext.request.contextPath}/js/bridge.js"></script>
    <%-- findings.js before hub.js: hub.js reads window.BawFindings while its
         own state literal is being built, so load order is load-bearing here,
         not a convention. --%>
    <script src="${pageContext.request.contextPath}/js/findings.js"></script>
    <script src="${pageContext.request.contextPath}/js/hub.js"></script>
</body>
</html>

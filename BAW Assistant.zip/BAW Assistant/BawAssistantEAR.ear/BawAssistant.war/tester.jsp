<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Rule Tester</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css" />
    <%--
      Same JSP-for-one-reason as index.jsp: client JavaScript cannot know its
      own context root. Everything else here is static.
    --%>
    <script>
        var config = {
            contextPath: '${pageContext.request.contextPath}',
            remoteUser:  '${pageContext.request.remoteUser}',
            serverName:  '${pageContext.request.serverName}',
            serverPort:  '${pageContext.request.serverPort}'
        };
    </script>
</head>
<body>
    <a class="skip" href="#main">Skip to main content</a>
    <header class="shell">
        <a class="shell-brand" href="${pageContext.request.contextPath}/">
            <b>BAW</b><span>Assistant</span>
        </a>
        <nav class="shell-nav" aria-label="Tools">
            <a href="${pageContext.request.contextPath}/">Live</a>
            <a href="${pageContext.request.contextPath}/review.jsp">Review</a>
            <a href="${pageContext.request.contextPath}/compare.jsp">Compare</a>
            <a href="${pageContext.request.contextPath}/rules.jsp">Rules</a>
            <a href="${pageContext.request.contextPath}/tester.jsp" aria-current="page">Tester</a>
            <a href="${pageContext.request.contextPath}/probe.jsp">Probe</a>
        </nav>
        <div class="shell-meta">${pageContext.request.remoteUser}</div>
    </header>

    <header class="masthead">
        <div class="wrap">
            <nav class="crumbs" aria-label="Breadcrumb">
                <a href="${pageContext.request.contextPath}/">Assistant</a>
                <span class="sep">/</span>
                <span aria-current="page">Rule tester</span>
            </nav>
            <div class="eyebrow">Rule tester</div>
            <h1>Try a rule on real code before it becomes policy</h1>
            <p class="lede">
                Opens Process Designer and docks the rule tester in place of the
                assistant. Pick a rule or write one, run it against the artifact
                you are looking at, and see exactly where it lands in the gutter.
                Nothing is saved and no rule is changed until you say so.
            </p>
        </div>
    </header>

    <main class="wrap" id="main">
        <div class="card">
            <div class="card-head">
                <h2>Connect</h2>
                <div id="brainStatus" class="status">Checking the rule engine&hellip;</div>
            </div>
            <div class="row">
                <input id="branchRef" type="text" placeholder="containerRef, e.g. 2063.abc-123&hellip;" />
                <button id="launch" class="btn primary">Open Designer</button>
            </div>
            <p class="muted">
                The containerRef is the <code>2063.&lt;guid&gt;</code> in Designer's own URL.
                A snapshot ref (<code>2064.&lt;guid&gt;</code>) works too, and opens read-only.
            </p>
        </div>

        <div class="card">
            <div class="card-head">
                <h2>Live</h2>
                <div class="row" style="margin:0">
                    <button id="dock" class="btn" disabled>Re-dock tester</button>
                    <button id="undock" class="btn" disabled>Remove panel</button>
                </div>
            </div>
            <div id="status" class="status">Not connected.</div>
            <dl id="ctx" class="ctx"></dl>
            <p class="muted">
                The tester panel docks inside Designer, where the artifact is.
                Everything below is a mirror of what it shows.
            </p>
        </div>

        <div class="card">
            <h2>Last run</h2>
            <div id="results"><div class="muted">Nothing tried yet.</div></div>
        </div>

        <p class="muted">
            Back to the <a href="${pageContext.request.contextPath}/">assistant</a>.
        </p>
    
        <footer class="foot">
            <span>BAW Assistant</span>
            <span class="sep">&middot;</span>
            <a href="${pageContext.request.contextPath}/">Back to live linting</a>
        </footer>
    </main>

    <script src="${pageContext.request.contextPath}/js/bridge.js"></script>
    <script src="${pageContext.request.contextPath}/js/tester.js"></script>
</body>
</html>

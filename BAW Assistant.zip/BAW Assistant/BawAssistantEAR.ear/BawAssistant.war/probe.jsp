<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>BAW Assistant - co-deployment probe</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css" />
    <%--
      This page is a JSP for exactly one reason: client JavaScript cannot know
      its own context root, and hardcoding it breaks the moment the app is
      deployed under a different one. Everything else here is static.

      If you see the literal ${pageContext.request.contextPath} in view-source
      below, the JSP was served as a static file and nothing else will work.
    --%>
    <script>
        var config = {
            contextPath: '${pageContext.request.contextPath}',
            remoteUser:  '${pageContext.request.remoteUser}',
            serverName:  '${pageContext.request.serverName}',
            serverPort:  '${pageContext.request.serverPort}',
            scheme:      '${pageContext.request.scheme}'
        };
    </script>
</head>
<body>
    <a class="skip" href="#main">Skip to main content</a>
    <header class="shell">
        <a class="shell-brand" href="${pageContext.request.contextPath}/">
            <b>BAW</b><span>Assistant</span>
        </a>
        <nav class="shell-nav" aria-label="Tools">
            <a href="${pageContext.request.contextPath}/">Live</a>
            <a href="${pageContext.request.contextPath}/review.jsp">Review</a>
            <a href="${pageContext.request.contextPath}/compare.jsp">Compare</a>
            <a href="${pageContext.request.contextPath}/rules.jsp">Rules</a>
            <a href="${pageContext.request.contextPath}/tester.jsp">Tester</a>
            <a href="${pageContext.request.contextPath}/probe.jsp" aria-current="page">Probe</a>
        </nav>
        <div class="shell-meta">${pageContext.request.remoteUser}</div>
    </header>

    <header class="masthead">
        <div class="wrap">
            <nav class="crumbs" aria-label="Breadcrumb">
                <a href="${pageContext.request.contextPath}/">Assistant</a>
                <span class="sep">/</span>
                <span aria-current="page">Co-deployment probe</span>
            </nav>
            <div class="eyebrow">Co-deployment probe</div>
            <h1>Can the assistant live next to Process Designer?</h1>
            <p class="lede">
                Seven checks, in dependency order. Each one proves the assumption the
                next depends on, so the first failure is the one worth fixing.
            </p>
        </div>
    </header>

    <main class="wrap" id="main">
        <section class="panel">
            <div class="panel-head">
                <h2>Environment</h2>
                <button id="rerun" class="btn">Re-run checks</button>
            </div>
            <dl id="env" class="env"></dl>
        </section>

        <section class="panel">
            <div class="panel-head">
                <h2>Checks</h2>
                <span id="score" class="score"></span>
            </div>
            <ol id="checks" class="checks"></ol>
        </section>

        <section class="panel">
            <div class="panel-head"><h2>Designer access</h2></div>
            <p class="muted">
                Paste a branch reference (<code>2063.&lt;guid&gt;</code>, visible in the Designer's
                own URL) and press <strong>Re-run checks</strong> - the session check pulls
                real data once it has one. The later checks additionally need a Designer
                window that <em>this page</em> opened: same origin lets us reach in, but
                only into a window we created.
            </p>
            <div class="row">
                <input id="branchRef" class="input" placeholder="containerRef, e.g. 2063.abc-123..." />
                <button id="openDesigner" class="btn primary">Open Designer</button>
                <button id="probeDesigner" class="btn" disabled>Probe it</button>
                <button id="probeAnnotations" class="btn" disabled>Probe annotations</button>
                <button id="tryAnnotation" class="btn" disabled>Draw a test marker</button>
                <button id="orionProbe" class="btn" disabled>Orion annotation test</button>
            </div>
            <pre id="designerOut" class="out" hidden></pre>
        </section>

        <section class="panel">
            <div class="panel-head"><h2>Verdict</h2></div>
            <div id="verdict" class="verdict muted">Run the checks to see a verdict.</div>
        </section>
    
        <footer class="foot">
            <span>BAW Assistant</span>
            <span class="sep">&middot;</span>
            <a href="${pageContext.request.contextPath}/">Back to live linting</a>
        </footer>
    </main>

    <script src="${pageContext.request.contextPath}/js/app.js"></script>
</body>
</html>

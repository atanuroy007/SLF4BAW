/* The hub: opens Process Designer, watches what the developer types, lints it,
 * and draws the findings in their own editor.
 *
 * Division of labour:
 *   bridge.js  knows Designer internals (Orion, dijit, the code surfaces)
 *   hub.js     knows artifacts, findings and the rule engine
 *
 * The rule engine is a servlet in this same WAR, so every call is same-origin:
 * no CORS, and the Designer's own CSP (connect-src 'self') is satisfied without
 * argument. That last point is not cosmetic - a fetch issued from inside the
 * Designer's realm is blocked outright, which is why this file, running in the
 * hub's realm, is the one that talks to the server.
 *
 * The API field exists only to point at a service elsewhere during development.
 * Left blank, everything resolves against this application's context path.
 */
(function () {
    'use strict';

    var $ = function (id) { return document.getElementById(id); };
    var B = window.BawBridge;
    /* Severity order, filtering, counting and stable identity live in
       findings.js, because the whole-application review asks the same
       questions of the same data and a second copy would drift. */
    var F = window.BawFindings;

    var state = {
        // Same-origin by construction - the rule engine ships in this WAR.
        // An override is kept only for pointing at a service during development.
        brain: localStorage.getItem('baw-brain') || (config.contextPath || ''),
        branchRef: localStorage.getItem('baw-probe-ref') || '',
        designer: null,
        watching: false,
        findings: [],
        artifactFindings: [],
        /* Findings from the OTHER code surfaces on screen.
         *
         * A coach component shows Title formula, On load and On icon click at
         * once, and the panel judged exactly one of them - so 1,251 characters
         * of handler sat on screen unexamined. These are linted from their own
         * live buffers, never annotated in the gutter (they point into an
         * editor that is not bound), and re-run only when the set of surfaces
         * changes rather than on every keystroke. */
        otherFindings: [],
        otherKey: null,
        /* The Designer's own validator findings, read from the shared
           annotation model. Displayed, never re-annotated - IBM already drew
           them, and writing them back would fight the validator that owns
           them. */
        designerFindings: [],
        /* The checklist rows a machine cannot settle, for the artifact type on
           screen. Fetched per type, not per artifact - they do not vary by
           instance and refetching each poll would be waste. */
        checklist: null,
        checklistType: null,
        checklistOpen: false,

        /* What the developer has adjusted in the panel.
         *
         * All of it lives here rather than in the DOM, because renderPanel
         * rebuilds the list on every poll - a collapsed group or an expanded
         * row held in the markup would spring back open twice a second.
         *
         * Font size and the two filters persist; an expanded row does not. A
         * row is opened to read one finding, and restoring that on the next
         * artifact would be clutter rather than continuity.
         */
        fontPx: window.BawFindings.clampFont(
                    localStorage.getItem('baw-panel-font'), 10, 20) || 13,
        groupsOpen: (function () {
            try {
                var v = JSON.parse(localStorage.getItem('baw-panel-groups'));
                if (v && typeof v === 'object') { return v; }
            } catch (e) { /* nothing stored, or private mode */ }
            /* Findings open, the checklist closed - the defects come first. */
            return { artifact: true, script: true, other: true, designer: true };
        }()),
        /* Empty means "no filter", so the panel opens showing everything. */
        sevFilter: [],
        catFilter: [],
        openRows: {},

        /* The code last linted, so the step it belongs to can be recovered
           from the committed model when the Designer stops saying. */
        lastBuffer: null,

        artifactModel: null,
        lastSense: null,
        minSeverity: localStorage.getItem('baw-min-sev') || 'warning',
        lastLintMs: null,

        /* Where a tick's time actually goes, in ms.
         *
         * "It takes a few minutes to validate after switching artifact" is not
         * something anyone should diagnose by reading code - the lint itself
         * runs in about fifteen milliseconds, so the time is being spent
         * somewhere else entirely. These four numbers say where: reading the
         * Designer's DOM, fetching the committed model, the engine call, and
         * painting annotations. */
        timing: { sig: null, model: null, check: null, lint: null, annotate: null }
    };

    /* Filters are restored after the literal above rather than inside it, so
       one malformed stored value cannot take the whole state object with it. */
    (function () {
        try {
            var v = JSON.parse(localStorage.getItem('baw-panel-filters'));
            if (v && Object.prototype.toString.call(v.sev) === '[object Array]') {
                state.sevFilter = v.sev;
            }
            if (v && Object.prototype.toString.call(v.cat) === '[object Array]') {
                state.catFilter = v.cat;
            }
        } catch (e) { /* nothing stored, or private mode */ }
    }());

    var now = (typeof performance !== 'undefined' && performance.now)
        ? function () { return performance.now(); }
        : function () { return Date.now(); };

    function el(tag, attrs) {
        var n = document.createElement(tag);
        attrs = attrs || {};
        Object.keys(attrs).forEach(function (k) {
            if (k === 'class') { n.className = attrs[k]; }
            else if (k === 'html') { n.innerHTML = attrs[k]; }
            else if (k.slice(0, 2) === 'on') { n.addEventListener(k.slice(2), attrs[k]); }
            else if (attrs[k] !== null && attrs[k] !== false) { n.setAttribute(k, attrs[k]); }
        });
        for (var i = 2; i < arguments.length; i++) {
            var c = arguments[i];
            if (c === null || c === undefined || c === false) { continue; }
            n.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
        }
        return n;
    }

    /* --------------------------------------------------------------- brain */

    function brainFetch(path, body) {
        var opts = { method: body ? 'POST' : 'GET', headers: {} };
        if (body) {
            opts.headers['Content-Type'] = 'application/json';
            opts.body = JSON.stringify(body);
        }
        return fetch(state.brain.replace(/\/$/, '') + path, opts).then(function (r) {
            if (!r.ok) {
                return r.json().catch(function () { return {}; }).then(function (d) {
                    throw new Error(d.detail || (r.status + ' ' + r.statusText));
                });
            }
            return r.json();
        });
    }

    function lint(code, language) {
        return brainFetch('/api/lint', {
            code: code, language: language || 'javascript',
            minSeverity: state.minSeverity
        });
    }

    /* Artifact rules - signature size, step count - are about the artifact as a
       whole, so they have no line number and never appear in the gutter. They
       belong in the panel, above the code findings. */
    function checkArtifact() {
        var tModel = now();
        return B.readArtifactModel().then(function (model) {
            /* This is the one step that can hit the network. If a switch is
               slow, expect the cost to be here, not in the engine. */
            state.timing.model = Math.round(now() - tModel);
            if (!model) { return null; }
            state.artifactModel = model;
            return brainFetch('/api/check', {
                artifact: model, minSeverity: state.minSeverity
            });
        }).then(function (r) {
            if (!r) { state.artifactFindings = []; return null; }
            state.artifactFindings = r.findings || [];
            return r;
        }).catch(function (e) {
            state.artifactFindings = [];
            setStatus('Artifact check failed: ' + e.message, 'warn');
            return null;
        });
    }

    /* The checklist for the artifact type on screen.
     *
     * Fetched once per type. The rows do not vary by instance, so refetching
     * them every poll would be waste - and the panel would flicker. */
    function loadChecklist(type) {
        if (!type || type === state.checklistType) { return Promise.resolve(); }
        state.checklistType = type;
        return brainFetch('/api/checklist?type=' + encodeURIComponent(type))
            .then(function (d) {
                state.checklist = d;
                renderPanel();
            })
            .catch(function () {
                /* Let the next tick try again. The type used to be marked
                   as loaded before the fetch resolved, so one transient
                   failure hid the review block for the rest of the session
                   - the same silent suppression as the empty-panel bug,
                   arriving by a different route. */
                state.checklist = null;
                state.checklistType = null;
            });
    }

    /* ------------------------------------------------------- Designer panel */

    /* Carbon's design language, hand-rolled.
     *
     * `knowledge/design/carbon-tokens.md` is the source for every value below,
     * and the tiebreak if this and css/app.css ever disagree. Two properties of
     * this sheet are not style choices:
     *
     *   - every class is `bawp-` prefixed, because this is injected into the
     *     DESIGNER's own document, where an unprefixed selector would fight
     *     Dojo's CSS;
     *   - every size is `em` rooted at `.bawp`, which is what makes the font
     *     control a single number - set the root and the whole panel scales,
     *     spacing included. Deliberately `em` and not a custom property, so
     *     nothing here depends on the Designer's rendering mode.
     *
     * Font sizes are changed on leaf text nodes only; containers stay at 1em so
     * their `em` padding stays root-relative instead of compounding.
     *
     * Corners are square. That is Carbon, not an oversight - the only radius in
     * the sheet is on a filter tag, which Carbon draws as a pill.
     */
    var PANEL_CSS = [
        '.bawp{font:400 13px/1.4 "IBM Plex Sans","Segoe UI",system-ui,sans-serif;',
        'height:100%;display:flex;flex-direction:column;background:#fff;color:#161616}',
        '.bawp *{box-sizing:border-box}',

        /* header */
        '.bawp-h{flex:none;padding:0.6em;border-bottom:1px solid #e0e0e0;display:flex;',
        'align-items:center;gap:0.3em;flex-wrap:wrap}',
        '.bawp-t{font-size:0.85em;font-weight:600;letter-spacing:.02em;flex:1}',

        /* A Carbon SECONDARY button: a real border and a filled hover, not the
           ghost variant. Ghost buttons were the first thing tried here and the
           controls disappeared into the header - a hairline of Gray 20 on
           white is not a button anyone can see. */
        '.bawp-b{font-family:inherit;font-size:0.85em;line-height:1.2;',
        'padding:0.4em 0.8em;min-height:2.3em;border:1px solid #8d8d8d;',
        'border-radius:0;background:#fff;color:#161616;cursor:pointer;',
        'transition:background 110ms cubic-bezier(.2,0,.38,.9)}',
        '.bawp-b:hover{background:#e5e5e5}',
        '.bawp-b:disabled{color:#a8a8a8;border-color:#e0e0e0;cursor:default;',
        'background:#fff}',
        '.bawp-b:focus{outline:2px solid #0f62fe;outline-offset:-2px}',

        /* Validate is the panel's primary action - the one thing a developer
           comes to the header to press - so it gets Carbon's primary button
           rather than sharing the secondary style with the zoom control. */
        '.bawp-b.primary{background:#0f62fe;border-color:#0f62fe;color:#fff;',
        'font-weight:600}',
        '.bawp-b.primary:hover{background:#0043ce;border-color:#0043ce}',
        '.bawp-b.primary:disabled{background:#c6c6c6;border-color:#c6c6c6;',
        'color:#fff}',

        /* Two square buttons that read as one control, with the shared border
           collapsed so it looks like a segmented pair rather than two things
           that happen to be adjacent. */
        '.bawp-fs{display:flex;flex:none}',
        '.bawp-fs .bawp-b{padding:0.4em 0.6em;font-weight:600;min-width:2.2em}',
        '.bawp-fs .bawp-b+.bawp-b{border-left:0}',

        '.bawp-m{width:100%;color:#6f6f6f;font-size:0.8em;line-height:1.3;',
        'font-family:"IBM Plex Mono",Consolas,monospace}',

        /* filters */
        '.bawp-fb{flex:none;padding:0.45em 0.6em;border-bottom:1px solid #e0e0e0;',
        'display:flex;flex-direction:column;gap:0.3em}',
        '.bawp-fb:empty{display:none;padding:0;border-bottom:0}',
        '.bawp-fr{display:flex;flex-wrap:wrap;gap:0.3em;align-items:center}',
        '.bawp-fl{font-size:0.8em;color:#6f6f6f;letter-spacing:.04em;',
        'text-transform:uppercase;flex:none;min-width:4.4em}',

        /* A Carbon tag - the one place a radius survives. */
        '.bawp-tag{font-family:inherit;font-size:0.8em;line-height:1.2;',
        'padding:0.25em 0.6em;border:1px solid #e0e0e0;border-radius:0.95em;',
        'background:#fff;color:#525252;cursor:pointer;display:inline-flex;',
        'align-items:center;gap:0.35em;',
        'transition:background 110ms cubic-bezier(.2,0,.38,.9)}',
        '.bawp-tag:hover{background:#e5e5e5}',
        '.bawp-tag:focus{outline:2px solid #0f62fe;outline-offset:-2px}',
        '.bawp-tag.on{background:#e0e0e0;border-color:#8d8d8d;color:#161616;',
        'font-weight:600}',
        /* Tabular figures: these counts change on every validate, and
           proportional digits make the tags jump about as they do. */
        '.bawp-tag .n{font-family:"IBM Plex Mono",Consolas,monospace;color:#6f6f6f;',
        'font-variant-numeric:tabular-nums}',
        '.bawp-tag.on .n{color:#161616}',
        /* Severity is a SHAPE as well as a colour.
           Conveyed by colour alone, critical and major are red and orange -
           the pair a red-green colour blindness makes hardest to separate, and
           severity is the first thing a developer reads off a row. Circle,
           triangle, diamond and hollow square are distinguishable with no
           colour at all. */
        '.bawp-mk{width:0.75em;height:0.75em;flex:none;display:block}',
        '.bawp-mk.critical{fill:#da1e28}',
        '.bawp-mk.major{fill:#ff832b}',
        '.bawp-mk.minor{fill:#f1c21b}',
        '.bawp-mk.warning{fill:none;stroke:#6f6f6f;stroke-width:2}',
        /* Clearing a filter has to be one obvious click. These persist across
           sessions, so a developer can meet a panel that was filtered days ago
           with no memory of doing it. */
        '.bawp-tag.clear{border-style:dashed;color:#0f62fe;border-color:#0f62fe}',

        /* Severity, in the engine's own rank order: critical > major > minor >
           warning. `warning` is the LOWEST band, which is why it is the
           quietest colour here and was wrong when it was orange. */
        '.bawp-sev-critical{background:#da1e28}',
        '.bawp-sev-major{background:#ff832b}',
        '.bawp-sev-minor{background:#f1c21b}',
        '.bawp-sev-warning{background:#6f6f6f}',

        /* groups */
        '.bawp-l{flex:1;overflow:auto;padding:0.3em 0.6em 0.9em}',
        '.bawp-g{margin-top:0.6em}',
        '.bawp-g:first-child{margin-top:0.15em}',
        /* Sticky, because four groups of findings is taller than the panel and
           scrolling into the middle of one otherwise loses which group you are
           reading. It needs an opaque background or the rows show through. */
        '.bawp-gh{display:flex;align-items:center;gap:0.45em;width:100%;',
        'text-align:left;padding:0.3em 0.15em;background:#fff;border:0;',
        'border-bottom:1px solid #e0e0e0;font-family:inherit;color:#161616;',
        'cursor:pointer;position:sticky;top:0;z-index:1}',
        '.bawp-gh:hover{background:#f4f4f4}',
        /* An empty group is still a statement - it is not a control. */
        '.bawp-gh.none{cursor:default;color:#6f6f6f}',
        '.bawp-gh.none:hover{background:#fff}',
        '.bawp-gh:focus{outline:2px solid #0f62fe;outline-offset:-2px}',
        '.bawp-gt{font-size:0.85em;font-weight:600;letter-spacing:.02em}',
        '.bawp-gs{font-size:0.8em;color:#6f6f6f;flex:1}',
        '.bawp-gn{font-size:0.8em;color:#6f6f6f;flex:none;',
        'font-family:"IBM Plex Mono",Consolas,monospace;',
        'font-variant-numeric:tabular-nums}',
        /* The count carries the worst severity in the group, so a closed group
           says how BAD it is and not only how much. */
        '.bawp-gn.critical{color:#da1e28;font-weight:600}',
        '.bawp-gn.major{color:#ff832b;font-weight:600}',
        '.bawp-gn.minor{color:#8a6d00}',
        /* An SVG chevron, rotated - not a text glyph. A glyph like the one
           this replaced depends on the font having it and on the Designer's
           own CSS not restyling it, and neither is ours to guarantee. */
        '.bawp-cx{width:0.85em;height:0.85em;flex:none;fill:#6f6f6f;',
        'transition:transform 70ms cubic-bezier(.2,0,.38,.9)}',
        '.bawp-g.open>.bawp-gh .bawp-cx{transform:rotate(90deg)}',
        '.bawp-gb{display:none}',
        '.bawp-g.open>.bawp-gb{display:block}',

        /* One finding.
           Collapsed it is a single line; the detail is ALWAYS rendered and
           hidden with CSS, never left unbuilt - test/designer/harness.js
           asserts on #bawp-list textContent, and a panel you cannot search is
           worse than one that renders a little more than it shows. */
        '.bawf{border-left:3px solid #6f6f6f;background:#f4f4f4;margin:0.3em 0;',
        'cursor:pointer;transition:background 110ms cubic-bezier(.2,0,.38,.9)}',
        '.bawf:hover{background:#e5e5e5}',
        '.bawf:focus{outline:2px solid #0f62fe;outline-offset:-2px}',
        '.bawf.critical{border-left-color:#da1e28}',
        '.bawf.major{border-left-color:#ff832b}',
        '.bawf.minor{border-left-color:#f1c21b}',
        '.bawf.warning{border-left-color:#6f6f6f}',
        /* A draft is a proposal about the standard, not policy. Arguable, not
           invisible. */
        '.bawf.draft{border-left-style:dashed}',
        '.bawf-s{display:flex;align-items:baseline;gap:0.45em;padding:0.45em 0.6em}',
        '.bawf-m{flex:1;min-width:0;line-height:1.35}',
        '.bawf:not(.open) .bawf-m{white-space:nowrap;overflow:hidden;',
        'text-overflow:ellipsis}',
        '.bawf-ln{font-size:0.8em;color:#6f6f6f;flex:none;',
        'font-family:"IBM Plex Mono",Consolas,monospace;',
        'font-variant-numeric:tabular-nums}',
        /* WHERE in the artifact - the step, gateway or variable this is about.
           On the summary line, because "which one" is the first thing a
           developer asks and it is useless behind a click. */
        '.bawf-w{font-size:0.8em;color:#525252;flex:none;max-width:45%;',
        'overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        '.bawf-d{display:none;padding:0 0.6em 0.5em}',
        '.bawf.open .bawf-d{display:block}',
        /* Why, before what to do about it - the checklist separates them and so
           does this. A developer who knows why a standard exists argues with it
           far less than one handed only an instruction. */
        '.bawf-why{font-size:0.9em;line-height:1.4;color:#525252;',
        'margin-bottom:0.35em}',
        '.bawf-do{font-size:0.9em;line-height:1.4;color:#161616;',
        'margin-bottom:0.35em}',
        '.bawf-r{font-size:0.8em;color:#6f6f6f;',
        'font-family:"IBM Plex Mono",Consolas,monospace}',

        '.bawp-e{color:#6f6f6f;font-size:0.9em;padding:1.23em 0.6em;text-align:center}',

        /* the checklist rows */
        '.bawp-cli{border-left:3px solid #e0e0e0;background:#f4f4f4;',
        'padding:0.45em 0.6em;margin:0.3em 0;font-size:0.9em;line-height:1.4}',
        '.bawp-cli.Critical,.bawp-cli.High{border-left-color:#f1c21b}',
        '.bawp-clm{font-size:0.85em;color:#6f6f6f;margin-top:0.15em;',
        'font-family:"IBM Plex Mono",Consolas,monospace}',

        /* The repair offer. Quiet until asked for, and the diff is deliberately
           plain text - a fix a developer cannot read before applying is a fix
           they should not be applying. */
        '.bawf-fix{margin-top:0.3em}',
        '.bawf-fixb{font-family:inherit;font-size:0.85em;line-height:1.2;',
        'padding:0.25em 0.6em;border:1px solid #e0e0e0;border-radius:0;',
        'background:#fff;color:#161616;cursor:pointer}',
        '.bawf-fixb:hover{background:#e5e5e5}',
        '.bawf-fixb:disabled{color:#a8a8a8;cursor:default}',
        '.bawf-fixb:focus{outline:2px solid #0f62fe;outline-offset:-2px}',
        '.bawf-diff{font-family:"IBM Plex Mono",Consolas,monospace;font-size:0.8em;',
        'white-space:pre-wrap;word-break:break-all;padding:0.15em 0.45em;',
        'margin:0.15em 0}',
        '.bawf-before{background:#fff1f1;color:#a2191f}',
        '.bawf-after{background:#defbe6;color:#0e6027}',

        '@media (prefers-reduced-motion:reduce){.bawp *{transition:none}}'
    ].join('');

    function panelDoc() { return state.designer && !state.designer.closed ? state.designer.document : null; }

    /* ------------------------------------------------------------ font size
     *
     * One number. `.bawp` carries it inline and every size in the sheet is `em`
     * rooted there, so padding, carets and tags all scale with the text instead
     * of the type growing inside a fixed box.
     */
    var FONT_MIN = 10;
    var FONT_MAX = 20;

    function applyFont(d) {
        var root = d && d.querySelector('.bawp');
        if (root) { root.style.fontSize = state.fontPx + 'px'; }
    }

    function stepFont(by) {
        var next = Math.min(FONT_MAX, Math.max(FONT_MIN, state.fontPx + by));
        if (next === state.fontPx) { return; }
        state.fontPx = next;
        try { localStorage.setItem('baw-panel-font', String(next)); } catch (e) { /* private mode */ }
        applyFont(panelDoc());
        renderPanel();          /* the +/- buttons show their own limits */
    }

    function ensurePanel() {
        var node = B.dockPanel(340);
        if (!node) { return null; }
        var d = panelDoc();
        if (d && !d.getElementById('bawp-style')) {
            var st = d.createElement('style');
            st.id = 'bawp-style';
            st.textContent = PANEL_CSS;
            d.head.appendChild(st);
        }
        if (!node.firstChild) {
            node.innerHTML =
                '<div class="bawp">'
                + '<div class="bawp-h"><span class="bawp-t">BAW Assistant</span>'
                + '<button type="button" class="bawp-b primary" id="bawp-check"'
                + ' title="Re-read the artifact and re-lint the open script">'
                + 'Validate</button>'
                + '<span class="bawp-fs" role="group" aria-label="Text size">'
                + '<button type="button" class="bawp-b" id="bawp-fs-down"'
                + ' title="Smaller text" aria-label="Smaller text">A&#8722;</button>'
                + '<button type="button" class="bawp-b" id="bawp-fs-up"'
                + ' title="Larger text" aria-label="Larger text">A+</button>'
                + '</span>'
                + '<span class="bawp-m" id="bawp-meta"></span></div>'
                + '<div class="bawp-fb" id="bawp-filters"></div>'
                /* polite, not assertive: a validate finishing should be
                   announced, never interrupt what is already being read. */
                + '<div class="bawp-l" id="bawp-list" role="region"'
                + ' aria-label="Findings" aria-live="polite"></div></div>';

            /* Wired here, inside the same guard that built the markup, so the
               handler is attached exactly once per panel. The panel lives in
               the Designer's document, so the listener does too - and it dies
               with the panel, which is what we want. */
            var btn = d && d.getElementById('bawp-check');
            if (btn) {
                btn.addEventListener('click', function () {
                    if (btn.disabled) { return; }
                    var label = btn.textContent;
                    btn.disabled = true;
                    btn.textContent = 'Checking';
                    validateNow().then(function () {
                        /* renderPanel may have rebuilt nothing, but the button
                           survives it - restore rather than assume. */
                        btn.disabled = false;
                        btn.textContent = label;
                    });
                });
            }
            var down = d && d.getElementById('bawp-fs-down');
            var up = d && d.getElementById('bawp-fs-up');
            if (down) { down.addEventListener('click', function () { stepFont(-1); }); }
            if (up) { up.addEventListener('click', function () { stepFont(1); }); }
        }
        applyFont(d);
        return node;
    }

    /* ------------------------------------------------------------- marks
     *
     * SVG rather than text glyphs. A glyph depends on the font carrying it and
     * on the Designer's stylesheet not restyling it, and inside IBM's document
     * neither is ours to promise.
     */
    var SVG_NS = 'http://www.w3.org/2000/svg';

    function svg(d, viewBox, cls) {
        var n = d.createElementNS(SVG_NS, 'svg');
        n.setAttribute('viewBox', viewBox);
        n.setAttribute('focusable', 'false');
        n.setAttribute('aria-hidden', 'true');
        n.setAttribute('class', cls);
        return n;
    }

    function shape(d, tag, attrs) {
        var n = d.createElementNS(SVG_NS, tag);
        Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); });
        return n;
    }

    /* Severity as a SHAPE as well as a colour.
     *
     * Critical and major are red and orange, which is the pair a red-green
     * colour blindness separates least well - and severity is the first thing
     * a developer reads off a collapsed row. Circle, triangle, diamond and
     * hollow square are told apart with no colour at all. */
    function severityMark(d, severity) {
        var sev = String(severity || 'warning').toLowerCase();
        var n = svg(d, '0 0 16 16', 'bawp-mk ' + sev);
        if (sev === 'critical') {
            n.appendChild(shape(d, 'circle', { cx: 8, cy: 8, r: 7 }));
        } else if (sev === 'major') {
            n.appendChild(shape(d, 'polygon', { points: '8,1 15,15 1,15' }));
        } else if (sev === 'minor') {
            n.appendChild(shape(d, 'polygon', { points: '8,1 15,8 8,15 1,8' }));
        } else {
            n.appendChild(shape(d, 'rect', { x: 2, y: 2, width: 12, height: 12 }));
        }
        /* Named for anyone who cannot see either the shape or the colour. */
        var t = d.createElementNS(SVG_NS, 'title');
        t.textContent = sev;
        n.appendChild(t);
        n.removeAttribute('aria-hidden');
        n.setAttribute('role', 'img');
        return n;
    }

    function chevron(d) {
        var n = svg(d, '0 0 16 16', 'bawp-cx');
        n.appendChild(shape(d, 'polygon', { points: '6,3 11,8 6,13' }));
        return n;
    }

    /* --------------------------------------------------------- panel state
     *
     * Everything a developer has adjusted lives in `state`, never in the DOM:
     * renderPanel rebuilds the list on every poll, so a collapsed group or an
     * expanded row held in the markup would spring back open twice a second.
     */

    function isOpen(f) { return state.openRows[F.key(f)] === true; }

    function toggleRow(f) {
        var k = F.key(f);
        if (state.openRows[k]) { delete state.openRows[k]; } else { state.openRows[k] = true; }
        renderPanel();
    }

    function toggleGroup(key) {
        state.groupsOpen[key] = !state.groupsOpen[key];
        try {
            localStorage.setItem('baw-panel-groups', JSON.stringify(state.groupsOpen));
        } catch (e) { /* private mode */ }
        renderPanel();
    }

    /* An empty selection means "no filter", not "nothing" - so the panel opens
       showing everything, which is the state a developer expects. */
    function toggleFilter(kind, value) {
        var list = state[kind];
        var i = list.indexOf(value);
        if (i < 0) { list.push(value); } else { list.splice(i, 1); }
        try {
            localStorage.setItem('baw-panel-filters',
                JSON.stringify({ sev: state.sevFilter, cat: state.catFilter }));
        } catch (e) { /* private mode */ }
        renderPanel();
    }

    function passesFilter(f) {
        return F.matches(f, { severity: state.sevFilter, category: state.catFilter });
    }

    /* Which step the code on screen belongs to.
     *
     * Three sources, in order of how much they can be trusted, because the
     * obvious one is not reliable:
     *
     *   1. The Designer's Properties panel, through sense().node. Exact when it
     *      is there - and it often is NOT. Selecting another step while the
     *      Script tab is open rebuilds only the script editor, so
     *      flow-element-id leaves the document entirely and this returns null
     *      even though the panel is still linting the right buffer
     *      (PROJECT.md §11).
     *   2. The committed model, when exactly one surface of this kind exists -
     *      an artifact with a single Script cannot be ambiguous.
     *   3. The committed model, when exactly one surface's code is byte for
     *      byte what is on screen. True until the developer edits, which is
     *      also when 1 usually works.
     *
     * If none of them settles it, this returns nothing. A wrong step name is
     * worse than no step name: it sends the developer to the wrong place and
     * looks authoritative doing it.
     */
    function bufferWhere() {
        var s = state.lastSense || {};
        if (s.node && s.node.name) { return s.node.name; }

        var m = state.artifactModel;
        if (!m || !m.surfaces || !s.surface) { return ''; }
        var sameKind = m.surfaces.filter(function (x) { return x.surface === s.surface; });
        if (sameKind.length === 1) { return sameKind[0].node || sameKind[0].name || ''; }

        var buffer = state.lastBuffer;
        if (buffer) {
            var exact = sameKind.filter(function (x) { return x.code === buffer; });
            if (exact.length === 1) { return exact[0].node || exact[0].name || ''; }
        }
        return '';
    }

    /* ------------------------------------------------------------ rendering */

    function renderPanel() {
        var node = ensurePanel();
        var d = panelDoc();
        if (!node || !d) { return; }
        var meta = d.getElementById('bawp-meta');
        var list = d.getElementById('bawp-list');
        if (!meta || !list) { return; }

        var s = state.lastSense || {};
        var m = state.artifactModel;
        var whereNow = bufferWhere();
        meta.textContent = (s.surface || 'no surface')
            + (whereNow ? '  @ ' + whereNow : '')
            + (state.lastLintMs !== null ? '  ' + state.lastLintMs + 'ms' : '')
            + (m ? '  ·  ' + (m.variablesApply === false
                        ? 'no vars' : m.variables.length + ' vars')
                 + ', ' + m.components.length
                 + (m.components.length === 1 ? ' step' : ' steps') : '')
            + timingSuffix();

        /* Artifact findings first - they are about the whole service, so they
           frame everything below them. They carry no line, hence no "L n".
           The Designer's own validator is last and visibly separate: it is not
           our judgement and cites no house standard, so mixing it in with the
           checklist findings would misrepresent both. */
        var groups = [
            { key: 'artifact', label: 'This artifact', hint: 'the service as a whole',
              all: state.artifactFindings || [], numbered: false },
            { key: 'script', label: 'This script', hint: 'the code surface on screen',
              all: state.findings || [], numbered: true },
            /* The other editors in front of the developer. Separate from "This
               script" because only that one is bound, annotated in the gutter
               and linted as it is typed - collapsing the two would imply the
               gutter should be showing these, and it cannot. */
            { key: 'other', label: 'Also on screen',
              hint: 'the other code surfaces here',
              all: state.otherFindings || [], numbered: true },
            { key: 'designer', label: 'Process Designer', hint: "IBM's own validator",
              all: state.designerFindings || [], numbered: true }
        ];

        var total = 0;
        var shown = 0;
        groups.forEach(function (g) {
            g.findings = g.all.filter(passesFilter);
            total += g.all.length;
            shown += g.findings.length;
        });

        renderFilters(d, groups);

        list.innerHTML = '';
        /* An empty group is still drawn, saying "none".
         *
         * Hiding it makes "checked, and clean" indistinguishable from "never
         * checked" - the same failure as the suppressed checklist. A developer
         * looking at a service with no artifact findings should be able to see
         * that the artifact WAS examined. */
        groups.forEach(function (g) { renderGroup(d, list, g); });

        /* An empty run is NOT an early exit.
         *
         * This used to return before the checklist, which suppressed it in the
         * one state where it matters most: clean code, where a developer is
         * most likely to read a green panel as a passed review.
         *
         * A filter that empties the panel says so, for the same reason. Silence
         * that means "you hid these" must never look like silence that means
         * "there is nothing here". */
        if (!shown) {
            var note = d.createElement('div');
            note.className = 'bawp-e';
            if (total) {
                note.textContent = total + ' finding' + (total === 1 ? '' : 's')
                    + ' hidden by the filters above.';
            } else {
                note.textContent = s.surface ? 'No findings.' : 'Open a code surface.';
            }
            list.appendChild(note);
        }

        renderChecklist(d, list);
    }

    /* Two rows of tags: severity, then category. Only the values actually
       present are offered - a filter for something that cannot be there is a
       control that does nothing, and the counts are over everything the panel
       holds so a developer can see what a tag would bring back. */
    function renderFilters(d, groups) {
        var bar = d.getElementById('bawp-filters');
        if (!bar) { return; }
        bar.innerHTML = '';

        var everything = [];
        groups.forEach(function (g) { everything = everything.concat(g.all); });
        var counts = F.tally(everything);
        var sev = counts.severity;
        var cat = counts.category;

        var sevKeys = F.severitiesPresent(sev);
        var catKeys = F.categoriesPresent(cat);
        /* One of anything is not a filter. */
        if (sevKeys.length < 2 && catKeys.length < 2) { return; }

        function row(label, keys, counts, kind, dot) {
            if (keys.length < 2) { return; }
            var r = d.createElement('div');
            r.className = 'bawp-fr';
            var l = d.createElement('span');
            l.className = 'bawp-fl';
            l.textContent = label;
            r.appendChild(l);
            keys.forEach(function (k) {
                var selected = state[kind].indexOf(k) >= 0;
                var tag = d.createElement('button');
                tag.type = 'button';
                tag.className = 'bawp-tag' + (selected ? ' on' : '');
                tag.setAttribute('aria-pressed', selected ? 'true' : 'false');
                if (dot) { tag.appendChild(severityMark(d, k)); }
                tag.appendChild(d.createTextNode(k));
                var n = d.createElement('span');
                n.className = 'n';
                n.textContent = String(counts[k]);
                tag.appendChild(n);
                tag.addEventListener('click', function () { toggleFilter(kind, k); });
                r.appendChild(tag);
            });
            bar.appendChild(r);
        }

        row('Severity', sevKeys, sev, 'sevFilter', true);
        row('Category', catKeys, cat, 'catFilter', false);

        /* Filters persist across sessions, so a developer can meet a panel
           that was filtered days ago with no memory of doing it. Clearing has
           to be one obvious click, not a hunt for which tags are pressed. */
        if (state.sevFilter.length || state.catFilter.length) {
            var r = d.createElement('div');
            r.className = 'bawp-fr';
            var clear = d.createElement('button');
            clear.type = 'button';
            clear.className = 'bawp-tag clear';
            clear.textContent = 'Clear filters';
            clear.addEventListener('click', function () {
                state.sevFilter = [];
                state.catFilter = [];
                try {
                    localStorage.removeItem('baw-panel-filters');
                } catch (e) { /* private mode */ }
                renderPanel();
            });
            r.appendChild(clear);
            bar.appendChild(r);
        }
    }

    /* A labelled, collapsible section. The count in the header is what makes
       collapsing safe: a closed group still says how much is inside it. */
    function renderGroup(d, list, g) {
        var empty = !g.all.length;
        var open = !empty && state.groupsOpen[g.key] !== false;
        var box = d.createElement('div');
        box.className = 'bawp-g' + (open ? ' open' : '');

        var head = d.createElement('button');
        head.type = 'button';
        head.className = 'bawp-gh' + (empty ? ' none' : '');
        if (empty) {
            head.disabled = true;
        } else {
            head.setAttribute('aria-expanded', open ? 'true' : 'false');
        }

        /* No chevron on a group that cannot open - a disclosure control that
           discloses nothing is a promise the panel does not keep. */
        if (!empty) { head.appendChild(chevron(d)); }

        var title = d.createElement('span');
        title.className = 'bawp-gt';
        title.textContent = g.label;
        head.appendChild(title);

        var hint = d.createElement('span');
        hint.className = 'bawp-gs';
        hint.textContent = g.hint ? '  ' + g.hint : '';
        head.appendChild(hint);

        var count = d.createElement('span');
        /* The count carries the worst severity in the group, so a CLOSED group
           says how bad it is and not only how much. */
        var worst = g.all.reduce(function (acc, f) {
            return F.rank(f.severity) < F.rank(acc) ? f.severity : acc;
        }, 'warning');
        count.className = 'bawp-gn' + (empty ? '' : ' ' + worst);
        /* Says when a filter is hiding part of the group, rather than quietly
           reporting the smaller number as the whole truth. */
        count.textContent = empty ? 'none'
            : (g.findings.length === g.all.length
                ? String(g.all.length)
                : g.findings.length + ' of ' + g.all.length);
        head.appendChild(count);

        if (!empty) {
            head.addEventListener('click', function () { toggleGroup(g.key); });
        }
        box.appendChild(head);

        var body = d.createElement('div');
        body.className = 'bawp-gb';
        /* Worst first. The engine returns findings in the order it found them,
           which is source order for a buffer - useful for reading a file top to
           bottom, and the wrong order for deciding what to fix. */
        F.sort(g.findings).forEach(function (f) {
            body.appendChild(findingRow(d, f, g.numbered));
        });
        box.appendChild(body);
        list.appendChild(box);
    }

    /* One finding.
     *
     * Collapsed it is a single line, because a panel where every row carries
     * its rationale, remediation, rule id and repair button is a scroll rather
     * than a list. Expanded it carries all four - the three things a developer
     * needs in order to trust a finding are which rule fired, the checklist
     * cell it came from, and whether it is policy or still a proposal.
     *
     * Clicking does both jobs: it reveals the line in the editor and opens the
     * detail. They are not in conflict - someone who wants to see the finding
     * wants to see the code it is about.
     */
    function findingRow(d, f, numbered) {
        var open = isOpen(f);
        var row = d.createElement('div');
        row.className = 'bawf ' + f.severity
            + (f.lifecycle === 'draft' ? ' draft' : '')
            + (open ? ' open' : '');
        /* Not a <button>: the repair controls are buttons and nesting them
           would be invalid. role plus tabindex plus a key handler gets the same
           behaviour without the bad markup. */
        row.setAttribute('role', 'button');
        row.setAttribute('tabindex', '0');
        row.setAttribute('aria-expanded', open ? 'true' : 'false');

        var summary = d.createElement('div');
        summary.className = 'bawf-s';
        summary.appendChild(severityMark(d, f.severity));

        var msg = d.createElement('div');
        msg.className = 'bawf-m';
        msg.textContent = f.message;
        /* A collapsed row ellipsises. Without this the truncation is lossy -
           the developer can see that something was cut and not what. */
        msg.setAttribute('title', f.message);
        summary.appendChild(msg);

        /* Which part of the artifact. For an artifact finding the engine now
           names the rows that actually matched; for a buffer finding it is the
           step whose code is on screen. */
        var where = f.subjects && f.subjects.length
            ? f.subjects.join(', ')
            : (numbered ? bufferWhere() : '');
        if (where) {
            var w = d.createElement('span');
            w.className = 'bawf-w';
            w.textContent = where;
            w.setAttribute('title', where);
            summary.appendChild(w);
        }

        if (numbered && f.line) {
            var ln = d.createElement('span');
            ln.className = 'bawf-ln';
            ln.textContent = 'L' + f.line;
            summary.appendChild(ln);
        }
        row.appendChild(summary);

        var detail = d.createElement('div');
        detail.className = 'bawf-d';

        if (f.rationale) {
            var why = d.createElement('div');
            why.className = 'bawf-why';
            why.textContent = f.rationale;
            detail.appendChild(why);
        }
        if (f.remediation) {
            var doIt = d.createElement('div');
            doIt.className = 'bawf-do';
            doIt.textContent = f.remediation;
            detail.appendChild(doIt);
        }

        var designer = f.source && f.source.locator === 'designer';
        var bits = [designer ? 'Process Designer' : f.ruleId];
        if (!designer && f.source && f.source.locator && f.source.locator !== 'house') {
            bits.push(f.source.locator);
        }
        if (f.category) { bits.push(f.category); }
        if (f.lifecycle === 'draft') { bits.push('draft'); }
        if (f.enforcement === 'auto-fixable') { bits.push('fixable'); }

        var rid = d.createElement('div');
        rid.className = 'bawf-r';
        rid.textContent = bits.join('  ·  ');
        detail.appendChild(rid);

        /* A repair is offered only where the engine says one exists, and it is
           never applied by the act of showing it. */
        if (f.enforcement === 'auto-fixable' && f.line) {
            detail.appendChild(fixControls(d, f));
        }
        row.appendChild(detail);

        function activate() {
            if (numbered && f.line) { revealLine(f.line, f.surface); }
            toggleRow(f);
        }
        row.addEventListener('click', activate);
        row.addEventListener('keydown', function (ev) {
            if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
                ev.preventDefault();
                activate();
            }
        });
        return row;
    }

    /* What the checklist asks that the engine cannot answer.
     *
     * Without this the panel quietly implies that a clean run means a passed
     * review, when two thirds of the checklist was never asked. Closed by
     * default: the defects come first, and this is what you open when the work
     * is ready to hand over. It wears the same group chrome as the findings, so
     * "what was checked" and "what still needs a person" read as one list.
     */
    function renderChecklist(d, list) {
        var cl = state.checklist;
        if (!cl || !cl.prompts || !cl.prompts.length) { return; }

        var open = state.checklistOpen;
        var box = d.createElement('div');
        box.className = 'bawp-g' + (open ? ' open' : '');

        var head = d.createElement('button');
        head.type = 'button';
        head.className = 'bawp-gh';
        head.setAttribute('aria-expanded', open ? 'true' : 'false');

        head.appendChild(chevron(d));

        var title = d.createElement('span');
        title.className = 'bawp-gt';
        title.textContent = 'Review checklist';
        head.appendChild(title);

        var hint = d.createElement('span');
        hint.className = 'bawp-gs';
        hint.textContent = '  needs a person'
            + (cl.artifactType ? '  ·  ' + cl.artifactType : '')
            + '  ·  ' + cl.automated + ' answered here';
        head.appendChild(hint);

        var count = d.createElement('span');
        count.className = 'bawp-gn';
        count.textContent = String(cl.forReview);
        head.appendChild(count);

        head.addEventListener('click', function () {
            state.checklistOpen = !state.checklistOpen;
            renderPanel();
        });
        box.appendChild(head);

        var body = d.createElement('div');
        body.className = 'bawp-gb';

        /* Highest priority first - a reviewer with limited time should meet the
           Critical rows before the Low ones. */
        var order = { Critical: 0, High: 1, Medium: 2, Low: 3 };
        var sorted = cl.prompts.slice().sort(function (a, b) {
            var pa = order[a.priority], pb = order[b.priority];
            pa = (pa === undefined) ? 9 : pa;
            pb = (pb === undefined) ? 9 : pb;
            return pa - pb;
        });
        sorted.forEach(function (p) {
            var row = d.createElement('div');
            row.className = 'bawp-cli ' + (p.priority || '');
            var t = d.createElement('div');
            t.textContent = p.checkText || p.message;
            row.appendChild(t);
            var meta = d.createElement('div');
            meta.className = 'bawp-clm';
            /* Every cell this one question occupies. The engine collapses a
               question the workbook asks twice into a single check and hands
               back the other cells in alsoAt - showing them keeps the duplicate
               traceable back to the sheet it came from. */
            var cells = [];
            if (p.source && p.source.locator) { cells.push(p.source.locator); }
            (p.alsoAt || []).forEach(function (c) { cells.push(c); });
            meta.textContent = [p.priority, p.impactedArea, p.primaryReviewer,
                    cells.join(', ')]
                .filter(function (x) { return x; }).join('  ·  ');
            row.appendChild(meta);
            body.appendChild(row);
        });
        box.appendChild(body);
        list.appendChild(box);
    }

    /* Offer a repair, show it before doing it, and let the developer decide.
     *
     * Deliberately two clicks. "Fix" only ASKS the server what the change would
     * be and shows the before and after; "Apply" is the one that touches the
     * buffer. This is the first thing the assistant does that writes anything,
     * and a single-click Apply next to a finding would eventually be pressed by
     * accident on code somebody cared about.
     *
     * Nothing is saved either way. The edit lands in the editor as if typed, so
     * Designer's own save and validation stay in charge of what reaches the
     * artifact.
     */
    function fixControls(d, finding) {
        var wrap = d.createElement('div');
        wrap.className = 'bawf-fix';

        var ask = d.createElement('button');
        ask.type = 'button';
        ask.className = 'bawf-fixb';
        ask.textContent = 'Fix';
        wrap.appendChild(ask);

        ask.addEventListener('click', function (ev) {
            ev.stopPropagation();          /* the row itself reveals the line */
            ask.disabled = true;
            ask.textContent = 'Checking';

            var buffer = B.readDisplayedBuffer();
            if (!buffer || !buffer.code) {
                ask.textContent = 'no buffer';
                return;
            }
            brainFetch('/api/fix', {
                code: buffer.code, language: buffer.language,
                ruleIds: [finding.ruleId]
            }).then(function (r) {
                var mine = (r.fixes || []).filter(function (x) {
                    return x.line === finding.line && x.ruleId === finding.ruleId;
                })[0];
                if (!mine) {
                    /* The engine offers nothing here. Say so rather than
                       leaving a button that looks broken. */
                    ask.textContent = 'no fix for this line';
                    return;
                }
                wrap.removeChild(ask);
                wrap.appendChild(diffAndApply(d, finding, mine, buffer.surface));
            }).catch(function (e) {
                ask.disabled = false;
                ask.textContent = 'Fix';
                setStatus('Could not work out a fix: ' + e.message, 'warn');
            });
        });
        return wrap;
    }

    /* The proposal, in full, with the only button that changes anything. */
    function diffAndApply(d, finding, fix, surface) {
        var box = d.createElement('div');

        var before = d.createElement('div');
        before.className = 'bawf-diff bawf-before';
        before.textContent = '- ' + fix.before.trim();
        box.appendChild(before);

        var after = d.createElement('div');
        after.className = 'bawf-diff bawf-after';
        /* A null `after` means the line goes away entirely - distinct from
           replacing it with nothing, which would leave a blank line. */
        after.textContent = (fix.after === null || fix.after === undefined)
            ? '(line removed)'
            : '+ ' + String(fix.after).trim();
        box.appendChild(after);

        var apply = d.createElement('button');
        apply.type = 'button';
        apply.className = 'bawf-fixb';
        apply.textContent = 'Apply to my editor';
        box.appendChild(apply);

        apply.addEventListener('click', function (ev) {
            ev.stopPropagation();
            apply.disabled = true;
            /* `before` is passed as the expectation: if the developer has typed
               since the proposal was computed, the edit is refused rather than
               applied to a line that has moved on. */
            var res = B.applyLineEdit(surface, fix.line, fix.after, fix.before);
            if (!res.ok) {
                apply.textContent = 'not applied';
                setStatus('Fix not applied: ' + res.reason, 'warn');
                return;
            }
            setStatus('Applied - review it and save when you are ready.', 'good');
            /* Re-lint so the finding disappears and the line numbers below it
               are right again. Fixes are offered one at a time for exactly this
               reason: no offset bookkeeping, no chance of corrupting a buffer. */
            runLint();
        });
        return box;
    }

    /* Scroll the developer's editor to a finding. */
    /* `surface` names which editor to scroll, and defaults to the bound one.
     *
     * A finding from another surface on screen carries its own, or clicking it
     * would scroll the bound editor to a line number that means nothing there.
     * Revealing it also focuses that editor, which on the next poll makes it
     * the surface the caret is in - so acting on the finding binds the panel
     * to the code it is about, which is what a developer would expect. */
    function revealLine(line, surface) {
        try {
            var s = { surface: surface || null };
            if (!s.surface) { s = B.sense(); }
            if (!s.surface) { return; }
            /* Ask the bridge, which scopes to the VISIBLE editor and the
               Properties panel. This used to query the whole Designer document
               and take the last match - the "never .last() blindly" trap the
               project already knows about - so with two artifacts open a click
               could scroll a hidden editor while the one on screen sat still. */
            var w = B.surfaceWidget(s.surface);
            if (!w || !w.editorObj) { return; }
            var tv = w.editorObj.getTextView(), tm = tv.getModel();
            var off = tm.getLineStart(Math.max(0, line - 1));
            tv.setSelection(off, off, true);
            tv.focus();
        } catch (e) { /* best effort */ }
    }

    /* ------------------------------------------------------------- the loop */

    /* A surface name as a developer reads it.
     *
     * The inline event handlers are keyed "event:On load" - prefixed so a
     * labelled surface can never collide with a named one - and the developer
     * sees "On load" beside the editor. Show them what they see. */
    function surfaceLabel(name) {
        var s = String(name || '');
        return s.indexOf('event:') === 0 ? s.slice('event:'.length) : s;
    }

    /* Lint every OTHER code surface on screen.
     *
     * The panel has always linted exactly one buffer, which is right when one
     * is on screen and wrong the moment several are: a coach component shows
     * all of its event handlers together, so two of three went unexamined no
     * matter which one was bound. Bounded to what is on screen on purpose -
     * code the developer cannot see belongs to the whole-application review,
     * and a ten-step service flow's other twenty-odd script surfaces would
     * flood the panel with another step's problems.
     *
     * Gated on a signature of names and character counts, so typing in the
     * bound surface does not re-lint its neighbours on every debounce. `force`
     * is for Validate, where the developer has asked for the work to be redone
     * whether or not anything looks different.
     */
    function lintOtherSurfaces(primary, force) {
        var key;
        try { key = B.otherSurfacesSignature(); } catch (e) { key = ''; }
        if (!force && key === state.otherKey) { return Promise.resolve(null); }
        state.otherKey = key;

        var buffers;
        try {
            buffers = B.readOnScreenBuffers().filter(function (b) {
                return b.surface !== primary;
            });
        } catch (e) { buffers = []; }

        if (!buffers.length) { state.otherFindings = []; return Promise.resolve(null); }

        return Promise.all(buffers.map(function (b) {
            return lint(b.code, b.language).then(function (r) {
                return (r.findings || []).map(function (f) {
                    /* Which editor it came from, so a row can say so and a
                       click can reveal the line in the right one. `subjects` is
                       what findingRow already renders as the "where" badge. */
                    f.surface = b.surface;
                    f.subjects = [surfaceLabel(b.surface)];
                    return f;
                });
            }).catch(function () {
                /* One unreadable surface must not lose the others. */
                return [];
            });
        })).then(function (lists) {
            var all = [];
            lists.forEach(function (l) { all = all.concat(l); });
            state.otherFindings = all;
            return all;
        });
    }

    function runLint(buffer) {
        buffer = buffer || B.readDisplayedBuffer();
        state.lastSense = B.sense();
        /* Kept so bufferWhere() can match what is on screen against the
           committed surfaces and recover WHICH step it is, in the common case
           where the Designer has dropped flow-element-id from the DOM. */
        state.lastBuffer = buffer ? buffer.code : null;
        if (!buffer || !buffer.code) {
            state.findings = [];
            state.designerFindings = [];
            state.lastLintMs = null;
            B.clearAnnotations();
            /* An empty BOUND surface is not an empty screen.
             *
             * This branch used to run the artifact rules and stop, which is
             * how a component showing three event handlers reported that they
             * were too long and nothing about what was in them: the bound
             * surface was the empty "Title formula". The other surfaces are
             * still there and still hold code. */
            return Promise.all([
                checkArtifact(),
                lintOtherSurfaces(buffer ? buffer.surface : null)
            ]).then(function () {
                renderPanel(); renderHub();
            });
        }
        return Promise.all([
            lint(buffer.code, buffer.language),
            checkArtifact(),
            lintOtherSurfaces(buffer.surface)
        ]).then(function (both) {
            var r = both[0];
            state.findings = r.findings || [];
            state.lastLintMs = r.elapsedMs;
            /* Only buffer findings are annotated - an artifact finding has no
               line to point at, and inventing one would be a lie. */
            var tAnnotate = now();
            var drawn = B.annotate(state.findings, buffer.surface);
            /* Measured, not just declared. Painting the gutter is the one
               phase that was in the diagnostic row and never filled in, so a
               slow repaint had nowhere to show up. */
            state.timing.annotate = Math.round(now() - tAnnotate);
            /* Read AFTER annotating, so ours are already in the model and get
               excluded by identity rather than by guessing from the text. */
            state.designerFindings = B.readDesignerFindings(buffer.surface);
            renderPanel(); renderHub();
            return drawn;
        }).catch(function (e) {
            setStatus('Lint failed: ' + e.message, 'bad');
        });
    }

    /* `auto` marks the poll's own re-attach. It stays quiet when there is no
       surface, because "open one, then press Watch again" is advice for someone
       who just pressed a button - not for a developer who closed a script tab. */
    function startWatching(auto) {
        if (!B.isAlive()) {
            if (!auto) { setStatus('Designer window is not open.', 'bad'); }
            return;
        }
        if (!auto) { state.autoWatchOff = false; }
        var ok = B.watch(function (buffer) { runLint(buffer); }, 350);
        state.watching = ok;
        if (!ok) {
            if (!auto) {
                setStatus('No code surface on screen - open one and it will lint itself.', 'warn');
            }
            renderHub();
            return null;
        }
        setStatus('Linting ' + B.watchedSurface() + ' as you type.', 'good');
        /* Returned so a caller that needs the result - Validate - can wait for
           it rather than reporting a count that has not been computed yet. */
        var done = runLint();
        renderHub();
        return done;
    }

    function stopWatching() {
        B.unwatch();
        B.clearAnnotations();
        state.watching = false;
        state.findings = [];
        state.designerFindings = [];
        state.otherFindings = [];
        state.otherKey = null;
        /* An explicit Stop is a decision, not a pause: without this the poll
           would re-attach to the next surface and undo it a second and a half
           later. Pressing Watch clears it again. */
        state.autoWatchOff = true;
        renderPanel(); renderHub();
        setStatus('Stopped. Annotations cleared. Press Watch to resume.', '');
    }

    /* ------------------------------------------------------------- hub view */

    function setStatus(text, kind) {
        var n = $('status');
        n.textContent = text;
        n.className = 'status ' + (kind || '');
    }

    function launchDesigner() {
        var ref = $('branchRef').value.trim();
        if (!ref) { setStatus('Paste a containerRef first.', 'bad'); return; }
        localStorage.setItem('baw-probe-ref', ref);
        state.branchRef = ref;

        var wc = encodeURIComponent('/processapps/platformRepo?BAW=true&BAW_tWAS=true');
        var url = '/WebPD/jsp/bootstrap.jsp?containerRef=' + encodeURIComponent(ref)
                + '&locale=en&WorkflowCenter=' + wc;
        /* Do not let the launcher target itself.
         *
         * window.open(url, name) reuses the window that CARRIES that name -
         * and this page carries it whenever it was loaded into a tab that used
         * to be the Designer, because a window keeps its name across
         * navigations. Launching then navigates the launcher away and the page
         * that was about to drive the Designer is gone. Seen live.
         *
         * Dropping our own name first means the lookup cannot find us, so it
         * finds the real Designer window or opens a new one. */
        if (window.name === 'baw-designer') { window.name = ''; }
        state.designer = window.open(url, 'baw-designer');
        if (state.designer === window) {
            setStatus('Could not open a separate Designer window.', 'bad');
            state.designer = null;
            return;
        }
        if (!state.designer) {
            setStatus('Pop-up blocked. Allow pop-ups for this site and retry.', 'bad');
            return;
        }
        B.attach(state.designer);
        B.setBranch(ref);
        setStatus('Designer opening...', '');

        var tries = 0;
        var poll = setInterval(function () {
            tries++;
            if (B.ready()) {
                clearInterval(poll);
                ensurePanel();
                setStatus('Designer ready. Artifact checks run automatically; '
                        + 'press Watch to lint code as you type.', 'good');
                /* Do not wait for Watch - open an artifact and it is checked. */
                checkArtifact().then(function () { renderPanel(); renderHub(); });
            } else if (tries > 60) {
                clearInterval(poll);
                setStatus('Designer did not become ready. Is it still loading?', 'warn');
            }
        }, 500);
    }

    function renderHub() {
        var alive = B.isAlive();
        $('watch').disabled = !alive || state.watching;
        $('stop').disabled = !state.watching;
        $('lintOnce').disabled = !alive;
        $('dock').disabled = !alive;

        var s = alive ? B.sense() : null;
        var dl = $('ctx');
        dl.innerHTML = '';
        [['Designer', alive ? 'connected' : 'not open'],
         ['Editor', s && s.editorType ? s.editorType : '-'],
         ['Artifact', s && s.artifactName ? s.artifactName : '-'],
         ['Surface', s && s.surface ? s.surface + ' (' + s.language + ')' : 'none displayed'],
         ['Watching', state.watching ? B.watchedSurface() : 'no'],
         ['Findings', String(state.findings.length)
             + (state.lastLintMs !== null ? '  (' + state.lastLintMs + ' ms)' : '')],
         /* Always shown here, unlike the panel, because this is the diagnostic
            view - if a switch feels slow, this row says which phase owns it. */
         ['Last tick', 'dom ' + fmtMs(state.timing.sig)
             + '  ·  model ' + fmtMs(state.timing.model)
             + '  ·  check ' + fmtMs(state.timing.check)
             + '  ·  lint ' + fmtMs(state.lastLintMs)
             + '  ·  draw ' + fmtMs(state.timing.annotate)]
        ].forEach(function (r) {
            dl.appendChild(el('dt', null, r[0]));
            dl.appendChild(el('dd', null, r[1]));
        });

        var list = $('findings');
        list.innerHTML = '';

        /* The severity ramp, not the borrowed pass/fail/skip idiom - a minor
           finding is a real finding that fired, not a check that was
           skipped, and the review console draws the same severity the same
           way, so this page should not disagree with it. */
        (state.artifactFindings || []).forEach(function (f) {
            var sev = String(f.severity || 'warning').toLowerCase();
            list.appendChild(el('div', { class: 'check ' + sev },
                el('div', { class: 'check-head' },
                    el('span', { class: 'pill ' + sev }, f.severity.toUpperCase()),
                    el('strong', null, 'Artifact'),
                    el('span', null, f.message)),
                f.rationale ? el('div', { class: 'why' }, f.rationale) : null,
                f.remediation ? el('div', { class: 'why' }, f.remediation) : null,
                el('div', { class: 'why' }, provenanceOf(f))));
        });

        var am = state.artifactModel;
        if (am) {
            /* Be explicit about provenance, and about the difference between
               "none" and "not applicable".
             *
             * Steps are live from the diagram; variables are the last commit,
             * because default values exist nowhere else. And a coach view has
             * no input/output variables by nature - saying "0 input/output
             * variables (as last saved)" made it look like a service flow with
             * an empty signature, which is a different and alarming thing. */
            var note = am.components.length
                + (am.components.length === 1 ? ' step' : ' steps')
                + (am.componentsAreLive ? ' (live)' : ' (as last saved)');
            if (am.variablesApply === false) {
                note += '  ·  no input/output variables for a ' + (am.type || 'this type');
            } else {
                note += '  ·  ' + am.variables.length + ' input/output variables ';
                note += am.variablesAreCommitted
                    ? '(as last saved' + (am.commitSeq !== null ? ', commit ' + am.commitSeq : '') + ')'
                    : '(unavailable - could not read the saved model)';
            }
            var settingCount = am.settings ? Object.keys(am.settings).length : 0;
            if (settingCount) { note += '  ·  ' + settingCount + ' settings read'; }
            if (am.surfaces && am.surfaces.length) {
                note += '  ·  ' + am.surfaces.length + ' committed code surface'
                     + (am.surfaces.length === 1 ? '' : 's');
            }
            if (am.uncommittedChanges) {
                note += '  ·  this artifact has unsaved changes, so committed values may lag';
            }
            list.appendChild(el('div', { class: 'muted', style: 'font-size:12px;margin:6px 0' }, note));
        }

        /* Both groups, or neither. Checking only the bound buffer here would
           print "No code findings in this buffer" while the panel beside it
           listed findings from the handler next to it - the silence that means
           "you cannot see these" looking exactly like the silence that means
           "there are none". */
        var others = state.otherFindings || [];
        if (!state.findings.length && !others.length) {
            list.appendChild(el('div', { class: 'muted' },
                state.watching ? 'No code findings in this buffer.' : 'Not watching yet.'));
            return;
        }
        state.findings.map(function (f) { return { f: f, label: null }; })
            .concat(others.map(function (f) {
                return { f: f, label: surfaceLabel(f.surface) };
            }))
            .forEach(function (row) {
            var f = row.f;
            var sev = String(f.severity || 'warning').toLowerCase();
            list.appendChild(el('div', {
                class: 'check ' + sev,
                onclick: function () { revealLine(f.line, f.surface); },
                style: 'cursor:pointer'
            },
                el('div', { class: 'check-head' },
                    el('span', { class: 'pill ' + sev }, f.severity.toUpperCase()),
                    el('strong', null, (row.label ? row.label + '  ·  ' : '') + 'Line ' + f.line),
                    el('span', null, f.message)),
                f.snippet ? el('div', { class: 'detail' }, f.snippet) : null,
                f.rationale ? el('div', { class: 'why' }, f.rationale) : null,
                f.remediation ? el('div', { class: 'why' }, f.remediation) : null,
                el('div', { class: 'why' }, provenanceOf(f))));
        });
    }

    /* Validate everything, now, from scratch.
     *
     * The automatic triggers cover open, change and save, but they are all
     * inference from what the DOM happens to expose. This is the escape hatch:
     * when the developer believes something is stale, one press must produce a
     * genuinely fresh answer rather than a cached one.
     *
     * So it does three things the poll deliberately does not. It drops the
     * committed-model cache, because the whole point of pressing it may be that
     * a save happened in a way we did not notice. It forgets both signatures, so
     * the next tick re-syncs instead of concluding nothing has changed. And it
     * re-binds the watcher, in case it is attached to an editor that no longer
     * exists.
     */
    function validateNow() {
        if (!B.isAlive()) {
            setStatus('Designer window is not open.', 'bad');
            return Promise.resolve();
        }
        B.invalidateModel();
        lastSignature = null;
        pendingSignature = null;
        lastSurfaceSignature = null;
        pendingSurfaceSignature = null;
        /* The third signature, forgotten for the same reason as the other two:
           Validate must re-judge the other surfaces on screen rather than
           conclude from an unchanged character count that it need not. */
        state.otherKey = null;

        state.lastSense = B.sense();
        var hasSurface = !!(state.lastSense && state.lastSense.surface);

        /* runLint already runs the artifact check alongside the buffer lint, so
           going through startWatching does both in one pass. Calling
           checkArtifact separately here would check the artifact twice. */
        var work;
        if (hasSurface && state.autoWatchOff && !state.watching) {
            /* Stopped on purpose. Answer the question that was asked - check it
               once - without quietly turning continuous linting back on. */
            work = runLint();
        } else if (hasSurface) {
            work = startWatching(true) || Promise.resolve();
        } else {
            state.findings = [];
            state.designerFindings = [];
            state.otherFindings = [];
            state.otherKey = null;
            state.lastLintMs = null;
            work = checkArtifact();
        }

        return Promise.resolve(work)
            .then(function () {
                renderPanel();
                renderHub();
                /* Every group the panel is about to show, or "nothing to
                   report" would be a lie the moment a handler beside the bound
                   one carries a finding. */
                var n = (state.artifactFindings || []).length
                      + state.findings.length
                      + (state.otherFindings || []).length;
                setStatus(n === 0
                        ? 'Checked - nothing to report.'
                        : 'Checked - ' + n + ' finding' + (n === 1 ? '' : 's') + '.',
                    n === 0 ? 'good' : 'warn');
            })
            .catch(function (e) {
                setStatus('Check failed: ' + e.message, 'bad');
            });
    }

    /* Only shown once something is slow enough to be worth looking at, so the
       panel stays quiet in the normal case but names the culprit when it is not. */
    function fmtMs(v) { return (v === null || v === undefined) ? '-' : v + 'ms'; }

    function timingSuffix() {
        var t = state.timing;
        var parts = [];
        if (t.sig !== null && t.sig >= 50) { parts.push('dom ' + t.sig + 'ms'); }
        if (t.model !== null && t.model >= 200) { parts.push('model ' + t.model + 'ms'); }
        if (t.check !== null && t.check >= 300) { parts.push('check ' + t.check + 'ms'); }
        return parts.length ? '  ·  ' + parts.join(' ') : '';
    }

    /* Rule id, the checklist cell it came from, and whether it is policy yet.
     *
     * The locator is the point: a developer who disagrees with a finding can go
     * and read the row it came from rather than argue with the tool. Rules that
     * are ours rather than the checklist's say so instead of citing a cell. */
    function provenanceOf(f) {
        if (f.source && f.source.locator === 'designer') {
            return 'Process Designer validation  ·  not a house rule';
        }
        var parts = [f.ruleId];
        if (f.source && f.source.locator && f.source.locator !== 'house') {
            parts.push('checklist ' + f.source.locator);
        } else {
            parts.push('house rule');
        }
        if (f.lifecycle === 'draft') { parts.push('draft - not yet policy'); }
        if (f.enforcement === 'auto-fixable') { parts.push('auto-fixable'); }
        return parts.join('  ·  ');
    }

    /* ----------------------------------------------------------------- init */

    function checkBrain() {
        brainFetch('/api/status').then(function (s) {
            var r = s.rules || {};
            var problems = (r.problems || []).length;
            $('brainStatus').textContent = (r.total || 0) + ' rules ('
                + (r.buffer || 0) + ' buffer, ' + (r.artifact || 0) + ' artifact, '
                + (r.manual || 0) + ' for review)'
                + (s.user ? '  ·  ' + s.user : '')
                + (problems ? '  ·  ' + problems + ' rule problem(s)' : '');
            $('brainStatus').className = 'status ' + (problems ? 'warn' : 'good');
        }).catch(function (e) {
            $('brainStatus').textContent = 'Rule engine unreachable'
                + (state.brain ? ' at ' + state.brain : '') + ' - ' + e.message;
            $('brainStatus').className = 'status bad';
        });
    }

    $('branchRef').value = state.branchRef;
    $('brainUrl').value = state.brain;
    $('minSev').value = state.minSeverity;

    $('brainUrl').addEventListener('change', function () {
        state.brain = this.value.trim();
        localStorage.setItem('baw-brain', state.brain);
        checkBrain();
    });
    $('minSev').addEventListener('change', function () {
        state.minSeverity = this.value;
        localStorage.setItem('baw-min-sev', state.minSeverity);
        if (state.watching) { runLint(); }
    });
    $('launch').addEventListener('click', launchDesigner);
    /* Not `startWatching` directly: the click handler would pass the Event as
       `auto`, and an Event is truthy - so a manual Watch would be treated as
       the poll's own re-attach and never clear the Stop flag. */
    $('watch').addEventListener('click', function () { startWatching(false); });
    $('stop').addEventListener('click', stopWatching);
    /* Was runLint() alone, which re-linted the buffer and left the artifact
       findings untouched - so "Re-check now" did not re-check the artifact. */
    $('lintOnce').addEventListener('click', function () { validateNow(); });
    $('dock').addEventListener('click', function () { ensurePanel(); renderPanel(); });

    /* Artifact rules need their own trigger.
     *
     * Watch binds a ModelChanged listener to the *code editor*, so it fires when
     * a script is typed - and never when a step is added to the diagram or a
     * variable to the signature. Those are exactly the changes the signature and
     * structure rules care about, which left them needing a manual press.
     *
     * So poll a cheap shape signature instead: artifact, step count, surface. It
     * costs one DOM read, catches every structural edit, and runs whether or not
     * the developer has pressed Watch - a service with fourteen inputs is worth
     * saying so about before anyone opens a script. */
    var lastSignature = null;
    var pendingSignature = null;
    var lastSurfaceSignature = null;
    var pendingSurfaceSignature = null;
    var lastDesignerKey = null;
    var lastSaveSignal = null;
    var checkInFlight = false;
    var checkQueued = false;
    var saveHooked = false;

    /* One entry point for all three triggers, so none of them can race the
       others. A trigger that arrives mid-check is remembered and replayed
       rather than dropped - a save landing during a check must not be the one
       that goes unvalidated. */
    function runArtifactCheck() {
        if (checkInFlight) { checkQueued = true; return; }
        checkInFlight = true;
        var t0 = now();
        checkArtifact()
            .then(function () { renderPanel(); renderHub(); })
            .catch(function () { /* already surfaced by checkArtifact */ })
            .then(function () {
                state.timing.check = Math.round(now() - t0);
                checkInFlight = false;
                if (checkQueued) { checkQueued = false; runArtifactCheck(); }
            });
    }

    setInterval(function () {
        if (!B.isAlive()) {
            if (lastSignature !== 'dead') {
                lastSignature = 'dead';
                saveHooked = false;
                renderHub();
            }
            return;
        }

        /* The save hook lives on a Designer widget, so it has to be re-bound
           after the Designer is opened - and again if it is ever rebuilt. */
        if (!saveHooked) {
            saveHooked = B.onSave(function () {
                /* 'good', not 'ok': app.css styles good/warn/bad, so an 'ok'
                   class left the save notice unstyled. */
                setStatus('Saved - re-checking the artifact.', 'good');
                runArtifactCheck();
            });
        }

        /* A save through Ctrl+S or the Designer's own autosave never reaches the
           onClick hook, so the indicator is the only notice we get - and the
           cached model is a commit out of date the moment it moves. */
        var save = B.saveSignal();
        if (lastSaveSignal !== null && save !== lastSaveSignal) {
            B.invalidateModel();
        }
        lastSaveSignal = save;

        var tSig = now();
        var sig = B.shapeSignature();
        var surfSig = B.surfaceSignature();
        state.timing.sig = Math.round(now() - tSig);

        /* The Designer's validator runs on its own schedule, not ours.
         *
         * Reading its findings once, straight after our lint, misses them
         * entirely: IBM debounces its validation, so at that moment the model
         * holds only our annotations and its parse errors arrive a beat later.
         * Verified live - the model carried "Parsing error: Unexpected token {"
         * while the panel showed nothing.
         *
         * So poll it. Iterating the annotation model is a cheap in-memory walk
         * and the panel is only rebuilt when the set actually changes. */
        if (state.lastSense && state.lastSense.surface) {
            var found = B.readDesignerFindings(state.lastSense.surface);
            var key = found.map(function (f) { return f.line + ':' + f.message; }).join('|');
            if (key !== lastDesignerKey) {
                lastDesignerKey = key;
                state.designerFindings = found;
                renderPanel();
                renderHub();
            }
        }

        /* The live buffer moved even though the artifact did not - a different
           script task on the same service flow. The artifact findings are still
           correct; the code findings are not. Re-bind and re-lint only. */
        if (surfSig !== lastSurfaceSignature) {
            if (surfSig !== pendingSurfaceSignature) {
                pendingSurfaceSignature = surfSig;   /* let the editor settle */
            } else {
                lastSurfaceSignature = surfSig;
                pendingSurfaceSignature = null;
                state.lastSense = B.sense();

                /* Drop the previous buffer's findings before anything else.
                   They describe a script the developer is no longer looking at,
                   and leaving them up while the new lint runs - or when the new
                   node has no script at all - is how "it kept showing the old
                   validations" happens. */
                state.findings = [];
                state.designerFindings = [];
                /* Cleared with the rest, and the signature with them: the new
                   surface set has to be linted, not assumed unchanged because
                   the previous one happened to look the same. */
                state.otherFindings = [];
                state.otherKey = null;
                lastDesignerKey = null;
                state.lastLintMs = null;

                if (state.lastSense.surface
                        && (!state.autoWatchOff || state.watching)) {
                    startWatching(true);             /* re-binds, then re-lints */
                } else {
                    state.watching = false;
                    renderPanel();
                    renderHub();
                }
            }
        }

        if (sig === lastSignature) { pendingSignature = null; return; }

        /* Wait for the Designer to settle before doing any work.
         *
         * Opening or switching an artifact is not one event. The Designer tears
         * the old editor down and builds a new one, so for a second or two the
         * signature churns through intermediate states - surfaces appear and
         * disappear, the diagram reports a rising step count as it renders, the
         * variable tree arrives late. Acting on each of those meant a full
         * artifact check AND a re-lint per intermediate state: several REST
         * round trips and several annotation repaints for a single switch,
         * with only the last one describing the artifact the developer is
         * actually looking at.
         *
         * One tick of stability is enough to tell a settled editor from one
         * still being built, and it costs a single poll interval. */
        if (sig !== pendingSignature) {
            pendingSignature = sig;
            renderHub();          /* show it moved; do no expensive work yet */
            return;
        }

        lastSignature = sig;
        pendingSignature = null;

        state.lastSense = B.sense();
        renderHub();

        /* The checklist follows the artifact TYPE, so it only reloads when the
           type changes - opening a second coach view does not refetch it. */
        if (state.lastSense && state.lastSense.editorType) {
            loadChecklist(state.lastSense.editorType);
        }

        /* Re-binding the code watcher is NOT done here. The surface signature
           above owns that, and it fires whenever the live buffer moves -
           including on an artifact switch, when both signatures change. Doing
           it in both places lint the same buffer twice per switch. */

        /* Artifact rules run on open, on change and on save - watching or not.
           Watch is about the code buffer; these are about the artifact. */
        runArtifactCheck();

        /* 500 ms, not 1500.
         *
         * The settle window above costs one interval, so a slow poll would make
         * switching artifacts feel worse, not better. A short interval with the
         * memoised DOM reads is both cheaper per tick than the old 1500 ms poll
         * and roughly three times more responsive: a switch now settles in about
         * a second instead of waiting out a long tick. */
    }, 500);

    checkBrain();
    renderHub();
}());

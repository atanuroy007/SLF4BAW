/* The rule manager: browse and author away from any one artifact.
 *
 * Where the tester answers "is this rule any good on THIS code", the manager
 * answers "what do we enforce, and which drafts have earned promotion". No
 * Designer is involved - a rule is tried here against a pasted snippet, which
 * is enough for authoring but deliberately not enough to trust. Anything that
 * matters gets tried in the tester, on real code.
 *
 * Policy rules are shown but not editable. That is not a missing feature: they
 * change by editing the WAR and redeploying, and that redeploy is what gives a
 * standard an author, a review and a date. Editing one here offers to start a
 * draft from it instead.
 */
(function () {
    'use strict';

    var $ = function (id) { return document.getElementById(id); };
    var API = (config.contextPath || '') + '/api';

    var state = {
        rules: [],
        selected: null,      /* the full rule being edited */
        editable: false,
        verdict: null,
        dirty: false
    };

    function el(tag, attrs) {
        var n = document.createElement(tag);
        attrs = attrs || {};
        Object.keys(attrs).forEach(function (k) {
            if (k === 'class') { n.className = attrs[k]; }
            else if (k.slice(0, 2) === 'on') { n.addEventListener(k.slice(2), attrs[k]); }
            else if (attrs[k] !== null && attrs[k] !== false) { n.setAttribute(k, attrs[k]); }
        });
        for (var i = 2; i < arguments.length; i++) {
            var c = arguments[i];
            if (c === null || c === undefined || c === false) { continue; }
            n.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
        }
        return n;
    }

    function api(path, body, method) {
        var opts = { method: method || (body ? 'POST' : 'GET'), headers: {} };
        if (body) {
            opts.headers['Content-Type'] = 'application/json';
            opts.body = JSON.stringify(body);
        }
        return fetch(API + path, opts).then(function (r) {
            if (!r.ok) {
                return r.json().catch(function () { return {}; }).then(function (d) {
                    throw new Error(d.detail || (r.status + ' ' + r.statusText));
                });
            }
            return r.json();
        });
    }

    function say(msg, kind) {
        var n = $('summary');
        n.textContent = msg;
        n.className = 'status ' + (kind || '');
    }

    /* ------------------------------------------------------------- the list */

    function matches(r) {
        var q = $('q').value.trim().toLowerCase();
        if ($('fKind').value && r.kind !== $('fKind').value) { return false; }
        if ($('fLife').value && r.lifecycle !== $('fLife').value) { return false; }
        if ($('fSev').value && r.severity !== $('fSev').value) { return false; }
        if (!q) { return true; }
        var hay = (r.id + ' ' + (r.name || '') + ' ' + (r.category || '') + ' '
                 + ((r.source && r.source.locator) || '')).toLowerCase();
        return hay.indexOf(q) >= 0;
    }

    function renderList() {
        var list = $('list');
        list.innerHTML = '';
        var shown = state.rules.filter(matches);

        shown.forEach(function (r) {
            var tags = [];
            tags.push(el('span', { class: 'rm-tag ' + (r.lifecycle === 'draft' ? 'draft' : 'policy') },
                r.lifecycle === 'draft' ? 'draft' : 'policy'));
            /* Saved drafts are the only editable ones; the list should say so
               rather than making you click to find out. */
            if (r.editable) {
                tags.push(el('span', { class: 'rm-tag ok' }, 'saved'));
            }
            /* Only meaningful for rules that carry examples; saying nothing is
               better than a green tick that means "we did not check". */
            if (r.verified === true) {
                tags.push(el('span', { class: 'rm-tag ok' }, 'verified'));
            } else if (r.examplesFailing > 0) {
                tags.push(el('span', { class: 'rm-tag bad' }, r.examplesFailing + ' failing'));
            }

            var meta = [r.kind, r.severity];
            if (r.source && r.source.locator && r.source.locator !== 'house') {
                meta.push(r.source.locator);
            }

            var row = el('div', {
                class: 'rm-row ' + r.severity + (state.selected && state.selected.id === r.id ? ' sel' : ''),
                onclick: function () { open(r.id); }
            },
                el('div', { class: 'rm-id' }, r.id),
                el('div', { class: 'rm-meta' }, meta.join('  ·  ')));
            tags.forEach(function (t) { row.appendChild(t); });
            list.appendChild(row);
        });

        if (!shown.length) {
            list.appendChild(el('div', { class: 'muted', style: 'padding:12px' },
                'Nothing matches those filters.'));
        }
        $('count').textContent = shown.length + ' of ' + state.rules.length;
    }

    /* ----------------------------------------------------------- the editor */

    function blank() {
        return {
            id: 'DRAFT.', kind: 'buffer', name: '', category: 'custom',
            severity: 'minor', lifecycle: 'draft', appliesTo: ['javascript'],
            pattern: '', notWhen: '', guardLines: 0, scanComments: false,
            message: '', rationale: '', remediation: '',
            examples: { fires: [], quiet: [] }
        };
    }

    function open(id) {
        api('/rules/' + encodeURIComponent(id)).then(function (d) {
            state.selected = d.rule;
            state.editable = d.editable;
            state.inWar = d.inWar;
            state.verdict = d.examples;
            state.dirty = false;
            renderList();
            renderEditor();
        }).catch(function (e) { say('Could not load ' + id + ': ' + e.message, 'bad'); });
    }

    function newDraft(from) {
        var r = from ? JSON.parse(JSON.stringify(from)) : blank();
        if (from) {
            /* Starting from policy: a new id, and the source locator dropped -
               it cites a checklist row this copy has not been reviewed against. */
            r.id = 'DRAFT.' + from.id.replace(/^HOUSE\./, '');
            r.lifecycle = 'draft';
            delete r.source;
        }
        state.selected = r;
        state.editable = true;
        state.verdict = null;
        state.dirty = true;
        renderList();
        renderEditor();
    }

    function lines(v) {
        return (v || '').split('\n---\n').filter(function (s) { return s.trim() !== ''; });
    }
    function unlines(a) { return (a || []).join('\n---\n'); }

    function field(label, value, onInput, opts) {
        opts = opts || {};
        var input;
        if (opts.options) {
            input = el('select');
            opts.options.forEach(function (o) {
                var op = el('option', { value: o }, o);
                if (o === value) { op.selected = true; }
                input.appendChild(op);
            });
        } else if (opts.rows) {
            input = el('textarea', { rows: opts.rows });
            input.value = value || '';
        } else {
            input = el('input', { type: 'text' });
            input.value = (value === null || value === undefined) ? '' : value;
        }
        if (!state.editable) { input.disabled = true; }
        if (opts.placeholder) { input.placeholder = opts.placeholder; }
        input.addEventListener('input', function () {
            state.dirty = true;
            onInput(input.value);
            var st = $('editorState');
            if (st && state.editable) { st.textContent = 'draft — unsaved changes'; }
        });
        input.addEventListener('change', function () { state.dirty = true; onInput(input.value); });
        return el('div', null, el('label', null, label), input);
    }

    function renderEditor() {
        var box = $('editor');
        box.innerHTML = '';
        $('verdict').innerHTML = '';

        var r = state.selected;
        if (!r) {
            $('editorTitle').textContent = 'No rule selected';
            $('editorState').textContent = '';
            box.appendChild(el('p', { class: 'muted' },
                'Pick a rule on the left, or start a new draft.'));
            box.appendChild(el('div', { class: 'rm-actions' },
                el('button', { class: 'btn primary', onclick: function () { newDraft(null); } },
                    'New draft rule')));
            return;
        }

        $('editorTitle').textContent = r.id;
        /* Two different read-only reasons, and conflating them misleads. A
           rule can be lifecycle:draft and still ship in the WAR - most of ours
           do - in which case it is every bit as read-only as policy here. */
        /* "saved" must not be claimed for a draft that has never been written -
           the label is the only thing telling the author whether their work is
           safe to navigate away from. */
        $('editorState').textContent = !state.editable
            ? (r.lifecycle === 'draft' ? 'draft, in the WAR — read-only'
                                       : 'policy — read-only')
            : (state.dirty ? 'draft — unsaved changes' : 'saved draft — editable');

        if (!state.editable) {
            box.appendChild(el('p', { class: 'muted' },
                'This rule ships in the WAR, so it changes by editing '
                + 'WEB-INF/rules and redeploying — whatever its lifecycle. That '
                + 'redeploy is what gives it a reviewer and a date. To '
                + 'experiment, start a draft from it under a new id.'));
        }

        box.appendChild(field('rule id', r.id, function (v) { r.id = v; }));
        box.appendChild(field('name', r.name, function (v) { r.name = v; }));

        var two = el('div', { class: 'rm-two' });
        two.appendChild(field('kind', r.kind, function (v) { r.kind = v; renderEditor(); },
            { options: ['buffer', 'artifact'] }));
        two.appendChild(field('severity', r.severity, function (v) { r.severity = v; },
            { options: ['critical', 'major', 'minor', 'warning'] }));
        box.appendChild(two);

        box.appendChild(field('appliesTo  (comma separated)',
            (r.appliesTo || []).join(', '),
            function (v) {
                r.appliesTo = v.split(',').map(function (s) { return s.trim(); })
                    .filter(function (s) { return s; });
            }));

        if (r.kind === 'artifact') {
            box.appendChild(field('check  (JSON)',
                typeof r.check === 'string' ? r.check : JSON.stringify(r.check || {}, null, 2),
                function (v) { r.checkText = v; }, { rows: 8 }));
        } else {
            box.appendChild(field('pattern', r.pattern, function (v) { r.pattern = v; },
                { rows: 3, placeholder: 'Java regular expression' }));
            var g = el('div', { class: 'rm-two' });
            g.appendChild(field('notWhen', r.notWhen, function (v) { r.notWhen = v; },
                { placeholder: '{1} is capture group 1' }));
            g.appendChild(field('guardLines', r.guardLines, function (v) { r.guardLines = v; }));
            box.appendChild(g);
            box.appendChild(field('scanComments', r.scanComments ? 'true' : 'false',
                function (v) { r.scanComments = (v === 'true'); },
                { options: ['false', 'true'] }));
        }

        box.appendChild(field('message', r.message, function (v) { r.message = v; }));
        box.appendChild(field('rationale  (why the standard exists)', r.rationale,
            function (v) { r.rationale = v; }, { rows: 3 }));
        box.appendChild(field('remediation  (what to do about it)', r.remediation,
            function (v) { r.remediation = v; }, { rows: 3 }));

        var ex = r.examples || { fires: [], quiet: [] };
        box.appendChild(field('must FIRE on   (separate with ---)', unlines(ex.fires),
            function (v) { ex.fires = lines(v); r.examples = ex; }, { rows: 4 }));
        box.appendChild(field('must stay QUIET on   (separate with ---)', unlines(ex.quiet),
            function (v) { ex.quiet = lines(v); r.examples = ex; }, { rows: 4 }));

        box.appendChild(field('try it against   (a snippet, not saved)', state.trySnippet || '',
            function (v) { state.trySnippet = v; }, { rows: 3,
                placeholder: 'paste code here and press Verify' }));

        var actions = el('div', { class: 'rm-actions' });
        actions.appendChild(el('button', { class: 'btn primary', onclick: verify }, 'Verify'));
        if (state.editable) {
            actions.appendChild(el('button', { class: 'btn', onclick: save }, 'Save draft'));
            actions.appendChild(el('button', { class: 'btn', onclick: remove }, 'Delete draft'));
        } else {
            actions.appendChild(el('button', { class: 'btn',
                onclick: function () { newDraft(r); } }, 'Start a draft from this'));
        }
        actions.appendChild(el('button', { class: 'btn', onclick: function () { newDraft(null); } },
            'New draft'));
        actions.appendChild(el('button', { class: 'btn', onclick: exportAll }, 'Export all'));
        box.appendChild(actions);

        renderVerdict();
    }

    /* --------------------------------------------------------------- verify */

    function payload() {
        var r = state.selected;
        var out = JSON.parse(JSON.stringify(r));
        if (r.kind === 'artifact' && r.checkText !== undefined) {
            try { out.check = JSON.parse(r.checkText); delete out.checkText; }
            catch (e) { return { __error: 'check is not valid JSON: ' + e.message }; }
        }
        delete out.checkText;
        return out;
    }

    function verify() {
        var rule = payload();
        if (rule.__error) { say(rule.__error, 'bad'); return; }
        var body = { rule: rule };
        if (state.trySnippet) { body.code = state.trySnippet; }
        api('/try', body).then(function (d) {
            state.verdict = d.ok ? d.examples : { error: d.error };
            state.tryFindings = d.findings || [];
            if (!d.ok) { say(d.error, 'bad'); }
            else if ((d.examples || {}).failed) {
                say((d.examples.failed) + ' example(s) failed', 'bad');
            } else if (d.promotable) {
                say('Examples pass. This rule could be promoted.', 'good');
            } else {
                say('Examples incomplete — needs at least one of each to be promotable.', 'warn');
            }
            renderVerdict();
        }).catch(function (e) { say('Verify failed: ' + e.message, 'bad'); });
    }

    function renderVerdict() {
        var box = $('verdict');
        box.innerHTML = '';
        var v = state.verdict;
        if (!v) { return; }
        if (v.error) {
            box.appendChild(el('div', { class: 'check fail' }, v.error));
            return;
        }
        (v.cases || []).forEach(function (c) {
            box.appendChild(el('div', { class: 'check ' + (c.passed ? 'skip' : 'fail') },
                (c.passed ? '✓ ' : '✗ ') + 'expected ' + c.expected + ', got ' + c.actual
                + '   ' + c.snippet.replace(/\n/g, ' ↵ ')));
        });
        (state.tryFindings || []).forEach(function (f) {
            box.appendChild(el('div', { class: 'check warn' },
                'snippet L' + f.line + '  ' + f.message));
        });
    }

    /* ------------------------------------------------------------ save/load */

    function save() {
        var rule = payload();
        if (rule.__error) { say(rule.__error, 'bad'); return; }
        api('/rules/save', { rule: rule }).then(function (d) {
            state.dirty = false;
            say('Saved ' + d.saved
                + ((d.examples || {}).verified ? ' — examples pass'
                    : ' — examples incomplete, so it cannot be promoted yet'),
                (d.examples || {}).verified ? 'good' : 'warn');
            return refresh().then(function () { open(d.saved); });
        }).catch(function (e) { say('Not saved: ' + e.message, 'bad'); });
    }

    function remove() {
        var id = state.selected && state.selected.id;
        if (!id) { return; }
        api('/rules/delete', { id: id }).then(function (d) {
            say(d.deleted ? 'Deleted ' + id : 'No draft called ' + id, '');
            state.selected = null;
            state.verdict = null;
            return refresh().then(renderEditor);
        }).catch(function (e) { say('Not deleted: ' + e.message, 'bad'); });
    }

    /* Export is how a draft becomes policy: take this file, commit it, redeploy.
       Downloaded rather than shown, because the next step is a text editor and
       a commit, not reading it in a browser. */
    function exportAll() {
        api('/rules/export', {}).then(function (doc) {
            var blob = new Blob([JSON.stringify(doc, null, 2)], { type: 'application/json' });
            var a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'house-rules.json';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(a.href);
            say('Exported ' + doc.rules.length + ' rules. Commit it over '
                + 'WEB-INF/rules/house-rules.json and redeploy to make drafts policy.', 'good');
        }).catch(function (e) { say('Export failed: ' + e.message, 'bad'); });
    }

    function refresh() {
        return api('/rules').then(function (d) {
            state.rules = d.rules || [];
            var drafts = 0, verified = 0;
            state.rules.forEach(function (r) {
                if (r.lifecycle === 'draft') { drafts++; }
                if (r.verified) { verified++; }
            });
            say(state.rules.length + ' rules — ' + (state.rules.length - drafts)
                + ' policy, ' + drafts + ' draft, ' + verified + ' verified against their examples',
                '');
            if ((d.problems || []).length) {
                say(state.rules.length + ' rules, but ' + d.problems.length
                    + ' problem(s): ' + d.problems.join('; '), 'warn');
            }
            renderList();
        });
    }

    /* ------------------------------------------------------------------ init */

    ['q', 'fKind', 'fLife', 'fSev'].forEach(function (id) {
        $(id).addEventListener('input', renderList);
        $(id).addEventListener('change', renderList);
    });

    /* A half-written draft is easy to lose by clicking away; the browser's own
       prompt is enough and does not need a modal of our own. */
    window.addEventListener('beforeunload', function (e) {
        if (state.dirty) { e.preventDefault(); e.returnValue = ''; }
    });

    refresh().then(renderEditor)
        .catch(function (e) { say('Rule engine unreachable — ' + e.message, 'bad'); });
}());

/* BawBridge - everything that runs against the Process Designer window.
 *
 * The hub opens the Designer with window.open and, because both pages are on
 * the BAW origin, can reach straight into it. This module is the only place
 * that knows Designer internals; the hub above it deals in artifacts and
 * findings.
 *
 * Every non-obvious line here is a verified finding, not a guess. The ones that
 * cost the most to learn:
 *
 *   - A hidden ddformSection returns "" from getValue(). It discards reads as
 *     well as writes, so a DOM survey of all nine surfaces reports eight empty
 *     ones that are not empty at all.
 *   - widget.editorObj is the real Orion editor. widget.editor is an
 *     HTMLDivElement, and the wrapper's addAnnotation accepts every shape
 *     without throwing, which makes it useless as a contract.
 *   - Annotation types must be registered on styler AND ruler BEFORE the
 *     annotation is added, or it lands in the model and never renders.
 *   - model.removeAnnotations() with no argument does not clear.
 *   - Nothing repaints without redrawLines().
 *   - The edit event is ModelChanged. Modify never fires, despite onModify
 *     existing as a method.
 *   - Type registration lives on the editor instance and dies with it. The
 *     Designer builds a new editor per artifact and per surface, so caching
 *     "already registered" leaves annotations in the model and invisible.
 *   - The Designer's own validator shares this annotation model and wipes
 *     EVERY annotation on each edit, ours included. Hence the watchdog.
 *   - Every code surface in the product ends its data-test-attr with
 *     ".jseditor", in coach views and service flows alike, so surfaces are
 *     discovered rather than enumerated.
 *   - Service flow scripts belong to the SELECTED DIAGRAM NODE, not the
 *     artifact. Reporting artifact-level context there is simply wrong.
 */
(function (global) {
    'use strict';

    /* Every code surface in the product ends its data-test-attr with
       ".jseditor", in both the coach view editor and the service flow editor.
       That one convention means surfaces can be discovered rather than
       enumerated, so a new editor type costs a LANGUAGE entry, not a rewrite. */
    var JSEDITOR_SELECTOR = '[data-test-attr$=".jseditor"]';

    /* An INLINE event handler's editor carries data-test-attr="jseditor" -
     * exactly that, with no name in front of it.
     *
     * The selector above needs a dot-prefixed name, so every one of these was
     * invisible: the panel reported "no surface" while a 36-line On load
     * handler was on screen, and a `debugger` two lines into another went
     * unreported. Probed live on 2026-08-31 against the "Sent to Admin"
     * client-side human service, which shows three at once - Title formula,
     * On load, On icon click.
     *
     * They are told apart by the LABEL beside them, because the widget id is a
     * Dojo uniqName_N_M that changes whenever the Designer rebuilds the panel.
     * The label is what the developer sees, and it is stable. */
    var BARE_JSEDITOR = '[data-test-attr="jseditor"]';

    /* Prefixed so a labelled surface can never collide with a named one, and
       so anything reading a surface name can tell which kind it has. */
    var EVENT_SURFACE = 'event:';

    /* The label in the editor's row - "On load:" becomes "On load". */
    function editorLabel(node) {
        var row = node;
        while (row && row.tagName !== 'TR') { row = row.parentElement; }
        if (!row) { return ''; }
        var cell = row.querySelector('td');
        var text = cell ? (cell.textContent || '') : '';
        return text.replace(/\s+/g, ' ').replace(/:\s*$/, '').trim();
    }

    var LANGUAGE = {
        /* Coach view - nine surfaces, reached through the Behavior tree. */
        inlineJavaScript: 'javascript',
        inlineCSS: 'css',
        headerHTML: 'html',
        eventHandlersLoad: 'javascript',
        eventHandlersView: 'javascript',
        eventHandlersChange: 'javascript',
        eventHandlersUnload: 'javascript',
        eventHandlersValidate: 'javascript',
        eventHandlersCollaboration: 'javascript',

        /* Service flow - per diagram node, reached through Properties >
           Implementation. Pre/post assignment scripts hang off activities
           generally, not only script tasks, which makes them a common place for
           logic to hide two tabs deep. */
        Script: 'javascript',
        preAssignmentScript: 'javascript',
        postAssignmentScript: 'javascript'
    };

    /* Kept for callers that want the known set; discovery is preferred. */
    var SURFACES = (function () {
        var out = [];
        for (var k in LANGUAGE) {
            if (Object.prototype.hasOwnProperty.call(LANGUAGE, k)) { out.push(k); }
        }
        return out;
    }());

    /* Surfaces actually present in the DOM right now, in document order. */
    function discoverSurfaces() {
        var d = doc();
        var out = [];
        if (!d) { return out; }
        /* Both scopes - the editor for coach views, the Properties panel for
           service flows. See surfaceScopes(). */
        surfaceScopes().forEach(function (scope) {
            var nodes = scope.querySelectorAll(JSEDITOR_SELECTOR);
            for (var i = 0; i < nodes.length; i++) {
                var attr = nodes[i].getAttribute('data-test-attr') || '';
                var name = attr.slice(0, attr.length - '.jseditor'.length);
                if (name && out.indexOf(name) < 0) { out.push(name); }
            }
            /* The inline event handlers, named by their label. */
            var bare = scope.querySelectorAll(BARE_JSEDITOR);
            for (var j = 0; j < bare.length; j++) {
                var label = editorLabel(bare[j]);
                if (!label) { continue; }
                var surface = EVENT_SURFACE + label;
                if (out.indexOf(surface) < 0) { out.push(surface); }
            }
        });
        return out;
    }

    function languageOf(surface) {
        return LANGUAGE[surface] || 'javascript';
    }

    var ANNOTATION_TYPE = {
        critical: 'orion.annotation.error',
        major: 'orion.annotation.error',
        minor: 'orion.annotation.warning',
        warning: 'orion.annotation.warning'
    };
    var CSS_KIND = { critical: 'error', major: 'error', minor: 'warning', warning: 'warning' };

    /* The docked panel's id. Parameterised because the assistant and the rule
       tester are separate pages that can both be pointed at one Designer; two
       panes sharing an id would silently hand the second one the first's
       node. */
    var PANEL_ID = 'bawAssistantPanel';
    var panelId = PANEL_ID;

    /** Choose which panel this page owns. Call before dockPanel. */
    function usePanel(id) { panelId = id || PANEL_ID; }

    var win = null;
    var watchHandle = null;

    function doc() { return win && !win.closed ? win.document : null; }

    /* ------------------------------------------------------------- lifecycle */

    function attach(w) { win = w; desired = null; removeWatchdog(); return isAlive(); }

    function isAlive() {
        if (!win || win.closed) { return false; }
        try { return !!win.document && typeof win.dijit !== 'undefined'; }
        catch (e) { return false; }   /* cross-origin: should not happen, but be honest */
    }

    function ready() {
        /* dijit appears well before the Designer is usable; the Library pane
           having width is the signal that the WorkflowCenter parameter took
           effect and navigation is possible. */
        if (!isAlive()) { return false; }
        try {
            var lead = win.dijit.byId('mainContainer_leading');
            return !!lead && lead.domNode.getBoundingClientRect().width > 0;
        } catch (e) { return false; }
    }

    /* --------------------------------------------------------------- sensing */

    /* Editors accumulate in the DOM - AppSettings, CaseProcess and CoachView can
       all be present at once. Always take the visible one, never .last() blindly
       and never the first match. */
    function visibleEditor() {
        var d = doc();
        if (!d) { return null; }
        var all = d.querySelectorAll('[data-test-editor]');
        for (var i = all.length - 1; i >= 0; i--) {
            if (all[i].offsetParent !== null) { return all[i]; }
        }
        return null;
    }

    /* Where code surfaces can live. There are two places, and using only the
     * first made every service flow script invisible to the linter.
     *
     * A coach view keeps its nine surfaces INSIDE its [data-test-editor]
     * element, so scoping there is right - and necessary, because editors
     * accumulate in the DOM and an unscoped query happily reads a hidden one.
     *
     * A service flow does not. Its script surfaces belong to the selected
     * diagram node, so they render in the Properties panel, which is a SIBLING
     * of the editor rather than a descendant. Verified live: the ancestor chain
     * of Script.jseditor runs
     *     #uniqName_N -> #propertiesPaneDiv -> #editorContainer_bottom
     *     -> #editorContainer -> #mainContainer
     * and passes through no [data-test-editor] at all. Scoped to the visible
     * editor the query returned zero surfaces, sense() reported "no surface",
     * and Watch had nothing to lint - silently, because zero surfaces looks
     * exactly like a node with no script.
     *
     * #editorContainer_bottom is safe to add: there is exactly one in the
     * document and it is bound to the active editor's selection, so unlike the
     * editor elements it cannot serve up a background artifact's code.
     */
    function surfaceScopes() {
        var d = doc();
        if (!d) { return []; }
        var scopes = [];
        var ed = visibleEditor();
        if (ed) { scopes.push(ed); }
        var props = d.getElementById('editorContainer_bottom');
        if (props && props.offsetParent !== null) { scopes.push(props); }
        return scopes.length ? scopes : [d];
    }

    /* Surface lookups are memoised for a fraction of a second.
     *
     * sense() runs four or five times per poll tick - the signature needs it,
     * the hub asks for it again, renderHub asks a third time, and re-binding the
     * watcher asks a fourth. Each pass re-queried every surface TWICE, once for
     * surfaceDisplayed and once for surfaceOnScreen. On a coach view with nine
     * surfaces that is ~36 querySelectorAll and nine forced layouts per pass,
     * repeated four times, against a very large Dojo DOM.
     *
     * offsetParent and getComputedStyle both force synchronous layout, so this
     * is not merely redundant work - it is the expensive kind. A 250 ms memo
     * collapses one tick's worth of passes into a single set of reads while
     * staying far shorter than the 1500 ms poll, so nothing goes stale. */
    var hostMemo = {};
    var charMemo = {};
    var hostMemoAt = 0;
    var HOST_MEMO_MS = 250;

    function memoReset() { hostMemo = {}; charMemo = {}; hostMemoAt = Date.now(); }

    function memoFresh() { return (Date.now() - hostMemoAt) < HOST_MEMO_MS; }

    function surfaceHost(name) {
        if (!memoFresh()) { memoReset(); }
        if (Object.prototype.hasOwnProperty.call(hostMemo, name)) {
            return hostMemo[name];
        }
        var found = surfaceHostUncached(name);
        hostMemo[name] = found;
        return found;
    }

    function surfaceHostUncached(name) {
        var scopes = surfaceScopes();
        var i, j, nodes;

        /* A labelled surface is matched on its label, not on an attribute:
           these editors all share data-test-attr="jseditor" and their widget
           ids are regenerated whenever the Designer rebuilds the panel. */
        if (String(name).indexOf(EVENT_SURFACE) === 0) {
            var wanted = String(name).slice(EVENT_SURFACE.length);
            for (i = scopes.length - 1; i >= 0; i--) {
                nodes = scopes[i].querySelectorAll(BARE_JSEDITOR);
                for (j = nodes.length - 1; j >= 0; j--) {
                    if (editorLabel(nodes[j]) === wanted) { return nodes[j]; }
                }
            }
            return null;
        }

        var sel = '[data-test-attr="' + name + '.jseditor"]';
        /* Last match wins, and the Properties panel is searched last, because
           on a service flow it holds the surface the developer is actually in. */
        for (var i = scopes.length - 1; i >= 0; i--) {
            var nodes = scopes[i].querySelectorAll(sel);
            if (nodes.length) { return nodes[nodes.length - 1]; }
        }
        return null;
    }

    function surfaceWidget(name) {
        var host = surfaceHost(name);
        if (!host) { return null; }
        try { return win.dijit.byId(host.getAttribute('widgetid') || host.id) || null; }
        catch (e) { return null; }
    }

    /* Can this surface's buffer be READ?
     *
     * A hidden .ddformSection returns "" from getValue() - it blocks reads as
     * well as writes - so this is the test that decides whether a read is
     * trustworthy. Deliberately NOT the test for "which surface is the
     * developer in": see surfaceOnScreen. */
    function surfaceDisplayed(name) {
        var host = surfaceHost(name);
        if (!host || !host.closest) { return false; }
        var section = host.closest('.ddformSection');
        if (!section) { return true; }        /* not sectioned: always live */
        try { return win.getComputedStyle(section).display !== 'none'; }
        catch (e) { return false; }
    }

    /* Is this surface actually in front of the developer?
     *
     * On a service flow's "Pre & post" tab all three surfaces - Script,
     * preAssignmentScript, postAssignmentScript - report their ddformSection as
     * displayed, because the sections are shown and it is the TAB that hides
     * Script. Picking the first displayed one therefore returned "Script" while
     * the developer was typing into preAssignmentScript, and the assistant lint
     * the wrong buffer without any sign that it had.
     *
     * offsetParent is null for a tab-hidden element, which is exactly the
     * distinction the section test cannot make. Both tests are needed and they
     * answer different questions - do not collapse them. */
    function surfaceOnScreen(name) {
        var host = surfaceHost(name);
        if (!host) { return false; }
        try { return host.offsetParent !== null; }
        catch (e) { return false; }
    }

    /* Does the caret sit in this surface right now?
     *
     * Only meaningful when several surfaces are on screen together, which is
     * exactly the coach event case. Costs one contains() against the active
     * element and is not memoised, because focus moves between polls. */
    function surfaceFocused(name) {
        var d = doc();
        var host = surfaceHost(name);
        if (!d || !host) { return false; }
        var active = d.activeElement;
        if (!active || active === d.body) { return false; }
        try { return host === active || host.contains(active); }
        catch (e) { return false; }
    }

    /* How many characters does this surface hold, without reading it out?
     *
     * getCharCount is O(1) on the text model - surfaceSignature already relies
     * on that - so this is cheap enough to ask during sense(). Returns -1 when
     * the answer is unknown, which is NOT the same as 0: an editor we cannot
     * reach is one we also cannot lint, so nothing should switch away from a
     * surface on the strength of it.
     *
     * Memoised with the host lookups, because sense() runs four or five times
     * per poll tick and every one of them would otherwise re-enter dijit. */
    function surfaceCharCount(name) {
        if (!memoFresh()) { memoReset(); }
        if (Object.prototype.hasOwnProperty.call(charMemo, name)) {
            return charMemo[name];
        }
        var n = -1;
        try {
            var o = orion(name);
            if (o && o.textModel) { n = o.textModel.getCharCount(); }
        } catch (e) { n = -1; }
        charMemo[name] = n;
        return n;
    }

    /* Which diagram node is selected?
     *
     * A coach view's surfaces belong to the artifact. A service flow's belong to
     * the selected node - a flow with ten steps has thirty script surfaces, and
     * which one is live depends entirely on the diagram selection. Anything that
     * reports "what is being edited" has to say which node, or it is describing
     * the wrong thing. */
    function selectedNode() {
        var d = doc();
        if (!d) { return null; }

        /* The canvas marks selection nowhere reachable: after a real click the
           selected node carries no class, no aria-selected and no tabindex, and
           the SVG holds no selection overlay we can find. Reading the Properties
           panel instead is both reliable and better - it is bound to the
           selection, and flow-element-id is a stable identifier where the node
           name is just a label the developer can change. */
        var bottom = d.getElementById('editorContainer_bottom');
        if (!bottom) { return null; }

        var idNode = bottom.querySelector('[data-test-attr="flow-element-id"]');
        if (!idNode) {
            return null;   // no flow element selected - a coach view, or nothing
        }
        var id = (idNode.value || idNode.textContent || '').trim();
        if (!id) { return null; }

        var nameNode = bottom.querySelector('[data-test-attr="general-name"]');
        var name = nameNode ? (nameNode.value || nameNode.textContent || '').trim() : '';

        /* Recover the node type from the diagram, which is the only place it
           lives. Matching on name is imperfect when two steps share one, but the
           id above is what we actually key on. */
        var type = null;
        if (name) {
            var nodes = d.querySelectorAll('[data-test-activity-name]');
            for (var i = 0; i < nodes.length; i++) {
                if (nodes[i].getAttribute('data-test-activity-name') === name) {
                    type = nodes[i].getAttribute('data-test-activity-type');
                    break;
                }
            }
        }
        return { id: id, name: name || null, type: type };
    }

    /* What is the developer looking at right now? */
    function sense() {
        var ed = visibleEditor();
        var out = {
            alive: isAlive(),
            editorType: ed ? ed.getAttribute('data-test-editor') : null,
            artifactName: null,
            node: null,
            surface: null,
            language: null,
            displayedSurfaces: []
        };
        if (!ed) { return out; }

        /* common.name is the artifact; general-name is the selected node's
           label, which on a service flow is a different thing entirely. Using
           the latter reported no artifact at all. */
        out.artifactName = artifactName(ed);
        out.node = selectedNode();

        /* Discover rather than enumerate - the ".jseditor" suffix holds across
           every editor, so this finds surfaces in editors nobody has probed. */
        var onScreen = null;
        var readable = null;
        var focused = null;
        discoverSurfaces().forEach(function (name) {
            if (!surfaceDisplayed(name)) { return; }
            out.displayedSurfaces.push(name);
            if (!readable) { readable = name; }
            if (!onScreen && surfaceOnScreen(name)) { onScreen = name; }
            /* Which one is the developer actually typing in?
             *
             * A coach component shows every event handler at once - Title
             * formula, On load, On icon click all on screen together - so
             * "first displayed" picks one arbitrarily and lints the wrong
             * buffer while looking like it works. That is the same failure the
             * Pre & post tab produced, arriving from a different direction, and
             * the cursor is the only thing that settles it. */
            if (!focused && surfaceFocused(name)) { focused = name; }
        });

        /* Prefer what the developer can see. Fall back to the first readable
           surface only when nothing is on screen, so a collapsed panel still
           reports something rather than going blank. */
        out.surface = focused || onScreen || readable;

        /* An EMPTY surface must not win a tie against a sibling holding code.
         *
         * A coach component shows its event editors together and "Title
         * formula" is first in document order, so with no caret anywhere
         * onScreen picked it - and it is normally empty. readDisplayedBuffer
         * then returned "", and runLint treats an empty buffer as nothing to
         * lint: the panel ran the ARTIFACT rules only and reported that the
         * handlers were too long while saying nothing about what was in them.
         * Measured live on "Sent to Admin": Title formula 0 characters, On load
         * 1,251, On icon click 1,251, and the panel bound to the 0.
         *
         * The caret still wins whenever there is one - that preference exists
         * because a developer typing in one of several editors is unambiguous,
         * and nothing here weakens it. This only breaks the NO-caret tie
         * differently.
         *
         * Deliberately lazy. The count is asked for once, of the surface
         * already chosen, and the scan happens only when that one is empty -
         * so the common case costs a single O(1) read and the expensive case
         * is the one that was previously broken. */
        if (!focused && out.surface && surfaceCharCount(out.surface) === 0) {
            for (var i = 0; i < out.displayedSurfaces.length; i++) {
                var alt = out.displayedSurfaces[i];
                if (alt === out.surface || !surfaceOnScreen(alt)) { continue; }
                if (surfaceCharCount(alt) > 0) { out.surface = alt; break; }
            }
        }

        if (out.surface) { out.language = languageOf(out.surface); }
        return out;
    }

    /* ---------------------------------------------------------------- buffer */

    /* Only the displayed surface can be read. Committed code for every surface
       comes from REST instead - see readModel(). */
    function readDisplayedBuffer() {
        var s = sense();
        if (!s.surface) { return null; }
        var b = readSurfaceBuffer(s.surface);
        if (!b) { return null; }
        b.artifactName = s.artifactName;
        return b;
    }

    /* Read ONE named surface, whether or not it is the one bound.
     *
     * Reading a surface the caret is not in works: probed live against the
     * three event editors of "Sent to Admin", where all three returned their
     * value in a single pass. That is what makes it possible to judge every
     * handler on screen rather than only the one being typed in. */
    function readSurfaceBuffer(name) {
        var w = surfaceWidget(name);
        if (!w) { return null; }
        var text;
        try { text = w.getValue() || ''; } catch (e) { return null; }
        return { surface: name, language: languageOf(name), code: text };
    }

    /* Every surface IN FRONT OF THE DEVELOPER that holds code.
     *
     * Bounded by what is on screen, deliberately. A coach view's surfaces
     * belong to the artifact and its event editors are shown together, so all
     * of them are the developer's current concern; a service flow's surfaces
     * belong to the SELECTED NODE, and a ten-step flow has thirty of them.
     * Reporting code the developer cannot see is the whole-application
     * review's job, not the panel's - which is why this filters on
     * surfaceOnScreen (offsetParent) and not merely surfaceDisplayed.
     *
     * Empty surfaces are dropped: there is nothing to lint, and an editor
     * awaiting its first character is not a finding. */
    function readOnScreenBuffers() {
        var s = sense();
        var out = [];
        s.displayedSurfaces.forEach(function (name) {
            if (!surfaceOnScreen(name)) { return; }
            var b = readSurfaceBuffer(name);
            if (b && b.code) { out.push(b); }
        });
        return out;
    }

    /* The on-screen surfaces OTHER than the bound one, as one cheap string.
     *
     * The point is to decide whether they need re-linting without reading them
     * out. getValue() returns the whole buffer and the panel re-lints on a
     * 350 ms debounce while the developer types, so asking nine editors for
     * their text on every keystroke would be exactly the kind of per-tick cost
     * the memo above exists to avoid. getCharCount is O(1).
     *
     * The bound surface is excluded deliberately: it changes on every
     * keystroke, and including it would invalidate this signature constantly
     * and defeat the whole gate. It is linted live on its own path anyway. */
    function otherSurfacesSignature() {
        var s = sense();
        var parts = [];
        s.displayedSurfaces.forEach(function (name) {
            if (name === s.surface || !surfaceOnScreen(name)) { return; }
            parts.push(name + ':' + surfaceCharCount(name));
        });
        return parts.join('|');
    }

    /* ------------------------------------------------------ the model readers
     *
     * One endpoint serves every artifact type. /rest/bpm/wle/pd/v1/asset/{poId}
     * ignores the name in the path: the poId picks the model, and the response's
     * own `domainProperty` names the key the model arrived under. Verified live
     * across ten artifacts covering all seven editor types, so there is no table
     * of per-type endpoints to keep in step with anything.
     *
     * Everything below is deliberately DOM-free and takes a parsed body rather
     * than reaching for the Designer. That is what lets the pre-deployment .twx
     * report reuse these readers unchanged - it will have payloads and no
     * Designer window at all.
     *
     * What the probing actually found, per type, is in
     * knowledge/artifact-catalog/artifact-model-map.md.
     */

    var MODEL_ENDPOINT = '/rest/bpm/wle/pd/v1/asset/';

    /* An empty model is not the same as a model we could not read.
     *
     * A coach view genuinely has no input/output variables - the concept does
     * not exist for it - while a service flow with none really does have none.
     * Reporting both as "0 variables (as last saved)" is what made every coach
     * view look like a service with an empty signature, so each reader says
     * whether variables APPLY to its type at all. */
    function emptyModel(type) {
        return { type: type || '', name: '', variables: [], components: [],
                 settings: {}, surfaces: [], variablesApply: true };
    }

    /**
     * The process app's acronym, for the exposed-variable prefix standard.
     *
     * It belongs to a DIFFERENT artifact from the process being read, so it
     * cannot come out of the payload in hand. It is resolved once per branch
     * and held here, which keeps parseAsset synchronous and DOM-free - the
     * property the pre-deployment report depends on. When it is not known the
     * readers report null rather than guessing, so a rule can tell 'not
     * prefixed' from 'cannot say'.
     */
    var appAcronym = null;
    var acronymForRef = null;

    function setAppAcronym(a) { appAcronym = a || null; }

    /**
     * What kind of team a lane's participant is.
     *
     * A lane is a SYSTEM lane when its team's type is 'System' - confirmed
     * live: the System lane of a real process points at a team named System
     * whose extensionElements.team[0].type is 'System', while a business lane
     * points at a StandardMembers team. The lane name is not the test; a team
     * called anything can be the system team and a lane called 'System' can be
     * an ordinary one.
     *
     * Held per team id, resolved before parsing, so parseAsset stays
     * synchronous. Only the teams a lane actually references are fetched, so
     * this is one or two calls the first time and none afterwards.
     */
    var teamTypeById = {};

    function setTeamType(id, type) { teamTypeById[id] = type || null; }

    function ensureTeams(ids, ref) {
        var missing = [];
        ids.forEach(function (id) {
            if (id && !Object.prototype.hasOwnProperty.call(teamTypeById, id)) {
                missing.push(id);
            }
        });
        if (!missing.length) { return Promise.resolve(); }
        return Promise.all(missing.map(function (id) {
            return fetch(MODEL_ENDPOINT + encodeURIComponent(id)
                         + '?containerRef=' + encodeURIComponent(ref),
                         { headers: { Accept: 'application/json' }, credentials: 'include' })
                .then(function (r) { return r.ok ? r.json() : null; })
                .then(function (body) {
                    var model = body && body.data && body.data[body.data.domainProperty];
                    var root = ((model || {}).rootElement || []).filter(function (x) {
                        return x && x.declaredType === 'resource'; })[0] || {};
                    var team = ((root.extensionElements || {}).team || [])[0] || {};
                    /* Recorded even when null, so a team that cannot be read is
                       not fetched again on every poll. */
                    teamTypeById[id] = team.type || null;
                })
                .catch(function () { teamTypeById[id] = null; });
        }));
    }

    /** Every team a lane of this payload points at. */
    function laneTeamRefs(body) {
        var out = [];
        var model = body && body.data && body.data[body.data.domainProperty];
        ((model || {}).rootElement || []).forEach(function (r) {
            var lanes = (((r || {}).laneSet || [])[0] || {}).lane || [];
            lanes.forEach(function (l) {
                if (l && l.partitionElementRef) { out.push(l.partitionElementRef); }
            });
        });
        return out;
    }

    function ensureAcronym(ref) {
        if (!ref || acronymForRef === ref) { return Promise.resolve(appAcronym); }
        return listProcessApps().then(function (apps) {
            var hit = null;
            for (var i = 0; i < apps.length; i++) {
                if (apps[i].branchRef === ref) { hit = apps[i]; break; }
            }
            /* A snapshot ref or a non-default branch will not match, and that
               is fine - unknown is a valid answer here. */
            acronymForRef = ref;
            appAcronym = hit ? (hit.shortName || null) : null;
            return appAcronym;
        }).catch(function () { acronymForRef = ref; appAcronym = null; return null; });
    }

    /**
     * Which lane each flow node sits in, and what each lane resolves to.
     *
     * laneSet[0].lane[] carries a name, the ids of its nodes in flowNodeRef,
     * and partitionElementRef - the team the lane is assigned to. A lane with
     * no partitionElementRef is assigned to nobody.
     */
    function readLanes(root) {
        var lanes = ((root.laneSet || [])[0] || {}).lane || [];
        var laneOf = {};
        var summary = [];
        var systemOf = {};
        lanes.forEach(function (l) {
            var name = l.name || '';
            var isSystem = teamTypeById[l.partitionElementRef] === 'System';
            (l.flowNodeRef || []).forEach(function (id) {
                laneOf[id] = name;
                systemOf[id] = isSystem;
            });
            summary.push({ name: name,
                           nodes: (l.flowNodeRef || []).length,
                           hasParticipant: !!l.partitionElementRef,
                           isSystem: isSystem });
        });
        return { laneOf: laneOf, systemOf: systemOf, lanes: summary };
    }

    /**
     * The longest run of consecutive activities that are all the same kind and
     * all in the same lane.
     *
     * This is the 'String of Pearls' the standards warn about: each system-lane
     * activity is a fresh Event Manager task, and the transitions cost more
     * than the work. It is a property of the GRAPH, which no where-predicate
     * can express - the condition language sees one row at a time - so it is
     * computed here and the rule tests the number.
     *
     * Ordering comes from sequenceFlow, which is dropped from components but is
     * exactly what says which step follows which.
     */
    function longestRun(flow, laneOf, isKind) {
        var next = {};
        var byId = {};
        flow.forEach(function (e) {
            if (!e) { return; }
            if (e.declaredType === 'sequenceFlow') {
                /* More than one outgoing edge is a branch, and a branch ends a
                   run - two activities on different paths are not sequential. */
                if (next[e.sourceRef] === undefined) { next[e.sourceRef] = e.targetRef; }
                else { next[e.sourceRef] = null; }
                return;
            }
            byId[e.id] = e;
        });

        var best = 0;
        Object.keys(byId).forEach(function (id) {
            var run = 0;
            var at = id;
            var guard = 0;
            while (at && byId[at] && isKind(byId[at]) && guard++ < 500) {
                /* A run is broken by crossing into another lane. */
                if (run > 0 && laneOf[at] !== laneOf[id]) { break; }
                run++;
                at = next[at];
            }
            if (run > best) { best = run; }
        });
        return best;
    }

    /**
     * A system activity is one sitting in a SYSTEM LANE.
     *
     * The lane is authoritative, not the activity: the owner's rule is that a
     * lane is a system lane when its default team is System. activityType is
     * kept as a secondary signal for a payload that carries no lanes at all,
     * such as a service flow.
     */
    function systemActivityTest(systemOf) {
        var anyLane = false;
        var k;
        for (k in systemOf) { if (systemOf.hasOwnProperty(k)) { anyLane = true; break; } }
        return function (e) {
            if (anyLane) { return systemOf[e.id] === true; }
            return (((e.extensionElements || {}).activityType || [])[0]) === 'ServiceTask';
        };
    }
    /** Every successor of every node, from the sequence flows. */
    function successors(flow) {
        var succ = {};
        flow.forEach(function (e) {
            if (!e || e.declaredType !== 'sequenceFlow') { return; }
            (succ[e.sourceRef] = succ[e.sourceRef] || []).push(e.targetRef);
        });
        return succ;
    }

    /**
     * The longest run of steps that alternate between a script and a system
     * activity - the JavaScript 1 -> Service Task 1 -> JavaScript 2 pattern
     * the standards say to merge.
     *
     * A run of 3 is the shortest that shows the defect: a script, a service
     * task, and a script again, where the two scripts could have been one.
     */
    function longestAlternation(flow, byId, succ, isSystem) {
        function kind(e) {
            if (!e) { return null; }
            if (e.declaredType === 'scriptTask') { return 'script'; }
            if (isSystem(e)) { return 'system'; }
            return null;
        }
        var best = 0;
        Object.keys(byId).forEach(function (start) {
            var seen = {};
            var at = start;
            var last = kind(byId[at]);
            var run = last ? 1 : 0;
            var guard = 0;
            while (last && guard++ < 200) {
                var outs = succ[at] || [];
                /* A branch ends the run - two steps on different paths are
                   not consecutive. */
                if (outs.length !== 1 || seen[at]) { break; }
                seen[at] = true;
                var nextId = outs[0];
                var k = kind(byId[nextId]);
                if (!k || k === last) { break; }
                run++;
                last = k;
                at = nextId;
            }
            if (run > best) { best = run; }
        });
        return best;
    }

    /**
     * Cycles with no way out.
     *
     * A loop is normal - a retry, a rework path - as long as SOMETHING can
     * leave it. What the standards call an infinite loop is a cycle where no
     * node has an edge to anything outside the cycle. Tarjan's algorithm
     * finds the strongly connected components; a component is trapped when
     * every edge from it lands back inside it.
     */
    function trappedCycles(byId, succ) {
        var index = 0;
        var stack = [];
        var onStack = {};
        var idx = {};
        var low = {};
        var comps = [];

        /* Iterative, because a deep flow would blow the stack. */
        Object.keys(byId).forEach(function (root) {
            if (idx[root] !== undefined) { return; }
            var work = [[root, 0]];
            while (work.length) {
                var frame = work[work.length - 1];
                var v = frame[0];
                if (frame[1] === 0) {
                    idx[v] = low[v] = index++;
                    stack.push(v);
                    onStack[v] = true;
                }
                var outs = succ[v] || [];
                if (frame[1] < outs.length) {
                    var w = outs[frame[1]++];
                    if (!byId[w]) { continue; }
                    if (idx[w] === undefined) { work.push([w, 0]); }
                    else if (onStack[w]) { low[v] = Math.min(low[v], idx[w]); }
                    continue;
                }
                work.pop();
                if (work.length) {
                    var parent = work[work.length - 1][0];
                    low[parent] = Math.min(low[parent], low[v]);
                }
                if (low[v] === idx[v]) {
                    var comp = [];
                    var x;
                    do { x = stack.pop(); onStack[x] = false; comp.push(x); } while (x !== v);
                    comps.push(comp);
                }
            }
        });

        var trapped = 0;
        comps.forEach(function (comp) {
            var inComp = {};
            comp.forEach(function (id) { inComp[id] = true; });
            /* A single node is only a cycle if it points at itself. */
            if (comp.length === 1 && (succ[comp[0]] || []).indexOf(comp[0]) < 0) { return; }
            var escapes = false;
            comp.forEach(function (id) {
                (succ[id] || []).forEach(function (t) {
                    if (!inComp[t] && byId[t]) { escapes = true; }
                });
            });
            if (!escapes) { trapped++; }
        });
        return trapped;
    }

    function isSubProcess(e) {
        return e.declaredType === 'subProcess';
    }

    /**
     * The process's EXPOSED variables - which are not EPVs.
     *
     * An EPV is its own artifact, a set of runtime-configurable constants. An
     * exposed variable is a field of THIS process published for search and the
     * Portal, and it carries an alias that is what everyone else sees. They
     * live under ioSpecification.dataInput/dataOutput extensionElements as
     * searchableField[], and the same field is listed on both sides, so they
     * are de-duplicated by alias.
     */
    function readExposedVariables(io, acronym) {
        var seen = {};
        var out = [];
        [io.dataInput, io.dataOutput].forEach(function (side) {
            (side || []).forEach(function (d) {
                var fields = ((d || {}).extensionElements || {}).searchableField || [];
                fields.forEach(function (f) {
                    var alias = (f || {}).alias || '';
                    if (!alias || seen[alias]) { return; }
                    seen[alias] = true;
                    out.push({
                        name: alias,
                        category: 'Exposed',
                        path: f.path || null,
                        hasDefault: false,
                        /* Computed here because a where-predicate cannot compare
                           two fields, and the acronym belongs to a different
                           artifact. Null when the acronym is not known, so the
                           rule can tell 'not prefixed' from 'cannot say'. */
                        acronymPrefixed: acronym
                            ? alias.toLowerCase().indexOf(String(acronym).toLowerCase()) === 0
                            : null
                    });
                });
            });
        });
        return out;
    }

    /**
     * A root whose declaredType is 'resource'.
     *
     * declaredType alone is NOT enough to call this a team. Probed live
     * across every resource-rooted artifact in three applications: 31 are
     * EPVs, 27 are teams, one is a tracking group and one a user attribute
     * definition - and reading them all as teams made those 33 non-teams
     * report `hasMembers: false`, which is exactly the set a "team has no
     * members" rule would have flagged, wrongly, every time.
     *
     * What actually discriminates is the extensionElements key.
     */
    function readResource(root, out) {
        var ext = root.extensionElements || {};
        out.name = root.name || '';
        out.variablesApply = false;

        var epv = (ext.epv || [])[0];
        if (epv) {
            /* An EPV's variables ARE its content, so they are reported as
               variables with their own category - a rule counting them needs
               no second vocabulary, and `category` is what tells them apart
               from a service signature. */
            out.variablesApply = true;
            (epv.epvVars || []).forEach(function (v) {
                var def = v.defaultValue || {};
                var value = (def.value === undefined || def.value === null)
                            ? '' : String(def.value);
                out.variables.push({
                    name: v.varName || v.externalName || '',
                    category: 'EPV',
                    hasDefault: def.useDefault === true,
                    /* Length rather than the value: a rule asks whether it is
                       within the limit, and the limit belongs in the rule. */
                    valueLength: value.length,
                    hasDocumentation: hasDocText(v.externalDescription),
                    typeName: v.variableTypeRef || null,
                    isList: false
                });
            });
            out.settings = {
                resourceKind: 'epv',
                isEpv: true,
                /* No participantRef means no team may change it at runtime,
                   which is what the checklist asks about. */
                exposedToTeam: !!epv.participantRef,
                hasDocumentation: hasDocText(epv.externalDescription)
            };
            return out;
        }

        var team = (ext.team || [])[0];
        if (team) {
            out.settings = { resourceKind: 'team',
                             isEpv: false,
                             teamType: team.type || null,
                             hasMembers: !!team.members };
            return out;
        }

        /* A tracking group, a user attribute definition, or something else
           that has yet to turn up. Naming the kind is honest; claiming it has
           no members would not be. */
        var kind = Object.keys(ext)[0] || 'unknown';
        out.settings = { resourceKind: kind, isEpv: false };
        return out;
    }

    /* Flow-shaped types: SERVICEFLOW, COACHFLOW, CaseProcess and Team all
       arrive under `definitions`. They are told apart by the declaredType of
       their root elements, never by position. */
    function readDefinitions(defs, type) {
        var out = emptyModel(type);
        var roots = (defs && defs.rootElement) || [];

        /* NEVER rootElement[0]. A CaseProcess carries three roots - the
           process, its interface, and a globalUserTask - and the process is
           only first by luck. Pick it by declaredType. */
        var root = null;
        var i;
        for (i = 0; i < roots.length; i++) {
            if (roots[i] && roots[i].declaredType === 'process') { root = roots[i]; break; }
        }
        if (!root) {
            for (i = 0; i < roots.length; i++) {
                if (roots[i] && roots[i].declaredType === 'resource') {
                    return readResource(roots[i], out);
                }
            }
            root = roots[0] || null;
        }
        if (!root) { return null; }

        out.name = root.name || '';

        var io = root.ioSpecification || {};
        out.variables = buildVariables(io.dataInput, 'Input')
                        .concat(buildVariables(io.dataOutput, 'Output'))
                        /* Exposed variables are reported as variables of their
                           own category, so a rule counting them needs no second
                           vocabulary - and they are NOT EPVs. */
                        .concat(readExposedVariables(io, appAcronym));

        /* A client-side human service nests its flow under
           extensionElements.userTaskImplementation[0].flowElement, NOT at the
           root. Code written for service flows finds zero steps there, and
           finds them silently. */
        var ext = root.extensionElements || {};
        var nested = (ext.userTaskImplementation || [])[0] || null;
        /* A HERITAGE human service nests its flow the same way, so nesting
           alone does not tell them apart. Probed across 9 heritage and 12
           client-side services in one application, with no overlap:
           a heritage service carries cachingType on the root, and a
           client-side one carries htmlHeaderTag on the implementation. */
        var isHeritage = !!nested && ext.cachingType !== undefined
                         && nested.htmlHeaderTag === undefined;
        var flow = (nested && nested.flowElement) || root.flowElement || [];

        out.components = [];
        for (i = 0; i < flow.length; i++) {
            var fe = flow[i] || {};
            /* Sequence flows are connections, not steps - counting them would
               inflate every step-count rule. */
            if (fe.declaredType === 'sequenceFlow') { continue; }
            out.components.push({
                name: fe.name || '',
                type: shortType(fe.declaredType),
                /* incoming/outgoing are ABSENT when empty, never empty arrays.
                   That absence is how an unconnected node is detected. */
                connected: !!(fe.incoming || fe.outgoing)
            });
            collectNodeScripts(fe, out.surfaces);
            /* A coach step in a client-side or heritage human service carries
               a whole layout of its own, and the inline event handlers on it
               were invisible: the panel reported "no surface" while a 36-line
               On load handler sat on screen. Same layout shape as a coach
               view's, so the same scanner reads it. */
            var coach = (fe.formDefinition || {}).coachDefinition;
            if (coach && coach.layout) {
                collectInlineEvents(coach.layout, out.surfaces, fe.name || '');
            }
        }

        var lanes = readLanes(root);
        var isSystemActivity = systemActivityTest(lanes.systemOf);
        var succ = successors(flow);
        var bpd = (ext.bpdExtension || [])[0] || {};
        var systemTasks = 0;
        var systemTasksKept = 0;
        flow.forEach(function (e) {
            if (!e || !isSystemActivity(e)) { return; }
            systemTasks++;
            /* deleteTaskOnCompletion is absent on a task that was never asked
               the question, which reads the same as false here on purpose:
               the standard is that a system task SHOULD be marked. */
            if (((e.extensionElements || {}).deleteTaskOnCompletion || [])[0] !== true) {
                systemTasksKept++;
            }
        });

        /* Per-activity facts the standards ask about. Counted here because
           each is a property of the flow as a whole, and the condition
           language compares one row at a time. */
        var byId = {};
        flow.forEach(function (e) { if (e && e.id) { byId[e.id] = e; } });

        /* WHICH elements each counter counted.
         *
         * A count tells a developer that something is wrong; a name tells them
         * where to go. "A gateway has an outgoing path with no condition" on a
         * process with eleven gateways is nearly unactionable on its own.
         *
         * These ride beside the count under the `<field>Names` convention that
         * ArtifactChecker looks for, so a settings rule gains subjects without
         * changing its check, its message or its examples. Capped in the
         * checker, not here. */
        var names = {};
        function noteName(key, value) {
            var n = String(value || '').trim();
            if (!n) { return; }
            if (!names[key]) { names[key] = []; }
            if (names[key].indexOf(n) < 0) { names[key].push(n); }
        }

        var noSubject = 0;
        var noDoc = 0;
        var notImplemented = 0;
        var openGatewayConditions = 0;
        var milTotal = 0;
        var milSystem = 0;
        var milParallel = 0;
        var milSubProcess = 0;
        var terminateDeletingInstance = 0;
        var errorBackToOwner = 0;
        var conditionalJoins = 0;
        var unlabelledGatewayLinks = 0;

        flow.forEach(function (e) {
            if (!e || e.declaredType === 'sequenceFlow') { return; }
            var ext = e.extensionElements || {};
            var isActivity = e.declaredType === 'callActivity'
                          || e.declaredType === 'subProcess'
                          || /Task$/.test(String(e.declaredType));
            if (isActivity) {
                /* The subject is what a business user sees in the Portal. The
                   narrative is deliberately NOT counted - the owner ruled it
                   is not required. */
                var uts = (ext.userTaskSettings || [])[0] || {};
                if (!String(uts.subject || '').trim()) {
                    noSubject++;
                    noteName('activitiesWithoutSubject', e.name || shortType(e.declaredType));
                }
                if (!hasDocText(e.documentation)) { noDoc++; }
                /* A callActivity with nothing to call is a phantom step. */
                if (e.declaredType === 'callActivity' && !e.calledElement) {
                    notImplemented++;
                    noteName('activitiesNotImplemented', e.name || shortType(e.declaredType));
                }
                var loop = (ext.loopSettings || [])[0];
                if (loop) {
                    milTotal++;
                    if (lanes.systemOf[e.id] === true) { milSystem++; }
                    /* sequential:false is a PARALLEL multi-instance loop, the
                       one that floods the engine with tokens. */
                    if (loop.sequential === false) { milParallel++; }
                    if (e.declaredType === 'subProcess') { milSubProcess++; }
                }
            }
        });

        /* A sequence line out of a CHOOSING gateway that still carries the
           Designer's default label. The default is "To <target name>", with a
           capital T in one application and lower case in another, so the
           comparison is case-insensitive. An unnamed line counts too. */
        flow.forEach(function (e) {
            if (!e || !/^(exclusive|inclusive|complex)Gateway$/.test(String(e.declaredType))) { return; }
            (e.outgoing || []).forEach(function (id) {
                var link = byId[id];
                if (!link) { return; }
                var target = byId[link.targetRef] || {};
                var name = String(link.name || '').trim();
                if (!name) {
                    unlabelledGatewayLinks++;
                    noteName('unlabelledGatewayLinks', e.name || shortType(e.declaredType));
                    return;
                }
                if (name.toLowerCase() === ('to ' + String(target.name || '')).toLowerCase()) {
                    unlabelledGatewayLinks++;
                    noteName('unlabelledGatewayLinks', e.name || shortType(e.declaredType));
                }
            });
        });

        /* A CONDITIONAL JOIN is an inclusive gateway with more than one
           incoming flow. A simple join is an AND - every incoming line must
           have a token. A conditional join makes the engine evaluate every
           possible upstream path to decide whether a token could still arrive,
           which is expensive on a large diagram. An inclusive gateway with one
           incoming flow is a SPLIT, not a join, and costs nothing. */
        flow.forEach(function (e) {
            if (!e || e.declaredType !== 'inclusiveGateway') { return; }
            if ((e.incoming || []).length > 1) {
                conditionalJoins++;
                noteName('conditionalJoins', e.name || shortType(e.declaredType));
            }
        });

        /* An error boundary event that leads straight back to the activity it
           is attached to retries forever, thrashing between the BPD engine and
           the service engine. attachedToRef names the owning activity. */
        flow.forEach(function (e) {
            if (!e || e.declaredType !== 'boundaryEvent' || !e.attachedToRef) { return; }
            (e.outgoing || []).forEach(function (id) {
                var link = byId[id];
                if (link && link.targetRef === e.attachedToRef) {
                    errorBackToOwner++;
                    /* Named for the activity it loops back to, which is the
                       one the developer has to open. */
                    var owner = byId[e.attachedToRef];
                    noteName('errorHandlersRoutedBackToOwner',
                             (owner && owner.name) || e.name || 'boundary event');
                }
            });
        });

        /* A terminate end event that deletes the instance's runtime data makes
           the runtime purge the Portal search index on every termination,
           which can deadlock BPM_INSTANCE_INDEX and BPM_TASK_INDEX. The flag
           is terminateEventSettings.deleteProcessInstance. */
        flow.forEach(function (e) {
            if (!e || e.declaredType !== 'endEvent') { return; }
            (e.eventDefinition || []).forEach(function (d) {
                var ts = (((d || {}).extensionElements || {}).terminateEventSettings || [])[0];
                if (ts && ts.deleteProcessInstance === true) {
                    terminateDeletingInstance++;
                    noteName('terminateEventsDeletingInstanceData',
                             e.name || 'terminate end event');
                }
            });
        });

        /* A gateway's outgoing flows must each carry a condition, except the
           one nominated as the default. An empty conditionExpression object
           is the shape a half-finished gate takes.

           Only a gateway that CHOOSES needs conditions. A parallelGateway is
           an AND split - every path is taken and none of them is conditional -
           so counting its outgoing flows reported three missing conditions on
           a correctly built parallel split. Found on a process built to carry
           one of everything. */
        flow.forEach(function (e) {
            if (!e || !/^(exclusive|inclusive|complex)Gateway$/.test(String(e.declaredType))) { return; }
            (e.outgoing || []).forEach(function (id) {
                if (id === e['default']) { return; }
                var link = byId[id];
                if (!link) { return; }
                var cond = link.conditionExpression;
                var text = cond && (cond.content || []).join('').trim();
                if (!text) {
                    openGatewayConditions++;
                    noteName('gatewayConditionsIncomplete',
                             e.name || shortType(e.declaredType));
                }
            });
        });

        out.settings = {
            activitiesWithoutSubject: noSubject,
            activitiesWithoutDocumentation: noDoc,
            activitiesNotImplemented: notImplemented,
            gatewayConditionsIncomplete: openGatewayConditions,
            hasDocumentation: hasDocText(root.documentation),
            processType: root.processType || null,
            isClosed: root.isClosed === true,
            exposedAs: (ext.exposedAs || [])[0] || null,
            resourceRoles: (root.resourceRole || []).length,
            nestedImplementation: !!nested,
            /* Heritage human services are not supported on containers, so
               which of the three kinds this is matters for migration. */
            isHeritageHumanService: isHeritage,
            cachingType: (ext.cachingType || [])[0] || null,
            /* Multi-instance loops are extensionElements.loopSettings, NOT
               the BPMN loopCharacteristics - verified live. */
            multiInstanceLoops: milTotal,
            multiInstanceLoopsInSystemLane: milSystem,
            parallelMultiInstanceLoops: milParallel,
            multiInstanceSubProcesses: milSubProcess,
            terminateEventsDeletingInstanceData: terminateDeletingInstance,
            errorHandlersRoutedBackToOwner: errorBackToOwner,
            conditionalJoins: conditionalJoins,
            unlabelledGatewayLinks: unlabelledGatewayLinks,
            maxScriptSystemAlternation: longestAlternation(flow, byId, succ, isSystemActivity),
            /* Merged below - see noteName. Declared here so the shape is
               visible in one place even when a run collects none. */
            trappedCycles: trappedCycles(byId, succ),
            /* Lanes, and the graph properties no predicate can express. */
            laneCount: lanes.lanes.length,
            systemLaneCount: lanes.lanes.filter(function (l) { return l.isSystem; }).length,
            lanesWithoutParticipant: lanes.lanes.filter(function (l) {
                return !l.hasParticipant; }).length,
            /* A lane holding both system and human work - the swimlane
               separation the standards ask for. */
            mixedLanes: (function () {
                var mixed = 0;
                lanes.lanes.forEach(function (l) {
                    if (l.isSystem) { return; }
                    /* a non-system lane containing a ServiceTask */
                    var hasService = false;
                    flow.forEach(function (e) {
                        if (!e || lanes.laneOf[e.id] !== l.name) { return; }
                        if ((((e.extensionElements || {}).activityType || [])[0]) === 'ServiceTask') {
                            hasService = true;
                        }
                    });
                    if (hasService) { mixed++; }
                });
                return mixed;
            }()),
            maxSequentialSystemActivities: longestRun(flow, lanes.laneOf, isSystemActivity),
            maxSequentialSubProcesses: longestRun(flow, lanes.laneOf, isSubProcess),
            systemTasks: systemTasks,
            systemTasksNotDeletedOnCompletion: systemTasksKept,
            searchableFields: readExposedVariables(io, null).length,
            /* Process-level flags the standards ask about directly. */
            autoTrackingEnabled: bpd.autoTrackingEnabled === true,
            atRiskCalcEnabled: bpd.atRiskCalcEnabled === true,
            optimizeExecForLatency: bpd.optimizeExecForLatency === true,
            appAcronymKnown: !!appAcronym
        };

        /* Fold in the `<field>Names` lists gathered by noteName, so a rule
           that counts something can also say which ones. Added after the
           literal rather than inside it because each list is built during the
           passes above. */
        Object.keys(names).forEach(function (k) {
            out.settings[k + 'Names'] = names[k];
        });
        return out;
    }

    /* A coach view. No `definitions` anywhere in the payload - the reason every
       coach view used to report zero variables while claiming the number was
       committed truth. */
    function readCoachView(model, type) {
        var out = emptyModel(type);
        var header = model.header || {};
        out.name = header.name || '';

        /* Config options are the coach view's signature, and they are absent
           from this payload entirely rather than empty. Variables therefore do
           not APPLY here - which is a different statement from "there are
           none", and the panel says so. */
        out.variablesApply = false;

        /* Nested views, with the config each one was bound to. This is the
           closest thing a coach view has to steps. */
        var items = (model.layout || {}).layoutItem || [];
        for (var i = 0; i < items.length; i++) {
            var it = items[i] || {};
            var cfg = {};
            (it.configData || []).forEach(function (c) {
                if (c && c.optionName) { cfg[c.optionName] = c.value; }
            });
            out.components.push({
                name: it.layoutItemId || '',
                type: it.declaredType || 'ViewRef',
                viewUUID: it.viewUUID || null,
                config: cfg
            });
        }

        /* The committed code, all of it. inlineScript carries the shared
           blocks; the load and unload handlers hang off the header and are the
           two surfaces most easily forgotten, because nothing in the editor
           groups them with the inline script. */
        (model.inlineScript || []).forEach(function (b, i) {
            out.surfaces.push({ surface: 'inlineJavaScript', index: i,
                                language: 'javascript',
                                name: b.name || 'Inline Javascript',
                                code: b.scriptBlock || '' });
        });
        /* EVERY lifecycle handler on the header, not just load and unload.
         *
         * The old pair missed viewJSFunction outright, and any of change,
         * validate or collaboration a view happens to define. Measured on Test
         * PA: 16 lifecycle handlers exist and only some were read, so a
         * whole-application review judged a coach view on part of its code and
         * reported the rest as clean. Deriving the surface name from the key
         * covers the ones IBM adds next as well. */
        lifecycleHandlers(header, out.surfaces);

        /* INLINE event handlers - a different thing entirely, and deliberately
           kept apart. See collectInlineEvents. */
        collectInlineEvents(model.layout, out.surfaces, out.name);

        out.settings = {
            isTemplate: header.isTemplate === true,
            hasLabel: header.hasLabel === true,
            isMobileReady: header.isMobileReady === true,
            useUrlBinding: header.useUrlBinding === true,
            firesBoundaryEvent: header.firesBoundaryEvent === true,
            hasDescription: !!(header.description || '').trim()
        };
        return out;
    }

    /* ------------------------------------------------ coach event handlers
     *
     * There are TWO kinds and they must not be conflated, because the standard
     * differs:
     *
     *   LIFECYCLE handlers belong to the coach view itself - load, view,
     *   change, unload, validate, collaboration. This is the bpmext contract,
     *   and implementation legitimately lives here. Length is normal.
     *
     *   INLINE handlers are configured on an instance of a view dropped onto a
     *   page - "On load", "On change", "On icon click" - and live in that
     *   layout item's configData. The standard is that these call a function;
     *   where the implementation lives is free, but the handler itself should
     *   not carry it.
     *
     * Both were invisible to the committed reader before 2026-08-30 apart from
     * loadJSFunction and unloadJSFunction. Measured on Test PA: 16 inline
     * handlers holding 4,214 characters, three of them 36 to 41 lines, none of
     * which any rule could see.
     */
    function lifecycleHandlers(header, into) {
        Object.keys(header || {}).forEach(function (key) {
            if (!/JSFunction$/.test(key)) { return; }
            var code = header[key];
            if (!code || !String(code).trim()) { return; }
            /* loadJSFunction -> eventHandlersLoad, matching the surface names
               the Designer's own DOM uses, so live and committed reads of the
               same handler agree on what to call it. */
            var kind = key.replace(/JSFunction$/, '');
            var surface = 'eventHandlers'
                + kind.charAt(0).toUpperCase() + kind.slice(1);
            into.push({ surface: surface, index: 0, language: 'javascript',
                        name: key, handlerKind: 'lifecycle',
                        code: String(code),
                        lines: String(code).split(String.fromCharCode(10)).length });
        });
    }

    /* A config option is an inline EVENT handler when its name is `event`
       followed by the event's own constant - eventON_LOAD, eventON_CHANGE,
       eventON_ICONCLICK.
     *
     * The trailing part is upper case, which is what separates a handler from
     * an ordinary option that merely begins with the same four letters:
     * `eventName` and `eventValue` are both real options carrying strings, and
     * a prefix test alone reports them as code. Both appear in the measured
     * corpus, so this is a live trap rather than a hypothetical one. */
    var INLINE_EVENT = /^event[A-Z][A-Z0-9_]*$/;

    function collectInlineEvents(layout, into, ownerName) {
        var items = (layout && layout.layoutItem) || [];
        items.forEach(function (item) {
            if (!item) { return; }
            (item.configData || []).forEach(function (c) {
                if (!c || !INLINE_EVENT.test(String(c.optionName || ''))) { return; }
                var code = c.value;
                if (!code || !String(code).trim()) { return; }
                into.push({
                    surface: 'inlineEventHandler',
                    index: into.length,
                    language: 'javascript',
                    /* The event, in the Designer's own vocabulary. */
                    name: String(c.optionName).replace(/^event/, ''),
                    handlerKind: 'inline',
                    node: item.layoutItemId || item.viewUUID || ownerName || null,
                    code: String(code),
                    lines: String(code).split(String.fromCharCode(10)).length
                });
            });
            /* A layout item can hold a layout of its own - a section, a table,
               a content box - and a handler nested three deep is still a
               handler. */
            if (item.layoutItem || item.layout) {
                collectInlineEvents(item.layout || { layoutItem: item.layoutItem },
                                    into, ownerName);
            }
        });
    }

    function readAppSettings(model, type) {
        var out = emptyModel(type);
        var d = model.projDefaults || {};
        out.name = d.name || '';
        out.variablesApply = false;
        out.settings = {
            acronym: d.acronym || null,
            targetEnvironment: d.targetEnvironment || null,
            isToolkit: d.isToolkit === true,
            isWbmEnabled: d.isWbmEnabled === true,
            namespace: d.namespace || null,
            hasDescription: !!(d.desc || '').trim(),
            /* Named here even though the envVarSet poId itself returns HTTP 500
               - the settings model still says whether a set exists. */
            envVarSet: (model.envVarSet || {}).name || null
        };
        return out;
    }

    function readUca(model, type) {
        var out = emptyModel(type);
        out.name = model.name || '';
        out.variablesApply = false;
        out.settings = {
            eventType: model.eventType || null,
            implementationType: model.implementationType || null,
            isEnabled: model.isEnabled === true,
            scheduleType: model.scheduleType,
            frequency: model.frequency,
            queue: model.queue || null,
            attachedService: model.attachedServiceName || null,
            /* A UCA's parameters are its data associations. 53 of the 62 real
               UCAs measured carry none at all, which is a Message UCA with no
               payload and not a defect. */
            parameterCount: (function () {
                var a = model.ucaDataAssociation;
                if (!a) { return 0; }
                return (Array.isArray(a) ? a : [a]).length;
            }()),
            hasDocumentation: hasDocText(model.documentation)
        };
        return out;
    }

    /* A business object. Its attributes are variables in everything but name,
       so they are reported as such - a "no more than N fields" rule should not
       need a second vocabulary to say the same thing. */
    function readBusinessObject(model, type) {
        var out = emptyModel(type);

        /* An enumerated type arrives under the same domainProperty as a
           business object, but it is a simpleType with a restriction rather
           than a complexType with a sequence. Reading it through
           complexType[0] alone produced a business object with NO NAME and
           zero attributes - and zero was then reported as fact, which is the
           F2 defect exactly: a count stated for a concept that does not
           apply. Two of the four artifacts a 'business object has no
           attributes' rule flagged across the measured corpus were
           enumerations, not empty objects. */
        var simple = (model.simpleType || [])[0];
        if (simple) {
            out.name = simple.name || '';
            /* Attributes are not a thing an enumeration has. */
            out.variablesApply = false;
            var values = ((simple.restriction || {}).enumeration) || [];
            for (var v = 0; v < values.length; v++) {
                out.components.push({
                    name: String((values[v] || {}).value || ''),
                    type: 'EnumerationValue'
                });
            }
            out.settings = {
                isEnumeration: true,
                targetNamespace: model.targetNamespace || null,
                hasDocumentation: hasDocText((simple.annotation || {}).documentation)
            };
            return out;
        }

        var ct = (model.complexType || [])[0] || {};
        out.name = ct.name || '';
        var seq = ct.sequence || {};
        var elements = seq.element || [];
        for (var i = 0; i < elements.length; i++) {
            var e = elements[i] || {};
            out.variables.push({
                name: e.name || '',
                category: 'Attribute',
                hasDefault: e['default'] !== undefined && e['default'] !== null,
                typeName: e.type || null,
                isList: e.maxOccurs === 'unbounded'
            });
        }
        var info = ((ct.annotation || {}).appinfo || [])[0] || {};
        out.settings = {
            /* Stated on both branches so a rule can test it rather than
               infer it from the key being missing. */
            isEnumeration: false,
            shared: (info.shared || [])[0] === true,
            allowAdditionalProperties: (info.allowAdditionalProperties || [])[0] === true,
            isShadow: (info.shadow || [])[0] === true,
            targetNamespace: model.targetNamespace || null
        };
        return out;
    }

    function readRestService(model, type) {
        var out = emptyModel(type);
        out.name = model.name || '';
        out.variablesApply = false;
        out.settings = {
            hasOpenApiDefinition: !!model.openAPIDefinitionURLTemplate
        };
        return out;
    }

    /* Keyed by the response's own domainProperty, which is the server telling
       us what it sent rather than us inferring it from the editor on screen. */
    var READERS = {
        CoachViewModel: readCoachView,
        definitions: readDefinitions,
        processAppSettings: readAppSettings,
        uca: readUca,
        schema: readBusinessObject,
        restService: readRestService
    };

    /* Every piece of committed code hanging off one diagram node.
     *
     * A step can carry three separate scripts and the editor shows them on
     * different tabs, so the pre and post assignment scripts are the classic
     * place for logic to hide - they belong to activities generally, not only
     * to script tasks. All three are ABSENT when empty rather than empty, so
     * nothing here treats a missing key as a problem.
     */
    function collectNodeScripts(node, into) {
        var name = node.name || shortType(node.declaredType);
        var body = ((node.script || {}).content || [])[0];
        if (body) {
            into.push({ surface: 'Script', node: name, nodeId: node.id || null,
                        language: 'javascript', code: body });
        }
        var ext = node.extensionElements || {};
        ['preAssignmentScript', 'postAssignmentScript'].forEach(function (key) {
            var code = (ext[key] || [])[0];
            if (code) {
                into.push({ surface: key, node: name, nodeId: node.id || null,
                            language: 'javascript', code: code });
            }
        });
    }

    function buildVariables(list, category) {
        return (list || []).map(function (v) {
            var ext = v.extensionElements || {};
            var dv = (ext.defaultValue || [])[0] || {};
            return {
                name: v.name,
                category: category,
                /* useDefault, not the presence of `value`: a default can be
                   recorded and switched off. */
                hasDefault: dv.useDefault === true,
                typeName: v.itemSubjectRef || null,
                isList: v.isCollection === true
            };
        });
    }

    /* "com.ibm.bpmsdk.model.bpmn20.ibmext.TFormTask" -> "TFormTask". The full
       class name is accurate and unreadable, and every rule that wants to match
       a step type would otherwise carry the package prefix. */
    function shortType(declaredType) {
        if (!declaredType) { return ''; }
        var dot = declaredType.lastIndexOf('.');
        return dot < 0 ? declaredType : declaredType.slice(dot + 1);
    }

    function hasDocText(documentation) {
        var docs = documentation || [];
        for (var i = 0; i < docs.length; i++) {
            var c = (docs[i] || {}).content || [];
            for (var j = 0; j < c.length; j++) {
                if (String(c[j] || '').trim()) { return true; }
            }
        }
        return false;
    }

    /**
     * Which editor type a payload represents, judged by its shape.
     *
     * Returns null when the shape does not settle it, so the caller keeps
     * whatever it already knew rather than being handed a guess.
     */
    function derivedEditorType(domainProperty, model) {
        if (domainProperty === 'CoachViewModel') { return 'CoachView'; }
        if (domainProperty === 'processAppSettings') { return 'AppSettings'; }
        if (domainProperty === 'uca') { return 'UCA'; }
        if (domainProperty === 'schema') { return 'BusinessObject'; }
        if (domainProperty === 'restService') { return 'RESTService'; }
        if (domainProperty !== 'definitions') { return null; }

        var roots = (model && model.rootElement) || [];
        var hasProcess = false;
        var hasBpdExtension = false;
        var nested = false;
        for (var i = 0; i < roots.length; i++) {
            var r = roots[i] || {};
            if (r.declaredType === 'resource') {
                var rext = r.extensionElements || {};
                if (rext.epv) { return 'EPV'; }
                if (rext.team) { return 'Team'; }
                /* A tracking group or user attribute definition. Let the
                   caller keep whatever the listing called it rather than
                   guessing at a type we do not model. */
                return null;
            }
            if (r.declaredType === 'process') {
                hasProcess = true;
                if (((r.extensionElements || {}).bpdExtension || []).length) {
                    hasBpdExtension = true;
                }
            }
            if (((r.extensionElements || {}).userTaskImplementation || []).length) {
                nested = true;
            }
        }
        /* A nested flow means a human service - but of which kind? A heritage
           service carries cachingType and a client-side one carries
           htmlHeaderTag on the implementation. Verified across 21 real
           services with no overlap. */
        if (nested) {
            for (i = 0; i < roots.length; i++) {
                var rext = (roots[i] || {}).extensionElements || {};
                var impl = (rext.userTaskImplementation || [])[0];
                if (!impl) { continue; }
                if (impl.htmlHeaderTag !== undefined) { return 'COACHFLOW'; }
                if (rext.cachingType !== undefined) { return 'HERITAGEFLOW'; }
            }
            return 'COACHFLOW';
        }
        /* A PROCESS is marked by extensionElements.bpdExtension, and nothing
           else is.
         *
         * The old test was `hasProcess && hasGlobalUserTask`, on the theory
         * that a case process carries a globalUserTask beside the process
         * itself. A globalUserTask is an INLINE user task, so a process
         * without one failed the test and was classified as a service flow.
         * Measured on Test PA: all 4 BPDs and 10 of the 24 case processes were
         * typed SERVICEFLOW, which is how process rules came to be applied to
         * service flows - and would equally have stopped them applying to real
         * processes once the scope was tightened.
         *
         * bpdExtension is where the process settings themselves live -
         * atRiskCalcEnabled, autoTrackingEnabled, optimizeExecForLatency - so
         * a rule about any of them is asking exactly "does this artifact have
         * a bpdExtension". Verified across BPD, case process, service flow and
         * integration service payloads: present on the first two, absent on
         * the second two.
         *
         * A BPD and a case process are NOT separable here, and that is a fact
         * about BAW rather than a gap in this reader: both come back as
         * converged processes carrying isConvergedProcess, a caseExtension and
         * a bpdExtension, differing only in fields neither type is guaranteed
         * to fill. The listing name is the only thing that tells them apart,
         * and readInventory keeps it as `listedAs`. Both are classified
         * CaseProcess, which is the vocabulary every process rule already
         * uses. */
        if (hasProcess) {
            return hasBpdExtension ? 'CaseProcess' : 'SERVICEFLOW';
        }
        return null;
    }

    /**
     * Parse one asset response into the engine's artifact shape.
     *
     * Returns null when the payload is not one we recognise, so the caller can
     * say "unavailable" rather than presenting an empty model as fact. Exposed
     * for the report path and for tests, which have payloads and no Designer.
     */
    function parseAsset(body, editorType) {
        var data = body && body.data;
        if (!data) { return null; }
        var dp = data.domainProperty;
        var reader = dp && READERS[dp];
        var model = dp && data[dp];
        if (!reader || !model) { return null; }

        var out = reader(model, editorType || '');
        if (!out) { return null; }

        /* Say which editor type this IS, from the payload itself.
         *
         * A caller in the Designer already knows - it read data-test-editor.
         * A caller outside one does not: the REST asset listing groups
         * artifacts by DISPLAY name ("General System Service", "Ajax Service",
         * "Regular Service"), while every artifact rule's appliesTo is written
         * in the editor vocabulary ("SERVICEFLOW", "COACHFLOW", "CaseProcess").
         * Passing the listing name straight through meant applies() matched
         * nothing and every artifact rule was skipped in silence - 584 models
         * including a 149-step service reported zero findings, which looks
         * exactly like a clean application.
         *
         * The payload is the authority, so the shape decides. */
        out.editorType = out.editorType || derivedEditorType(dp, model) || editorType || '';
        out.commitSeq = (data.commitSeq === undefined) ? null : data.commitSeq;
        out.uncommitted = data.hasUnCommittedChanges === true;
        out.readonly = data.readonly === true;
        out.domainProperty = dp;
        return out;
    }

    /* ------------------------------------------------- applications and time
     *
     * Everything here is DOM-free and takes a containerRef, because a snapshot
     * ref (2064.…) works wherever a branch ref (2063.…) does. That one fact is
     * what makes comparing a track against what was actually deployed possible
     * at all - the same readers, pointed at a different moment.
     */

    /**
     * Process apps and toolkits arrive in the SAME shape from two endpoints,
     * so one mapper serves both. Exposed for tests, which have a payload and
     * no server.
     *
     * The difference that matters: a process app carries `defaultBranchID`
     * and a **toolkit carries null** - all 115 of them on the probed server.
     * The old filter dropped anything without one, so a toolkit list built on
     * it would have come back empty and looked like "this server has no
     * toolkits". A toolkit's refs live in `installedSnapshots[]` instead, as
     * `.ID` (the snapshot) and `.branchID` (the branch it was taken from);
     * both were verified to serve /assets.
     */
    function parseContainers(body, kind) {
        var items = (body && body.data && body.data.processAppsList) || [];
        return items.map(function (a) {
            var snaps = a.installedSnapshots || [];
            /* The tip is the snapshot the toolkit is currently consumed at.
               Falling back to the newest keeps a toolkit usable when nothing
               is marked, rather than dropping it. */
            var tip = null;
            for (var i = 0; i < snaps.length; i++) {
                if (snaps[i] && snaps[i].snapshotTip) { tip = snaps[i]; break; }
            }
            if (!tip && snaps.length) { tip = snaps[snaps.length - 1]; }
            return {
                kind: kind,
                id: a.ID,
                name: a.name,
                shortName: a.shortName,
                branchRef: a.defaultBranchID || (tip && tip.branchID) || null,
                branchName: a.defaultVersion || (tip && tip.branchName) || null,
                /* Only a toolkit needs this: it is the ref to analyse when the
                   toolkit has no branch of its own to point at. */
                snapshotRef: (tip && tip.ID) || null,
                snapshotName: (tip && tip.name) || null,
                modifiedOn: a.lastModified_on
            };
        }).filter(function (a) { return !!(a.branchRef || a.snapshotRef); })
          .sort(function (x, y) {
              return String(x.name || '').localeCompare(String(y.name || ''));
          });
    }

    /** Every process app on the server, with the branch each one defaults to. */
    function listProcessApps() {
        return fetch('/rest/bpm/wle/v1/processApps',
                     { headers: { Accept: 'application/json' }, credentials: 'include' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (body) { return parseContainers(body, 'app'); })
            .catch(function () { return []; });
    }

    /**
     * Every toolkit on the server.
     *
     * The endpoint is `/toolkit`, singular. `/toolkits` is a 404, which is the
     * kind of thing that reads as "no toolkits on this server" if you assume
     * the plural by symmetry with /processApps.
     */
    function listToolkits() {
        return fetch('/rest/bpm/wle/v1/toolkit',
                     { headers: { Accept: 'application/json' }, credentials: 'include' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (body) { return parseContainers(body, 'toolkit'); })
            .catch(function () { return []; });
    }

    /** Snapshots taken from a branch, newest first. */
    function listSnapshots(ref) {
        return fetch('/rest/bpm/wle/pd/v1/snapshots?containerRef=' + encodeURIComponent(ref),
                     { headers: { Accept: 'application/json' }, credentials: 'include' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (body) {
                var snaps = (body && body.data && body.data.snapshots) || [];
                return snaps.map(function (s) {
                    return { ref: s.snapshotId, name: s.name, created: s.created,
                             seq: s.snapshotSeqNum };
                }).sort(function (x, y) { return (y.created || 0) - (x.created || 0); });
            })
            .catch(function () { return []; });
    }

    /**
     * Every artifact in one containerRef, parsed.
     *
     * `onProgress(done, total)` is called as it goes, because a real
     * application is hundreds of artifacts and a silent wait of that length
     * looks identical to a hang.
     */
    function readInventory(ref, onProgress, onSkip) {
        return fetch('/rest/bpm/wle/pd/v1/assets?containerRef=' + encodeURIComponent(ref),
                     { headers: { Accept: 'application/json' }, credentials: 'include' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (body) {
                var groups = (body && body.data) || {};
                var targets = [];
                Object.keys(groups).forEach(function (type) {
                    var g = groups[type];
                    if (!g || !g.items) { return; }
                    g.items.forEach(function (i) {
                        if (i && i.poId) {
                            targets.push({ poId: i.poId, listedAs: type,
                                           name: i.name || i.poId });
                        }
                    });
                });

                var out = {};
                var done = 0;
                /* Sequential on purpose. Firing several hundred parallel
                   requests at the Designer's REST API is a good way to be
                   throttled or to fall over, and this is not a latency-critical
                   path - it runs when someone asks for a comparison. */
                function next(i) {
                    if (i >= targets.length) { return Promise.resolve(out); }
                    var t = targets[i];
                    return readModel(t.poId, ref, t.listedAs).then(function (m) {
                        done++;
                        if (onProgress) { onProgress(done, targets.length); }
                        if (m) {
                            m.poId = t.poId;
                            m.listedAs = t.listedAs;
                            if (!m.name) { m.name = t.name; }
                            out[t.poId] = m;
                        } else if (onSkip) {
                            /* An artifact the readers do not recognise, or one
                               that would not load. Reported rather than
                               dropped: a report that quietly omits what it
                               could not read presents a partial sweep as a
                               complete one, which is the same failure as
                               stating a count for a concept that does not
                               apply. */
                            onSkip(t);
                        }
                        return next(i + 1);
                    });
                }
                return next(0);
            })
            .catch(function () { return {}; });
    }

    /** Fetch and parse one artifact. DOM-free; the report path can call this. */
    function readModel(poId, ref, editorType) {
        var container = ref || branchRef;
        var url = MODEL_ENDPOINT + encodeURIComponent(poId)
                + '?containerRef=' + encodeURIComponent(container);
        /* Resolved first, and cached per branch, because parseAsset is
           synchronous and the acronym lives in another artifact. */
        return ensureAcronym(container)
            .then(function () {
                return fetch(url, { headers: { Accept: 'application/json' },
                                    credentials: 'include' });
            })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (body) {
                if (!body) { return null; }
                /* Lane teams decide which lane is the system lane, and that
                   cannot be answered from this payload alone. */
                return ensureTeams(laneTeamRefs(body), container)
                    .then(function () { return parseAsset(body, editorType); });
            })
            .catch(function () { return null; });
    }

    /* ---------------------------------------------------------- artifact model
     *
     * What the artifact rules need: the variable list and the step count. Both
     * are read live from the Designer, so a variable added seconds ago counts.
     *
     * Everything here scopes to the *visible* editor. With two service flows
     * open, an unscoped diagram query returned 22 nodes for a flow that has 6 -
     * the kind of wrong answer that looks like a working feature.
     */

    /* Variables come from the committed model over REST, not from the DOM.
     *
     * The Variables tab renders its tree only once visited, so a DOM read
     * reports zero variables for an artifact the developer has not clicked
     * through - which looks exactly like a service that genuinely has none.
     * Worse, `hasDefault` is never on the tree row at all; it lives in the
     * detail panel, one variable at a time.
     *
     * The model has all of it, including useDefault, and costs one cached
     * lookup. The tradeoff is that it reflects the last commit, so a variable
     * added seconds ago is not counted until saved. That is worth saying out
     * loud rather than hiding.
     */
    var branchRef = null;
    var inventoryCache = null;        /* name -> poId for the current branch */
    var modelCache = {};              /* poId -> {variables, commitSeq, at}  */
    var MODEL_TTL_MS = 10000;         /* re-read after a save, not per poll  */

    function setBranch(ref) {
        if (ref !== branchRef) {
            branchRef = ref;
            inventoryCache = null;
            modelCache = {};
        }
    }

    /* The artifact on screen, from the Designer's own editor selector.
     *
     * `common.name` was the first identity used here, learned on a coach view.
     * A service flow does not have it: the visible SERVICEFLOW editor element
     * holds only its five tab panels, and the Properties panel that carries a
     * name sits outside the editor and describes the selected *node*. So the
     * read returned null, loadVariables bailed on the spot, and every service
     * flow reported "0 variables - could not read the saved model". Verified
     * live: `[data-test-attr="common.name"]` matched nothing in the whole
     * document with ProbeServiceFlow open.
     *
     * dijit.byId('editorDropdown') is the breadcrumb selector, bound to the
     * artifact currently on screen, and it carries both halves of the identity:
     *
     *     value          "<branchRef>-<poId>"     e.g. 2063.<guid>-1.<guid>
     *     displayedValue "ProbeServiceFlow"
     *
     * The poId is what the REST model actually wants, so this also retires the
     * name -> poId inventory lookup and the name collision it carried with it.
     *
     * Split on the FIRST "-" after the branch ref, not on "-" generally: both
     * halves are dotted GUIDs and are themselves full of hyphens.
     */
    function activeArtifact() {
        if (!isAlive()) { return null; }
        var w;
        try { w = win.dijit && win.dijit.byId('editorDropdown'); } catch (e) { return null; }
        if (!w || !w.get) { return null; }

        var value, label;
        try {
            value = w.get('value') || '';
            label = (w.get('displayedValue') || '').trim();
        } catch (e) { return null; }

        var poId = null;
        if (branchRef && value.indexOf(branchRef + '-') === 0) {
            poId = value.slice(branchRef.length + 1);
        } else {
            /* No branch set yet, or a ref we were not told about. The poId is
               the last "<digits>.<guid>" in the value either way. */
            var m = /(\d+\.[0-9a-fA-F-]{36})$/.exec(value);
            if (m) { poId = m[1]; }
        }
        if (!poId && !label) { return null; }
        return { poId: poId || null, name: label || null };
    }

    function artifactName(editor) {
        var active = activeArtifact();
        if (active && active.name) { return active.name; }
        /* Coach views do carry common.name; keep it as the fallback. */
        if (!editor) { return null; }
        var n = editor.querySelector('[data-test-attr="common.name"]');
        if (!n) { return null; }
        return (n.value || n.textContent || '').trim() || null;
    }

    function loadInventory() {
        if (inventoryCache) { return Promise.resolve(inventoryCache); }
        if (!branchRef) { return Promise.resolve(null); }
        return fetch('/rest/bpm/wle/pd/v1/assets?containerRef='
                     + encodeURIComponent(branchRef),
                     { headers: { Accept: 'application/json' },
                       credentials: 'include' })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (body) {
                if (!body) { return null; }
                var map = {};
                var groups = body.data || {};
                Object.keys(groups).forEach(function (k) {
                    ((groups[k] || {}).items || []).forEach(function (i) {
                        if (i.name) { map[i.name] = i.poId; }
                    });
                });
                inventoryCache = map;
                return map;
            })
            .catch(function () { return null; });
    }

    /* Variables plus commit state for the open artifact, or null. */
    function loadVariables(editor) {
        if (!branchRef) { return Promise.resolve(null); }

        /* The editor selector hands us the poId outright. Fall back to the
           name -> poId inventory only when it cannot (an editor that predates
           the selector, or a name-only identity). */
        var active = activeArtifact();
        var direct = active && active.poId
            ? Promise.resolve(active.poId)
            : loadInventory().then(function (map) {
                  var name = artifactName(editor);
                  return (name && map && map[name]) || null;
              });

        return direct.then(function (poId) {
            if (!poId) { return null; }
            var hit = modelCache[poId];
            if (hit && (Date.now() - hit.at) < MODEL_TTL_MS) { return hit; }

            /* One endpoint, and the response says what it is.
             *
             * This used to branch on the editor type and send coach views to
             * /coachview while parsing the reply as BPMN - reading
             * definitions.rootElement[0].ioSpecification out of a payload that
             * has no `definitions` key at all. The parse produced zero
             * variables for every coach view ever opened, and because the
             * result was still non-null the panel reported "0 input/output
             * variables (as last saved)" - stating as committed fact a number
             * it had never read. */
            var editorType = editor.getAttribute('data-test-editor') || '';
            return readModel(poId, branchRef, editorType).then(function (model) {
                if (!model) { return null; }
                model.poId = poId;
                model.at = Date.now();
                modelCache[poId] = model;
                return model;
            });
        });
    }

    /* --------------------------------------------------------- change signals
     *
     * Three moments must re-run the artifact rules: opening an artifact, changing
     * it, and saving it. None of them is a single event the Designer offers, so
     * each is sensed from something cheap and specific.
     *
     * The step count alone was the first signature, and it misses the change that
     * matters most to the signature rules: adding an input variable moves no
     * step, no node and no surface. So the variable tree is counted too, and the
     * save indicator is watched for the third moment.
     */

    /* Variables rendered in the Variables tab, or -1 when the tab has never been
       visited and the tree therefore does not exist. Deliberately NOT a variable
       source - it cannot see default values, which is why the rules read the
       committed model. It is only here to notice that the count moved. */
    /* The "_row" suffix is the Designer's FORM row, not a data row: verified
       live, `variables.actionableTree_row` is the ancestor that wraps the whole
       tree widget, so counting it gives 1 - and counting it as a descendant of
       the tree gives 0, which reads exactly like a service with no variables.
       The real rows are dijit tree items; the five group headers (Input, Output,
       Private, Exposed process variables, Localization resources) carry
       `treeEditorControl_category` and are not variables. */
    function variableRowCount(editor) {
        if (!editor) { return -1; }
        var tree = editor.querySelector('[data-test-attr="variables.actionableTree"]');
        if (!tree) { return -1; }
        var items = tree.querySelectorAll('[role="treeitem"]');
        var n = 0;
        for (var i = 0; i < items.length; i++) {
            if (!/(^|\s)treeEditorControl_category(\s|$)/.test(items[i].className || '')) { n++; }
        }
        return n;
    }

    /* The save indicator, with its clock stripped out.
     *
     * "#editingInfo" reads "Last saved 6 minutes ago by you." and is the one
     * signal that catches EVERY save - the toolbar button, Ctrl+S, and the
     * Designer's own autosave alike. Taken raw it also drifts with the clock
     * ("6 minutes" -> "7 minutes") and would re-check once a minute for no
     * reason, so the digits are removed. A real save resets the phrase itself
     * ("a few seconds ago"), which still registers. */
    function saveSignal() {
        var d = doc();
        if (!d) { return ''; }
        var el = d.getElementById('editingInfo');
        if (!el) { return ''; }
        return (el.textContent || '').replace(/\d+/g, '#').trim();
    }

    /* Which code surface is live, and is it still the same one?
     *
     * Deliberately separate from shapeSignature, because the two answer
     * different questions and change at different times. Switching from one
     * script task to another in the SAME service flow changes nothing
     * structural - same artifact, same editor, same step count, and the surface
     * is still called "Script" - so the shape signature is byte-identical and
     * the artifact findings are genuinely unchanged. But the buffer underneath
     * is a different script, and the watcher is still bound to the previous
     * node's Orion instance.
     *
     * That used to re-bind by accident: the Properties panel rebuild made the
     * surface flicker out and back, which changed the shape signature. Once
     * intermediate states were filtered out to stop artifact checks thrashing,
     * the accident stopped happening and stale findings stayed on screen.
     *
     * Two things identify the live buffer. The host element's widget id changes
     * when the Designer builds a new editor for the newly selected node, and
     * the character count changes when the content differs. getCharCount is
     * O(1) on the text model - cheaper than reading the buffer out. */
    function surfaceSignature() {
        if (!isAlive()) { return 'dead'; }
        var s = sense().surface;
        if (!s) { return 'none'; }
        var host = surfaceHost(s);
        var key = host ? (host.getAttribute('widgetid') || host.id || '') : '';
        var chars = -1;
        try {
            var o = orion(s);
            if (o && o.textModel) { chars = o.textModel.getCharCount(); }
        } catch (e) { chars = -1; }
        return [s, key, chars].join('|');
    }

    /* Everything worth re-checking on, as one string. One DOM pass, no REST. */
    function shapeSignature() {
        if (!isAlive()) { return 'dead'; }
        /* First call of the tick - start a fresh memo, so the rest of this tick
           reads the DOM once and every later tick sees the DOM as it now is. */
        memoReset();
        var s = sense();
        var ed = visibleEditor();
        return [s.artifactName, s.editorType, s.surface,
                s.node ? s.node.id : '',
                readComponents(ed).length,
                variableRowCount(ed),
                saveSignal()].join('|');
    }

    /* The toolbar Save, hooked precisely rather than waited for.
     *
     * saveSignal() catches a save within a poll tick; this fires on the click
     * itself, so the common case feels immediate. Both paths clear the model
     * cache, because a save is exactly when the committed model - the only place
     * variable defaults live - has just changed underneath it. */
    var saveHandle = null;

    function onSave(fn) {
        offSave();
        if (!isAlive()) { return false; }
        try {
            var btn = win.dijit.byId('saveAll_btn');
            if (!btn) { return false; }
            var aspect = win.require('dojo/aspect');
            saveHandle = aspect.after(btn, 'onClick', function () {
                modelCache = {};
                try { fn(); } catch (e) { /* never break the Designer's own save */ }
            }, true);
            return true;
        } catch (e) { return false; }
    }

    function offSave() {
        if (saveHandle) {
            try { saveHandle.remove(); } catch (e) { /* editor already gone */ }
            saveHandle = null;
        }
    }

    /* A save happened; the cached model is now the previous commit. */
    function invalidateModel() { modelCache = {}; }

    /* Steps on the diagram. Lanes are containers, not steps, and sequence flows
       are not elements the developer would call a step either - neither appears
       as an addressable activity node. */
    function readComponents(editor) {
        var out = [];
        if (!editor) { return out; }
        var nodes = editor.querySelectorAll('[data-test-activity-name]');
        for (var i = 0; i < nodes.length; i++) {
            var type = nodes[i].getAttribute('data-test-activity-type') || '';
            if (type === 'swimlane') { continue; }
            out.push({
                name: nodes[i].getAttribute('data-test-activity-name'),
                /* The diagram reports a coach as the FULL class name -
                   com.ibm.bpmsdk.model.bpmn20.ibmext.TFormTask - while the
                   committed reader shortens it. Two vocabularies for one
                   concept meant a rule matching TFormTask worked against the
                   corpus and never fired for a developer. Shorten both. */
                type: shortType(type)
            });
        }
        return out;
    }

    /* The artifact as the rule engine wants it.
     *
     * Mixed sourcing, deliberately: steps are counted live from the diagram, so
     * a step added a moment ago is included; variables come from the committed
     * model, because that is the only place their default values exist. The
     * returned `variablesAreCommitted` flag lets the caller say so plainly
     * rather than presenting stale data as live.
     */
    function readArtifactModel() {
        var editor = visibleEditor();
        if (!editor) { return Promise.resolve(null); }
        var type = editor.getAttribute('data-test-editor') || '';
        var name = artifactName(editor) || '';
        var components = readComponents(editor);

        return loadVariables(editor).then(function (model) {
            return {
                type: type,
                name: name || (model ? model.name : ''),
                variables: model ? model.variables : [],
                /* Steps stay live from the diagram - one added a moment ago is
                   counted - but fall back to the committed model for a type the
                   diagram does not draw, such as a business object. */
                components: components.length ? components
                                              : (model ? model.components : []),
                componentsAreLive: components.length > 0,
                /* Everything the committed model knows beyond variables and
                   steps: service settings, coach-view header flags, UCA event
                   configuration, business-object annotations. This is what
                   per-artifact-type rules read. */
                settings: model ? model.settings : {},
                /* Committed code surfaces. A coach view keeps its load and
                   unload handlers here, where the editor never shows them
                   beside the inline script. */
                surfaces: model ? model.surfaces : [],
                variablesAreCommitted: !!model,
                /* Whether input/output variables are a thing for this type at
                   all. A coach view has none by nature; a service flow with an
                   empty signature really does have none. Reporting both as
                   "0 (as last saved)" made the first look like the second. */
                variablesApply: model ? model.variablesApply !== false : true,
                commitSeq: model ? model.commitSeq : null,
                uncommittedChanges: model ? model.uncommitted : false
            };
        });
    }

    /* ----------------------------------------------------------- annotations */

    function orion(surface) {
        var w = surfaceWidget(surface);
        if (!w || !w.editorObj) { return null; }
        var ed = w.editorObj;
        try {
            var tv = ed.getTextView();
            return { widget: w, editor: ed, textView: tv, textModel: tv.getModel(),
                     model: ed.getAnnotationModel() };
        } catch (e) { return null; }
    }

    /* Types must exist on the styler and ruler before any annotation is added.
       Registering afterwards leaves the annotation in the model, unrendered.

       Registration lives on the editor *instance*, and the Designer builds a new
       one every time an artifact is opened or a surface is switched. Caching
       "already registered" therefore produces the worst possible bug: the
       annotations are in the model, the code looks correct, and nothing appears.
       addAnnotationType is idempotent and cheap - call it every time. */
    function ensureTypes(o) {
        var styler = o.editor.getAnnotationStyler && o.editor.getAnnotationStyler();
        var ruler = o.editor.getAnnotationRuler && o.editor.getAnnotationRuler();
        var overview = o.editor.getOverviewRuler && o.editor.getOverviewRuler();
        ['orion.annotation.error', 'orion.annotation.warning'].forEach(function (t) {
            [styler, ruler, overview].forEach(function (target) {
                try { if (target && target.addAnnotationType) { target.addAnnotationType(t); } }
                catch (e) { /* a missing ruler is not fatal */ }
            });
        });
    }

    /* The Designer runs its own JavaScript validator on every edit, and it does
       not merely add its findings - it calls replaceAnnotations(everything,
       itsOwnFindings). Verified: a one-character edit removed all four of our
       annotations along with its own, then re-added only its own.

       Ours are therefore transient by design, and something has to put them
       back. This watchdog re-asserts them when it sees them removed by someone
       else. Our own writes set `applying`, so it never reacts to itself. */
    var desired = null;          /* {surface, annotations: [...]} */
    var watchdog = null;
    var applying = false;
    var reassertTimer = null;

    function installWatchdog(o) {
        if (watchdog && watchdog.editor === o.editor) { return; }
        removeWatchdog();
        var handler = function (e) {
            if (applying || !desired) { return; }
            var removed = e && e.removed;
            if (!removed || !removed.length) { return; }
            var lostOurs = desired.annotations.some(function (a) {
                return removed.indexOf(a) >= 0;
            });
            if (!lostOurs) { return; }
            /* Let the validator finish its pass first, or the two of us trade
               writes indefinitely. */
            if (reassertTimer) { win.clearTimeout(reassertTimer); }
            reassertTimer = win.setTimeout(function () {
                reassertTimer = null;
                reassert();
            }, 400);
        };
        try {
            o.model.addEventListener('Changed', handler);
            watchdog = { editor: o.editor, model: o.model, handler: handler };
        } catch (e) { /* without this, annotations simply do not persist */ }
    }

    function removeWatchdog() {
        if (reassertTimer && win) {
            try { win.clearTimeout(reassertTimer); } catch (e) { /* ignore */ }
        }
        reassertTimer = null;
        if (!watchdog) { return; }
        try { watchdog.model.removeEventListener('Changed', watchdog.handler); }
        catch (e) { /* editor already gone */ }
        watchdog = null;
    }

    /* Put ours back without disturbing the Designer's own findings. */
    function reassert() {
        if (!desired) { return; }
        var o = orion(desired.surface);
        if (!o) { return; }
        ensureTypes(o);
        applying = true;
        try {
            var present = collectAnnotations(o);
            var missing = desired.annotations.filter(function (a) {
                return present.indexOf(a) < 0;
            });
            if (missing.length) {
                o.model.replaceAnnotations([], missing);
                repaint(o);
            }
        } catch (e) { /* best effort */ }
        applying = false;
    }

    /* What the Designer's OWN validator has found in this buffer.
     *
     * IBM ships a real JavaScript validator and it writes into the same
     * annotation model we do - undefined identifiers, unknown tw.local
     * properties, syntax problems. It has type information about the artifact
     * that we cannot reconstruct from a regex, so reimplementing it would be
     * both wasted effort and worse.
     *
     * Reading it costs nothing and it is already on screen, so the panel can be
     * the one place a developer looks instead of two. It also answers two
     * checklist rows outright - General!B10 "code free from JavaScript errors"
     * and General!B14 "all validation errors removed" - with no rule authoring.
     *
     * Ours are excluded by identity, not by parsing the title: `desired` holds
     * the exact objects we added, so anything else in the model is IBM's. These
     * are NEVER re-annotated - they are already drawn, and writing them back
     * would fight the validator that owns them.
     */
    function readDesignerFindings(surface) {
        var s = surface || sense().surface;
        if (!s) { return []; }
        var o = orion(s);
        if (!o) { return []; }

        var mine = (desired && desired.surface === s) ? desired.annotations : [];
        var out = [];
        collectAnnotations(o).forEach(function (a) {
            if (mine.indexOf(a) >= 0) { return; }          /* ours */
            var type = a.type || '';
            if (type.indexOf('orion.annotation.') !== 0) { return; }
            /* Bookmarks, folding, matching brackets and the like are furniture,
               not findings. Only the two diagnostic types are of interest. */
            var isError = type === 'orion.annotation.error';
            if (!isError && type !== 'orion.annotation.warning') { return; }

            var line = 0;
            try { line = o.textModel.getLineAtOffset(a.start) + 1; } catch (e) { return; }

            var text = (a.title || '').toString().trim();
            if (!text) { return; }

            out.push({
                ruleId: 'DESIGNER',
                ruleName: 'Process Designer validation',
                category: 'javascript',
                /* IBM's own severity, mapped onto ours. Their "error" is a real
                   defect; their "warning" is advisory. */
                severity: isError ? 'major' : 'minor',
                message: text,
                line: line,
                column: 0,
                endColumn: 0,
                snippet: '',
                occurrences: 1,
                lifecycle: 'active',
                enforcement: 'advisory',
                source: { sourceId: 'IBM-PROCESS-DESIGNER', locator: 'designer',
                          authorityStatus: 'technical' }
            });
        });

        out.sort(function (a, b) { return a.line - b.line; });
        return out;
    }

    function collectAnnotations(o) {
        var acc = [];
        try {
            var it = o.model.getAnnotations(0, o.textModel.getCharCount());
            /* Removing while iterating invalidates the iterator - collect first. */
            while (it && it.hasNext && it.hasNext()) { acc.push(it.next()); }
        } catch (e) { /* empty */ }
        return acc;
    }

    function clearAnnotations(surface) {
        var s = surface || sense().surface;
        if (!s) { return 0; }
        var o = orion(s);
        if (!o) { return 0; }
        var mine = (desired && desired.surface === s) ? desired.annotations : [];
        desired = null;
        removeWatchdog();
        applying = true;
        var existing = collectAnnotations(o);
        var toRemove = existing.filter(function (a) { return mine.indexOf(a) >= 0; });
        /* removeAnnotations() with no argument does NOT clear - and we must not
           delete the Designer's own findings along with ours. */
        try { o.model.replaceAnnotations(toRemove, []); } catch (e) {
            toRemove.forEach(function (a) {
                try { o.model.removeAnnotation(a); } catch (e2) { /* ignore */ }
            });
        }
        applying = false;
        repaint(o);
        return toRemove.length;
    }

    function repaint(o) {
        try { o.textView.redrawLines(0, o.textModel.getLineCount()); }
        catch (e) { try { o.textView.redraw(); } catch (e2) { /* ignore */ } }
    }

    /* findings: [{line, severity, message, ruleId}] - the lint service's shape. */
    function annotate(findings, surface) {
        var s = surface || sense().surface;
        if (!s) { return { drawn: 0, reason: 'no displayed surface' }; }
        var o = orion(s);
        if (!o) { return { drawn: 0, reason: 'no Orion editor for ' + s }; }

        ensureTypes(o);
        var existing = collectAnnotations(o);
        var lineCount = o.textModel.getLineCount();
        var next = [];

        (findings || []).forEach(function (f) {
            var idx = Math.max(0, Math.min((f.line || 1) - 1, lineCount - 1));
            var kind = CSS_KIND[f.severity] || 'warning';
            var start, end;
            try {
                start = o.textModel.getLineStart(idx);
                end = o.textModel.getLineEnd(idx);
            } catch (e) { return; }
            if (end <= start) { end = start + 1; }   /* empty line: keep a width */
            next.push({
                start: start, end: end,
                type: ANNOTATION_TYPE[f.severity] || 'orion.annotation.warning',
                title: (f.ruleId ? f.ruleId + ': ' : '') + (f.message || ''),
                html: '<div class="annotationHTML ' + kind + '"></div>',
                style: { styleClass: 'annotation ' + kind },
                overviewStyle: { styleClass: 'annotationOverview ' + kind },
                rangeStyle: { styleClass: 'annotationRange ' + kind }
            });
        });

        applying = true;
        try {
            /* Remove only what we put there last time. The Designer's own
               findings share this model and are not ours to delete. */
            var mine = (desired && desired.surface === s) ? desired.annotations : [];
            var toRemove = existing.filter(function (a) { return mine.indexOf(a) >= 0; });
            o.model.replaceAnnotations(toRemove, next);
        } catch (e) {
            applying = false;
            return { drawn: 0, reason: e.message };
        }
        applying = false;
        desired = { surface: s, annotations: next };
        installWatchdog(o);
        repaint(o);
        return { drawn: next.length, surface: s };
    }

    /* ----------------------------------------------------------- repairing
     *
     * The ONLY thing in this module that writes anything, anywhere.
     *
     * It edits the developer's editor buffer, at their explicit request, one
     * line at a time. It does not save: the change sits in the editor exactly
     * as if it had been typed, so the developer reviews it, and Designer's own
     * save pipeline and validators remain the authority over what reaches the
     * artifact. Nothing here touches REST and nothing here touches an artifact.
     */

    /**
     * Replace or delete one line of a surface.
     *
     * `after` of null removes the line, including its newline. `expected` is
     * the text the caller believes is there; if the line has changed since the
     * proposal was computed - the developer kept typing - the edit is refused
     * rather than applied to something else. That check is the whole safety
     * story for a stale fix.
     */
    function applyLineEdit(surface, line, after, expected) {
        var s = surface || sense().surface;
        if (!s) { return { ok: false, reason: 'no surface' }; }
        var o = orion(s);
        if (!o) { return { ok: false, reason: 'no editor for ' + s }; }

        try {
            var idx = line - 1;
            if (idx < 0 || idx >= o.textModel.getLineCount()) {
                return { ok: false, reason: 'line ' + line + ' is out of range' };
            }
            var start = o.textModel.getLineStart(idx);
            var end = o.textModel.getLineEnd(idx);
            var current = o.textModel.getText(start, end);

            /* Compare without the line delimiter.

               Orion excludes it from getLineEnd, while a server splitting
               on a newline keeps the carriage return - and BAW stores these
               buffers with CRLF. A literal comparison therefore refuses
               every fix on a difference that is not real. */
            var normalise = function (t) { return String(t).replace(/\r$/, ''); };
            if (typeof expected === 'string'
                    && normalise(current) !== normalise(expected)) {
                return { ok: false, reason: 'the line has changed since the fix was offered',
                         current: current };
            }

            if (after === null || after === undefined) {
                /* Take the newline with it, or the fix leaves a blank line
                   where the defect used to be. The last line has no trailing
                   newline to take. */
                var endWithBreak = (idx + 1 < o.textModel.getLineCount())
                    ? o.textModel.getLineStart(idx + 1)
                    : end;
                o.textModel.setText('', start, endWithBreak);
            } else {
                o.textModel.setText(after, start, end);
            }
            return { ok: true };
        } catch (e) {
            return { ok: false, reason: e.message };
        }
    }

    /* ------------------------------------------------------------- watching */

    /* ModelChanged carries {start, addedCharCount, removedCharCount}, so a
       consumer can re-lint incrementally. Modify never fires - do not use it. */
    function watch(callback, debounceMs) {
        unwatch();
        var s = sense().surface;
        if (!s) { return false; }
        var o = orion(s);
        if (!o) { return false; }

        var timer = null;
        var pending = null;
        var handler = function (e) {
            pending = { start: e && e.start, added: e && e.addedCharCount,
                        removed: e && e.removedCharCount };
            if (timer) { win.clearTimeout(timer); }
            timer = win.setTimeout(function () {
                timer = null;
                var delta = pending; pending = null;
                try { callback(readDisplayedBuffer(), delta); } catch (err) { /* keep alive */ }
            }, debounceMs || 350);
        };

        try { o.textView.addEventListener('ModelChanged', handler); }
        catch (e) { return false; }

        watchHandle = {
            surface: s,
            detach: function () {
                if (timer) { try { win.clearTimeout(timer); } catch (e) {} }
                try { o.textView.removeEventListener('ModelChanged', handler); }
                catch (e) { /* the editor may already be gone */ }
            }
        };
        return true;
    }

    function unwatch() {
        if (watchHandle) { watchHandle.detach(); watchHandle = null; }
    }

    function watchedSurface() { return watchHandle ? watchHandle.surface : null; }

    /* ----------------------------------------------------------------- panel */

    /* mainContainer is a dijit.layout.BorderContainer. A trailing region can be
       added and removed at runtime; resize() is required either way, because
       the layout does not reflow on its own. */
    function dockPanel(width) {
        if (!isAlive()) { return null; }
        var existing = win.dijit.byId(panelId);
        if (existing) { return existing.domNode; }
        var mc = win.dijit.byId('mainContainer');
        if (!mc) { return null; }
        try {
            var ContentPane = win.require('dijit/layout/ContentPane');
            var pane = new ContentPane({
                id: panelId, region: 'trailing', splitter: true,
                style: 'width:' + (width || 340) + 'px;padding:0;overflow:hidden;'
            });
            mc.addChild(pane);
            mc.resize();
            return pane.domNode;
        } catch (e) { return null; }
    }

    function undockPanel() {
        if (!isAlive()) { return false; }
        try {
            var pane = win.dijit.byId(panelId);
            if (!pane) { return false; }
            var mc = win.dijit.byId('mainContainer');
            if (mc) { mc.removeChild(pane); }
            pane.destroyRecursive();
            if (mc) { mc.resize(); }
            return true;
        } catch (e) { return false; }
    }

    global.BawBridge = {
        SURFACES: SURFACES,
        /* Read-only, and exported because SURFACES is the KNOWN set while this
           is what is actually on screen - including the label-named inline
           event handlers, which no enumeration can predict. */
        discoverSurfaces: discoverSurfaces,
        attach: attach, isAlive: isAlive, ready: ready,
        sense: sense,
        readDisplayedBuffer: readDisplayedBuffer, readModel: readModel,
        /* Every code surface on screen, not just the bound one. A coach
           component shows three event editors at once and the panel used to
           judge exactly one of them. */
        readSurfaceBuffer: readSurfaceBuffer,
        readOnScreenBuffers: readOnScreenBuffers,
        otherSurfacesSignature: otherSurfacesSignature,
        /* Exposed so the hub can reveal a finding in the surface the
           developer is actually looking at, instead of re-querying the
           whole document and taking the last match. */
        surfaceHost: surfaceHost, surfaceWidget: surfaceWidget,
        /* DOM-free: parse a payload the caller already has. The report
           path and the tests use these without a Designer window. */
        parseAsset: parseAsset,
        /* Exposed for the model tests: the live diagram and the committed
           model must shorten a step type the same way. */
        shortType: shortType,
        /* The report path has no Designer and no branch to resolve from. */
        setAppAcronym: setAppAcronym,
        /* Tests and the whole-application review supply team types directly. */
        setTeamType: setTeamType,
        /* Applications, snapshots and whole-inventory reads. A snapshot
           ref works wherever a branch ref does, so these are what let a
           track be compared against what was actually deployed. */
        listProcessApps: listProcessApps, listToolkits: listToolkits,
        parseContainers: parseContainers, listSnapshots: listSnapshots,
        readInventory: readInventory,
        readArtifactModel: readArtifactModel, setBranch: setBranch,
        shapeSignature: shapeSignature, surfaceSignature: surfaceSignature,
        saveSignal: saveSignal,
        onSave: onSave, offSave: offSave,
        invalidateModel: invalidateModel, activeArtifact: activeArtifact,
        annotate: annotate, clearAnnotations: clearAnnotations,
        applyLineEdit: applyLineEdit,
        readDesignerFindings: readDesignerFindings,
        watch: watch, unwatch: unwatch, watchedSurface: watchedSurface,
        dockPanel: dockPanel, undockPanel: undockPanel, usePanel: usePanel
    };
}(window));

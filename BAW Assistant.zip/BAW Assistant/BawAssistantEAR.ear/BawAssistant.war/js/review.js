/* Review a whole application at a container ref.
 *
 * Path 2 of the product: not "is this script right" but "is this application
 * fit to deploy". The owner settled the shape on 2026-08-30 - there is NO .twx
 * export. It reads live artifacts over REST at a container ref, which is a
 * named snapshot or the tip of a branch or track, and a snapshot ref behaves
 * exactly like a branch ref everywhere, so one code path serves both.
 *
 * Division of labour, and it is not arbitrary:
 *
 *   the browser SWEEPS   bridge.js's readers are keyed on the payload's own
 *                        domainProperty and are two thousand lines deep.
 *                        harvest-corpus.js already imports them rather than
 *                        reimplementing them, so a second copy cannot drift; a
 *                        Java sweep would be that second copy. The browser also
 *                        holds the LTPA session, which this servlet does not.
 *
 *   the server JUDGES    POST /api/review takes a batch of artifacts and runs
 *                        every automated rule over them. Batching is not
 *                        optional: the body cap is 2 MB and the largest
 *                        measured application is 2,041,023 characters of code.
 *
 * Laid out after IBM's own IDA report, which the owner nominated as the model.
 * Its structure maps almost one to one onto what a Finding already carries:
 * Symptom is `message`, Best Practice is `remediation` plus `rationale`,
 * Reference is `source`, and the severity tabs and category chips are
 * `severity` and `category`.
 */
(function () {
    'use strict';

    var $ = function (id) { return document.getElementById(id); };
    var B = window.BawBridge;
    var F = window.BawFindings;
    var API = (window.config && config.contextPath) || '';

    /* Chosen against the 2 MB body cap with room for JSON escaping, which can
       nearly double a string of code full of quotes and backslashes. */
    var BATCH_CHARS = 300000;

    var state = {
        containers: { app: [], toolkit: [] },
        refs: [],
        report: null,
        severity: '',          /* '' is every level */
        categories: [],
        qSymptom: '',
        qArtifact: '',
        open: {},
        /* By rule, or by artifact.
         *
         * IBM's IDA report answers "which symptom is widespread" on one page
         * and "which artifact is worst" on another, and a reader comparing the
         * two is doing it by memory. They are the same findings asked a
         * different question, so this is one control rather than two pages.
         * Grouping by rule is the default because that is the order a reviewer
         * fixes things in - the widespread symptom first. */
        group: 'rule',
        sort: 'severity',
        /* Which view is on screen, and which row the detail pane is showing.
           Selection is by key rather than by index so it survives a filter
           change that reorders the list. */
        view: 'findings',
        selected: null
    };

    /* Take the reader to the list they have just narrowed.
     *
     * Pressing a summary tile without this changes a list a screen and a half
     * below the fold, so the page appears to do nothing. The command bar is
     * sticky, so scrolling here never costs the reader their controls. */
    function goToFindings() { showView('findings'); }

    /* One screen, five questions. Switching a view is not navigation - the
       report does not change and nothing is refetched - so it costs a class
       and a display, and the filters keep whatever they were set to. */
    var VIEWS = { findings: 'workFindings', overview: 'workOverview',
                  artifacts: 'workArtifacts', dup: 'workDup', manual: 'workManual' };

    function showView(name) {
        if (!VIEWS[name]) { return; }
        state.view = name;
        Object.keys(VIEWS).forEach(function (k) {
            $(VIEWS[k]).style.display = (k === name) ? '' : 'none';
        });
        var btns = document.querySelectorAll('#views .view');
        for (var i = 0; i < btns.length; i++) {
            var on = btns[i].getAttribute('data-view') === name;
            btns[i].setAttribute('aria-selected', on ? 'true' : 'false');
            /* Roving tabindex: Tab reaches one stop in the tablist, the
               selected view; the other four are reachable by arrow key,
               per the ARIA tab pattern - not by tabbing past each in turn. */
            btns[i].tabIndex = on ? 0 : -1;
        }
    }

    /* Left/Right (and Home/End) move the roving tab stop within a tablist and
     * activate what they land on, per the ARIA authoring practice for tabs.
     * #views is a real tablist. #tabs is a GROUP of filter buttons - they
     * control no tabpanel, so role="tab" would be a promise nothing keeps -
     * but arrow keys through a set of filters is the same useful behaviour,
     * so the item selector is a parameter rather than a hardcoded role.
     *
     * Delegated on the container rather than bound per-button, because
     * #tabs is rebuilt from scratch on every render() and a per-button
     * listener would need rewiring every time. */
    function wireRovingTablist(containerId, itemSelector) {
        var SEL = itemSelector || '[role="tab"]';
        var container = $(containerId);
        container.addEventListener('keydown', function (ev) {
            var k = ev.key;
            if (k !== 'ArrowLeft' && k !== 'ArrowRight' && k !== 'Home' && k !== 'End') { return; }
            var items = container.querySelectorAll(SEL);
            if (!items.length) { return; }
            var i = Array.prototype.indexOf.call(items, document.activeElement);
            if (i < 0) { i = 0; }
            var next = i;
            if (k === 'ArrowLeft') { next = (i - 1 + items.length) % items.length; }
            else if (k === 'ArrowRight') { next = (i + 1) % items.length; }
            else if (k === 'Home') { next = 0; }
            else { next = items.length - 1; }
            ev.preventDefault();
            items[next].click();
            /* #tabs replaces its buttons on click (render() rebuilds the
               list); #views does not. Re-query either way so focus lands on
               whichever node is live afterwards, at the same position. */
            var after = container.querySelectorAll(SEL);
            if (after[next]) { after[next].focus(); }
        });
    }

    /* The same findings, grouped by the artifact they were found in.
     *
     * Deliberately NOT in findings.js: that module is shared with the docked
     * panel, which lints one buffer and has no notion of an artifact. A
     * grouping only the report can use belongs to the report. */
    function byArtifact(list) {
        var index = {};
        var out = [];
        (list || []).forEach(function (f) {
            if (!f) { return; }
            var name = f.artifact || '(unnamed)';
            var row = index[name];
            if (!row) {
                row = { key: name, artifact: name, artifactType: f.artifactType || '',
                        severity: f.severity || 'warning', occurrences: [] };
                index[name] = row;
                out.push(row);
            }
            /* The worst severity in an artifact wins its row, so an artifact
               holding one critical is never filed under minor. */
            if (F.rank(f.severity) < F.rank(row.severity)) { row.severity = f.severity; }
            row.occurrences.push(f);
        });
        return out;
    }

    /* One comparator for both groupings. "Worst first" is the reviewer's order;
       "most findings" is the manager's; "name" is for finding a known one. */
    function sortRows(rows) {
        var how = state.sort;
        return rows.slice().sort(function (a, b) {
            if (how === 'count') {
                var d = b.occurrences.length - a.occurrences.length;
                if (d !== 0) { return d; }
            } else if (how === 'name') {
                return String(a.ruleId || a.artifact)
                    .localeCompare(String(b.ruleId || b.artifact));
            }
            var s = F.rank(a.severity) - F.rank(b.severity);
            if (s !== 0) { return s; }
            var c = b.occurrences.length - a.occurrences.length;
            if (c !== 0) { return c; }
            return String(a.ruleId || a.artifact)
                .localeCompare(String(b.ruleId || b.artifact));
        });
    }

    /* "539 finding(s) in 55 rule(s)" is system voice. The count is known at
       the point of writing, so the word can simply be right. English needs one
       irregular here - "copies" - and nothing else in this report does. */
    function n(count, one, many) {
        return count + ' ' + (count === 1 ? one : (many || one + 's'));
    }

    function setStatus(node, text, kind) {
        var n = $(node);
        n.textContent = text;
        n.className = 'status ' + (kind || '');
    }

    function api(path, body) {
        var opts = { method: 'POST', headers: { 'Content-Type': 'application/json' },
                     body: JSON.stringify(body) };
        return fetch(API.replace(/\/$/, '') + path, opts).then(function (r) {
            if (!r.ok) { throw new Error(r.status + ' ' + r.statusText); }
            return r.json();
        });
    }

    function el(tag, attrs) {
        var n = document.createElement(tag);
        attrs = attrs || {};
        Object.keys(attrs).forEach(function (k) {
            if (k === 'class') { n.className = attrs[k]; }
            else if (k.slice(0, 2) === 'on') { n.addEventListener(k.slice(2), attrs[k]); }
            else if (attrs[k] !== null && attrs[k] !== false) { n.setAttribute(k, attrs[k]); }
        });
        for (var i = 2; i < arguments.length; i++) {
            var c = arguments[i];
            if (c === null || c === undefined || c === false) { continue; }
            n.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
        }
        return n;
    }

    var SVG = 'http://www.w3.org/2000/svg';
    /* Severity as a shape as well as a colour - critical and major are red and
       orange, the pair a red-green colour blindness separates least well. */
    function severityMark(sev) {
        var s = String(sev || 'warning').toLowerCase();
        var n = document.createElementNS(SVG, 'svg');
        n.setAttribute('viewBox', '0 0 16 16');
        n.setAttribute('class', 'mk ' + s);
        n.setAttribute('role', 'img');
        var shape;
        if (s === 'critical') {
            shape = document.createElementNS(SVG, 'circle');
            shape.setAttribute('cx', 8); shape.setAttribute('cy', 8); shape.setAttribute('r', 7);
        } else if (s === 'major') {
            shape = document.createElementNS(SVG, 'polygon');
            shape.setAttribute('points', '8,1 15,15 1,15');
        } else if (s === 'minor') {
            shape = document.createElementNS(SVG, 'polygon');
            shape.setAttribute('points', '8,1 15,8 8,15 1,8');
        } else {
            shape = document.createElementNS(SVG, 'rect');
            shape.setAttribute('x', 2); shape.setAttribute('y', 2);
            shape.setAttribute('width', 12); shape.setAttribute('height', 12);
        }
        n.appendChild(shape);
        var t = document.createElementNS(SVG, 'title');
        t.textContent = s;
        n.appendChild(t);
        return n;
    }

    /* ------------------------------------------------------------- choosing */

    Promise.all([B.listProcessApps(), B.listToolkits()]).then(function (both) {
        state.containers.app = both[0];
        state.containers.toolkit = both[1];
        fillContainers();
        setStatus('status', n(both[0].length, 'application') + ', '
                + n(both[1].length, 'toolkit'), 'good');
    }).catch(function (e) {
        setStatus('status', 'Could not list applications: ' + e.message, 'bad');
    });

    function chosen() {
        var list = state.containers[$('kind').value] || [];
        return list[parseInt($('container').value, 10)] || null;
    }

    function fillContainers() {
        var list = state.containers[$('kind').value] || [];
        var sel = $('container');
        sel.innerHTML = '';
        if (!list.length) {
            sel.appendChild(el('option', null, 'none found'));
            $('run').disabled = true;
            return;
        }
        list.forEach(function (c, i) {
            sel.appendChild(el('option', { value: String(i) },
                c.name + '  (' + c.shortName + ')'));
        });
        loadRefs();
    }

    $('kind').addEventListener('change', fillContainers);
    $('container').addEventListener('change', loadRefs);

    /* The track plus every snapshot taken from it. Both are containerRefs and
       the engine cannot tell them apart, which is the whole point. */
    function loadRefs() {
        var c = chosen();
        if (!c) { return; }
        $('run').disabled = true;
        setStatus('status', 'reading snapshots...', '');

        var branch = c.branchRef;
        var promise = branch ? B.listSnapshots(branch) : Promise.resolve([]);
        promise.then(function (snaps) {
            var refs = [];
            if (branch) {
                refs.push({ ref: branch,
                            label: (c.branchName || 'Main') + '  (current track)' });
            }
            snaps.forEach(function (s) {
                var when = s.created ? new Date(s.created).toISOString().slice(0, 10) : '';
                refs.push({ ref: s.ref, label: 'snapshot ' + s.name + '  ' + when });
            });
            /* A toolkit usually has no branch of its own, so the snapshot it is
               consumed at is the only thing to read. Without this the toolkit
               would list nothing and look broken. */
            if (!refs.length && c.snapshotRef) {
                refs.push({ ref: c.snapshotRef,
                            label: 'snapshot ' + (c.snapshotName || 'installed') });
            }
            state.refs = refs;
            var sel = $('ref');
            sel.innerHTML = '';
            refs.forEach(function (r, i) {
                sel.appendChild(el('option', { value: String(i) }, r.label));
            });
            $('run').disabled = !refs.length;
            setStatus('status', refs.length
                ? n(refs.length, 'moment') + ' available'
                : 'nothing readable for this container', refs.length ? 'good' : 'warn');
        });
    }

    /* ------------------------------------------------------------ analysing */

    $('run').addEventListener('click', function () {
        var c = chosen();
        var ref = state.refs[parseInt($('ref').value, 10)];
        if (!c || !ref) { return; }
        run(c, ref);
    });

    function progress(done, total) {
        var bar = $('bar');
        bar.style.display = '';
        bar.firstChild.style.width = total ? Math.round(done * 100 / total) + '%' : '0';
    }

    function run(container, ref) {
        $('run').disabled = true;
        $('views').style.display = 'none';
        Object.keys(VIEWS).forEach(function (k) { $(VIEWS[k]).style.display = 'none'; });

        var skipped = [];
        setStatus('status', 'reading artifacts...', '');

        B.readInventory(ref.ref, function (done, total) {
            progress(done, total);
            setStatus('status', 'reading artifact ' + done + ' of ' + total, '');
        }, function (t) {
            skipped.push({ name: t.name, type: t.listedAs, poId: t.poId });
        }).then(function (models) {
            var list = Object.keys(models).map(function (k) { return models[k]; });
            if (!list.length) {
                throw new Error('nothing readable at this ref');
            }
            return judge(list).then(function (result) {
                result.container = container;
                result.ref = ref;
                result.models = list;
                result.skipped = skipped;
                result.duplicates = duplicates(list);
                return result;
            });
        }).then(function (report) {
            state.report = report;
            $('bar').style.display = 'none';
            render();
            $('run').disabled = false;
        }).catch(function (e) {
            $('bar').style.display = 'none';
            setStatus('status', 'Analysis failed: ' + e.message, 'bad');
            $('run').disabled = false;
        });
    }

    /* Post the artifacts in batches and merge what comes back.
     *
     * Batched by accumulated CODE characters rather than by artifact count,
     * because artifacts are wildly uneven - most carry none at all and one
     * coach view can carry more than a hundred others together. */
    function judge(models) {
        var batches = [];
        var current = [];
        var size = 0;
        models.forEach(function (m) {
            var payload = {
                /* The editor type the PAYLOAD says it is, never the display
                   name the asset listing grouped it under.
                 *
                 * Every rule's appliesTo is written in the editor vocabulary -
                 * SERVICEFLOW, COACHFLOW, CaseProcess - while the listing says
                 * "Integration Service", "Human Service", "BPD". Sending the
                 * listing name matches nothing, silently: the first live run
                 * of this page reported 313 artifact findings where the same
                 * sweep judged headlessly reported 362, because 9 heritage
                 * services, 4 BPDs and 11 assorted services were each filed
                 * under a type no rule has ever heard of.
                 *
                 * harvest-corpus.js hit this before and says so at the line it
                 * does the same thing; this is that fix, in the second caller.
                 * The listing name travels beside it as listedAs. */
                type: m.editorType || m.type,
                name: m.name, poId: m.poId, listedAs: m.listedAs,
                variables: m.variables, components: m.components,
                settings: m.settings,
                /* Pass the reader's surface through, rather than rebuilding a
                 * subset of it.
                 *
                 * This used to send {surface, node, language, code} only, which
                 * silently dropped `name`, `lines`, `index` and `handlerKind`.
                 * HOUSE.UI.INLINE_EVENT_HANDLER_LONG counts surfaces where
                 * `lines` > 5, and an absent field cannot be greater than 5 -
                 * so the rule was DEAD in the review while passing every test,
                 * because Corpus measures it over models.json, which does carry
                 * `lines`. Proven live: the same 41-line handler returns 13
                 * findings without `lines` and 14 with it.
                 *
                 * That is the `type` vs `editorType` defect one field along -
                 * a caller reshaping what the reader published, and a rule
                 * going quiet instead of erroring. Copying the surface whole
                 * means the next field a reader learns to publish arrives here
                 * without anyone remembering to add it. */
                surfaces: (m.surfaces || []).map(function (s) {
                    var copy = {};
                    Object.keys(s || {}).forEach(function (k) { copy[k] = s[k]; });
                    copy.node = s.node || null;
                    copy.language = s.language || 'javascript';
                    copy.code = s.code || '';
                    return copy;
                })
            };
            var chars = 0;
            payload.surfaces.forEach(function (s) { chars += s.code.length; });
            if (current.length && size + chars > BATCH_CHARS) {
                batches.push(current);
                current = [];
                size = 0;
            }
            current.push(payload);
            size += chars;
        });
        if (current.length) { batches.push(current); }

        var findings = [];
        var scanned = { artifacts: 0, surfaces: 0, characters: 0, byType: {} };
        var rulesRun = 0;
        var i = 0;

        function next() {
            if (i >= batches.length) {
                return Promise.resolve({ findings: findings, scanned: scanned,
                                         rulesRun: rulesRun });
            }
            var batch = batches[i++];
            setStatus('status', 'checking batch ' + i + ' of ' + batches.length, '');
            progress(i, batches.length);
            return api('/api/review', { artifacts: batch, minSeverity: 'info' })
                .then(function (r) {
                    findings = findings.concat(r.findings || []);
                    rulesRun = r.rulesRun || rulesRun;
                    var s = r.scanned || {};
                    scanned.artifacts += s.artifacts || 0;
                    scanned.surfaces += s.surfaces || 0;
                    scanned.characters += s.characters || 0;
                    Object.keys(s.byType || {}).forEach(function (t) {
                        scanned.byType[t] = (scanned.byType[t] || 0) + s.byType[t];
                    });
                    return next();
                });
        }
        return next();
    }

    /* Identical code in more than one place.
     *
     * Deliberately NOT a rule, and the reason is worth stating: every rule kind
     * the engine has judges ONE thing in isolation - a buffer rule sees one
     * surface, an artifact rule one model. Duplication is a property of a SET,
     * so expressing it as a rule would mean inventing a kind that lies about
     * what it can see. It belongs to the level that holds the whole
     * application, which is here.
     *
     * Whitespace-normalised so a reformat does not hide a copy, and nothing
     * cleverer - near-duplicate detection is a different, much larger question.
     */
    function duplicates(models) {
        var byContent = {};
        models.forEach(function (m) {
            (m.surfaces || []).forEach(function (s) {
                var code = String(s.code || '');
                var key = code.replace(/\s+/g, ' ').trim();
                /* A one-line surface is duplicated all over any estate without
                   it meaning anything. */
                if (key.length < 120) { return; }
                if (!byContent[key]) { byContent[key] = []; }
                byContent[key].push({
                    artifact: m.name, type: m.editorType || m.type,
                    where: s.surface + (s.node ? ' @ ' + s.node : ''),
                    lines: code.split('\n').length
                });
            });
        });
        var groups = [];
        Object.keys(byContent).forEach(function (k) {
            if (byContent[k].length > 1) { groups.push(byContent[k]); }
        });
        groups.sort(function (a, b) {
            var d = b.length - a.length;
            return d !== 0 ? d : (b[0].lines - a[0].lines);
        });
        return groups;
    }

    /* -------------------------------------------------------------- showing */

    function visible() {
        if (!state.report) { return []; }
        var qs = state.qSymptom.toLowerCase();
        var qa = state.qArtifact.toLowerCase();
        return state.report.findings.filter(function (f) {
            if (state.severity && f.severity !== state.severity) { return false; }
            if (state.categories.length
                    && state.categories.indexOf(f.category || '') < 0) { return false; }
            if (qs && String(f.message || '').toLowerCase().indexOf(qs) < 0) { return false; }
            if (qa && String(f.artifact || '').toLowerCase().indexOf(qa) < 0) { return false; }
            return true;
        });
    }

    function render() {
        var r = state.report;
        var all = r.findings;
        var counts = F.tally(all);

        setStatus('scanned', n(r.scanned.artifacts, 'artifact') + ', '
            + n(r.scanned.surfaces, 'code surface') + ', '
            + r.scanned.characters.toLocaleString() + ' characters, against '
            + n(r.rulesRun, 'automated rule'), 'good');

        /* Summary tiles, which are also the filter.
         *
         * They used to be read-only. A reader who sees "3 CRITICAL" reaches
         * for it - that is the whole point of putting the number there - and
         * nothing happened, so the summary and the controls that act on it
         * were two separate halves of the page joined only by the reader's
         * memory. Pressing one now narrows the report and takes you to it.
         *
         * Artifacts and Findings are totals rather than filters, so they clear
         * the filters instead of setting one. */
        var tiles = $('tiles');
        tiles.innerHTML = '';
        [['Artifacts', r.scanned.artifacts, '', null],
         ['Findings', all.length, '', ''],
         ['Critical', counts.severity.critical || 0, 'critical', 'critical'],
         ['Major', counts.severity.major || 0, 'major', 'major'],
         ['Minor', counts.severity.minor || 0, 'minor', 'minor'],
         ['Warning', counts.severity.warning || 0, 'warning', 'warning']
        ].forEach(function (t) {
            var sev = t[3];
            var pressable = sev !== null;
            var on = pressable && state.severity === sev;
            var node = el('div', {
                class: 'tile ' + t[2] + (pressable ? ' act' : '') + (on ? ' sel' : ''),
                role: pressable ? 'button' : null,
                tabindex: pressable ? '0' : null,
                'aria-pressed': pressable ? (on ? 'true' : 'false') : null
            },
                el('span', { class: 'n' }, String(t[1])),
                el('span', { class: 'k' }, t[0]));
            if (pressable) {
                var act = function () {
                    /* Pressing the tile that is already on clears it, so the
                       control that narrows is also the one that widens. */
                    state.severity = on ? '' : sev;
                    render();
                    goToFindings();
                };
                node.addEventListener('click', act);
                node.addEventListener('keydown', function (ev) {
                    if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
                        ev.preventDefault(); act();
                    }
                });
            }
            tiles.appendChild(node);
        });

        /* by category, each with its own severity split - the IDA report's
           warnings summary, which is the most scannable thing on it. */
        var cats = $('categories');
        cats.innerHTML = '';
        Object.keys(counts.category).sort(function (a, b) {
            return counts.category[b] - counts.category[a];
        }).forEach(function (c) {
            var mine = all.filter(function (f) { return f.category === c; });
            var mc = F.tally(mine).severity;
            /* A category card filters to its category, the same gesture as a
               severity tile. Selecting one that is already on clears it. */
            var conOn = state.categories.length === 1 && state.categories[0] === c;
            var card = el('div', {
                class: 'tile act' + (conOn ? ' sel' : ''),
                role: 'button', tabindex: '0',
                'aria-pressed': conOn ? 'true' : 'false'
            },
                el('span', { class: 'k' }, c),
                el('span', { class: 'n' }, String(mine.length)));
            (function (cat, on) {
                var act = function () {
                    state.categories = on ? [] : [cat];
                    render();
                    goToFindings();
                };
                card.addEventListener('click', act);
                card.addEventListener('keydown', function (ev) {
                    if (ev.key === 'Enter' || ev.key === ' ' || ev.key === 'Spacebar') {
                        ev.preventDefault(); act();
                    }
                });
            }(c, conOn));
            var split = el('div', { class: 'split' });
            [['critical', 'Critical'], ['major', 'Major'], ['minor', 'Minor'],
             ['warning', 'Warning']].forEach(function (p) {
                if (!mc[p[0]]) { return; }
                split.appendChild(el('div', null,
                    el('span', { class: 'v' }, String(mc[p[0]])),
                    el('span', { class: 'l' }, p[1])));
            });
            card.appendChild(split);
            cats.appendChild(card);
        });
        /* The chooser has done its job; give the screen to the findings. */
        $('setup').style.display = 'none';
        $('topbar').style.display = '';
        $('views').style.display = '';
        $('what').textContent = (r.container && (r.container.name || '')) + '  ·  '
            + ((r.ref && r.ref.label) || 'current track');
        $('vFindings').textContent = String(all.length);
        $('vArtifacts').textContent = String(r.scanned.artifacts);
        $('vDup').textContent = String((r.duplicates || []).length);
        showView(state.view);

        renderInventory(r);
        renderTabs(all, counts);
        renderChips(all, counts);
        renderFindings();
        renderDuplicates(r);
        renderManual(r);
    }

    function renderInventory(r) {
        var inv = $('inventory');
        inv.innerHTML = '';
        var types = Object.keys(r.scanned.byType).sort(function (a, b) {
            return r.scanned.byType[b] - r.scanned.byType[a];
        });
        types.forEach(function (t) {
            inv.appendChild(el('div', null,
                el('span', null, t),
                el('span', { class: 'c' }, String(r.scanned.byType[t]))));
        });
        setStatus('invCount', n(types.length, 'type') + ' read', 'good');

        if (r.skipped.length) {
            var fold = $('unreadableFold');
            fold.style.display = '';
            $('unreadableSummary').textContent =
                n(r.skipped.length, 'artifact') + ' the readers do not recognise';
            var box = $('unreadable');
            box.innerHTML = '';
            var byType = {};
            r.skipped.forEach(function (s) {
                byType[s.type] = (byType[s.type] || 0) + 1;
            });
            Object.keys(byType).sort().forEach(function (t) {
                box.appendChild(el('div', null,
                    el('span', null, t),
                    el('span', { class: 'c' }, String(byType[t]))));
            });
        } else {
            $('unreadableFold').style.display = 'none';
        }

    }

    function renderTabs(all, counts) {
        var tabs = $('tabs');
        tabs.innerHTML = '';
        var levels = [['', 'All levels', all.length]];
        F.SEVERITY_ORDER.forEach(function (s) {
            if (counts.severity[s]) {
                levels.push([s, s.charAt(0).toUpperCase() + s.slice(1),
                             counts.severity[s]]);
            }
        });
        levels.forEach(function (l) {
            var on = state.severity === l[0];
            /* A filter, expressed the same way as the category chips
               beside it: a button that is pressed or not. It used to declare
               role="tab" while controlling no tabpanel, which is a contract a
               screen reader cannot honour. */
            tabs.appendChild(el('button', {
                class: 'tab', type: 'button',
                'aria-pressed': on ? 'true' : 'false',
                onclick: function () { state.severity = l[0]; render(); }
            }, l[1] + '  ', el('span', { class: 'n' }, String(l[2]))));
        });
    }

    function renderChips(all, counts) {
        var chips = $('chips');
        chips.innerHTML = '';
        Object.keys(counts.category).sort().forEach(function (c) {
            var on = state.categories.indexOf(c) >= 0;
            chips.appendChild(el('button', {
                class: 'chip', type: 'button',
                'aria-pressed': on ? 'true' : 'false',
                onclick: function () {
                    var i = state.categories.indexOf(c);
                    if (i < 0) { state.categories.push(c); }
                    else { state.categories.splice(i, 1); }
                    render();
                }
            }, c, el('span', { class: 'n' }, String(counts.category[c]))));
        });

        /* Only fade the right edge when there is actually something past it.
           A permanent fade on a row that fits hides the last chip for no
           reason, which is the defect the fade exists to prevent. */
        chips.classList.toggle('fits', chips.scrollWidth <= chips.clientWidth + 1);
    }

    /* One row per SYMPTOM, expandable to the artifacts it fired on.
     *
     * This is the whole reason the report is readable at application scale.
     * A thousand findings is a thousand rows; the same thousand grouped by the
     * rule that produced them is forty. IBM's report does the same, and for
     * the same reason. */
    /* The list, one line per row, and the detail beside it.
     *
     * It used to be an accordion: opening a row pushed everything below it
     * down, so a reader working through 55 rules lost their place every time
     * they looked at one, and with 172 artifacts it was unusable. A list plus
     * a detail pane is the shape every triage tool converges on, for the same
     * reason - the list never moves.
     */
    function rowKey(row, byRule) {
        return state.group + '|' + (byRule ? row.ruleId : row.artifact);
    }

    function currentRows() {
        var byRule = state.group === 'rule';
        return sortRows(byRule ? F.byRule(visible()) : byArtifact(visible()));
    }

    function renderFindings() {
        var shown = visible();
        var byRule = state.group === 'rule';
        var rows = currentRows();
        var box = $('findings');
        box.innerHTML = '';

        var grouped = byRule ? n(rows.length, 'rule') : n(rows.length, 'artifact');
        setStatus('shown', shown.length === state.report.findings.length
            ? n(shown.length, 'finding') + ' in ' + grouped
            : shown.length + ' of ' + n(state.report.findings.length, 'finding')
              + ', in ' + grouped,
            shown.length ? 'warn' : 'good');

        if (!rows.length) {
            box.appendChild(el('div', { class: 'empty' },
                el('div', { class: 't' }, state.report.findings.length
                    ? 'Nothing matches those filters'
                    : 'No findings'),
                el('div', { class: 'b' }, state.report.findings.length
                    ? 'Clear a filter to widen the search.'
                    : 'Every automated rule ran and none fired.')));
            renderDetail(null);
            return;
        }

        /* Keep the selection if it survived the filter; otherwise take the
           worst row, so the pane is never empty when there is something to
           show. */
        var keys = rows.map(function (r) { return rowKey(r, byRule); });
        if (keys.indexOf(state.selected) < 0) { state.selected = keys[0]; }

        var heading = null;
        var headed = state.sort === 'severity';
        var SEV = { critical: 'Critical', major: 'Major',
                    minor: 'Minor', warning: 'Warning' };

        rows.forEach(function (row, i) {
            if (headed && row.severity !== heading) {
                heading = row.severity;
                var count = rows.filter(function (x) { return x.severity === heading; }).length;
                box.appendChild(el('div', { class: 'sev-head ' + heading },
                    el('span', { class: 'bar' }),
                    el('span', null, SEV[heading] || heading),
                    el('span', { class: 'n' },
                        byRule ? n(count, 'rule') : n(count, 'artifact'))));
            }

            var key = rowKey(row, byRule);
            var on = key === state.selected;
            var r = el('div', {
                id: 'lrow-' + i,
                class: 'lrow ' + row.severity + (on ? ' sel' : ''),
                role: 'option', tabindex: '-1',
                'aria-selected': on ? 'true' : 'false'
            });
            r.appendChild(severityMark(row.severity));

            var mid = el('div', { class: 'row-mid' });
            var title = el('div', { class: 'row-t' },
                byRule ? row.message : row.artifact);
            if (byRule && row.lifecycle === 'draft') {
                title.appendChild(el('span', { class: 'tag-draft',
                    title: 'A proposed rule, not policy' }, 'draft'));
            }
            mid.appendChild(title);
            mid.appendChild(el('div', { class: 'row-s' }, byRule
                ? [row.ruleId, row.category].filter(Boolean).join('  \u00b7  ')
                : row.artifactType));
            r.appendChild(mid);

            var artifacts = {};
            row.occurrences.forEach(function (o) { artifacts[o.artifact] = true; });
            r.appendChild(el('span', { class: 'row-n',
                title: byRule ? 'findings / artifacts' : 'findings' }, byRule
                ? String(row.occurrences.length) + ' / '
                  + String(Object.keys(artifacts).length)
                : String(row.occurrences.length)));

            r.addEventListener('click', function () { select(key); });
            box.appendChild(r);
        });

        /* role="option" only means something to a screen reader alongside
           role="listbox" plus a stated active option - without this the list
           announces as an unlabelled group and arrow-key moves say nothing. */
        var selIdx = keys.indexOf(state.selected);
        if (selIdx >= 0) { box.setAttribute('aria-activedescendant', 'lrow-' + selIdx); }
        else { box.removeAttribute('aria-activedescendant'); }

        renderDetail(rows[selIdx] || rows[0]);
    }

    function select(key) {
        if (state.selected === key) { return; }
        state.selected = key;
        renderFindings();
        var node = document.querySelector('#findings .lrow.sel');
        if (node) { node.scrollIntoView({ block: 'nearest' }); }
    }

    /* Move through the list from the keyboard.
     *
     * A triage list that needs the mouse for every row is one nobody finishes.
     * Arrow keys move the selection and the detail follows, which is what
     * makes a detail pane worth having. */
    function step(delta) {
        var byRule = state.group === 'rule';
        var keys = currentRows().map(function (r) { return rowKey(r, byRule); });
        if (!keys.length) { return; }
        var i = keys.indexOf(state.selected);
        i = (i < 0) ? 0 : Math.max(0, Math.min(keys.length - 1, i + delta));
        select(keys[i]);
    }

    /* Everything needed to act on the selected row, in one place: what the
       standard says, why, where it fired, and which checklist cell it came
       from. This is the old expanded row, given a pane of its own. */
    function renderDetail(row) {
        var box = $('detail');
        box.innerHTML = '';
        if (!row) {
            box.appendChild(el('div', { class: 'empty' },
                el('div', { class: 't' }, 'Nothing selected'),
                el('div', { class: 'b' }, 'Choose a finding to see the standard it '
                    + 'cites and every artifact it fired on.')));
            return;
        }
        var byRule = state.group === 'rule';

        box.appendChild(el('div', { class: 'd-head' },
            severityMark(row.severity),
            el('h2', null, byRule ? row.message : row.artifact)));

        var bits = byRule
            ? [row.ruleId, row.category,
               row.lifecycle === 'draft' ? 'draft' : null,
               (row.source && row.source.locator && row.source.locator !== 'house')
                   ? row.source.locator : null]
            : [row.artifactType];
        box.appendChild(el('div', { class: 'd-meta' },
            bits.filter(function (x) { return x; }).join('  \u00b7  ')));

        if (byRule && row.lifecycle === 'draft') {
            box.appendChild(el('div', { class: 'notify warn d-note' },
                el('div', { class: 't' }, 'A proposal, not policy'),
                el('div', { class: 'b' }, 'This rule is a draft. It is measured and '
                    + 'reported, but it has not been promoted to the house standard, '
                    + 'so treat it as a question rather than a settled defect.')));
        }

        if (byRule && row.remediation) {
            box.appendChild(el('div', { class: 'd-h' }, 'What to do'));
            box.appendChild(el('div', { class: 'd-body' }, row.remediation));
        }
        if (byRule && row.rationale) {
            box.appendChild(el('div', { class: 'd-h' }, 'Why'));
            box.appendChild(el('div', { class: 'd-body muted' }, row.rationale));
        }

        box.appendChild(el('div', { class: 'd-h' },
            'Where  ' + n(row.occurrences.length, 'occurrence')));
        var whereWrap = el('div', { class: 'd-where-wrap' });
        var table = el('table', { class: 'd-where' });
        /* Capped: past this the list stops being a pointer to the work and
           becomes the work. The count above is always the whole truth. */
        row.occurrences.slice(0, 200).forEach(function (o) {
            var place = [o.surface, o.node].filter(function (x) { return x; })
                .join('  \u00b7  ') + (o.line ? '  L' + o.line : '');
            table.appendChild(byRule
                ? el('tr', null,
                    el('td', null, o.artifact || '(unnamed)'),
                    el('td', { class: 'loc' }, place))
                : el('tr', null,
                    el('td', { class: 'mkcell' }, severityMark(o.severity)),
                    el('td', null, o.message),
                    el('td', { class: 'loc' }, place)));
        });
        whereWrap.appendChild(table);
        box.appendChild(whereWrap);
        if (row.occurrences.length > 200) {
            box.appendChild(el('p', { class: 'muted' },
                'and ' + (row.occurrences.length - 200) + ' more'));
        }
    }

    /* The report, as a file.
     *
     * A review that cannot leave the browser cannot be attached to a change
     * record, and this is a governance artifact at LSEG. One row per finding -
     * not per rule - because a spreadsheet is filtered and pivoted by whoever
     * receives it, and pre-grouping it takes that away. Exports what is
     * FILTERED, so the file matches what is on screen.
     */
    function toCsv() {
        var cols = ['severity', 'ruleId', 'category', 'lifecycle', 'symptom',
                    'artifact', 'artifactType', 'surface', 'node', 'line',
                    'subjects', 'remediation'];
        function cell(v) {
            var s = (v === null || v === undefined) ? '' : String(v);
            /* Quote everything: a message can hold a comma, a quote or a
               newline, and a CSV that is only sometimes quoted is worse than
               one that always is. */
            return '"' + s.replace(/"/g, '""') + '"';
        }
        var lines = [cols.join(',')];
        visible().forEach(function (f) {
            lines.push([f.severity, f.ruleId, f.category, f.lifecycle, f.message,
                        f.artifact, f.artifactType, f.surface, f.node, f.line,
                        (f.subjects || []).join('; '), f.remediation]
                .map(cell).join(','));
        });
        return lines.join(String.fromCharCode(13) + String.fromCharCode(10));
    }

    function download() {
        var r = state.report;
        if (!r) { return; }
        /* r.container is the container OBJECT, not its name - fillContainers
           builds its options from c.name and c.shortName. */
        var raw = (r.container && (r.container.shortName || r.container.name))
                  || 'application';
        var name = String(raw).replace(/[^A-Za-z0-9._-]+/g, '-');
        var stamp = new Date().toISOString().slice(0, 10);
        var blob = new Blob([toCsv()], { type: 'text/csv;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = 'baw-review-' + name + '-' + stamp + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        /* Revoked on the next tick, not immediately: revoking before the
           browser has started the download cancels it in some builds. */
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    }

    function renderDuplicates(r) {
        if (!r.duplicates.length) { return; }
        var box = $('dupes');
        box.innerHTML = '';
        var copies = 0;
        r.duplicates.forEach(function (g) { copies += g.length - 1; });
        setStatus('dupCount', n(r.duplicates.length, 'block') + ', '
            + n(copies, 'redundant copy', 'redundant copies'), 'warn');
        r.duplicates.slice(0, 25).forEach(function (g) {
            var card = el('div', { class: 'check warn' },
                el('div', { class: 'check-head' },
                    el('strong', null, g.length + ' copies'),
                    el('span', { class: 'muted' }, g[0].lines + ' lines each')));
            g.forEach(function (c) {
                card.appendChild(el('div', { class: 'detail' },
                    c.artifact + '  ·  ' + c.type + '  ·  ' + c.where));
            });
            box.appendChild(card);
        });

    }

    /* The checklist rows no machine settles, per artifact type present.
     *
     * A report of automated findings alone reads as a passed review. The panel
     * makes the same point per artifact; this makes it per application, which
     * is where a sign-off actually happens. */
    function renderManual(r) {
        var types = Object.keys(r.scanned.byType);
        var box = $('manual');
        box.innerHTML = '';
        var pending = types.length;
        if (!pending) { return; }

        /* One question is one check, even when several artifact types ask it.
         *
         * Most of the checklist is General - "is the code free of JavaScript
         * errors", "are all validation errors removed" - and applies to every
         * type. Listing it per type turned 67 questions into 430 rows across
         * 21 headings, which is not a review checklist, it is a wall. The
         * endpoint already collapses a question the workbook asks twice within
         * one type (PROJECT.md §3.3); this is the same principle one level up,
         * across types.
         *
         * So: each question once, with the types it covers beside it. The
         * count is then the number of QUESTIONS a person has to answer, which
         * is the number they actually care about. */
        var byQuestion = {};

        types.forEach(function (t) {
            fetch(API.replace(/\/$/, '') + '/api/checklist?type=' + encodeURIComponent(t))
                .then(function (x) { return x.ok ? x.json() : null; })
                .then(function (d) {
                    (d && d.prompts ? d.prompts : []).forEach(function (p) {
                        var text = p.checkText || p.message || '';
                        if (!text) { return; }
                        if (!byQuestion[text]) {
                            byQuestion[text] = { prompt: p, types: [], artifacts: 0 };
                        }
                        byQuestion[text].types.push(t);
                        byQuestion[text].artifacts += r.scanned.byType[t] || 0;
                    });
                })
                .catch(function () { /* a type with no checklist rows */ })
                .then(function () {
                    if (--pending > 0) { return; }
                    drawManual(box, byQuestion, types.length);
                });
        });
    }

    function drawManual(box, byQuestion, typeCount) {
        var order = { Critical: 0, High: 1, Medium: 2, Low: 3 };
        var questions = Object.keys(byQuestion).map(function (k) {
            return byQuestion[k];
        }).sort(function (a, b) {
            var pa = order[a.prompt.priority], pb = order[b.prompt.priority];
            pa = (pa === undefined) ? 9 : pa;
            pb = (pb === undefined) ? 9 : pb;
            if (pa !== pb) { return pa - pb; }
            /* Then by reach: a question covering the whole application before
               one that applies to a single type. */
            return b.artifacts - a.artifacts;
        });

        box.innerHTML = '';
        questions.forEach(function (q) {
            var p = q.prompt;
            /* A question every type asks is an application-wide question; say
               that rather than printing twenty-one type names. */
            var scope = q.types.length === typeCount
                ? 'every artifact type'
                : q.types.slice(0, 6).join(', ')
                  + (q.types.length > 6 ? ' and ' + (q.types.length - 6) + ' more' : '');
            box.appendChild(el('div', { class: 'check' },
                el('div', null, p.checkText || p.message),
                el('div', { class: 'detail' },
                    [p.priority, p.impactedArea, p.primaryReviewer, scope,
                     n(q.artifacts, 'artifact')]
                        .filter(function (x) { return x; }).join('  ·  '))));
        });

        setStatus('manualCount', n(questions.length, 'question') + ' for a person',
            'warn');
        $('vManual').textContent = String(questions.length);
    }

    /* --------------------------------------------------------------- search */

    function debounce(fn, ms) {
        var t = null;
        return function () {
            if (t) { clearTimeout(t); }
            t = setTimeout(fn, ms);
        };
    }

    $('qSymptom').addEventListener('input', debounce(function () {
        state.qSymptom = $('qSymptom').value.trim();
        renderFindings();
    }, 200));
    $('qArtifact').addEventListener('input', debounce(function () {
        state.qArtifact = $('qArtifact').value.trim();
        renderFindings();
    }, 200));
    $('reset').addEventListener('click', function () {
        state.severity = '';
        state.categories = [];
        state.qSymptom = '';
        state.qArtifact = '';
        $('qSymptom').value = '';
        $('qArtifact').value = '';
        if (state.report) { render(); }
    });

    /* Grouping and sorting redraw the findings only. They do not touch the
       filters, so the counts in the tabs and chips stay put and the reader
       does not lose their place in the report. */
    $('groupBy').addEventListener('change', function () {
        state.group = this.value;
        if (state.report) { renderFindings(); }
    });
    $('sortBy').addEventListener('change', function () {
        state.sort = this.value;
        if (state.report) { renderFindings(); }
    });
    /* The five views. Switching one is not navigation and refetches nothing. */
    (function () {
        var btns = document.querySelectorAll('#views .view');
        for (var i = 0; i < btns.length; i++) {
            (function (b) {
                b.addEventListener('click', function () {
                    showView(b.getAttribute('data-view'));
                });
            }(btns[i]));
        }
    }());
    wireRovingTablist('views');
    wireRovingTablist('tabs', 'button.tab');

    /* Back to the chooser, with the report still in hand until a new one
       replaces it - pressing Re-analyse by accident should not destroy what is
       on screen. */
    $('again').addEventListener('click', function () {
        $('setup').style.display = '';
        $('topbar').style.display = 'none';
        $('views').style.display = 'none';
        Object.keys(VIEWS).forEach(function (k) { $(VIEWS[k]).style.display = 'none'; });
        $('run').disabled = false;
        setStatus('status', 'Choose an application and press Analyse.', '');
    });

    /* Arrow keys move through the list; Home and End jump to its ends.
     *
     * Bound on the list rather than the document, so typing in the search box
     * is never intercepted - the defect this shape invites. */
    $('findings').addEventListener('keydown', function (ev) {
        var k = ev.key;
        if (k === 'ArrowDown' || k === 'ArrowUp' || k === 'Home' || k === 'End') {
            ev.preventDefault();
            if (k === 'ArrowDown') { step(1); }
            else if (k === 'ArrowUp') { step(-1); }
            else if (k === 'Home') { step(-1e9); }
            else { step(1e9); }
        }
    });

    $('exportCsv').addEventListener('click', download);
    /* Print expands every row through CSS rather than through state, so
       printing does not leave the page rearranged behind the dialog. */
    $('printReport').addEventListener('click', function () { window.print(); });
}());

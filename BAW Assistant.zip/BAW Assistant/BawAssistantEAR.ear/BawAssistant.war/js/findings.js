/* What a set of findings means, independently of who is drawing it.
 *
 * Two surfaces ask the same questions of the same data: the panel docked in
 * the Designer, and the whole-application review. Ordering by severity,
 * counting by category, deciding whether a filter admits a finding and giving
 * one a stable identity are the same problems in both, and a second copy of
 * any of them would drift - which is the argument `harvest-corpus.js` already
 * makes for importing bridge.js rather than reimplementing its readers.
 *
 * Deliberately DOM-free and dependency-free, so it can be tested with nothing
 * but node, and so nothing here can quietly start depending on a Designer.
 *
 * The severity order is the ENGINE's, from Rule.severityRank:
 *
 *     critical 0  >  major 1  >  minor 2  >  warning 3
 *
 * `warning` is the lowest band, not the second highest. Anything that sorts or
 * colours findings has to honour that or it contradicts the server.
 */
(function () {
    'use strict';

    var ORDER = ['critical', 'major', 'minor', 'warning'];

    /* Unknown severities sort last, matching the engine, which returns 3 for
       anything it does not recognise rather than rejecting it. */
    function rank(severity) {
        var i = ORDER.indexOf(String(severity || '').toLowerCase());
        return i < 0 ? ORDER.length : i;
    }

    /* A stable identity for a finding, so an expanded row survives a redraw.
     *
     * Line and message both matter: one rule can fire twice on the same line
     * with different messages, and the same message can appear on two lines.
     * Artifact findings carry line 0, which is what separates them from a
     * buffer finding of the same rule.
     *
     * The SURFACE matters for the same reason. Once more than one code surface
     * is judged at a time - a coach component shows three event handlers
     * together, and the review sweeps every surface of every artifact - two
     * findings can agree on rule, line and message and still be two different
     * facts about two different editors. Without this, expanding one expanded
     * the other. Absent on findings that carry no surface, which keeps every
     * existing identity exactly as it was.
     */
    function key(f) {
        if (!f) { return ''; }
        return (f.ruleId || '') + '|' + (f.line || 0) + '|' + (f.message || '')
             + '|' + (f.surface || '');
    }

    /* An EMPTY selection means "no filter", not "nothing".
     *
     * That is the whole contract of the filter bar: a panel with no tags
     * pressed shows everything, which is the state a developer expects on
     * opening it. Read the other way round, a fresh panel would look empty and
     * clean code and a hidden list would be indistinguishable.
     */
    function matches(f, filters) {
        if (!f) { return false; }
        filters = filters || {};
        var sev = filters.severity || [];
        var cat = filters.category || [];
        if (sev.length && sev.indexOf(f.severity) < 0) { return false; }
        if (cat.length && cat.indexOf(f.category || '') < 0) { return false; }
        return true;
    }

    function filter(list, filters) {
        return (list || []).filter(function (f) { return matches(f, filters); });
    }

    /* How many of each severity and each category, over everything held - NOT
       over what is currently shown.
     *
     * The counts on a filter tag have to say what pressing it would bring back.
     * Counting the filtered set instead makes every unpressed tag read zero,
     * which is the least useful number available.
     */
    function tally(list) {
        var severity = {};
        var category = {};
        (list || []).forEach(function (f) {
            if (!f) { return; }
            var s = f.severity || 'warning';
            severity[s] = (severity[s] || 0) + 1;
            if (f.category) { category[f.category] = (category[f.category] || 0) + 1; }
        });
        return { severity: severity, category: category };
    }

    /* The severities present, in the engine's order - never alphabetical, which
       would put critical after major and warning in the middle. */
    function severitiesPresent(counts) {
        return ORDER.filter(function (k) { return (counts || {})[k]; });
    }

    function categoriesPresent(counts) {
        return Object.keys(counts || {}).sort();
    }

    /* Worst first, then by position, then by rule, so the order is total and a
       redraw cannot shuffle two findings that tie. */
    function sort(list) {
        return (list || []).slice().sort(function (a, b) {
            var d = rank(a.severity) - rank(b.severity);
            if (d !== 0) { return d; }
            d = (a.line || 0) - (b.line || 0);
            if (d !== 0) { return d; }
            return String(a.ruleId || '').localeCompare(String(b.ruleId || ''));
        });
    }

    /* Group findings by rule: one row per symptom, expandable to the artifacts
       it fired on. That is how IBM's own IDA report is laid out, and at
       application scale it is the difference between 1,186 rows and 40.
     *
     * `where` is whatever identifies the occurrence - an artifact for the
     * review, a line for the panel - and is kept per occurrence rather than
     * merged, because a rule that fired 200 times is not 200 identical facts.
     */
    function byRule(list) {
        var index = {};
        var out = [];
        (list || []).forEach(function (f) {
            if (!f) { return; }
            var id = f.ruleId || '';
            var row = index[id];
            if (!row) {
                row = {
                    ruleId: id,
                    ruleName: f.ruleName || '',
                    severity: f.severity || 'warning',
                    category: f.category || '',
                    message: f.message || '',
                    remediation: f.remediation || '',
                    rationale: f.rationale || '',
                    source: f.source || null,
                    lifecycle: f.lifecycle || 'active',
                    occurrences: []
                };
                index[id] = row;
                out.push(row);
            }
            /* The worst severity a rule produced wins the row, so a rule that
               is critical somewhere is never filed under minor. */
            if (rank(f.severity) < rank(row.severity)) { row.severity = f.severity; }
            row.occurrences.push(f);
        });
        /* Loudest first within a severity: a reviewer wants the widespread
           problem before the one-off. */
        out.sort(function (a, b) {
            var d = rank(a.severity) - rank(b.severity);
            if (d !== 0) { return d; }
            d = b.occurrences.length - a.occurrences.length;
            if (d !== 0) { return d; }
            return String(a.ruleId).localeCompare(String(b.ruleId));
        });
        return out;
    }

    /* The font control's one number, kept honest at both ends. Below 10 the
       panel is unreadable; above 20 a finding no longer fits its row. */
    function clampFont(n, min, max) {
        var v = parseInt(n, 10);
        if (!(v >= min && v <= max)) { return null; }
        return v;
    }

    window.BawFindings = {
        SEVERITY_ORDER: ORDER,
        rank: rank,
        key: key,
        matches: matches,
        filter: filter,
        tally: tally,
        severitiesPresent: severitiesPresent,
        categoriesPresent: categoriesPresent,
        sort: sort,
        byRule: byRule,
        clampFont: clampFont
    };
}());

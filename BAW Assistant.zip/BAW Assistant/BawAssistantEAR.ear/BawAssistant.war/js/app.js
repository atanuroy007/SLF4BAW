/* Co-deployment probe.
 *
 * Answers one question: can an app served from the BAW origin actually reach
 * Process Designer? Checks run in dependency order so the first failure is the
 * one that matters - there is no point testing DOM reach if the page is not
 * even same-origin.
 *
 * Everything here is read-only. Nothing is written to any artifact.
 */
(function () {
    'use strict';

    var $ = function (id) { return document.getElementById(id); };
    var designerWindow = null;

    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) { n.className = cls; }
        if (text !== undefined && text !== null) { n.textContent = String(text); }
        return n;
    }

    /* ---------------------------------------------------------- environment */
    function renderEnv() {
        var dl = $('env');
        dl.innerHTML = '';
        var origin = window.location.origin;
        var rows = [
            ['Page origin', origin],
            ['Context path', config.contextPath],
            ['Server', config.serverName + ':' + config.serverPort + ' (' + config.scheme + ')'],
            ['remoteUser', config.remoteUser && config.remoteUser !== 'null'
                ? config.remoteUser : '(not security-constrained)'],
            ['User agent', navigator.userAgent.slice(0, 90)]
        ];
        rows.forEach(function (r) {
            dl.appendChild(el('dt', null, r[0]));
            dl.appendChild(el('dd', null, r[1]));
        });
    }

    /* -------------------------------------------------------------- checks */
    var results = [];

    function record(name, status, detail, why) {
        results.push({ name: name, status: status, detail: detail, why: why });
    }

    function renderChecks() {
        var ol = $('checks');
        ol.innerHTML = '';
        results.forEach(function (r) {
            var li = el('li', 'check ' + r.status);
            var head = el('div', 'check-head');
            head.appendChild(el('span', 'pill ' + r.status, r.status.toUpperCase()));
            head.appendChild(el('strong', null, r.name));
            li.appendChild(head);
            if (r.detail) { li.appendChild(el('div', 'detail', r.detail)); }
            if (r.why) { li.appendChild(el('div', 'why', r.why)); }
            ol.appendChild(li);
        });
        var count = function (st) {
            return results.filter(function (r) { return r.status === st; }).length;
        };
        var parts = [count('pass') + ' pass'];
        if (count('warn')) { parts.push(count('warn') + ' warn'); }
        if (count('fail')) { parts.push(count('fail') + ' fail'); }
        if (count('skip')) { parts.push(count('skip') + ' pending'); }
        $('score').textContent = parts.join(', ');
        renderVerdict();
    }

    function renderVerdict() {
        var v = $('verdict');
        var firstFail = results.filter(function (r) { return r.status === 'fail'; })[0];
        var pending = results.filter(function (r) { return r.status === 'skip'; }).length;
        var warned = results.filter(function (r) { return r.status === 'warn'; }).length;
        if (firstFail) {
            v.className = 'verdict bad';
            v.textContent = 'Blocked at: ' + firstFail.name + '. '
                + (firstFail.why || 'Fix this before testing anything downstream.');
            return;
        }
        if (pending) {
            v.className = 'verdict warn';
            v.textContent = 'No failures so far, but ' + pending
                + ' check(s) still need a Designer window. Open one below.';
            return;
        }
        v.className = warned ? 'verdict warn' : 'verdict good';
        v.textContent = 'Co-deployment works. The assistant can be served from the '
            + 'BAW origin, reuses the logged-in session, and can reach into a '
            + 'Designer window it opened.';
    }

    /* 1 - is the JSP actually being processed? */
    function checkJsp() {
        var cp = config.contextPath;
        if (typeof cp !== 'string' || cp.indexOf('${') === 0) {
            record('JSP is processed', 'fail', 'contextPath is the literal expression',
                'The page is being served as a static file. Check the .jsp extension '
                + 'and that the module is a web module.');
            return false;
        }
        record('JSP is processed', 'pass', 'contextPath resolved to "' + cp + '"');
        return true;
    }

    /* 2 - are we on the same origin as BAW? */
    function checkOrigin() {
        return fetch(config.contextPath + '/', { method: 'HEAD' })
            .then(function () {
                record('Served from the BAW server', 'pass',
                    window.location.origin,
                    'Same scheme, host and port as Designer means frame-ancestors '
                    + "'self' permits framing and the DOM is reachable.");
                return true;
            })
            .catch(function (e) {
                record('Served from the BAW server', 'fail', String(e));
                return false;
            });
    }

    /* 3 - does the BAW web module respond on this origin? */
    function checkBawReachable() {
        return fetch('/WebPD/jsp/bootstrap.jsp', { method: 'HEAD', credentials: 'include' })
            .then(function (r) {
                if (r.status === 404) {
                    record('BAW is on this origin', 'fail', 'HTTP 404 for /WebPD/',
                        'This app is deployed somewhere BAW is not. Same origin means '
                        + 'same scheme + host + PORT - a different server in the cell '
                        + 'does not qualify unless one HTTP server fronts both.');
                    return false;
                }
                record('BAW is on this origin', 'pass', '/WebPD/ responded ' + r.status);
                return true;
            })
            .catch(function (e) {
                record('BAW is on this origin', 'fail', String(e));
                return false;
            });
    }

    /* 4 - does the LTPA session carry over?
     *
     * The cleanest signal is the identity WebSphere put on the request to THIS
     * app. If remoteUser is populated, global security authenticated the caller
     * before our page ever ran - which is exactly what the delivery model needs.
     */
    function checkIdentity() {
        var u = config.remoteUser;
        if (u && u !== 'null') {
            record('Server sees an authenticated user', 'pass',
                'remoteUser = ' + u,
                'WebSphere resolved a caller identity on a request to this app, so '
                + 'the LTPA session spans both applications. The assistant needs no '
                + 'credentials of its own.');
            return true;
        }
        record('Server sees an authenticated user', 'warn',
            'remoteUser is empty',
            'Not necessarily a problem: an app with no security constraint may not '
            + 'be given the identity even when the session is valid. The REST check '
            + 'below is the fallback signal.');
        return true;
    }

    /* 5 - can we actually reach the design REST API?
     *
     * Status interpretation matters more than it looks. Only 401/403 and an HTML
     * login page mean the session failed. A 405 (method not allowed) or 400 (bad
     * request) means the request was authenticated and routed to the resource,
     * which then objected to the method or the arguments - that is a PASS for the
     * question being asked here.
     */
    function checkRestReachable() {
        /* pd/v1/assets is the GET resource. pd/v2/assets answers
           "Allow: OPTIONS, PUT" and is never a GET - asking it anything is a
           405 that says nothing about the session. Without a containerRef, v1
           returns a JSON InvalidContainerRefException, which still proves the
           request was authenticated and routed. */
        var ref = ($('branchRef') && $('branchRef').value.trim()) || '';
        var url = '/rest/bpm/wle/pd/v1/assets'
            + (ref ? '?containerRef=' + encodeURIComponent(ref) : '');

        return fetch(url, {
            headers: { Accept: 'application/json' },
            credentials: 'include'
        }).then(function (r) {
            var ct = (r.headers.get('content-type') || '').toLowerCase();
            var isJson = ct.indexOf('json') >= 0;

            if (r.status === 401 || r.status === 403) {
                record('Design REST API accepts our session', 'fail',
                    'HTTP ' + r.status,
                    'The credentials were rejected outright. Check that both apps '
                    + 'are in the same security domain and share LTPA keys.');
                return false;
            }
            if (ct.indexOf('html') >= 0) {
                record('Design REST API accepts our session', 'fail',
                    'HTTP ' + r.status + ', HTML returned',
                    'An HTML body here is a login page standing in for data - the '
                    + 'session did not carry over.');
                return false;
            }
            if (!isJson) {
                record('Design REST API accepts our session', 'warn',
                    'HTTP ' + r.status + ' (' + (ct || 'no content-type') + ')',
                    'Not a rejection - the request reached the resource - but not '
                    + 'data either. Unexpected for this endpoint.');
                return true;
            }

            return r.json().then(function (body) {
                if (r.status >= 400) {
                    var d = (body && body.Data) || {};
                    record('Design REST API accepts our session', 'pass',
                        'HTTP ' + r.status + ' - ' + (d.errorNumber || 'JSON error')
                            + ' (authenticated)',
                        'The API answered with a structured error rather than a login '
                        + 'page, so the session is valid. Paste a containerRef below '
                        + 'and re-run to pull real data.');
                    return true;
                }
                var types = Object.keys((body && body.data) || {});
                var items = types.reduce(function (n, k) {
                    return n + (((body.data[k] || {}).items || []).length);
                }, 0);
                record('Design REST API accepts our session', 'pass',
                    'HTTP 200 - ' + types.length + ' asset types, '
                        + items + ' artifacts in this branch',
                    'Authenticated, same-origin, and returning real design-time data. '
                    + 'This is everything the assistant needs to ground itself.');
                return true;
            });
        }).catch(function (e) {
            record('Design REST API accepts our session', 'fail', String(e),
                'A network-level failure here usually means a CORS boundary, which '
                + 'would mean the app is not actually same-origin.');
            return false;
        });
    }

    /* 5-7 need a Designer window this page opened. */
    function pendingDesignerChecks() {
        record('Designer window opened by this page', 'skip',
            'Open one below', 'Same origin lets us reach the Designer; it does not '
            + 'put our code on its page. The window must be one we created.');
        record('Same-origin DOM reach', 'skip', 'Needs a Designer window');
        record('Orion code surface readable', 'skip', 'Needs a Designer window');
    }

    function runChecks() {
        results = [];
        renderEnv();
        if (!checkJsp()) { renderChecks(); return; }
        checkOrigin()
            .then(function (ok) { return ok ? checkBawReachable() : false; })
            .then(function (ok) { if (ok) { checkIdentity(); } return ok; })
            .then(function (ok) { return ok ? checkRestReachable() : false; })
            .then(function () { pendingDesignerChecks(); renderChecks(); })
            .catch(function (e) {
                record('Unexpected error', 'fail', String(e));
                renderChecks();
            });
    }

    /* ------------------------------------------------------ Designer probe */
    function openDesigner() {
        var ref = $('branchRef').value.trim();
        if (!ref) {
            alert('Paste a containerRef first - it looks like 2063.<guid> and is '
                + 'visible in the Designer URL.');
            return;
        }
        /* The WorkflowCenter parameter is mandatory: without it the Library pane
           renders at width 0 and artifact navigation is impossible. */
        var wc = encodeURIComponent('/processapps/platformRepo?BAW=true&BAW_tWAS=true');
        var url = '/WebPD/jsp/bootstrap.jsp?containerRef=' + encodeURIComponent(ref)
                + '&locale=en&WorkflowCenter=' + wc;
        designerWindow = window.open(url, 'baw-designer');
        $('probeDesigner').disabled = !designerWindow;
        $('probeAnnotations').disabled = !designerWindow;
        $('tryAnnotation').disabled = !designerWindow;
        if ($('orionProbe')) { $('orionProbe').disabled = !designerWindow; }
        var out = $('designerOut');
        out.hidden = false;
        out.textContent = designerWindow
            ? 'Designer window opened. Wait for it to finish loading, open a coach '
              + 'view, then press "Probe it".'
            : 'window.open was blocked. Allow pop-ups for this site and retry.';
    }

    function probeDesigner() {
        var out = $('designerOut');
        var lines = [];
        function say(s) { lines.push(s); out.textContent = lines.join('\n'); }

        if (!designerWindow || designerWindow.closed) {
            say('The Designer window is closed. Open it again.');
            return;
        }

        /* 5 - can we touch its document at all? */
        var doc;
        try {
            doc = designerWindow.document;
            say('[pass] Same-origin DOM reach - document.title = '
                + JSON.stringify(doc.title));
        } catch (e) {
            say('[fail] Same-origin DOM reach blocked: ' + e.message);
            say('       The Designer is on a different origin than this page.');
            return;
        }

        /* Is Dojo up yet? */
        var dijit = designerWindow.dijit;
        if (!dijit) {
            say('[wait] dijit is not defined yet - the Designer is still loading.');
            return;
        }
        say('[pass] Dojo/dijit reachable from this page');

        /* Which editors are open? */
        var editors = doc.querySelectorAll('[data-test-editor]');
        say('[info] open editors: ' + (editors.length
            ? Array.prototype.map.call(editors, function (n) {
                return n.getAttribute('data-test-editor');
              }).join(', ')
            : 'none - open an artifact first'));

        /* 7 - Probe A: is an Orion code surface readable? */
        var hosts = doc.querySelectorAll(
            '[data-test-editor="CoachView"] [data-test-attr="inlineJavaScript.jseditor"]');
        if (!hosts.length) {
            say('[skip] No inlineJavaScript surface on screen. Open a coach view and '
                + 'select Behavior > Inline Javascript, then probe again.');
            return;
        }
        var host = hosts[hosts.length - 1];
        var widget = dijit.byId(host.getAttribute('widgetid') || host.id);
        if (!widget) {
            say('[fail] Found the editor node but dijit.byId returned nothing.');
            return;
        }
        var code = null;
        try { code = widget.getValue(); } catch (e) {
            say('[fail] widget.getValue() threw: ' + e.message);
            return;
        }
        say('[pass] Read the Orion buffer - ' + (code || '').length
            + ' characters, ' + (code || '').split('\n').length + ' lines');

        /* Probe A proper: is the annotation model reachable? This decides
           whether inline squiggles are possible or findings stay in a panel. */
        var keys = [];
        for (var k in widget) { if (k.indexOf('_') !== 0 || true) { keys.push(k); } }
        var interesting = keys.filter(function (k) {
            return /editor|orion|textView|annotation/i.test(k);
        });
        say('[info] editor-ish properties on the widget: '
            + (interesting.length ? interesting.join(', ') : 'none found'));
        say(interesting.length
            ? '       -> inline annotation looks reachable; confirm the object type.'
            : '       -> no obvious handle; findings would live in a side panel.');

        say('');
        say('First 200 characters of the live buffer:');
        say((code || '').slice(0, 200));
    }


    /* ------------------------------------------------- annotation deep probe */

    /* The nine Orion surfaces a coach view exposes, by data-test-attr prefix. */
    var SURFACES = ['inlineJavaScript', 'inlineCSS', 'headerHTML',
                    'eventHandlersLoad', 'eventHandlersView', 'eventHandlersChange',
                    'eventHandlersUnload', 'eventHandlersValidate',
                    'eventHandlersCollaboration'];

    function liveDoc(say) {
        if (!designerWindow || designerWindow.closed) {
            say('The Designer window is closed. Open it again.');
            return null;
        }
        try {
            return designerWindow.document;
        } catch (e) {
            say('Same-origin DOM reach blocked: ' + e.message);
            return null;
        }
    }

    /* The visible widget for one surface, or null. Editors accumulate in the
       DOM, so always take the last match rather than the first. */
    function surfaceWidget(doc, name) {
        var nodes = doc.querySelectorAll('[data-test-attr="' + name + '.jseditor"]');
        if (!nodes.length) { return null; }
        var host = nodes[nodes.length - 1];
        var dj = designerWindow.dijit;
        return dj ? dj.byId(host.getAttribute('widgetid') || host.id) : null;
    }

    function sig(fn) {
        if (typeof fn !== 'function') { return '(not a function)'; }
        var src = String(fn).replace(/\s+/g, ' ');
        var brace = src.indexOf('{');
        var head = brace > 0 ? src.slice(0, brace + 1) : src.slice(0, 120);
        return 'arity ' + fn.length + '   ' + head.slice(0, 150);
    }

    function sectionShown(doc, name) {
        var nodes = doc.querySelectorAll('[data-test-attr="' + name + '.jseditor"]');
        if (!nodes.length) { return 'n/a'; }
        var node = nodes[nodes.length - 1];
        var section = node.closest ? node.closest('.ddformSection') : null;
        if (!section) { return 'unknown'; }
        try {
            return designerWindow.getComputedStyle(section).display !== 'none'
                ? 'yes' : 'NO';
        } catch (e) { return 'unknown'; }
    }

    function probeAnnotations() {
        var out = $('designerOut');
        var lines = [];
        function say(s) { lines.push(s); out.textContent = lines.join('\n'); }
        out.hidden = false;

        var doc = liveDoc(say);
        if (!doc) { return; }

        /* A 0-character read is ambiguous: the surface may be genuinely empty,
           or it may sit in a hidden ddformSection. Writes are known to be
           discarded there; report whether reads are affected too. */
        say('=== surfaces on screen ===');
        var first = null;
        var found = 0;
        SURFACES.forEach(function (name) {
            var w = surfaceWidget(doc, name);
            if (!w) { return; }
            found++;
            if (!first) { first = w; }
            var len = -1;
            var err = '';
            try { len = (w.getValue() || '').length; } catch (e) { err = e.message; }
            say('  ' + name
                + '  ->  ' + (err ? 'ERROR ' + err : len + ' chars')
                + '   (section displayed: ' + sectionShown(doc, name) + ')');
        });
        if (!found) {
            say('  none - open a coach view in the Designer first.');
            return;
        }

        say('');
        say('=== annotation API ===');
        ['addAnnotation', 'addAnnotations', 'updateAnnotations',
            'clearAnnotations'].forEach(function (m) {
            say('  ' + m + ': ' + sig(first[m]));
        });

        say('');
        say('=== editor handles ===');
        ['editor', 'editorObj', 'containingEditor'].forEach(function (k) {
            var v = first[k];
            if (v === undefined || v === null) {
                say('  ' + k + ': (absent)');
                return;
            }
            var ctor = (v.constructor && v.constructor.name) || typeof v;
            var methods = [];
            for (var m in v) {
                try {
                    if (typeof v[m] === 'function'
                        && /annotation|model|textview|ruler|marker/i.test(m)) {
                        methods.push(m);
                    }
                } catch (e) { /* some getters throw; skip them */ }
            }
            say('  ' + k + ': ' + ctor
                + (methods.length
                    ? '\n      [' + methods.slice(0, 14).join(', ') + ']'
                    : ''));
        });

        say('');
        say('Next: "Draw a test marker". Visual only - no model change, no');
        say('commitSeq movement - and clearAnnotations() removes it afterwards.');
    }

    /* Try the plausible annotation shapes and let the failures tell us which
       one the API expects. Nothing here modifies the artifact model. */
    function tryAnnotation() {
        var out = $('designerOut');
        var lines = [];
        function say(s) { lines.push(s); out.textContent = lines.join('\n'); }
        out.hidden = false;

        var doc = liveDoc(say);
        if (!doc) { return; }

        var w = null;
        var used = '';
        for (var i = 0; i < SURFACES.length && !w; i++) {
            w = surfaceWidget(doc, SURFACES[i]);
            if (w) { used = SURFACES[i]; }
        }
        if (!w) { say('No code surface on screen.'); return; }

        var code = '';
        try { code = w.getValue() || ''; } catch (e) { /* keep going */ }
        say('surface: ' + used + '   buffer: ' + code.length + ' chars');
        say('');

        var end = Math.min(5, Math.max(code.length, 1));
        var attempts = [
            ['A  {line, severity, message}',
                { line: 1, severity: 'error', message: 'BAW Assistant test marker' }],
            ['B  {start, end, type, title}',
                { start: 0, end: end, type: 'orion.annotation.error',
                  title: 'BAW Assistant test marker' }],
            ['C  {line, text}', { line: 1, text: 'BAW Assistant test marker' }],
            ['D  positional (1, message)', 'POSITIONAL']
        ];

        attempts.forEach(function (a) {
            try {
                if (a[1] === 'POSITIONAL') {
                    w.addAnnotation(1, 'BAW Assistant test marker');
                } else {
                    w.addAnnotation(a[1]);
                }
                say('[no throw]  ' + a[0]);
            } catch (e) {
                say('[threw]     ' + a[0] + '  ->  ' + e.message);
            }
        });

        say('');
        say('Look at the Designer editor gutter now. Note which shape above did');
        say('not throw AND actually drew a marker - those are different things.');

        try {
            w.clearAnnotations();
            say('');
            say('[ok] clearAnnotations() ran - markers removed.');
        } catch (e) {
            say('');
            say('[err] clearAnnotations() -> ' + e.message);
        }
    }


    /* --------------------------------------------- Orion annotation (real API)
     *
     * The dijit wrapper's addAnnotation has arity 1, minified parameter names and
     * accepts every shape without throwing - permissive, and therefore useless as
     * a contract. editorObj is the actual Eclipse Orion editor and exposes the
     * documented API: getAnnotationModel, getTextView, getAnnotationStyler.
     *
     * Success is proven by reading the annotation back out of the model, not by
     * the absence of an exception.
     */
    function orionProbe() {
        var out = $('designerOut');
        var lines = [];
        function say(s) { lines.push(s); out.textContent = lines.join('\n'); }
        out.hidden = false;

        var doc = liveDoc(say);
        if (!doc) { return; }

        /* Work on whichever surface is actually displayed - a hidden section is
           the one place the Designer is known to behave differently. */
        var w = null, used = '';
        for (var i = 0; i < SURFACES.length && !w; i++) {
            var cand = surfaceWidget(doc, SURFACES[i]);
            if (cand && sectionShown(doc, SURFACES[i]) === 'yes') {
                w = cand; used = SURFACES[i];
            }
        }
        if (!w) {
            for (var j = 0; j < SURFACES.length && !w; j++) {
                w = surfaceWidget(doc, SURFACES[j]);
                if (w) { used = SURFACES[j] + ' (section hidden)'; }
            }
        }
        if (!w) { say('No code surface on screen.'); return; }
        say('surface: ' + used);

        var ed = w.editorObj;
        if (!ed || typeof ed.getAnnotationModel !== 'function') {
            say('[fail] editorObj has no getAnnotationModel - this build differs '
                + 'from the one probed. Report the editor handles output.');
            return;
        }

        var model, textView, textModel;
        try {
            model = ed.getAnnotationModel();
            textView = ed.getTextView();
            textModel = textView && textView.getModel ? textView.getModel() : null;
        } catch (e) {
            say('[fail] reaching the Orion objects threw: ' + e.message);
            return;
        }
        say('[ok]   annotationModel: ' + ((model && model.constructor
            && model.constructor.name) || typeof model));
        say('[ok]   textView: ' + ((textView && textView.constructor
            && textView.constructor.name) || typeof textView));

        if (!model || typeof model.addAnnotation !== 'function') {
            say('[fail] the annotation model has no addAnnotation.');
            return;
        }

        /* Orion works in character offsets, not line numbers. Findings carry a
           line, so this conversion is the bridge the assistant will need. */
        var start = 0, end = 1, lineCount = 0;
        if (textModel && typeof textModel.getLineStart === 'function') {
            try {
                lineCount = textModel.getLineCount();
                start = textModel.getLineStart(0);
                end = Math.max(start + 1, textModel.getLineEnd(0));
                say('[ok]   line 1 maps to offsets ' + start + '-' + end
                    + '  (' + lineCount + ' lines in buffer)');
            } catch (e) {
                say('[warn] line->offset conversion threw: ' + e.message);
            }
        } else {
            say('[warn] no getLineStart on the text model; using offset 0-1');
        }

        function countAnnotations() {
            try {
                var it = model.getAnnotations(0, Math.max(end, 1));
                var n = 0;
                while (it && it.hasNext && it.hasNext()) { it.next(); n++; }
                return n;
            } catch (e) { return -1; }
        }

        var before = countAnnotations();
        say('[info] annotations present before: ' + before);

        var annotation = {
            start: start,
            end: end,
            type: 'orion.annotation.error',
            title: 'BAW Assistant: test marker',
            html: '<div class="annotationHTML error"></div>',
            style: { styleClass: 'annotation error' },
            overviewStyle: { styleClass: 'annotationOverview error' },
            rangeStyle: { styleClass: 'annotationRange error' }
        };

        try {
            model.addAnnotation(annotation);
            say('[ok]   model.addAnnotation() did not throw');
        } catch (e) {
            say('[fail] model.addAnnotation() threw: ' + e.message);
            return;
        }

        var after = countAnnotations();
        say('[' + (after > before ? 'PASS' : 'fail') + ']   annotations after: '
            + after + (after > before
                ? '  <- the annotation is really in the model'
                : '  <- it was accepted and discarded'));

        /* A model entry still needs a styler and ruler to be visible. */
        try {
            var styler = ed.getAnnotationStyler && ed.getAnnotationStyler();
            var ruler = ed.getAnnotationRuler && ed.getAnnotationRuler();
            say('[info] styler: ' + (styler ? 'present' : 'ABSENT')
                + ',  ruler: ' + (ruler ? 'present' : 'ABSENT'));
            if (styler && typeof styler.addAnnotationType === 'function') {
                styler.addAnnotationType('orion.annotation.error');
                say('[ok]   registered orion.annotation.error with the styler');
            }
            if (ruler && typeof ruler.addAnnotationType === 'function') {
                ruler.addAnnotationType('orion.annotation.error');
                say('[ok]   registered orion.annotation.error with the ruler');
            }
        } catch (e) {
            say('[warn] styler/ruler registration threw: ' + e.message);
        }

        say('');
        say('LOOK AT THE EDITOR NOW - is there a marker in the left gutter or a');
        say('squiggle under line 1? Model presence and visible rendering are');
        say('different things, and only your eyes can confirm the second.');
        say('');
        say('Press "Probe annotations" then this button again to retry, or');
        say('"Draw a test marker" - it ends by calling clearAnnotations().');
    }

    /* ----------------------------------------------------------------- init */
    var refInput = $('branchRef');
    try {
        var saved = window.localStorage.getItem('baw-probe-ref');
        if (saved && !refInput.value) { refInput.value = saved; }
    } catch (e) { /* private mode: not important */ }
    refInput.addEventListener('change', function () {
        try { window.localStorage.setItem('baw-probe-ref', refInput.value.trim()); }
        catch (e) { /* ignore */ }
    });

    $('rerun').addEventListener('click', runChecks);
    $('openDesigner').addEventListener('click', openDesigner);
    $('probeDesigner').addEventListener('click', probeDesigner);
    $('probeAnnotations').addEventListener('click', probeAnnotations);
    $('tryAnnotation').addEventListener('click', tryAnnotation);
    if ($('orionProbe')) { $('orionProbe').addEventListener('click', orionProbe); }
    runChecks();
}());

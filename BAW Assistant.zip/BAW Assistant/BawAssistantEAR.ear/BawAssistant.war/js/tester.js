/* The rule tester: author a rule against the code you are actually looking at.
 *
 * Same bridge as the assistant, different panel. Where the assistant asks "what
 * is wrong with this artifact", the tester asks "is this rule any good" - and
 * the only honest answer comes from running it on real code, in the real editor,
 * and seeing where it lands.
 *
 * Two things it will not do:
 *
 *   Nothing is saved. /api/try compiles the candidate, uses it, and throws it
 *   away; the rule store is never touched. A half-written pattern here cannot
 *   affect another developer.
 *
 *   Annotations are always OURS to remove. The tester draws its candidate's
 *   findings in the gutter and clears them on the next run, so a test never
 *   leaves marks behind that look like real findings.
 */
(function () {
    'use strict';

    var $ = function (id) { return document.getElementById(id); };
    var B = window.BawBridge;

    var PANEL_ID = 'bawRuleTesterPanel';

    var state = {
        brain: config.contextPath || '',
        branchRef: localStorage.getItem('baw-probe-ref') || '',
        designer: null,
        rules: [],
        draft: null,        /* the rule being edited */
        lastResult: null,
        lastSense: null
    };

    /* Deliberately not the assistant's panel: both pages can be pointed at one
       Designer, and two panes sharing an id hand the second one the first's
       node. */
    B.usePanel(PANEL_ID);

    function el(tag, attrs) {
        var n = document.createElement(tag);
        attrs = attrs || {};
        Object.keys(attrs).forEach(function (k) {
            if (k === 'class') { n.className = attrs[k]; }
            else if (k.slice(0, 2) === 'on') { n.addEventListener(k.slice(2), attrs[k]); }
            else if (attrs[k] !== null && attrs[k] !== false) { n.setAttribute(k, attrs[k]); }
        });
        for (var i = 2; i < arguments.length; i++) {
            var c = arguments[i];
            if (c === null || c === undefined || c === false) { continue; }
            n.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
        }
        return n;
    }

    function api(path, body) {
        var opts = { method: body ? 'POST' : 'GET', headers: {} };
        if (body) {
            opts.headers['Content-Type'] = 'application/json';
            opts.body = JSON.stringify(body);
        }
        return fetch(state.brain.replace(/\/$/, '') + path, opts).then(function (r) {
            if (!r.ok) {
                return r.json().catch(function () { return {}; }).then(function (d) {
                    throw new Error(d.detail || (r.status + ' ' + r.statusText));
                });
            }
            return r.json();
        });
    }

    function setStatus(msg, kind) {
        var n = $('status');
        if (n) { n.textContent = msg; n.className = 'status ' + (kind || ''); }
    }

    /* ------------------------------------------------------------ the draft */

    function blankRule() {
        return {
            id: 'DRAFT.NEW_RULE',
            kind: 'buffer',
            name: 'New rule',
            category: 'custom',
            severity: 'minor',
            lifecycle: 'draft',
            appliesTo: ['javascript'],
            pattern: '',
            notWhen: '',
            guardLines: 0,
            message: '',
            examples: { fires: [], quiet: [] }
        };
    }

    /* A rule as the browser holds it, normalised for /api/try. Empty strings are
       dropped rather than sent: an empty notWhen is not the same as no notWhen,
       and the engine treats "" as absent anyway - being explicit here keeps the
       payload honest. */
    function candidate() {
        var d = state.draft || blankRule();
        var out = {
            id: d.id || 'DRAFT.UNNAMED',
            kind: d.kind,
            name: d.name || d.id,
            category: d.category || 'custom',
            severity: d.severity || 'minor',
            lifecycle: 'draft',
            appliesTo: d.appliesTo && d.appliesTo.length ? d.appliesTo : ['javascript'],
            message: d.message || d.name || d.id
        };
        if (d.kind === 'artifact') {
            try { out.check = JSON.parse(d.checkText || '{}'); }
            catch (e) { out.__checkError = e.message; }
        } else {
            out.pattern = d.pattern || '';
            if (d.notWhen) { out.notWhen = d.notWhen; }
            if (d.guardLines) { out.guardLines = Number(d.guardLines) || 0; }
            if (d.scanComments) { out.scanComments = true; }
        }
        out.examples = {
            fires: (d.examples && d.examples.fires) || [],
            quiet: (d.examples && d.examples.quiet) || []
        };
        return out;
    }

    /* ------------------------------------------------------------- run it */

    function run() {
        var rule = candidate();
        if (rule.__checkError) {
            setStatus('The check is not valid JSON: ' + rule.__checkError, 'bad');
            return Promise.resolve();
        }
        if (rule.kind === 'buffer' && !rule.pattern) {
            setStatus('Give the rule a pattern first.', 'warn');
            return Promise.resolve();
        }

        var body = { rule: rule };
        var sense = B.isAlive() ? B.sense() : null;
        state.lastSense = sense;

        /* Test against whatever the developer is looking at. A buffer rule wants
           the open script; an artifact rule wants the model. Falling back to the
           examples alone is still useful - it is how you work on a rule before
           opening anything. */
        var pre = Promise.resolve(null);
        if (rule.kind === 'artifact') {
            pre = B.isAlive() ? B.readArtifactModel() : Promise.resolve(null);
            return pre.then(function (model) {
                if (model) { body.artifact = model; }
                return send(body, rule);
            });
        }
        if (sense && sense.surface) {
            var buf = B.readDisplayedBuffer();
            if (buf && buf.code) {
                body.code = buf.code;
                body.language = buf.language || 'javascript';
            }
        }
        return send(body, rule);
    }

    function send(body, rule) {
        return api('/api/try', body).then(function (r) {
            state.lastResult = r;

            if (!r.ok) {
                B.clearAnnotations();
                setStatus(r.error, 'bad');
                render();
                return r;
            }

            /* Draw the candidate's findings where they actually fall. This is
               the whole point of testing in Designer rather than on a snippet:
               a pattern that looks precise can light up half the file. */
            if (body.code && r.findings) {
                B.annotate(r.findings, state.lastSense && state.lastSense.surface);
            } else {
                B.clearAnnotations();
            }

            var n = (r.findings || []).length;
            var ex = r.examples || {};
            setStatus(
                n + ' finding' + (n === 1 ? '' : 's') + ' on this buffer  ·  '
                + (ex.failed ? ex.failed + ' example(s) FAILED'
                             : (r.promotable ? 'examples pass, promotable'
                                             : 'examples incomplete')),
                ex.failed ? 'bad' : (r.promotable ? 'good' : 'warn'));
            render();
            return r;
        }).catch(function (e) {
            setStatus('Could not run: ' + e.message, 'bad');
        });
    }

    /* Save the draft.
     *
     * The server forces lifecycle to draft and refuses an id that already
     * exists as policy, so there is nothing to validate here beyond having
     * something to send - letting the server own the rules means one answer
     * rather than two that can drift.
     */
    function saveDraft() {
        var rule = candidate();
        if (rule.__checkError) {
            setStatus('The check is not valid JSON: ' + rule.__checkError, 'bad');
            return Promise.resolve();
        }
        delete rule.__checkError;
        return api('/api/rules/save', { rule: rule }).then(function (r) {
            var ex = r.examples || {};
            setStatus('Saved ' + r.saved
                + (ex.verified ? ' - examples pass'
                               : ' - examples incomplete, so it cannot be promoted yet'),
                ex.verified ? 'good' : 'warn');
            return refreshRules();
        }).catch(function (e) {
            setStatus('Not saved: ' + e.message, 'bad');
        });
    }

    function deleteDraft() {
        var id = (state.draft && state.draft.id) || '';
        if (!id) { return; }
        return api('/api/rules/delete', { id: id }).then(function (r) {
            setStatus(r.deleted ? 'Deleted ' + id : 'No draft called ' + id, '');
            return refreshRules();
        }).catch(function (e) {
            setStatus('Not deleted: ' + e.message, 'bad');
        });
    }

    function refreshRules() {
        return api('/api/rules').then(function (d) {
            state.rules = (d.rules || []).map(function (r) {
                return { id: r.id, kind: r.kind, name: r.name, category: r.category,
                         severity: r.severity, appliesTo: r.appliesTo,
                         lifecycle: r.lifecycle };
            });
            var n = $('brainStatus');
            if (n) { n.textContent = state.rules.length + ' rules loaded'; }
            render();
        });
    }

    /* ------------------------------------------------------- Designer panel */

    /* The tester's own docked panel, on the same tokens as the assistant's -
       see knowledge/design/carbon-tokens.md. The two sit side by side in the
       same Designer, so a difference in palette between them reads as one of
       them being broken. Prefixed `bawt-` for the same reason `bawp-` is:
       this is injected into IBM's document. */
    var PANEL_CSS = [
        '.bawt{font:400 13px/1.4 "IBM Plex Sans","Segoe UI",system-ui,sans-serif;',
        'height:100%;display:flex;flex-direction:column;background:#fff;color:#161616}',
        '.bawt *{box-sizing:border-box}',
        '.bawt-h{padding:0.6em;border-bottom:1px solid #e0e0e0;display:flex;',
        'align-items:center;gap:0.45em;flex-wrap:wrap;flex:none}',
        '.bawt-t{font-weight:600;font-size:0.85em;letter-spacing:.02em}',
        '.bawt-m{color:#6f6f6f;font-size:0.8em;',
        'font-family:"IBM Plex Mono",Consolas,monospace}',
        '.bawt-b{flex:1;overflow:auto;padding:0.6em;display:flex;',
        'flex-direction:column;gap:0.6em}',
        '.bawt-l{display:block;font-size:0.8em;letter-spacing:.02em;',
        'color:#6f6f6f;margin-bottom:0.15em}',
        '.bawt-f{display:flex;gap:0.45em}',
        '.bawt-f > div{flex:1}',
        /* Carbon's field: a filled box with a single bottom rule, no radius,
           and a 2px focus ring drawn inside so focus never reflows anything. */
        'input.bawt-i,select.bawt-i,textarea.bawt-i{width:100%;font:inherit;',
        'font-size:0.9em;padding:0.3em 0.6em;border:0;',
        'border-bottom:1px solid #8d8d8d;border-radius:0;background:#f4f4f4;',
        'color:#161616}',
        'input.bawt-i:focus,select.bawt-i:focus,textarea.bawt-i:focus{',
        'outline:2px solid #0f62fe;outline-offset:-2px}',
        'textarea.bawt-i{font-family:"IBM Plex Mono",Consolas,monospace;',
        'font-size:0.85em;resize:vertical;line-height:1.5}',
        '.bawt-btn{font:inherit;font-size:0.85em;padding:0.3em 0.6em;',
        'border:1px solid #8d8d8d;border-radius:0;background:#fff;color:#161616;',
        'cursor:pointer;transition:background 110ms cubic-bezier(.2,0,.38,.9)}',
        '.bawt-btn:hover:not(:disabled){background:#e5e5e5}',
        '.bawt-btn.primary{background:#0f62fe;border-color:#0f62fe;color:#fff}',
        '.bawt-btn.primary:hover:not(:disabled){background:#0043ce;border-color:#0043ce}',
        '.bawt-btn:disabled{color:#a8a8a8;border-color:#e0e0e0;cursor:default}',
        '.bawt-btn:focus{outline:2px solid #0f62fe;outline-offset:-2px}',
        /* Severity in the engine's rank order: critical > major > minor >
           warning. This used to give critical and major one red and colour
           warning louder than minor, which contradicts Rule.severityRank. */
        '.bawt-r{border-left:3px solid #6f6f6f;background:#f4f4f4;',
        'padding:0.45em 0.6em;margin-bottom:0.3em;font-size:0.9em;cursor:pointer}',
        '.bawt-r:hover{background:#e5e5e5}',
        '.bawt-r.critical{border-left-color:#da1e28}',
        '.bawt-r.major{border-left-color:#ff832b}',
        '.bawt-r.minor{border-left-color:#f1c21b}',
        '.bawt-r.warning{border-left-color:#6f6f6f}',
        '.bawt-ex{font-size:0.85em;padding:0.3em 0.6em;margin-bottom:0.15em}',
        '.bawt-ex.pass{background:#defbe6;color:#0e6027}',
        '.bawt-ex.fail{background:#fff1f1;color:#a2191f}',
        '.bawt-note{font-size:0.85em;color:#6f6f6f;line-height:1.4}',
        '@media (prefers-reduced-motion:reduce){.bawt *{transition:none}}'
    ].join('');

    function panelDoc() {
        return state.designer && !state.designer.closed ? state.designer.document : null;
    }

    function ensurePanel() {
        var node = B.dockPanel(460);
        if (!node) { return null; }
        var d = panelDoc();
        if (d && !d.getElementById('bawt-style')) {
            var st = d.createElement('style');
            st.id = 'bawt-style';
            st.textContent = PANEL_CSS;
            d.head.appendChild(st);
        }
        if (!node.firstChild) {
            node.innerHTML =
                '<div class="bawt">'
                + '<div class="bawt-h"><span class="bawt-t">Rule Tester</span>'
                + '<span class="bawt-m" id="bawt-ctx"></span></div>'
                + '<div class="bawt-b" id="bawt-body"></div></div>';
        }
        return node;
    }

    /* Build the editor inside the Designer's document. Every node is created
       with that document, not ours - a node made by document.createElement here
       and appended there works in practice but is not the same document, and
       Dojo's own widgets have been unhappy about it before. */
    function field(d, label, value, onInput, opts) {
        opts = opts || {};
        var wrap = d.createElement('div');
        var l = d.createElement('label');
        l.className = 'bawt-l';
        l.textContent = label;
        wrap.appendChild(l);

        var input;
        if (opts.options) {
            input = d.createElement('select');
            opts.options.forEach(function (o) {
                var op = d.createElement('option');
                op.value = o; op.textContent = o;
                if (o === value) { op.selected = true; }
                input.appendChild(op);
            });
        } else if (opts.rows) {
            input = d.createElement('textarea');
            input.rows = opts.rows;
            input.value = value || '';
        } else {
            input = d.createElement('input');
            input.type = 'text';
            input.value = value === null || value === undefined ? '' : value;
        }
        input.className = 'bawt-i';
        if (opts.placeholder) { input.placeholder = opts.placeholder; }
        input.addEventListener('change', function () { onInput(input.value); });
        if (!opts.options) {
            input.addEventListener('input', function () { onInput(input.value); });
        }
        wrap.appendChild(input);
        return wrap;
    }

    function lines(v) {
        return (v || '').split('\n---\n').map(function (s) { return s; })
            .filter(function (s) { return s.trim() !== ''; });
    }
    function unlines(a) { return (a || []).join('\n---\n'); }

    function renderPanel() {
        var node = ensurePanel();
        var d = panelDoc();
        if (!node || !d) { return; }
        var body = d.getElementById('bawt-body');
        var ctx = d.getElementById('bawt-ctx');
        if (!body || !ctx) { return; }

        var s = state.lastSense || (B.isAlive() ? B.sense() : null);
        ctx.textContent = s
            ? ((s.artifactName || 'no artifact') + '  ·  ' + (s.surface || 'no surface'))
            : 'Designer not open';

        var dr = state.draft || (state.draft = blankRule());
        body.innerHTML = '';

        /* Pick an existing rule to start from. Editing a copy, never the rule
           itself - the store is not touched by anything on this panel. */
        var picker = d.createElement('div');
        var pl = d.createElement('label');
        pl.className = 'bawt-l'; pl.textContent = 'start from';
        picker.appendChild(pl);
        var sel = d.createElement('select');
        sel.className = 'bawt-i';
        var blank = d.createElement('option');
        blank.value = ''; blank.textContent = '— new rule —';
        sel.appendChild(blank);
        state.rules.forEach(function (r) {
            var o = d.createElement('option');
            o.value = r.id;
            o.textContent = r.id + '  (' + r.kind
                + (r.lifecycle === 'draft' ? ', draft' : ', policy') + ')';
            if (r.id === dr.id) { o.selected = true; }
            sel.appendChild(o);
        });
        sel.addEventListener('change', function () { loadRule(sel.value); });
        picker.appendChild(sel);
        body.appendChild(picker);

        body.appendChild(field(d, 'rule id', dr.id, function (v) { dr.id = v; }));

        var row1 = d.createElement('div'); row1.className = 'bawt-f';
        row1.appendChild(field(d, 'kind', dr.kind, function (v) {
            dr.kind = v; renderPanel();
        }, { options: ['buffer', 'artifact'] }));
        row1.appendChild(field(d, 'severity', dr.severity, function (v) {
            dr.severity = v;
        }, { options: ['critical', 'major', 'minor', 'warning'] }));
        body.appendChild(row1);

        if (dr.kind === 'buffer') {
            body.appendChild(field(d, 'pattern', dr.pattern, function (v) {
                dr.pattern = v;
            }, { rows: 3, placeholder: 'a Java regular expression' }));

            var row2 = d.createElement('div'); row2.className = 'bawt-f';
            row2.appendChild(field(d, 'notWhen', dr.notWhen, function (v) {
                dr.notWhen = v;
            }, { placeholder: 'guard; {1} = capture 1' }));
            row2.appendChild(field(d, 'guardLines', dr.guardLines, function (v) {
                dr.guardLines = v;
            }));
            body.appendChild(row2);
        } else {
            body.appendChild(field(d, 'check (JSON)',
                dr.checkText || JSON.stringify(dr.check || {}, null, 2),
                function (v) { dr.checkText = v; }, { rows: 6 }));
        }

        body.appendChild(field(d, 'message', dr.message, function (v) { dr.message = v; }));

        body.appendChild(field(d, 'must FIRE on  (separate with ---)',
            unlines(dr.examples.fires),
            function (v) { dr.examples.fires = lines(v); }, { rows: 3 }));
        body.appendChild(field(d, 'must stay QUIET on  (separate with ---)',
            unlines(dr.examples.quiet),
            function (v) { dr.examples.quiet = lines(v); }, { rows: 3 }));

        var bar = d.createElement('div');
        bar.className = 'bawt-f';
        var runBtn = d.createElement('button');
        runBtn.className = 'bawt-btn primary';
        runBtn.textContent = 'Run on this buffer';
        runBtn.addEventListener('click', function () {
            runBtn.disabled = true;
            runBtn.textContent = 'Running';
            run().then(function () {
                runBtn.disabled = false;
                runBtn.textContent = 'Run on this buffer';
            });
        });
        var clearBtn = d.createElement('button');
        clearBtn.className = 'bawt-btn';
        clearBtn.textContent = 'Clear marks';
        clearBtn.addEventListener('click', function () {
            B.clearAnnotations();
            setStatus('Annotations cleared.', '');
        });
        bar.appendChild(runBtn);
        bar.appendChild(clearBtn);
        body.appendChild(bar);

        renderResults(d, body);

        /* Save is deliberately separate from Run, and sits below the result:
           the natural order is try it, look at what it did, then keep it. */
        var saveBar = d.createElement('div');
        saveBar.className = 'bawt-f';
        var saveBtn = d.createElement('button');
        saveBtn.className = 'bawt-btn';
        saveBtn.textContent = 'Save as draft';
        saveBtn.addEventListener('click', function () {
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving';
            saveDraft().then(function () {
                saveBtn.disabled = false;
                saveBtn.textContent = 'Save as draft';
            });
        });
        var delBtn = d.createElement('button');
        delBtn.className = 'bawt-btn';
        delBtn.textContent = 'Delete draft';
        delBtn.addEventListener('click', function () { deleteDraft(); });
        saveBar.appendChild(saveBtn);
        saveBar.appendChild(delBtn);
        body.appendChild(saveBar);

        var note = d.createElement('div');
        note.className = 'bawt-note';
        note.textContent = 'A saved draft runs for everyone immediately, but is '
            + 'never binding and never auto-applied. Making it policy means '
            + 'exporting the rules, committing, and redeploying.';
        body.appendChild(note);
    }

    function renderResults(d, body) {
        var r = state.lastResult;
        if (!r) { return; }

        var head = d.createElement('div');
        head.className = 'bawt-l';
        head.textContent = 'result';
        body.appendChild(head);

        if (!r.ok) {
            var err = d.createElement('div');
            err.className = 'bawt-ex fail';
            err.textContent = r.error;
            body.appendChild(err);
            return;
        }

        (((r.examples || {}).cases) || []).forEach(function (c) {
            var row = d.createElement('div');
            row.className = 'bawt-ex ' + (c.passed ? 'pass' : 'fail');
            row.textContent = (c.passed ? '✓ ' : '✗ ')
                + 'expected ' + c.expected + ', got ' + c.actual
                + '   ' + c.snippet.replace(/\n/g, ' ↵ ').slice(0, 70);
            body.appendChild(row);
        });

        (r.findings || []).forEach(function (f) {
            var row = d.createElement('div');
            row.className = 'bawt-r ' + f.severity;
            row.textContent = 'L' + f.line + '  ' + f.message;
            body.appendChild(row);
        });

        if (!(r.findings || []).length) {
            var none = d.createElement('div');
            none.className = 'bawt-note';
            none.textContent = 'No findings on the open buffer.';
            body.appendChild(none);
        }
    }

    /* ------------------------------------------------------- the hub mirror */

    function render() {
        var alive = B.isAlive();
        $('dock').disabled = !alive;
        $('undock').disabled = !alive;

        var s = alive ? B.sense() : null;
        var dl = $('ctx');
        dl.innerHTML = '';
        [['Designer', alive ? 'connected' : 'not open'],
         ['Artifact', s && s.artifactName ? s.artifactName : '-'],
         ['Surface', s && s.surface ? s.surface : 'none displayed'],
         ['Rule', state.draft ? state.draft.id : '-']
        ].forEach(function (row) {
            dl.appendChild(el('dt', null, row[0]));
            dl.appendChild(el('dd', null, row[1]));
        });

        var out = $('results');
        out.innerHTML = '';
        var r = state.lastResult;
        if (!r) {
            out.appendChild(el('div', { class: 'muted' }, 'Nothing tried yet.'));
        } else if (!r.ok) {
            out.appendChild(el('div', { class: 'check fail' }, r.error));
        } else {
            (((r.examples || {}).cases) || []).forEach(function (c) {
                out.appendChild(el('div', { class: 'check ' + (c.passed ? 'skip' : 'fail') },
                    (c.passed ? '✓ ' : '✗ ') + 'expected ' + c.expected
                    + ', got ' + c.actual + '  —  ' + c.snippet.replace(/\n/g, ' ↵ ')));
            });
            (r.findings || []).forEach(function (f) {
                out.appendChild(el('div', { class: 'check warn' },
                    'L' + f.line + '  ' + f.message));
            });
        }
        if (state.designer && !state.designer.closed) { renderPanel(); }
    }

    function loadRule(id) {
        if (!id) { state.draft = blankRule(); renderPanel(); render(); return; }
        api('/api/rules').then(function (d) {
            var found = null;
            (d.rules || []).forEach(function (r) { if (r.id === id) { found = r; } });
            if (!found) { return; }
            /* describe() is a summary, not the full definition - it has no
               pattern. Fetching the whole rule needs GET /api/rules/{id}, which
               does not exist yet, so start from the summary and let the author
               paste the pattern. Being explicit beats silently loading a rule
               with an empty pattern that then "fires on nothing". */
            state.draft = {
                id: found.id, kind: found.kind, name: found.name,
                category: found.category, severity: found.severity,
                lifecycle: 'draft', appliesTo: found.appliesTo,
                pattern: '', notWhen: '', guardLines: 0,
                message: '', examples: { fires: [], quiet: [] }
            };
            setStatus('Loaded ' + id + '. The pattern is not returned by /api/rules '
                    + '- paste it in, or start from a new rule.', 'warn');
            renderPanel(); render();
        });
    }

    /* ------------------------------------------------------------------ init */

    function launchDesigner() {
        var ref = $('branchRef').value.trim();
        if (!ref) { setStatus('Enter a containerRef first.', 'warn'); return; }
        localStorage.setItem('baw-probe-ref', ref);
        state.branchRef = ref;
        B.setBranch(ref);

        var url = '/WebPD/jsp/bootstrap.jsp?containerRef=' + encodeURIComponent(ref)
                + '&locale=en&WorkflowCenter='
                + encodeURIComponent('/processapps/platformRepo?BAW=true&BAW_tWAS=true');
        /* Do not let the launcher target itself.
         *
         * window.open(url, name) reuses the window that CARRIES that name -
         * and this page carries it whenever it was loaded into a tab that used
         * to be the Designer, because a window keeps its name across
         * navigations. Launching then navigates the launcher away and the page
         * that was about to drive the Designer is gone. Seen live.
         *
         * Dropping our own name first means the lookup cannot find us, so it
         * finds the real Designer window or opens a new one. */
        if (window.name === 'baw-designer') { window.name = ''; }
        state.designer = window.open(url, 'baw-designer');
        if (state.designer === window) {
            setStatus('Could not open a separate Designer window.', 'bad');
            state.designer = null;
            return;
        }
        if (!state.designer) {
            setStatus('The browser blocked the new window. Allow pop-ups for this site.', 'bad');
            return;
        }
        B.attach(state.designer);
        setStatus('Opening Designer…', '');

        var tries = 0;
        var poll = setInterval(function () {
            tries++;
            if (B.ready()) {
                clearInterval(poll);
                ensurePanel();
                renderPanel();
                setStatus('Designer ready. Open a script, then Run.', 'good');
                render();
            } else if (tries > 60) {
                clearInterval(poll);
                setStatus('Designer did not become ready. Is it still loading?', 'warn');
            }
        }, 500);
    }

    $('branchRef').value = state.branchRef;
    $('launch').addEventListener('click', launchDesigner);
    $('dock').addEventListener('click', function () { ensurePanel(); renderPanel(); });
    $('undock').addEventListener('click', function () {
        B.clearAnnotations();
        B.undockPanel();
        setStatus('Panel removed.', '');
    });

    api('/api/rules').then(function (d) {
        state.rules = (d.rules || []).map(function (r) {
            return { id: r.id, kind: r.kind, name: r.name, category: r.category,
                     severity: r.severity, appliesTo: r.appliesTo };
        });
        $('brainStatus').textContent = state.rules.length + ' rules loaded';
        $('brainStatus').className = 'status good';
    }).catch(function (e) {
        $('brainStatus').textContent = 'Rule engine unreachable - ' + e.message;
        $('brainStatus').className = 'status bad';
    });

    state.draft = blankRule();
    render();

    /* Keep the context line honest as the developer moves around Designer. */
    setInterval(function () {
        if (!B.isAlive()) { return; }
        var s = B.sense();
        var key = (s.artifactName || '') + '|' + (s.surface || '');
        if (key !== state.lastKey) {
            state.lastKey = key;
            state.lastSense = s;
            render();
        }
    }, 1000);
}());

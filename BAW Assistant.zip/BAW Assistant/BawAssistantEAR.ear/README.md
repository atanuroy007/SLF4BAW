# BawAssistantEAR.ear — the product

Exploded EAR for the BAW Assistant. Context root `/assistant`, pinned in
`META-INF/application.xml`.

**See [`../PROJECT.md`](../PROJECT.md)** for what the assistant is, how it is
built and deployed, and what is still pending. This file covers the layout of
this directory and the diagnostic probe that lives at `/assistant/probe.jsp`.

Everything the assistant does is read-only. It never writes to any artifact.

> This started life as a Tier A probe — static files and one JSP, no Java, no
> build. It is now **Tier B**: static files, JSPs *and* servlets. There is still
> no `web.xml` (Servlet 3.0 annotations make it optional), but there is Java,
> and it must be compiled to Java 8 bytecode (major 52) or it fails at class
> load. Build it with `..\build.ps1`.

## Layout

```
BawAssistantEAR.ear/
├── BawAssistant.war/
│   ├── index.jsp                     hub / launcher
│   ├── rules.jsp                     rule manager
│   ├── tester.jsp                    rule tester
│   ├── probe.jsp                     co-deployment probe (below)
│   ├── css/app.css
│   ├── js/
│   │   ├── hub.js                    hub UI + the panel docked inside Designer
│   │   ├── bridge.js                 all Designer DOM and REST access
│   │   ├── app.js, rules.js, tester.js
│   └── WEB-INF/
│       ├── rules/house-rules.json    the 123 rules
│       └── classes/com/bawassistant/ compiled — written by build.ps1
├── META-INF/application.xml
└── src/
    ├── main/java/com/bawassistant/   the engine (9 classes)
    └── test/java/com/bawassistant/   SelfTest, Verify, Emit
```

## Do not edit `WEB-INF/classes` by hand

`build.ps1` deletes and recopies it on every build, so the exploded tree can
never drift from `src/`. Edit `src/` and rebuild:

```powershell
powershell -ExecutionPolicy Bypass -File ..\build.ps1
```

## Deploying

Two artifacts, same content:

| Artifact | Use |
|---|---|
| this exploded directory | edit files in place on the server during development |
| `../BawAssistantEAR-deploy.ear` | admin console install — **required for Java changes** |

`..\deploy-assistant.ps1` copies only the static files, JSPs and rules. It does
**not** copy `WEB-INF/classes`, so it cannot deploy a Java change. See §6 of
`../PROJECT.md`.

Admin console → Applications → Application Types → WebSphere enterprise
applications → Install (or Update → Replace the entire application) → point at
the `.ear` → Save to the master configuration → synchronise nodes → Start.

Then open `https://<your-baw-host>:9443/assistant/`.

---

## The co-deployment probe — `/assistant/probe.jsp`

The probe answered the question the whole delivery model rested on before any
assistant code existed: **can an assistant served from the BAW origin actually
reach Process Designer?** It is kept because it is still the fastest way to
diagnose a broken environment.

Each check proves the assumption the next one depends on, so **the first
failure is the only one worth fixing**.

| # | Check | What a failure means |
|---|---|---|
| 1 | JSP is processed | The page was served as a static file — `contextPath` never resolved, and nothing downstream can work |
| 2 | Served from the BAW server | Basic reachability of this app |
| 3 | BAW is on this origin | `/WebPD/` 404s → the app is deployed where BAW is not. Same origin means same scheme + host + **port**; a different server in the cell does not qualify unless one HTTP server fronts both |
| 4 | **Authenticated session reused** | A 401/403, or an HTML login page instead of JSON, means the LTPA cookie is not carrying over |
| 5 | Designer window opened by this page | Same origin lets us *reach* the Designer; it does not put our code *on* its page. The window must be one this page created |
| 6 | Same-origin DOM reach | `contentWindow.document` denied → the Designer is on a different origin after all |
| 7 | Orion code surface readable | Whether `dijit.byId(...).getValue()` returns the live buffer — and whether an annotation handle is exposed |

Checks 5–7 need a Designer window. Paste a `containerRef` (it looks like
`2063.<guid>` and is visible in the Designer's own URL), press **Open
Designer**, wait for it to load, open a coach view and select
*Behavior → Inline Javascript*, then press **Probe it**.

Check 7 is the one that decided the product. An annotation model turned out to
be reachable, which is why findings are drawn as inline markers in the
developer's own editor rather than in a side panel with click-to-scroll.

### If check 1 fails

Look at **view-source**, not the DOM inspector. A JSP served as a static file
renders a page that looks correct while the source still contains the literal
`${pageContext.request.contextPath}` — the inspector will not show you that.

See the `baw-websphere-webapp` skill for the full deployment reference.

# The token table

The one source for every colour, size and space in the product. Written down
2026-08-30, when the owner asked for an enterprise-grade UI in the idiom of
IBM's **Carbon design system**.

It is applied **by hand in two places**, and that duplication is deliberate:

| Where | What it styles |
|---|---|
| `PANEL_CSS` in `js/hub.js` | the panel docked inside the Designer |
| `css/app.css` | the hub, rules, tester, compare, review and probe pages |

They cannot share a file. `PANEL_CSS` is injected into the **Designer's own
document**, where an unprefixed stylesheet would fight Dojo's CSS — which is
why every panel class carries a `bawp-` prefix and every rule in that sheet is
prefixed too. `app.css` styles ordinary pages of our own and uses plain class
names. Sharing one file would mean either prefixing our own pages for no
reason or letting unprefixed selectors loose in IBM's document.

So: change a value here first, then apply it in both. If the two ever
disagree, this file is right.

## Why no Carbon library

Non-negotiable 5 is zero third-party jars, and the same argument retires a
front-end framework: nothing is vendored, nothing is fetched at runtime, and
the Designer's CSP would have to be argued with. What we take from Carbon is
its **design language** — the type scale, the 8px spacing grid, the grey ramp,
the status colours, the 2px focus ring, and square corners. IBM Plex Sans was
already the panel's font stack, so the typography was half-done before this
started.

The one Carbon trait that will look like a bug if you do not expect it:
**corners are square.** `border-radius: 0` everywhere except tags, which are
pills. The panel used 3px radii before this.

## Colour

Carbon's grey ramp, White theme. Names are Carbon's, so they can be checked
against IBM's published palette rather than taken on trust.

| Token | Value | Carbon | Used for |
|---|---|---|---|
| `--ui-background` | `#ffffff` | White | page and panel ground |
| `--ui-01` | `#f4f4f4` | Gray 10 | a raised row, a panel body |
| `--ui-02` | `#ffffff` | White | a card on `--ui-01` |
| `--ui-03` | `#e0e0e0` | Gray 20 | subtle borders, dividers |
| `--ui-04` | `#8d8d8d` | Gray 50 | strong border, disabled text |
| `--hover-ui` | `#e5e5e5` | Gray 20 hover | row and button hover |
| `--selected-ui` | `#e0e0e0` | Gray 20 | a selected filter |
| `--text-01` | `#161616` | Gray 100 | primary text |
| `--text-02` | `#525252` | Gray 70 | secondary text, rationale |
| `--text-03` | `#a8a8a8` | Gray 40 | placeholder |
| `--text-helper` | `#6f6f6f` | Gray 60 | rule ids, meta, helper text |
| `--interactive` | `#0f62fe` | Blue 60 | buttons, links, focus |
| `--interactive-hover` | `#0043ce` | Blue 70 | hover on the above |

### Severity, in the engine's own rank order

`Rule.severityRank` orders them `critical 0 > major 1 > minor 2 > warning 3`,
and **`warning` is the lowest band, not the second highest.** The old panel
coloured `warning` orange and `minor` blue, so the ramp read backwards against
the engine's own ordering. These descend with rank:

| Severity | Rank | Token | Carbon |
|---|---|---|---|
| critical | 0 | `#da1e28` | Red 60 |
| major | 1 | `#ff832b` | Orange 40 |
| minor | 2 | `#f1c21b` | Yellow 30 |
| warning | 3 | `#6f6f6f` | Gray 60 |

`warning` is grey rather than Carbon's informational blue on purpose: blue is
the interactive colour here, and a blue 3px left border on a row reads as
"selected" rather than "lowest severity".

These are **borders and small marks, never text colour** — Yellow 30 on white
fails contrast as text and passes as a 3px rule, which is exactly how Carbon
uses it in a notification.

### Status, for the pages

| Token | Value | Carbon | Used for |
|---|---|---|---|
| `--support-error` | `#da1e28` | Red 60 | `.status.bad`, a failed check |
| `--support-success` | `#198038` | Green 60 | `.status.good`, a passed check |
| `--support-warning` | `#f1c21b` | Yellow 30 | `.status.warn` |
| `--support-info` | `#0f62fe` | Blue 60 | neutral notice |

## Type

IBM Plex Sans, with IBM Plex Mono for anything the developer must read
character by character — rule ids, refs, diffs, code.

```
font-family: "IBM Plex Sans", "Segoe UI", system-ui, sans-serif;
font-family: "IBM Plex Mono", Consolas, "Courier New", monospace;
```

Neither is fetched. Both ship with Process Designer, and the fallbacks carry
the rest.

**Every size in the panel is `em`, rooted at `.bawp`.** That is what makes the
font-size control one number: set `.bawp { font-size: <n>px }` and the whole
panel scales, spacing included. Deliberately `em` and not a CSS custom
property, so nothing depends on the Designer's rendering mode.

The px column is what each `em` resolves to at the **default root of 13px**:

| Role | Size | at 13px | Weight | Carbon |
|---|---|---|---|---|
| group header | `0.85em` | 11px | 600 | label-01 |
| row message | `1em` | 13px | 400 | body-compact-01 |
| rationale, remediation | `0.9em` | 11.7px | 400 | helper-text-01 |
| rule id, meta, mono | `0.8em` | 10.4px | 400 | code-01 |
| button label | `0.85em` | 11px | 400 | label-01 |

`line-height` is `1.4` for prose and `1.2` for single-line rows, per Carbon's
compact productive styles.

The pages in `app.css` use px directly — they are ordinary documents with no
zoom control, and the browser's own zoom already serves them.

## Space

Carbon's 8px grid. In `app.css` these are px. In `PANEL_CSS` they are `em`, so
that spacing scales with the font control; the px column is again at a 13px
root.

| Token | px | `em` in the panel |
|---|---|---|
| `spacing-01` | 2 | `0.15em` |
| `spacing-02` | 4 | `0.3em` |
| `spacing-03` | 8 | `0.6em` |
| `spacing-04` | 12 | `0.92em` |
| `spacing-05` | 16 | `1.23em` |
| `spacing-06` | 24 | `1.85em` |

The `em` values are not round because the grid is 8px and the root is 13px.
They are chosen to land on the grid at the default size and to scale
proportionally away from it, which is the right behaviour for a zoom control
and the reason they are written down rather than recomputed each time.

## Focus, and why it is not optional

```
outline: 2px solid #0f62fe;
outline-offset: -2px;
```

Carbon's focus ring, on every button, filter and expandable row. `outline` and
not `border`, so focus never reflows the layout; the negative offset draws it
inside the element, which is what stops it being clipped inside the panel's
scrolling list.

Nothing in this product may set `outline: none` without putting an equally
visible indicator back. The panel is keyboard-reachable inside the Designer
and a developer who tabs into it must be able to see where they are.

## Motion

`70ms` for a disclosure, `110ms` for a hover, both on Carbon's productive
easing `cubic-bezier(0.2, 0, 0.38, 0.9)`. Anything longer is felt as lag in a
panel this small.

Everything animated must also be correct with animation off — the collapse
state is a class, not a transition, so `prefers-reduced-motion` costs nothing
and is honoured.

---

# The shell, and the pages as one product

Added 2026-08-31, when the owner asked for the landing page, the sub pages and
the navigation to be enterprise-grade rather than six pages sharing a
stylesheet.

The gap was not style. It was **navigation**: there was none. The hub carried a
line of links in its footer, every other page carried no way back at all, and
the only route from the review to the rule manager was the browser's back
button. Carbon answers this with the **UI Shell**, and that is what was built.

## What the shell is

A 48px sticky header on every page, carrying the product name, the six tools,
and the signed-in user.

| Token | Value | Why |
|---|---|---|
| `--shell-bg` | `#161616` Gray 100 | **Dark in both themes.** Carbon's header is Gray 100 whether the page under it is White or Gray 100. It is chrome, not content; inverting it with the theme makes the product look like two products. |
| `--shell-bg-hover` | `#353535` Gray 80 | nav hover |
| `--shell-ink` | `#f4f4f4` Gray 10 | active item, brand |
| `--shell-ink-2` | `#c6c6c6` Gray 30 | resting nav item, meta |
| `--shell-line` | `#393939` Gray 80 | the rule under the header |
| `--shell-accent` | `#4589ff` Blue 50 | Blue 60 does not have the contrast on Gray 100; Blue 50 is Carbon's interactive colour on dark |
| `--shell-h` | `48px` | Carbon header height, and what every sticky offset is measured from |

**The current page is marked three ways** — a 3px Blue bottom border, a lighter
background, and full-strength text — plus `aria-current="page"`. Three signals
because one of them is colour, and colour alone is not a signal.

Everything that sticks is offset from `--shell-h`: the report's filter bar, the
landing page's sidebar, the data table's header row. Change the header height
and they follow.

## Where things sit, and why

**The landing page does two jobs** — it *is* the live-linting tool, and it is
the product's front door. Stacking them put every other tool below three
working panels, so the page a developer opens every morning had its navigation
under the fold.

It is now a two-column workspace: the work on the left where the eye starts,
the other tools in a sticky column beside it. Source order is main-then-aside,
so a narrow window stacks the work first and the signposts after it. The shell
is the global navigation; the sidebar is the orientation, and it costs the
primary task nothing.

**A page's masthead uses the same width class as its `<main>`.** Three widths
exist and mixing them puts the title on a different left edge from the content
beneath it:

| Class | Width | Used by |
|---|---|---|
| `.wrap` | 940px | prose-shaped pages — tester, probe |
| `.wrap.work` | 1180px | the landing page's two-column workspace |
| `.wrap.wide` | 1312px | data-dense pages — review, compare, rules. Carbon's max grid |

**Filters sit with what they filter.** "Show *severity*" was in the Connect
panel, two panels above the findings it governs, which reads as a connection
setting. It is now in the Findings panel head. The report's severity tabs and
category chips are sticky under the shell, because a sweep is ~500 findings in
~50 rules and filters that scroll away turn narrowing the list into a round
trip to the top.

**The rule manager's list gets the larger column.** It was 2fr against the
editor's 3fr, so browsing 175 rules happened in the narrower half of the page
while an empty "New rule" box held the wider one. Search now has its own row —
it had been squeezed to about twelve characters on the page whose whole job is
finding one rule among 175 — and the three facets are labelled.

## Rules that are not negotiable here

- **A label is an element, not a placeholder.** A placeholder disappears when
  someone types, so a field labelled only by one is unlabelled exactly when the
  value needs checking. The container ref is a GUID nobody remembers.
- **A disabled control says why.** Watch, Stop, Validate and Re-dock are dead
  until Designer is open, and a disabled control with no stated reason is a
  dead end — the developer cannot tell whether it is broken, unavailable, or
  waiting on them.
- **Development plumbing is folded away.** The API override sat at the same
  weight as the one field that matters.
- **Every page has a skip link** to `#main`. The shell put six links in front
  of the content, and a keyboard user should not tab through all of them.
- **Nothing scrolls horizontally.** Verified at 375px. The shell's nav scrolls
  within itself rather than wrapping, because a sticky element that changes
  height is worse than one that scrolls.
- **`prefers-reduced-motion` kills animation as well as transition.** The
  earlier rule covered transitions only, which would have left the loading
  skeleton shimmering for someone who asked it not to.

## What was added to `app.css`

`.shell*`, `.skip`, `.crumbs`, `.workspace` / `.col-main` / `.col-side`,
`.tiles-nav` / `.tile-link`, `.notify`, `.empty`, `.skeleton`, `.filterbar`,
`.field`, `.dt`, `.foot`, `.sr-only`, and button sizes and variants
(`.sm`, `.lg`, `.ghost`, `.danger`).

`PANEL_CSS` in `js/hub.js` is **unchanged** — the shell belongs to our own
pages, and the docked panel lives in the Designer's document where there is no
page to put a header on. The duplication this file describes is therefore
unaffected: the token table above is still applied by hand in two places, and
this section applies only to the first.

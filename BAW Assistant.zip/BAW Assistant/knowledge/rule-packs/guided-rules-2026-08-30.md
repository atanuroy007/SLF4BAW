# The checklist prompts the owner asked to be measured

The owner annotated all 67 manual review prompts on 2026-08-30, saying for each
one whether it belongs at develop time, at snapshot review, or with a person,
and in most cases how to measure it. This records what was built from that.

---

## Axis 1 — `scope`, now carried on every rule

Every rule declares when it can be evaluated:

| | rules |
|---|---|
| `["develop","snapshot"]` | **134** |
| `["snapshot"]` | **12** |

Almost everything is both, because a full application review runs everything
the panel runs. What carries information is the rule that **only** a
whole-application review can answer — it needs another artifact, the whole
application, or a second moment — and no amount of work on the panel will make
it answerable there.

`scope` is absent-means-both, is emitted by `export()`, and is pinned by four
self-test checks including one that it survives export. A promotion that
silently dropped the classification would be worse than not having it.

Five of the twelve are **two-moment** questions — Process!B8, B9, B13,
Variables & EPVs!B9 and General!B21 all ask whether something *changed*.
`/compare.jsp` already answers that shape, so they are the cheapest snapshot
wins: the machinery exists, only the link from prompt to comparison is missing.

---

## Axis 2 — what was built

Eight new draft rules, one correction to a rule shipped hours earlier, and two
engine additions the owner's guidance required.

### Rules, measured

| Rule | Checklist row | Corpus |
|---|---|---|
| `HOUSE.UI.COACH_PER_SERVICE` | UI!B5 | 42 of 340 client-side human services |
| `HOUSE.PERF.CACHEABLE_SERVICE` | Services!B7 | 94 of 899 service flows |
| `HOUSE.CODE.NO_COMMENTS` | Services!B11 | 210 of 734 scripts of 30+ lines |
| `HOUSE.EPV.TOO_MANY_FIELDS` | V&E!B10, UCA!B7 | **13 of 31 EPVs** |
| `HOUSE.EPV.NO_TEAM` | V&E!B5 | **24 of 31 EPVs** |
| `HOUSE.EPV.VALUE_TOO_LONG` | V&E!B6 | 0 of 31 — a boundary guard, never exercised |
| `HOUSE.VIEW.RESERVED_NAME` | UI!B18 | 0 — a boundary guard, never exercised |
| `HOUSE.CODE.ASSIGNMENT_SCRIPT` | General!B8, Process!B14 | 432 scripts / 255 artifacts — **see the caveat below** |

### The correction

`HOUSE.FLOW.UNCONNECTED_STEP` now applies to `SERVICEFLOW` and `COACHFLOW`
only. The owner: *"check for any disconnected components in any artifact, apart
from process, process may have disconnected activities."* Pinned by a self-test
check that a process with an orphan step raises nothing and a service with the
same step does.

### Two engine additions

- **`any: "artifact"`** reaches the artifact's own top-level fields. Nothing
  could test an artifact's *name* before — `field:` compares numbers only, and
  every where-predicate ran against a row of some collection. UI!B18 ("is the
  coach view named after a reserved word", rated Critical) is the row that
  needed it. A real key of that name still wins, so nothing existing changes.
- **`gt` / `gte` / `lt` / `lte` inside a where-predicate**, comparing one row's
  own number as distinct from `op`/`value` which compares the aggregate. This
  is what keeps the 255-character limit in the rule instead of baking it into
  the reader. A non-numeric field satisfies none of them rather than counting
  as zero.

---

## EPVs were never unreadable

Five checklist rows were previously recorded as blocked because "`envVarSet`
returns HTTP 500". That conflated two different artifacts. **An EPV — exposed
process variable — reads perfectly well**; it is the environment variable *set*
that 500s, and no checklist row asks about one.

Probed live across every resource-rooted artifact in all three applications:

| `extensionElements` key | count | what it is |
|---|---|---|
| `epv` | 31 | an EPV |
| `team` | 27 | a team |
| `trackinggroup` | 1 | a tracking group |
| `userAttributeDefinition` | 1 | a user attribute definition |

This is also the fix for the Team misclassification recorded in PROJECT.md §11:
`declaredType === 'resource'` was being read as "team", so all 33 non-teams
reported `hasMembers: false` — precisely the set a "team has no members" rule
would have flagged, wrongly, every time. The discriminator is the
`extensionElements` key, not the declaredType.

The reader now emits an EPV's variables as `variables[]` with
`category: "EPV"`, each carrying `valueLength`, `hasDefault` and
`hasDocumentation`, and settings `{resourceKind, isEpv, exposedToTeam}`. Keying
the rules on the variable *category* rather than the artifact type means they
work whether the type arrived from the editor or from the reader.

Verified end to end: the Java engine over the 60 real resource artifacts
reports 13 EPVs above 30 variables and 24 with no team — the same numbers the
live probe predicted.

---

## A measurement gap this exposed

`HOUSE.CODE.ASSIGNMENT_SCRIPT` reads `surfaces[]`, which **is** in the artifact
the panel posts to `/api/check` — and which no rule had ever read. The corpus
run reported it as never firing, on a corpus holding 432 pre and post
assignment scripts.

The rule is right; `models.json` was the problem. `tools/harvest-corpus.js`
wrote the code surfaces out as files and their metadata into `manifest.json`,
but not into the models the artifact rules are measured against. **Unmeasurable
rather than quiet**, which is the harder failure to notice — the same shape as
`HOUSE.SQL.PRODUCT_TABLE` looking safely silent while it was 89% blind.

The harvester now records each artifact's surfaces in `models.json` — name,
kind, language and line count, without the code, which is already on disk
beside it. **The corpora on disk predate this, so re-harvest before trusting a
surfaces-based rule's corpus count.**

---

## Still not measurable, from the owner's own annotations

- **Lanes** are the largest single blocker in the Process sheet — Process!B5,
  B11, B12, B21 and the "optimize execution for latency" check at B18 all need
  them, and the reader does not read lanes at all.
- **Coach-view config options are absent from the payload**, which blocks UI!B16,
  B17, B31, B35 and the localisation check at UI!B12.
- **Process settings** — auto-tracking (B6), at-risk calculations (B7) — are one
  reader field each.
- **UCA parameters** are not read, blocking UCA!B5 and B6.
- The owner marked UI!B13 ("are reusable functions written in the inline
  JavaScript block") as needing the AI path, which is blocked on procurement.

### One contradiction in the source worth a decision

The workbook asks for two different EPV size limits: **30** on UCA!B7 and
Variables & EPVs!B10, and **40–50** on Variables & EPVs!B7.
`HOUSE.EPV.TOO_MANY_FIELDS` implements 30, the stricter limit that two rows
agree on. At 30 it flags 13 of 31 EPVs; the largest carries 217 variables and
would be flagged by any of the three thresholds.

---

## Addendum — the process reader, and a correction

Added later the same day, after the owner reported three checks not appearing
for a developer and corrected a mistake in the classification above.

### EPVs and exposed variables are not the same thing

This note, and the scope classification, treated Process!B10 ("are exposed
variables prefixed with the process acronym") as an EPV question. It is not.

- An **EPV** is its own artifact: a set of runtime-configurable constants,
  reached through `extensionElements.epv`.
- An **exposed variable** is a field of the *process itself*, published for
  search and the Portal under an **alias**. It lives at
  `ioSpecification.dataInput[n].extensionElements.searchableField[]`, each entry
  carrying a `path` and an `alias`, and the same field is listed on both the
  input and output sides.

Because of that mistake B10 was filed as snapshot-only, needing "the EPV
artifact". It needs neither: the aliases are in the process payload in hand,
and only the acronym comes from elsewhere. It is answerable live, and now is.

### What the process payload actually carries

Probed live across the real BPDs in all three applications:

| | where |
|---|---|
| lanes, their nodes and their participant | `laneSet[0].lane[]` — `name`, `flowNodeRef[]`, `partitionElementRef` |
| step ordering | `flowElement[]` of `declaredType: sequenceFlow`, via `sourceRef`/`targetRef` |
| whether a step is a system task | `extensionElements.activityType[0] === 'ServiceTask'` |
| delete on completion | `extensionElements.deleteTaskOnCompletion[0]` |
| auto-tracking, at-risk, latency | `extensionElements.bpdExtension[0]` |
| exposed variable aliases | `ioSpecification.*.extensionElements.searchableField[]` |

Lanes were the largest single blocker in the catalogue, gating nine practices.
They were in the payload the whole time.

### Two things the condition language cannot express

"Sequential system activities" is a property of the **graph**, and a
where-predicate sees one row at a time. "Is this alias prefixed with the app
acronym" compares two fields, one of which belongs to another artifact.

Both are computed in the reader and exposed as plain numbers and booleans, so
the rule still owns the threshold:
`maxSequentialSystemActivities`, `maxSequentialSubProcesses`,
`systemTasksNotDeletedOnCompletion`, and `acronymPrefixed` per exposed variable.

The acronym is resolved once per branch from the process-app listing and held
in the reader, which keeps `parseAsset` synchronous and DOM-free — the property
the pre-deployment report depends on. When it cannot be resolved the readers
report **null**, and the rule's `exists` guard turns that into silence rather
than a false finding.

### Measured over the real processes

| Rule | Checklist | Fires |
|---|---|---|
| `HOUSE.PROC.SEQUENTIAL_SYSTEM_ACTIVITIES` | Process!B5 | **6 of 12** processes, longest run 3 |
| `HOUSE.PROC.LATENCY_NOT_OPTIMIZED` | Process!B18 | **6 of 12** — every run is unoptimised |
| `HOUSE.PROC.SYSTEM_TASK_NOT_DELETED` | Process!B12 | **3 of 12** |
| `HOUSE.NAME.EXPOSED_VARIABLE_PREFIX` | Process!B10 | **1 of 12** — 3 aliases, none prefixed |
| `HOUSE.PROC.SEQUENTIAL_SUBPROCESSES` | Process!B16 | 0 — a guard, not yet exercised |

Two more flags are now read but have no rule, deliberately: `autoTrackingEnabled`
is **off on all 12** (a rule would never fire) and `atRiskCalcEnabled` is **on
for all 12** (a rule would fire on everything). Both are the owner's call rather
than ours.

### Two live defects fixed at the same time

`HOUSE.FLOW.UNCONNECTED_STEP` fired on **every** artifact with steps. The panel
reads components from the live diagram, where `readComponents` emits
`{name, type}` and no connectivity at all, and a bare `isFalse` is satisfied by
an absent key. `connected` must now be present and false. This is the third
time that trap has bitten; the guard is now on every rule that uses `isFalse`.

`HOUSE.UI.COACH_PER_SERVICE` could never fire for a developer. The diagram
reports a coach as `com.ibm.bpmsdk.model.bpmn20.ibmext.TFormTask` — the full
class name — while the committed reader shortens it. Two vocabularies for one
concept, so a rule that matched 42 artifacts in the corpus matched none live.
`readComponents` now shortens the same way.

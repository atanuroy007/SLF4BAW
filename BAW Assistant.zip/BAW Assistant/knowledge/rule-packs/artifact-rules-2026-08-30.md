# Per-artifact-type rules, measured

**What this covers:** the eight artifact rules added on 2026-08-30, which are
the first rules to read anything beyond `variables` and `components`. Written
against the `settings` the Phase 4 readers put in the artifact model —
coach-view header flags, UCA event configuration, business-object annotations.

**Corpus:** the same three applications as
[`quietness-2026-08-29.md`](quietness-2026-08-29.md), measured through
`com.bawassistant.Corpus` over the `models.json` each harvest saved —
**1,719 artifact models**: 198 + 937 + 584.

Before 2026-08-30 all seven artifact rules applied to `SERVICEFLOW`,
`CaseProcess` and `COACHFLOW` only. Business objects, coach views, UCAs, teams,
REST services and application settings had **no rule of any kind**.

---

## The engine could not read settings at all

The handoff said this batch was "JSON plus examples, no engine change". It was
not. `ArtifactChecker.evaluate` could read a top-level array (`count:` / `any:`)
and a top-level **numeric** field (`field:`), and `settings` is a nested object,
so it was unreachable. Proven against the running server with `/api/try` rather
than argued, on build `20260830-100523`:

| probe | verdict |
|---|---|
| `{"any":"settings","where":{"field":"isTemplate","isTrue":true}}` | fires → **quiet** |
| `{"field":"settings.isTemplate","op":"==","value":1}` — dotted path | fires → **quiet** |
| `{"count":"settings.list","op":">","value":0}` | fires → **quiet** |
| `{"field":"variablesApply","op":"==","value":0}` — a boolean via `field:` | fires → fires, **quiet → fires** |

The last row is the one worth remembering: `field:` coerces a non-number to `0`,
so a boolean read that way is true and false at the same time. Flattening
`settings` onto the top level would not have worked either.

**The change:** six lines. When `any:` or `count:` names something that is an
object rather than an array, `ArtifactChecker` reads it as a collection of
exactly one row. Settings rules then use the same `and`/`or`/`not`/`eq`/`isTrue`
predicates as every other rule, and there is no second condition language for
the one shape on the model that is not a list. Pinned by 16 self-test checks.

---

## The rules, and what they actually matched

All eight ship as **drafts**. Nothing was promoted.

| Rule | Type | Hits | Of |
|---|---|---|---|
| `HOUSE.UCA.NO_IMPLEMENTATION` | UCA | **2** | 62 |
| `HOUSE.BO.SHARED` | BusinessObject | **2** | 259 |
| `HOUSE.UCA.DISABLED` | UCA | **5** | 62 |
| `HOUSE.VIEW.BOUNDARY_EVENT_UNDOCUMENTED` | CoachView | **6** | 96 |
| `HOUSE.BO.TOO_MANY_ATTRIBUTES` | BusinessObject | **32** | 259 |
| `HOUSE.BO.ATTRIBUTE_CONVENTION` | BusinessObject | **35** | 259 |
| `HOUSE.VIEW.NO_DESCRIPTION` | CoachView | **35** | 96 |
| `HOUSE.FLOW.EXPOSED_TO_URL` | COACHFLOW | **36** | 340 |

### Ready to promote on this evidence — read line by line

**`HOUSE.UCA.NO_IMPLEMENTATION`** — both hits are real, and they are not the
same defect:

- `LCGS120 IGDX Workflow Notifications` — disabled *and* wired to nothing.
- `LCU007 Cause of Death Codes` — **enabled**, event type Timer, implementation
  `null`. A live UCA attached to nothing. Nothing at runtime reports that the
  event was ignored; this is the kind of thing only a structural check finds.

**`HOUSE.UCA.DISABLED`** — 5 hits, all genuine dead configuration: two Portal
Update UCAs on `Variable`, two on `Service`, and the IGDX one above. Each still
carries its event, queue and attached service and each is inert.

The condition tests that `isEnabled` is **present and false**, not merely false.
A bare `isFalse` is also satisfied by the key being absent, so without the guard
the rule would fire on every UCA whose settings a later reader did not populate.
Pinned by a self-test check.

### Correct, but promoting means accepting a backlog

**`HOUSE.FLOW.EXPOSED_TO_URL`** (36) and **`HOUSE.VIEW.NO_DESCRIPTION`** (35)
are not matching anything wrong — they report a fact about the artifact. 11% of
client-side human services really are URL-exposed and 36% of coach views really
have no description. Whether either is a defect is the standards owner's call,
exactly like `LOOSE_EQUALITY` in the 2026-08-29 pack.

**`HOUSE.BO.ATTRIBUTE_CONVENTION`** (35 objects, 242 attribute names) needs a
decision before it goes anywhere, because what it matched splits cleanly:

| shape | names | example |
|---|---|---|
| leading capital | 149 | `TRSCCorridorUnits`, `LIDPGuaranteedMinDbAdjRule` |
| `snake_case` | 90 | `created_by`, `date_of_pay_override` |
| non-ASCII | 3 | `缴费编号`, `客户姓名`, `账号` |

The snake_case names mirror database columns and the capitalised ones carry a
domain acronym prefix; both look deliberate rather than careless. And the
pattern `^[a-z][A-Za-z0-9]*$` rejects any non-Latin name by construction, which
is a property of the rule, not of the code it is reading. **Do not promote
without deciding what the standard says about objects that mirror a system of
record.**

**`HOUSE.BO.TOO_MANY_ATTRIBUTES`** (32) is a threshold, not a defect. The
corpus median is 6 attributes, p90 is 25 and the widest object is
`PolicyDetail` at **143**. `> 20` sits just under p90.

**`HOUSE.BO.SHARED`** (2) is quiet and specific, but what the `shared`
annotation changes about an object is **not verified** anywhere in this
knowledge base — the rule asks a reviewer to confirm the setting was deliberate
rather than asserting it is wrong. That is why it is a draft.

---

## A rule was withdrawn during measurement, and it found a model bug

`HOUSE.BO.NO_ATTRIBUTES` — "this business object declares no attributes" —
fired 4 times. Two of the four **are not business objects**:

| artifact | what it really is |
|---|---|
| `test` | a genuine empty complexType — true positive |
| `CoachCalculateDeathBenefitValues` | a genuine empty complexType — true positive |
| `VisbilityEnum` | a `simpleType` enumeration of NONE / FULL / READ |
| `FC_BP_CM_CurrentComment` | a `simpleType` enumeration |

Confirmed by reading both payloads live from
`/rest/bpm/wle/pd/v1/asset/{poId}`, not inferred.

**The cause is the reader, not the rule.** An enumerated type arrives under the
same `domainProperty: "schema"` as a business object, but it is a `simpleType`
with a `restriction.enumeration` and has no `complexType` anywhere.
`readBusinessObject` looked only at `complexType[0]`, so every enumeration in
the product read as a business object **with no name at all** and zero
attributes — and the zero was then reported as committed fact. That is finding
F2 again, in a different artifact type.

Fixed in `bridge.js`: an enumeration keeps its name, reports its values as
`components` typed `EnumerationValue`, sets `variablesApply: false` because
attributes are not a thing it has, and carries `settings.isEnumeration`. Pinned
by 9 checks in `test/bridge-model.test.js` against
`payloads/BusinessObjectEnum.json`.

**The rule itself stays withdrawn.** Excluding enumerations means saying "is not
an enumeration **and** has no attributes" — two conditions over two different
parts of the model — and the condition language allows one aggregate per rule.
Adding a second is a bigger decision than this batch. The rule is worth 2 true
positives in 259 objects, which does not pay for that.

---

## What is still unmeasurable

- **`RESTService`, `AppSettings`, `Team` and `CaseProcess` have no rules.** The
  first three because the corpus holds 0, 3 and 27 of them; a threshold chosen
  against 3 application-settings artifacts would be a guess wearing a number.
- **`Team` is worse than under-sampled — the type is wrong.** `derivedEditorType`
  returns `Team` for any root whose `declaredType` is `resource`, which in this
  corpus captures 31 EPVs, 1 TrackingGroup and 1 UserAttributeDefinition
  alongside 27 real teams. Those 33 are *exactly* the 33 models with
  `hasMembers: false`, while all 27 real teams have members. A
  "team has no members" rule would have fired 33 times and been wrong 33 times.
  **Fix the classifier before writing any Team rule.**
- **`SERVICEFLOW` exposure is not being read.** `settings.exposedAs` is `null`
  on all 899 service flows while `COACHFLOW` reads it correctly on all 340, so
  a service-flow exposure rule would be built on a hole in the reader rather
  than on the artifact. Not chased.
- **`isMobileReady` is `false` on 96 of 96 coach views**, so a rule on it fires
  on everything and says nothing.

---

## Reproducing this

```powershell
node tools\harvest-corpus.js            # writes samples\corpus*, never committed
& $java -cp $classes com.bawassistant.Corpus `
    BawAssistantEAR.ear\BawAssistant.war\WEB-INF\rules\house-rules.json `
    samples\corpus-app3
```

`Corpus` reports artifact rules over `models.json` and buffer rules over the
harvested code surfaces. `samples/corpus*/` is customer source and is
gitignored — the counts in this file are the only thing that leaves it.

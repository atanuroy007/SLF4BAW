# Draft rule quietness, measured

**Corpus:** `2063.b109061c-8764-4447-83d0-ba499d2aa279` — a Life Admin Claims
application. 210 artifacts, **287 code surfaces, 6,328 lines, 266,245
characters**. Harvested 2026-08-29 with `tools/harvest-corpus.js`, measured
with `com.bawassistant.Corpus`.

For scale: the previous corpus (CAPOC) held 1,173 characters of deliberately
defective probe code. This one is 227× larger and is real production code, so
for the first time "does this rule leave correct code alone" is a question that
can actually be answered.

| Artifact type | Surfaces |
|---|---|
| Human Service | 115 |
| General System Service | 90 |
| CoachView | 34 |
| BPD | 29 |
| Regular Service | 15 |
| Integration Service | 4 |

**13 of the 42 automated drafts fired. 34 rules were silent.**

The two rules already active as policy fired **5 times in 266k characters**,
which is a good sign about how the active set was chosen.

---

## Read the lines, not the counts

A fire count says how loud a rule is and nothing about whether it is right.
Every rule below was judged by reading what it actually matched.

### Promote — true positives, low volume

| Rule | Hits / files | Evidence |
|---|---|---|
| `HOUSE.NULL.TW_LOCAL_CHAIN` | 2 / 2 | `tw.local.reinsurancePolicyInformation.dateOfDeath.formatDate()` — a genuine unguarded chain. |
| `HOUSE.UI.INLINE_STYLE` | 2 / 1 | `buttonNode.style.width = "100%"` — real inline style manipulation. |
| `HOUSE.CODE.WORK_MARKER` | 6 / 3 | Real `// TODO:` comments. But see the toolkit-code caveat below - all six are in vendor code. |

### Fix before promoting — the rule is wrong, not the code

| Rule | Hits / files | What it is actually matching |
|---|---|---|
| `HOUSE.CODE.LOOSE_EQUALITY` | **475 / 97** | Flags `x != null` and `x != undefined`, which is the deliberate idiom for catching both at once — the very defensive check the checklist asks developers to write. Roughly a third of all files. Promoting this as it stands would bury the panel. **Add a `notWhen` excluding comparisons against `null` and `undefined`, then re-measure.** |
| `HOUSE.NULL.LIST_INDEX` | **166 / 12** | Flags `cases[0] = new tw.object.Case()` — an *assignment that creates* the element, which cannot fail the way an unguarded *read* can. Concentrated in initialisation scripts that build structures index by index. **Exclude assignment targets.** |
| `HOUSE.REL.SELF_ASSIGNMENT` | 9 / 6 | `this._formatOptions.dateOptions.constraints.datePattern = datePattern;` is not a self-assignment: a local variable is being assigned to a property that merely shares its name. All nine are false. |
| `HOUSE.REL.SYSTEM_WRITE` | 6 / 3 | `tw.system.coachValidation = new tw.object.CoachValidation()` is the **documented IBM pattern** for coach validation, not a reliability defect. Needs an exception for `coachValidation`, or the rule is simply wrong. |

### A standards decision, not a rule defect

`HOUSE.NULL.LIST_ITERATION` — **59 hits across 40 files**. Every one is the
canonical `for (var i = 0; i < tw.local.X.listLength; i++)`. The rule is doing
exactly what it says, and its rationale is sound: `.listLength` on a list that
was never populated throws before the loop runs once. So this is not noise —
it is a real backlog, and the question is whether the house standard is worth
59 findings against this application. **That is the owner's call, not a fix.**

The same reading applies to `HOUSE.CODE.DEEP_PATH` (65 / 17),
`HOUSE.DATE.RAW_ARITHMETIC` (52 / 17) and `HOUSE.CODE.COMMENTED_CODE` (48 /
20): loud, but not obviously wrong. Each needs the same line-by-line read
before a decision.

---

## Two caveats that affect the numbers

**The corpus contains vendor and duplicated code.** `Date-Time-Picker`,
`Date-Time-Picker-2` and `Date-Time-Picker-3` are **byte-identical copies** of
the same IBM control. Any rule firing there is counted three times, and it is
not the customer's code to review anyway — `HOUSE.CODE.WORK_MARKER` and
`HOUSE.CFG.HARDCODED_TEAM` (18 / 3) are almost entirely inside them. A future
harvest should be able to exclude toolkit-derived artifacts; until it can,
discount findings in those three files.

*(That triplication is itself worth telling the application's owners about.)*

**Silence is not quietness.** The 34 rules that never fired may be genuinely
quiet or may simply have met nothing they look for. This corpus has no
`eval`, no SQL, no `debugger` and no hardcoded credentials — several of the
silent rules target exactly those. They are unproven, not proven safe.

---

## Where this leaves promotion

Nothing has been promoted. Promotion is export → commit → redeploy, one rule
at a time, and each of the three "promote" candidates should go through that
path on its own so its effect is visible in isolation.

The four "fix first" rules are the more valuable outcome: each has a specific,
testable defect, and each fix should add a `quiet` example capturing the exact
construct it wrongly flagged — so the build gate stops it coming back.

---

# Second measurement: the four rules fixed, and a much larger application

**Corpus B:** `2063.f72da6dc-7bee-489d-84c5-122145f7cf86` — a Life Claims
application. **2,099 code surfaces, 47,367 lines, 2,042,281 characters.** Eight
times Corpus A and 1,700 times the original CAPOC sample.

## The four defects are fixed

Each fix carries `quiet` examples holding the exact construct it wrongly
flagged, so the build gate stops the defect returning. All 56 example-carrying
rules still verify.

| Rule | Before | After | What changed |
|---|---|---|---|
| `HOUSE.REL.SYSTEM_WRITE` | 6 hits, all false | **0** | Only flags *replacing* a `tw.system` object now. Setting a property on one - `tw.system.currentTask.dueDate` - is the documented and only supported way to do that job; flagging it told developers to stop doing the one thing they can do. `coachValidation` stays exempt for the same reason. |
| `HOUSE.REL.SELF_ASSIGNMENT` | 9 hits, all false | **8, all true** | `` let the identifier alternative match the last segment of a dotted path, so `this.opts.constraints.datePattern = datePattern` looked self-assigning. Now finds only real ones: `paymentMeth = paymentMeth;`, `polSys = polSys;`. |
| `HOUSE.NULL.LIST_INDEX` | 166 on Corpus A | **33 on A** | No longer flags `cases[0] = new ...`, an assignment that *creates* the element, and treats a just-created element as guarded. |
| `HOUSE.CODE.LOOSE_EQUALITY` | 475 on Corpus A | **326 on A** | No longer flags `x != null` / `x != undefined`. |

A note on that last fix, because it nearly shipped broken. The first attempt
wrote `\s*(?!null|undefined)` — useless, because the engine matches `\s*` as
zero width and then tests the lookahead against the space itself. It cut 475 to
448 and looked like progress. The whitespace has to go **inside** the
lookahead: `(?!\s*(?:null|undefined))`. The rule's own `quiet` example
caught it; the corpus number alone would not have.

## Loud, and correct

These are not defects. Each was read line by line and is doing what it says.

| Rule | Corpus B | The judgement |
|---|---|---|
| `HOUSE.NULL.LIST_INDEX` | 1,634 / 176 files | Genuine. `tw.local.results[0].rows` on a SQL result that may be empty is *the* classic BAW runtime failure, and this application does it everywhere. |
| `HOUSE.CODE.LOOSE_EQUALITY` | 1,149 / 364 | Genuine `==` on strings and numbers now that the null idiom is excluded. |
| `HOUSE.CODE.DEEP_PATH` | 606 / 89 | |
| `HOUSE.CODE.COMMENTED_CODE` | 277 / 148 | |
| `HOUSE.NULL.LIST_ITERATION` | 173 / 135 | |

Whether a standard is worth this many findings is the owner's call. Promoting
any of them means accepting a backlog, not accepting noise — a different
decision, and one worth making deliberately.

The tail is quiet and promotable on the evidence: `TW_LOCAL_CHAIN` 33,
`SQL.INLINE_QUERY` 29, `DATE.RAW_ARITHMETIC` 26, `LONG_CONDITION` 17,
`NESTED_LIST_LOOP` 14, `SQL.PRODUCT_TABLE` 11, `GLOBAL_DOM_LOOKUP` 9,
`REL.EMPTY_IF` 8, `SELF_ASSIGNMENT` 8, `HARDCODED_TEAM` 5, `WINDOW_BINDING` 2,
`PARSEINT_RADIX` 2, `INLINE_STYLE` 2, `CONCAT_IN_LOOP` 1.

**The active policy set stayed quiet on two million characters:**
`HARDCODED_CONFIG` 22, `EMPTY_CATCH` 16, `UNTRACKED_TIMEOUT` 1. That is a good
independent signal about how the active 14 were chosen.

---

# Duplicate code

**174 duplicated blocks, 364 redundant surfaces — 17% of the application.**

| Copies | What |
|---|---|
| x22 | `Build-Parameters` — identical across LCGS012, LCGS014, LCGS015 … LCGS140 and a Regular Service |
| x22 | `Initialize` — identical across LC001 … LC026 human services |
| x20 | `preAssignmentScript` on the GEX Handler human task |
| x19, x18, x14 | counter increment / initialise scripts |

This matters twice over. For the customer it is a maintainability finding in
its own right: a fix to one of those 22 copies fixes one of them. For the
measurement it is a distortion — a finding inside a block copied 22 times is
counted 22 times, so a rule can look far noisier than it is.

## Why this is NOT a house rule

Every rule kind the engine has judges **one thing in isolation**: a `buffer`
rule sees a single code surface, an `artifact` rule sees a single artifact's
model. Duplication is a property of a **set** of artifacts, so no regex over
one buffer and no condition over one model can ever detect it. Expressing it as
a rule would mean inventing a kind that lies about what it can see.

It lives in `com.bawassistant.Corpus`, at the level that holds the whole
application, and belongs in the pre-deployment `.twx` report (R3) for the same
reason. If it should also appear in the Designer panel, that needs a new rule
kind with application-wide scope - a real design decision, not a pattern.

# IBM IDA checkstyle, triaged against this engine

**Source:** <https://sdc-china.github.io/IDA-doc/checkstyle/checkstyle-checkstyle-rules-description.html>
— IBM's own checkstyle catalogue for BAW process applications, read 2026-08-30.
**129 rules** across ten sections, plus a table of 27 default thresholds.

This is a vendor standard, not the customer's checklist, so nothing here is
policy. Everything adopted ships as a **draft** citing the IDA rule it came
from, with `authorityStatus: needs-approval`.

---

## What the catalogue is worth

Nine of the 129 were reachable with the model and engine we have. Two more
turned out to be things we already had **and had wrong** — which is the more
valuable half of this exercise: IBM's catalogue was worth reading not mainly
for the rules it added but for the two defects it exposed in rules already
shipping, one of them active policy.

| | rules | |
|---|---|---|
| **Adopted** — new, measured, shipping as drafts | **7** | below |
| **Already covered, and improved because of this** | **3** | below |
| Needs application-wide scope — the `.twx` report | 41 | plan item 4 |
| Needs a reader addition; the data is in the payload | 41 | listed below |
| Not applicable — IBM Case Manager, or desktop-PD inventory | 37 | listed below |

---

## Adopted

Every count is from `com.bawassistant.Corpus` over the same three applications
as the other packs: **3,911 code surfaces** and **1,719 artifact models**.

| Rule | Kind | Hits | Surfaces / models |
|---|---|---|---|
| `HOUSE.PERF.THREAD_SLEEP` | buffer | 2 | 2 surfaces |
| `HOUSE.CODE.SCRIPT_VERY_LONG` | buffer | 18 | 18 surfaces |
| `HOUSE.SEC.SQL_INJECTION` | buffer | 94 | 73 surfaces |
| `HOUSE.MIG.LIVE_CONNECT` | buffer | 103 | 74 surfaces |
| `HOUSE.CODE.SCRIPT_TOO_LONG` | buffer | 137 | 137 surfaces |
| `HOUSE.FLOW.UNCONNECTED_STEP` | artifact | — | 89 models |
| `HOUSE.NAME.UNTITLED_VARIABLE` | artifact | — | 1 model |

### Read the lines

**`HOUSE.MIG.LIVE_CONNECT`** — every match is a genuine Java call from
JavaScript: `java.util.logging.Logger`, `java.util.Base64`,
`new java.util.Date()`, `Packages.org.apache.log4j`,
`Packages.org.apache.commons.httpclient`, `Packages.com.ibm.json.java.JSONObject`.
No false positive found. This is the most directly useful rule in the batch for
LSEG, because LiveConnect is deprecated on containers: each of these 103 calls
is a migration blocker that currently nothing reports.

**`HOUSE.PERF.THREAD_SLEEP`** — 2 hits, both `Thread.sleep(` inside one human
service's "Task Available or Continue" script. Quiet, specific, correct.

**`HOUSE.NAME.UNTITLED_VARIABLE`** — 1 model, and worth the rule on its own:
the business object `ClaimDeathBenefitValuesAndReasons` has 72 attributes of
which **27 are named `Untitled7` through `Untitled33`**.

**`HOUSE.FLOW.UNCONNECTED_STEP`** — 89 of 1,239 flow models. The 139
unconnected components are mostly script tasks (70), then boundary events (33),
then start and end events (16). See the data-object trap below: without
excluding data objects this rule fires on **85%** of flow models instead of 7%.

**The script-length pair** implements IBM's own two thresholds (100 and 300
lines) and is **mutually exclusive** — a 400-line block raises the CRITICAL
rule only, never both. The corpus median script is 8 lines and p90 is 51, so
137 + 18 = 155 of 3,911 surfaces. The match is a zero-width assertion at the
start of the buffer, so the finding lands on line 1 rather than annotating a
hundred lines of gutter.

### One of these was wrong on its first draft

`HOUSE.SEC.SQL_INJECTION` originally matched any concatenation into `.sql`. Its
top match across the corpus was:

```javascript
stmt.sql = tw.local.sql + '?';
stmt.sql = tw.local.sql + ', ?';
```

That is a developer **building a parameterised query** — appending placeholders
in a loop, the exact thing IBM's advice tells them to do. Flagging it is the
failure mode this project has hit before: a rule that flags the guard the
standard asks for teaches people to switch the linter off.

The condition now requires an **unquoted identifier** after a `+`, so appending
a literal or a `?` stays quiet and only a variable going into the SQL text
fires. 126 hits → 94; 85 surfaces → 73. All three idioms are pinned as quiet
examples so this cannot regress.

---

## Already covered — and two of them were broken

### `HOUSE.FLOW.TOO_MANY_STEPS` was counting data objects as steps

Active **policy**, not a draft. `flowElement[]` mixes activities, events,
gateways, **data objects** and `sequenceFlow` connections. The reader drops
sequence flows — the model map says so — but kept data objects, and the rule
counted them.

| | fires on |
|---|---|
| as shipped | 548 of 1,239 flow models (44%) |
| excluding data objects | **242** of 1,239 (20%) |

The rule now excludes `dataObject` in its own condition, which needed no code
change. There are 6,537 data objects across those models — roughly five per
flow — so a service with six real steps and five data objects was reading as
eleven and tripping a limit of ten.

This also explains the 85% figure above: **all 6,537 data objects report as
unconnected, and none of them reports as connected**, because a data object has
no incoming or outgoing by design.

Related IDA rules: `check-bpd-phantom-steps`, `check-bpd-step-incorrectly-referenced`.

### `HOUSE.SQL.PRODUCT_TABLE` was 89% blind

A **critical** draft that the corpus reported as silent — which our own doctrine
reads as "the corpus contains nothing it looks for". It was not silent for that
reason. The corpus contains 157 references to internal `LSW_` / `BPM_` tables
and the rule found 18 of them.

The pattern required the table name to sit directly against the SQL keyword.
Every real query qualifies the table with a schema:

```sql
from <#=tw.local.db2SchemaQualifier#>.BPM_PRCS_CNTR
"LEFT JOIN " + procdbSchema + ".LSW_TASK lswTask "
```

The pattern now also matches a table name preceded by a dot, which is what a
schema qualifier always ends with. **18 hits → 171, in 84 surfaces.** IBM rates
this CRITICAL in four separate rules, and this is the shape it actually takes.

Related IDA rules: `check-bpd-component-contains-inner-table-in-script`,
`check-service-item-contains-inner-table-in-script`, and their two
data-mapping variants (which we cannot see — mappings are not code surfaces).

### `HOUSE.BO.SHARED` gained IBM's reason

Written a few hours earlier with the honest but weak rationale "what the shared
annotation changes is not verified here". IBM states it: *if a shared business
object is a large object, it can cause database bloat and other runtime
performance issues*, and rates it MAJOR. Severity raised minor → major,
rationale and remediation rewritten, source re-cited to IDA.

### Covered already, no change needed

- `check-too-big-businessobject-used` — we have `HOUSE.BO.TOO_MANY_ATTRIBUTES`.
  **Thresholds differ**: IBM says 50, ours says 20, chosen from the corpus p90
  of 25. 32 objects exceed 20 and 8 exceed 50. A threshold decision, not a bug.
- `check-service-with-too-many-inputvariables` / `-outputvariables` — we have
  `HOUSE.SIG.TOO_MANY_INPUTS` / `_OUTPUTS`. IBM says 15; ours are **stricter**
  at 10, and are already active policy from the customer's own checklist.
- `check-bpd-variables-naming-conversion` for *steps* — `HOUSE.NAME.DEFAULT_STEP_NAME`.
- The four `*-javascript-coding-style` rules — that is what our 54 buffer rules
  are, collectively; there is nothing single to add.
- `check-service-item-contains-infinite-loop`, `check-bpd-contains-infinite-loop`
  — `HOUSE.LOOP.UNBOUNDED` covers the JavaScript half. The BPMN-graph half is
  under "needs a reader addition".

---

## Not adopted, and why

### Needs application-wide scope (41)

Every `check-app-with-too-many-*` (15), `check-app-too-many-toolkit`,
`check-app-with-mismatch-version-toolkits`, `check-toolkit-nested-level`,
`check-app-toolkit-size`, `check-app-unused-service`, and the 14 Migration
rules that ask "does this application contain any X" — heritage coaches,
heritage services, external implementations, KPIs, historical analysis
scenarios, simulation analysis scenarios, milestones, icon settings, ad hoc
start events, BPDs, ICM integration services, deprecated coach views (×2),
deprecated task routing policy — plus `check-inline-web-service-configuration`.

These all count or inventory artifacts **across a whole process application**.
This engine checks one artifact at a time, by design: the panel lints what the
developer has open. They belong to the pre-deployment `.twx` report
(PROJECT.md §8 item 9), which is the piece that sees an application whole, and
`tools/harvest-corpus.js` already produces exactly the inventory they need.
**They are a reason to build that report, not a reason to change this engine.**

### Needs a reader addition (41)

The data is in the payload; `bridge.js` does not read it yet. The largest
groups:

- **Documentation, everywhere** (11 rules): business object and its properties,
  service, BPD, participant, variables, web service and its operations. Our
  readers surface `hasDescription` for coach views and app settings and
  `hasDocumentation` for UCAs, and nothing else. This is the cheapest block to
  unlock — one field per reader — and it would turn 11 IDA rules into 11 JSON
  rules.
- **Lanes and participants** (5): system-lane human services, all-users
  participants, multi-instance loops in a system lane, sequential activities,
  delete-on-completion. Lanes are not read at all.
- **Per-step implementation detail** (12): phantom steps, gateway conditions,
  message events without a UCA, errors not fully implemented, `toString` in
  data mappings, SQL injection in data mappings, scripts on start/end events,
  SOPE after Postpone, exception loops. Steps are read as `{name, type,
  connected}` and nothing more.
- **Unused things** (4): unused variables, duplicated EPVs, duplicated resource
  bundles. These need cross-referencing the variable list against the code, so
  they also need a condition language that can correlate two collections — the
  engine allows one aggregate per rule.
- **Counts inside an artifact** (5): coach views per coach (>500), coaches per
  human service (>5), nested client-side human services (>25), searchable
  fields (>25), auto-tracking. The coach-view reader only walks the **top level**
  of `layout.layoutItem`, so a >500 rule would never fire; it needs to recurse.

### Not applicable (37)

The 19 Case Solution and Case Type rules are IBM Case Manager artifacts —
case types, pages, property views, roles, page layouts. Nothing in this product
reads them and the corpus contains none. `check-coachcontrol-with-no-binding-value`
needs to know which config option is the binding, which is not established.
The remainder are desktop Process Designer inventory questions that are
answered by the migration tooling rather than by a linter.

---

## The threshold table

IBM publishes 27 default thresholds. Where ours differ, ours are stricter and
came from the customer's checklist or from the corpus, so none was changed:

| | IBM | ours |
|---|---|---|
| INPUT_VARIABLE_THRESHOLD | 15 | 10 (active policy) |
| OUTPUT_VARIABLE_THRESHOLD | 15 | 10 (active policy) |
| ATTRIBUTE_THRESHOLD | 50 | 20 (draft) |
| JAVASCRIPT_LINES_MEDIUM_THRESHOLD | 100 | 100 — adopted |
| JAVASCRIPT_LINES_HIGH_THRESHOLD | 300 | 300 — adopted |

The remaining 22 are application-scope counts, and belong with the `.twx`
report.

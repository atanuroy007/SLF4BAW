 ✖ needs the Service-No-Task field named ||||| tag | source |
|---|---|
| `[Stream]` | `ref/Stream - Development Standards.docx` — the internal standards, 2017-09-25. BPM sections only; the Integration Designer (SCA/BPEL/mediation/adapters) and ODM halves are deliberately excluded. |
| `[CL]` | The LSEG review checklist, 91 rows, already carried as 67 prompts + 24 automated rules. |
| `[IDA]` | IBM's IDA checkstyle catalogue, 129 rules — see `ida-checkstyle-2026-08-30.md`. |
| `[IBM]` | IBM published guidance: the *BPM Performance Tuning and Best Practices* Redbooks (SG24-8216, REDP-4784), IBM Docs for BAW 20.x–24.x, and the IBM BPM best-practice index. |
| `[Skill]` | The `baw-coach-view` defect checklist carried with this project. |

| status | meaning |
|---|---|
| **✅** | enforced today by a named rule |
| **◐** | implementable now or with one reader field — a rule could exist |
| **▣** | snapshot-only: needs the whole application or a second moment. Answered by the whole-application review, which reads live artifacts at a container ref - a named snapshot, or the tip of a branch or track. There is no `.twx` export (owner, 2026-08-30). |
| **○** | a judgement; should stay a review prompt |
| **✖** | blocked, with the reason |

---

## A. Process / BPD design

| # | Practice | Source | Status |
|---|---|---|---|
| A1 | Give a process business-level granularity; do not mimic programming-level steps. Push logic without business significance into services. | Stream, IBM | ○ |
| A2 | Keep total components in one process to a workable number. Stream says ≤20 including start and end; our rule flags >10 steps excluding data objects. **Threshold conflict — see §M.** | Stream, CL | ✅ `HOUSE.FLOW.TOO_MANY_STEPS` |
| A3 | A process may have at most **one** system swimlane. It describes what BAW does, not the systems it integrates with. | Stream | ◐ laneCount read; needs lane kind |
| A4 | Use separate swimlanes for human and system activities. | Stream, CL | ◐ laneCount read; needs lane kind |
| A5 | Minimise Service Tasks in the system lane — prefer *Service (No Task)*. Each Service Task persists state and context at the transition. | Stream, IBM | ✖ needs the Service-No-Task field named |
| A6 | Never interleave `JavaScript → Service Task → JavaScript → Service Task`. Merge the scripts, then merge the service tasks. | Stream, IBM | ◐ activityType + ordering now read |
| A7 | Merge consecutive system-lane activities into one wrapping task; each is a new Event Manager task and the transitions are expensive. | Stream, IBM, IDA, CL | ✅ `HOUSE.PROC.SEQUENTIAL_SYSTEM_ACTIVITIES` |
| A8 | If sequential system-lane activities are unavoidable, tick **Optimize Execution for Latency** on the process overview. | Stream, CL | ✅ `HOUSE.PROC.LATENCY_NOT_OPTIMIZED` |
| A9 | Merge sequential sub-processes into one. | Stream, CL | ✅ `HOUSE.PROC.SEQUENTIAL_SUBPROCESSES` |
| A10 | Do not use multi-instance loops for batch or system-lane activities — they generate excessive tokens and run single-threaded. | Stream, IBM, IDA, CL | ◐ needs loopCharacteristics |
| A11 | Avoid sub-processes as the activity of a multi-instance loop unless the first activity is a user task. | Stream, IBM | ◐ |
| A12 | Turn auto-tracking **off** for processes that do not need business metrics; events are persisted by the Performance Data Warehouse. | Stream, IBM, IDA, CL | ✅ `HOUSE.PROC.AUTO_TRACKING_ON` |
| A13 | Disable at-risk calculation when it is not required. | CL | ✅ `HOUSE.PROC.AT_RISK_ON` |
| A14 | Avoid processes that run perpetually. If polling is genuinely needed, use a UCA rather than a looping BPD. | Stream, IBM | ○ |
| A15 | Use conditional joins only when necessary — the engine must evaluate every upstream path. | Stream, IBM | ◐ |
| A16 | Mark system-lane tasks **Delete on Completion** when you create them; completed tasks bloat the database and slow instance migration. | Stream, IBM, IDA, CL | ✅ `HOUSE.PROC.SYSTEM_TASK_NOT_DELETED` |
| A17 | Emit Common Base Events only where they have business relevance; event emission is persistent and costly. | Stream, IBM | ○ |
| A18 | Limit searchable business variables. Stream/IBM say rarely more than 10; IDA enforces 25. **Threshold conflict — see §M.** | Stream, IBM, IDA | ✅ `HOUSE.PROC.TOO_MANY_SEARCHABLE` |
| A19 | Do not route an activity's error handler back to the same activity — the server thrashes between BPD and service engine. | Stream, IBM | ◐ needs graph |
| A20 | Every gateway must have complete, implemented conditions. | IDA | ◐ needs gateway config |
| A21 | Label sequence lines leaving a gateway. | CL, Stream | ◐ reader drops sequence flows |
| A22 | Every message event must have a UCA attached. | IDA | ◐ |
| A23 | Every activity must have an implementation — no phantom steps. | IDA | ◐ |
| A24 | Remove unconnected components; a step with no incoming or outgoing never runs. **Processes are exempt** — they may legitimately carry disconnected activities. | CL, IDA | ✅ `HOUSE.FLOW.UNCONNECTED_STEP` |
| A25 | Detect and remove potential infinite loops. | IDA | ◐ needs graph |
| A26 | Every declared Error needs an error code and mapping, or it throws its own exception instead of being handled. | IDA | ◐ |
| A27 | No script on start or end events; move it into a component of its own. | IDA | ◐ |
| A28 | Avoid pre and post assignment scripts on activities — they run but are invisible on the diagram. | Stream, CL, IDA | ✅ `HOUSE.CODE.ASSIGNMENT_SCRIPT` |
| A29 | Limit an activity's input and output variables to **15** — settled 2026-08-30. Stream's stricter 5 is carried separately as an advisory draft. | Stream, CL, IDA | ✅ `HOUSE.SIG.TOO_MANY_*` |
| A30 | Remove unnecessary KPIs from activities. | Stream | ✖ not read |
| A31 | Never assign a lane participant to "all users" / `tw_allusers` — with a large LDAP the runtime populates the whole registry. | IDA | ◐ lanesWithoutParticipant now read |
| A32 | Keep a Team Filter Service simple and short — it runs on every task assignment. | CL | ◐ partly: `HOUSE.CODE.SCRIPT_TOO_LONG` |
| A33 | Keep the diagram readable: align sequence lines, do not let them cross or overlap. | Stream, CL | ○ |
| A34 | Provide an activity **subject** and **narrative** — they are what the business user sees in Process Portal. | IDA | ◐ |
| A35 | The terminate end event's *Delete all terminated instance runtime data* causes frequent purges that can deadlock the index tables. Upgrade to 23.0.1+ and patch. | IDA | ◐ |

## B. Service flows and integration

| # | Practice | Source | Status |
|---|---|---|---|
| B1 | Prefer synchronous invocation within a module; reserve asynchronous for module edges. | Stream, IBM | ○ |
| B2 | Pass only the variables a service needs — invocation is by value, so every business object is copied. | Stream, IBM | ◐ |
| B3 | Enable caching on services that retrieve static data. A service with no inputs is the obvious candidate. | CL | ✅ `HOUSE.PERF.CACHEABLE_SERVICE` |
| B4 | Never access internal BAW tables (`LSW_*`, `BPM_*`) with SQL; use the published JavaScript and REST APIs. | Stream, IBM, IDA, CL | ✅ `HOUSE.SQL.PRODUCT_TABLE` |
| B5 | Build SQL with `SQLStatement.parameters`, never by concatenating variables into `.sql`. | IDA | ✅ `HOUSE.SEC.SQL_INJECTION` |
| B6 | Use efficient SQL; avoid `SELECT *` and unindexed predicates. | IBM | ○ |
| B7 | Deal with faults from external services deliberately — never swallow them. | IBM, Stream | ✅ `HOUSE.CODE.EMPTY_CATCH` |
| B8 | Avoid global error handling in a service; it burns CPU and can loop forever in coaches. | Stream, IBM | ◐ |
| B9 | Never let a Stay-on-Page event directly follow a Postpone. | IDA | ◐ |
| B10 | Remove unconnected items from services. | CL, IDA | ✅ `HOUSE.FLOW.UNCONNECTED_STEP` |
| B11 | Every service should be reachable — used by another artifact or exposed. Delete the rest. | IDA | ▣ |
| B12 | Handle every end event of a nested service in the caller: a service with three ends needs three outgoing lines where it is used. | CL | ▣ |
| B13 | Keep a local, flattened copy of a WSDL. Remote retrieval and deeply nested imports dominate web-service latency. | Stream, IBM | ○ |
| B14 | Confirm a web-service integration is configured on the server tab, not inline — inline configuration is lost on conversion. | IDA | ◐ |
| B15 | Give an exposed service a response carrying status, status code and detail. | CL | ◐ needs two aggregates |
| B16 | Do not expose a human service as a URL without confirming the caller is authorised. | IDA | ✅ `HOUSE.FLOW.EXPOSED_TO_URL` |
| B17 | Never sleep a request thread (`Thread.sleep`); model the wait instead. | IDA | ✅ `HOUSE.PERF.THREAD_SLEEP` |
| B18 | Avoid `toString()` on a potentially large variable in a data mapping. | IDA | ✖ mappings not read |
| B19 | Do not use BAW as a system of record. | IBM | ○ |
| B20 | Use the facade pattern for Advanced Integration Services. | IBM | ○ |
| B21 | Use the sync-over-async invocation pattern with caution. | IBM | ○ |

## C. Human services (client-side)

| # | Practice | Source | Status |
|---|---|---|---|
| C1 | **One coach per service.** Many coaches in one service tangle navigation, initialisation and validation. | Stream, CL | ✅ `HOUSE.UI.COACH_PER_SERVICE` |
| C2 | Limit diagram components in a human service to 10. | Stream | ✅ `HOUSE.FLOW.TOO_MANY_STEPS` |
| C3 | Prefer client-side human services: they offload the server, allow client-side validation and cut round trips. | Stream, IBM | ○ |
| C4 | Do not nest client-side human services deeply; IDA flags more than 25 in one CSHS. | IDA | ◐ |
| C5 | Always wire a coach to an end node. | Stream, IBM, IDA | ✅ `HOUSE.FLOW.UNCONNECTED_STEP` |
| C6 | Clear variables in an exposed human service that is not intended to reach an endpoint — otherwise memory is held until the EJB timeout (two hours). | Stream, IBM, CL | ◐ |
| C7 | Never copy and paste a fragment between services; extract it and reuse it. | Stream | ○ |
| C8 | Do not cross sequence lines — crossings signal complexity worth breaking up. | Stream, CL | ○ |
| C9 | Use common styling across all human services. | Stream, CL | ▣ |
| C10 | Use publish/subscribe events carefully for inter-coach-view communication. | Stream | ○ |
| C11 | Prefer the out-of-the-box atomic coach view components over hand-written ones. | Stream, CL | ▣ |
| C12 | Perform create/read/update/delete against systems of record **before or after** the coach, not by Ajax during it. | Stream, IBM | ○ |
| C13 | Use a setup script step to preload data rather than an Ajax call on load — browsers cap concurrent connections. | Stream | ◐ |
| C14 | Beware button indirection: keep a 1:1 correspondence between a coach's buttons and the boundary events leaving the coach. | Stream | ○ |

## D. Coach views

| # | Practice | Source | Status |
|---|---|---|---|
| D1 | Never name a coach view after a JavaScript or framework reserved word — the name becomes an identifier in generated code. | Stream, CL | ✅ `HOUSE.VIEW.RESERVED_NAME` |
| D2 | Avoid deeply nested coach views — they cost both render time and comprehensibility. | Stream, IBM, CL | ◐ needs recursion |
| D3 | Keep a coach's total view count sane; IDA flags more than 500. | IDA | ◐ needs recursion |
| D4 | Limit configuration options to 10 per view. | Stream | ✖ options absent from payload |
| D5 | Group configuration options by technical/functional significance, label them, and document each. | Stream, CL | ✖ options absent from payload |
| D6 | Bind a business object built **for the view** — not the large process-level object; bound objects are persisted on every boundary event. | Stream, IBM | ○ |
| D7 | Fire boundary events sparingly: each one commits data from browser to server. | Stream, IBM, CL | ✅ `HOUSE.VIEW.BOUNDARY_EVENT_UNDOCUMENTED` (partial) |
| D8 | Avoid unnecessary change events — compare before setting, and do not set a value equal to the old one. | Stream, CL | ○ |
| D9 | Tick **Prototype-level event handlers** on frequently reused views to keep handlers off every instance. | Stream, CL | ◐ |
| D10 | Do not use `change()` as a `bind()`/`bindAll()` callback; use a separate function, and rebind when the base object changes. | Stream, CL | ◐ buffer rule |
| D11 | In `change()`, distinguish a config change from a binding change with `event.type == "config"` and `event.property`. | Stream, Skill | ◐ buffer rule |
| D12 | Destroy DOM nodes the view created, in `unload()` — `destroyRecursive()` then delete the reference. | Stream, CL, Skill | ◐ needs two surfaces |
| D13 | Disconnect every event handler in `unload()`; track handles when you create them. | Stream, Skill | ◐ |
| D14 | Track every timer and interval and clear them in `unload()` and before any full re-render. | Skill | ✅ `HOUSE.LIFE.UNTRACKED_*` |
| D15 | Use `load`, `view`, `change`, `unload` and `validate` for what each is for. | Stream, Skill | ○ |
| D16 | Declare AMD dependencies properly rather than calling `require()` inline. | Stream | ✅ `HOUSE.UI.NON_AMD_LOAD` |
| D17 | Declare functions and objects on the coach view object (`this`), never on `window`. | Stream, CL | ✅ `HOUSE.UI.WINDOW_BINDING` |
| D18 | Put reusable functions in the Inline JavaScript block; call them from the handlers. | Stream, CL | ◐ surfaces[] |
| D19 | Limit global coach-view variables. | Stream | ✅ `HOUSE.UI.WINDOW_BINDING` |
| D20 | Never build a class name from data — dojo splits on whitespace, so data controls arbitrary classes. | Skill | ✅ `HOUSE.UI.CLASS_FROM_DATA` |
| D21 | Never build an attribute selector from an id — a quote in the value throws. | Skill | ✅ `HOUSE.UI.SELECTOR_FROM_DATA` |
| D22 | Never set `innerHTML` from process data; use `textContent` and built nodes. | Skill, CL | ✅ `HOUSE.SEC.INNERHTML_CONCAT` |
| D23 | Do not use cross-site scripting patterns. | Stream | ✅ `HOUSE.SEC.INNERHTML_CONCAT` |
| D24 | Scope DOM lookups to the view; never `document.getElementById` a global id — view instances are not unique. | Skill | ✅ `HOUSE.UI.GLOBAL_DOM_LOOKUP` |
| D25 | Read every configuration option you declare. A declared, defaulted, documented but unused option is a bug. | Skill | ✖ options absent |
| D26 | Mutating APIs return a boolean; a silent `return` leaves the caller unable to tell the call was ignored. | Skill | ○ |
| D27 | Handle and log exceptions to the console. | Stream, CL | ✅ `HOUSE.CODE.EMPTY_CATCH` |
| D28 | Leave no `debugger` statements or breakpoints. | Stream | ✅ `HOUSE.CODE.DEBUGGER` |
| D29 | Check browser compatibility for custom CSS. | Stream, CL | ○ |
| D30 | Tag coach views properly so they can be found. | Stream, CL | ◐ tags not read |
| D31 | Use a deferred Section where it applies, and async loading for tables. | CL | ◐ |
| D32 | Avoid inline style manipulation; use classes. | CL | ✅ `HOUSE.UI.INLINE_STYLE` |
| D33 | Never block the UI thread with `alert`, `confirm` or `prompt`. | Skill | ✅ `HOUSE.UI.BLOCKING_DIALOG` |
| D34 | Divide the labour: atomic views by programmers, composite views by business SMEs. | Stream, IBM | ○ |
| D35 | Meet the accessibility bar — labels, roles, keyboard reachability, focus management. | Skill | ○ |

## E. Data — business objects, variables, EPVs

| # | Practice | Source | Status |
|---|---|---|---|
| E1 | Minimise the **number** of variables; every one is persisted at each context save. | Stream, IBM, CL | ✅ `HOUSE.SIG.TOO_MANY_*` |
| E2 | Minimise the **size** of each variable; avoid carrying large objects through a process. | Stream, IBM | ◐ |
| E3 | Null out large variables — DB result sets especially — as soon as they are finished with. | Stream, IBM | ◐ buffer rule |
| E4 | Delete unused variables before leaving a component. | CL | ◐ needs two aggregates |
| E5 | Keep a business object narrow; IDA flags more than 50 attributes, our draft flags 20. **Threshold conflict — see §M.** | Stream, IDA | ✅ `HOUSE.BO.TOO_MANY_ATTRIBUTES` |
| E6 | A business object should carry only what the process actually needs. | IDA, IBM | ○ |
| E7 | Do not mark a business object **shared** unless you mean it — a large shared object causes database bloat. | IDA | ✅ `HOUSE.BO.SHARED` |
| E8 | Keep repeated attributes in a list object rather than `field1, field2, field3`. | CL | ◐ needs row-vs-row |
| E9 | Document the business object and each of its properties. | IDA | ◐ one reader field |
| E10 | An EPV should carry no more than 30 variables. **Conflicts with the checklist's own 40–50 — see §M.** | CL | ✅ `HOUSE.EPV.TOO_MANY_FIELDS` |
| E11 | Expose every EPV to the team that owns its values, or nobody can change them at runtime. | CL | ✅ `HOUSE.EPV.NO_TEAM` |
| E12 | Keep an EPV value within 255 characters. | CL | ✅ `HOUSE.EPV.VALUE_TOO_LONG` |
| E13 | Do not duplicate EPVs within a process or service. | IDA | ◐ |
| E14 | Do not duplicate resource bundles within a service. | IDA | ◐ |
| E15 | Give input variables no defaults — a default hides a missing binding. | CL | ✅ `HOUSE.SIG.INPUT_HAS_DEFAULT` |
| E16 | Never leave a variable named `Untitled`. | IDA, CL | ✅ `HOUSE.NAME.UNTITLED_VARIABLE` |
| E17 | Do not change, rename or delete an **exposed** variable once instances exist — it breaks in-flight migration. | Stream, CL | ▣ two moments |
| E18 | Prefix exposed variables with the process app acronym. | CL | ✅ `HOUSE.NAME.EXPOSED_VARIABLE_PREFIX` |
| E19 | Store configuration in EPVs or environment variables, never hard-coded in scripts. | Stream, Own | ✅ `HOUSE.CFG.HARDCODED_*` |
| E20 | Never write to `tw.epv.*` at run time — an EPV is configuration, not state. | Own | ✅ `HOUSE.REL.EPV_WRITE` |
| E21 | Never write to `tw.system.*` (the documented `coachValidation` case excepted). | Own | ✅ `HOUSE.REL.SYSTEM_WRITE` |

## F. JavaScript and scripting

| # | Practice | Source | Status |
|---|---|---|---|
| F1 | Keep a script block under **100** lines, with **300** critical — settled 2026-08-30, following IBM and IDA over Stream's stricter 50. | Stream, IBM, IDA | ✅ `HOUSE.CODE.SCRIPT_TOO_LONG` / `_VERY_LONG` |
| F2 | Avoid excessive server-side JavaScript; it is interpreted and slower than compiled alternatives. | IBM, Stream | ✅ (the two above) |
| F3 | Do not call Java from JavaScript (LiveConnect, `Packages.*`, `java.*`) — deprecated on containers. | IDA | ✅ `HOUSE.MIG.LIVE_CONNECT` |
| F4 | Indent four spaces; do not use tabs. | Stream | ○ |
| F5 | Keep lines under 80 characters; break after an operator and indent the continuation. | Stream | ◐ |
| F6 | Be generous with comments, keep them current, and comment *why* rather than *what*. | Stream, CL | ✅ `HOUSE.CODE.NO_COMMENTS` |
| F7 | Declare all functions before use; inner functions follow the `var` statement. | Stream | ○ |
| F8 | Minimise global functions and variables. | Stream | ✅ `HOUSE.UI.WINDOW_BINDING` |
| F9 | Wrap an immediately-invoked function expression in parentheses. | Stream | ○ |
| F10 | Use `===` / `!==`. The `!= null` idiom that catches null and undefined together is the deliberate exception. | Own, IDA | ✅ `HOUSE.CODE.LOOSE_EQUALITY` (draft) |
| F11 | Always pass a radix to `parseInt`. | Own | ✅ `HOUSE.CODE.PARSEINT_RADIX` |
| F12 | Never compare against `NaN`; use `isNaN`. | Own | ✅ `HOUSE.CODE.NAN_COMPARE` |
| F13 | Never assign inside a condition. | Own | ✅ `HOUSE.CODE.ASSIGN_IN_CONDITION` |
| F14 | Never `eval` or `with`. | Own | ✅ `HOUSE.CODE.DANGEROUS_EVAL` |
| F15 | Guard `JSON.parse` — malformed input throws. | Own | ✅ `HOUSE.REL.JSON_PARSE_UNGUARDED` |
| F16 | Guard `tw.local` chains before dereferencing; absence is normal, not exceptional. | CL, Own | ✅ `HOUSE.NULL.TW_LOCAL_CHAIN` |
| F17 | Check `listLength` before indexing a list; never assume `[0]` exists on a read. | Own | ✅ `HOUSE.NULL.LIST_INDEX` |
| F18 | Do not build unbounded loops (`while(true)`, `for(;;)`) without an exit. | IDA, Own | ✅ `HOUSE.LOOP.UNBOUNDED` |
| F19 | Do not use `<=` against `listLength` — off by one. | Own | ✅ `HOUSE.LOOP.OFF_BY_ONE` |
| F20 | Do not call `tw.system.*` services or read EPVs inside a loop. | Own | ✅ `HOUSE.PERF.*_IN_LOOP` |
| F21 | Do not concatenate strings in a loop; build an array and join. | Own | ✅ `HOUSE.PERF.CONCAT_IN_LOOP` |
| F22 | Never make a synchronous XHR. | Own | ✅ `HOUSE.SEC.SYNC_XHR` |
| F23 | Do not assign a redirect target from process data. | Own | ✅ `HOUSE.SEC.OPEN_REDIRECT` |
| F24 | Never log credentials, tokens or personal data. | Own | ✅ `HOUSE.SEC.LOG_SENSITIVE` |
| F25 | Never hard-code credentials. | Own, Stream | ✅ `HOUSE.SEC.HARDCODED_CREDENTIALS` |
| F26 | Remove commented-out code and stale work markers before promotion. | Own | ✅ `HOUSE.CODE.COMMENTED_CODE`, `WORK_MARKER` |
| F27 | Keep the code free of the Designer validator's own errors and warnings. | CL | ✅ IBM's validator is harvested into the panel |

## G. Naming and documentation

| # | Practice | Source | Status |
|---|---|---|---|
| G1 | Business object: PascalCase, letters and numbers only, as few words as possible; `Request`/`Response` postfix for I/O objects. | Stream | ◐ |
| G2 | Business object attributes and flow variables: lowerCamelCase. | Stream, CL | ✅ `HOUSE.BO.ATTRIBUTE_CONVENTION`, `HOUSE.NAME.VARIABLE_CONVENTION` |
| G3 | JavaScript variables: short, logical, lowerCamelCase; no `variable1`, `asd123`. | Stream | ✅ (G2's rules) |
| G4 | Constants in UPPER_SNAKE_CASE; constructor functions capitalised; private members prefixed `_`. | Stream | ◐ |
| G5 | Process names describe the action performed, capitalised. | Stream | ◐ |
| G6 | Coach view name: business object name + `View`. | Stream | ◐ |
| G7 | Human service: verb phrase, spaces between words, capitalised. | Stream | ◐ |
| G8 | Postfix by artifact kind: `TS`, `CS`, `IS`, `GS`, `ES`, `UCA`, `WS`, `AIS`, `DS`, `EPV`. | Stream | ◐ |
| G9 | Toolkit names carry a `Toolkit` suffix; acronym ≤7 characters and unique per instance. | Stream | ▣ |
| G10 | Names under 64 characters; no abbreviations beyond the acronym. | Stream | ◐ |
| G11 | Lanes named for the role; tasks named with verbs; gateways phrased as questions. | Stream | ◐ needs lanes |
| G12 | Coaches include the word `Coach`; logging artifacts include `Log`. | Stream | ◐ |
| G13 | A UCA used as a BPD event includes `Event`; its implementing service is named `Implement <UCA name>`. | Stream | ◐ |
| G14 | Variable naming by scope: `BPD<Activity>Request/Response`, `<Activity>Request/Response`, `BPD<name>` for private. | Stream | ◐ |
| G15 | Snapshots use semantic versioning; tracks are named for the feature and end in `Track`. | Stream | ▣ |
| G16 | Document every artifact and every component; keep the documentation current through changes. | Stream, CL, IDA | ◐ one reader field, ×11 rules |
| G17 | Give every activity a subject and narrative for Process Portal. | IDA | ◐ |
| G18 | Never leave a default step name (`Untitled`, `Script task 1`). | CL | ✅ `HOUSE.NAME.DEFAULT_STEP_NAME` |

## H. UCAs and events

| # | Practice | Source | Status |
|---|---|---|---|
| H1 | Design a UCA with exactly two parameters: one correlation, one `Map` for business data — it removes future mapping changes and migration risk. | Stream, CL | ◐ needs UCA parameters |
| H2 | A UCA should never exceed 5 parameters. | CL | ◐ needs UCA parameters |
| H3 | A UCA must declare an implementation; one wired to nothing fails silently. | CL | ✅ `HOUSE.UCA.NO_IMPLEMENTATION` |
| H4 | A disabled UCA is dead configuration that still reads as live. | CL | ✅ `HOUSE.UCA.DISABLED` |
| H5 | Name a UCA's attached service the same as the UCA. | Stream | ▣ |
| H6 | Avoid timer-based UCA implementations. | Stream | ◐ |
| H7 | Avoid synchronous queues for UCAs. | Stream | ◐ |
| H8 | Handle trigger time deliberately for repeating timers. | CL | ○ |
| H9 | Use durable subscription and consume-message options deliberately. | CL | ○ |

## I. Toolkits, versioning and governance

| # | Practice | Source | Status |
|---|---|---|---|
| I1 | Avoid deep toolkit nesting; IDA flags more than 4 levels. | Stream, IDA | ▣ |
| I2 | Keep the toolkit count per application down; IDA flags more than 25. | IDA | ▣ |
| I3 | Keep a toolkit under 50 MB. | IDA | ▣ |
| I4 | Never create mutually dependent toolkits. | IBM | ▣ |
| I5 | All toolkit dependencies must be on matching versions. | IDA | ▣ |
| I6 | Organise toolkits by logical domain rather than one large toolkit. | IDA | ○ |
| I7 | Keep per-type artifact counts within bounds (services 25–50, BPDs 15, business objects 50, reports 15, SLAs 15…). Use smart folders. | IDA | ▣ ×15 rules |
| I8 | Delete unused artifacts — services, pages, properties, rules, views. | IDA | ▣ |
| I9 | Use a governance process for snapshot installation. | IBM | ○ |
| I10 | Plan release-to-release migration and the rolling-upgrade path. | IBM | ○ |

## J. Migration and deprecation (container readiness)

| # | Practice | Source | Status |
|---|---|---|---|
| J1 | Replace LiveConnect Java calls with plain JavaScript. | IDA | ✅ `HOUSE.MIG.LIVE_CONNECT` |
| J2 | Convert BPDs to processes; desktop-authored BPDs are unsupported on containers. | IDA | ▣ |
| J3 | Re-implement Heritage Coaches with the BPM UI toolkit. | IDA | ▣ |
| J4 | Convert heritage services and external implementations. | IDA | ▣ |
| J5 | Replace ad hoc start events with ad hoc activities implemented as sub-processes. | IDA | ▣ |
| J6 | Replace deprecated assignment types — Last User in Lane, Routing Policy, List of Users — with a team filter or retrieval service. | IDA | ▣ |
| J7 | Convert deprecated coach views to UI views. | IDA | ▣ |
| J8 | Milestones, icon settings, simulation configurations, KPIs and historical analysis scenarios have no equivalent and are dropped on conversion. | IDA | ▣ |
| J9 | Provide backward compatibility for in-flight instances whenever a process changes; plan for orphan tokens. | Stream, CL | ▣ two moments |

## K. Runtime, operations and security

| # | Practice | Source | Status |
|---|---|---|---|
| K1 | Put configuration in `100Custom.xml`, never edited into product files. | IBM | ○ |
| K2 | Purge data regularly; use an offline process server for production. | IBM | ○ |
| K3 | Back up regularly and plan disaster recovery. | IBM | ○ |
| K4 | Tune the Process Center — every Designer user depends on it — and keep Designer close to it on the network. | Stream, IBM | ○ |
| K5 | Use query tables / composite query tables for high-volume task and process list queries. | IBM | ○ |
| K6 | Secure the environment; map security roles to real groups rather than "all authenticated". | IBM, Own | ○ *(this product's own outstanding item)* |
| K7 | Monitor the Process Federation Server Elasticsearch service. | IBM | ○ |
| K8 | Plan and perform non-functional testing before go-live. | IBM | ○ |
| K9 | Ensure every business process has a named business owner. | IBM | ○ |
| K10 | Use the JavaScript loop detector and process monitor to check BPMN health. | IBM | ○ |

---

## L. Where this product stands

| | count | |
|---|---|---|
| practices catalogued | **209** | across 11 sections |
| **✅ enforced today** | **69** | by 79 automated rules |
| **◐ implementable** | 68 | mostly one reader field away |
| **○ judgement** | 42 | should stay a review prompt |
| **▣ snapshot-only** | 24 | needs the `.twx` report |
| **✖ blocked** | 6 | the data does not reach us |

Counted from the tables rather than by hand — `grep -c '^| [A-K][0-9]'`.
Section sizes: A 35, B 21, C 14, D 35, E 21, F 27, G 18, H 9, I 10, J 9, K 10.

**A third of the catalogue is already enforced.** 69 of 209 practices, drawn
from five independent authorities, are checked automatically today, and 68
more are within reach of the model the readers already produce.

The largest single unlock remains **documentation fields on the readers** (G16
alone is 11 IDA rules plus checklist rows), followed by **lanes**, which gate
nine practices in section A on their own.

## M. Threshold conflicts to settle

Five limits are stated differently by different authorities. Ours are noted so
a decision can be made once rather than argued per rule.

| Limit | Stream | IBM/IDA | Checklist | **Ours** | settled? |
|---|---|---|---|---|---|
| Script block lines | 50 | 100 / 300 | — | **100 / 300** | ✔ 2026-08-30 — IBM/IDA over Stream |
| Activity input / output variables | 5 | 15 | 15 | **15** | ✔ 2026-08-30 — was 10 |
| Business object attributes | — | 50 | — | **20** (draft) | open |
| Components in one process | 20 | — | — | **10 steps** (active policy) | open |
| Searchable business variables | 10 | 25 | — | not read | open |
| EPV variables | — | — | **30 *and* 40–50** | **30** | open — the workbook contradicts itself |

**Settled 2026-08-30.** Script blocks stay at 100/300: IBM and IDA agree on
those figures and the corpus supports them (median script 8 lines, p90 51).
Input and output variables move from 10 to **15**, which is what both the
checklist and IBM's own IDA threshold say. Measured effect across the 1,239
flow models: inputs 11 → **4**, outputs 13 → **2**. Stream's stricter figure
of 5 is not lost — it is carried as `HOUSE.SIG.PREFER_FIVE_INPUTS`, an
advisory draft that fires on 99 models and stays subordinate in the panel.

The EPV row is a contradiction inside the customer's own workbook: UCA!B7 and
Variables & EPVs!B10 say 30, Variables & EPVs!B7 says 40–50. We implement 30,
the stricter figure two rows agree on.

---

## Sources

- `ref/Stream - Development Standards.docx` (internal, 2017-09-25) — BPM sections only.
- [IBM Business Process Manager V8.5 Performance Tuning and Best Practices (SG24-8216)](https://www.redbooks.ibm.com/redbooks/pdfs/sg248216.pdf)
- [IBM Business Process Manager V7.5 Performance Tuning and Best Practices (REDP-4784)](https://redbooks.ibm.com/abstracts/redp4784.html)
- [IBM Docs — Building process applications](https://www.ibm.com/docs/en/SS8JB4_24.x/com.ibm.wbpm.wle.editor.doc/topics/proccessapp_highlevel_roadmap.html)
- [IBM Docs — Building a client-side human service](https://www.ibm.com/docs/en/baw/20.x?topic=services-building-client-side-human-service)
- [IBM developer recipe — designing maintainable IBM BPM / BAW client-side human services](https://developer.ibm.com/recipes/tutorials/designing-ibm-bpm-ibm-baw-client-side-human-services/)
- [IDA checkstyle rules description](https://sdc-china.github.io/IDA-doc/checkstyle/checkstyle-checkstyle-rules-description.html)
- The LSEG review checklist workbook, and the `baw-coach-view` skill carried with this project.

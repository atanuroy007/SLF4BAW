# The whole-application review, and what building it found

Written 2026-08-30 to 08-31, as Phase 8 of `IMPLEMENTATION-PLAN.md` was built,
deployed and verified live.

The feature itself is described in `PROJECT.md` §8 item 9. This note is the
**evidence**: the numbers it produces, how they were checked, and the five
defects that only appeared because something finally read a whole application
and drew the result.

---

## What it reports, measured

Test PA (`2063.54dfabb5-c3d4-43aa-8e8a-5f64b0437fd0`), the shape reference:

| | |
|---|---|
| artifacts swept | 218 read, 40 the readers do not recognise |
| code surfaces | 138 |
| characters of code | 99,616 |
| automated rules run | 108 |
| findings | ~500, in ~50 rules |
| duplicated blocks | 2 blocks, 3 redundant copies |
| checklist questions for a person | 66 |
| wall clock, in a browser | **12 seconds** |

Twelve seconds matters: the page warns that a large application "takes a few
minutes", written before it had ever been run. It is wrong and deliberately
left conservative until a 957-artifact application has been measured.

*Sample Process With All* raises exactly **16 findings**, the number recorded
in PROJECT.md §10 before this feature existed. That is the single best
end-to-end signal that the sweep, the batching and the rule set all behave.

## How the totals were checked

**Two independent paths to the same number**, because a page agreeing with
itself proves nothing:

1. the review's own client path against the deployed `/api/review`;
2. `com.bawassistant.Corpus` over a harvest of the same ref.

They agree exactly on artifact findings (369), on findings naming a subject
(105), and on characters (92,086 at the time of that run). They disagree on
**surface count** — 113 live against 118 harvested — and that is not an error:
the harvest writes a file per surface including five that carry no code, and
the endpoint skips an empty surface. Identical character counts are what say
so.

**Buffer findings vary by one or two between runs.** That is
`BufferLinter`'s time budget, and it is the subject of finding 5 below.

---

## Five defects, none of which any earlier test could have found

### 1. The review sent the listing name instead of the editor type

A model carries both `type` — the asset listing's display name, "Integration
Service", "Human Service", "BPD" — and `editorType`, what the payload says it
is. Every rule's `appliesTo` is written in the editor vocabulary, so sending
`type` matches **nothing, in silence**.

First live run: **313 artifact findings where the same sweep judged headlessly
reported 370**, with 9 heritage services, 4 BPDs and 11 assorted services filed
under types no rule has ever heard of. `harvest-corpus.js` carries a comment
about hitting this exact trap first; this was the same bug in the second
caller.

### 2. Process rules were being applied to service flows

Reported by the owner. Two independent causes, either of which would have
hidden the other:

- **The classifier.** `derivedEditorType` called a flow a `CaseProcess` only
  when the payload carried a `globalUserTask` root. That is an *inline* user
  task, so any process without one was typed `SERVICEFLOW`: **all 4 BPDs and
  10 of the 24 case processes** in Test PA. A process is marked by
  `extensionElements.bpdExtension`, which is where `atRiskCalcEnabled`,
  `autoTrackingEnabled` and `optimizeExecForLatency` live.
- **The scope.** 14 `HOUSE.PROC.*` rules listed `SERVICEFLOW` and `COACHFLOW`,
  and 6 artifact rules had an empty `appliesTo`, which applies them to every
  type.

The classifier had to be fixed **first**. Tightening the scope alone would
have looked like a fix while silently switching every process rule off for the
14 misclassified processes.

Measured before → after, on 218 artifacts:

| rule | before | after | |
|---|---|---|---|
| `ACTIVITY_NO_SUBJECT` | 140 | 27 | 67 coach flows and 60 service flows have no Portal task subject |
| `MIXED_LANE` | 14 | 6 | a service flow **has** a `laneSet`, so lanes never discriminated |
| `AT_RISK_ON` | 27 | 27 | right rule, wrong type — all 27 were processes, 14 mislabelled |

**121 false positives removed from one application.**

*Why it escaped:* `RuleVerifier` treated an example whose type was out of
scope as a **broken** example, so a quiet example could not say "this rule does
not apply to that type" — the most useful thing a quiet example can pin.
Nothing in the build could hold a rule's scope. It can now, and each rescoped
rule carries one.

### 3. The corpus tool could not resolve lane teams

`harvest-corpus.js` called `parseAsset` directly, but only `readModel` awaits
`ensureAcronym` and `ensureTeams` first — and the team behind a lane is what
makes it the *system* lane.

Every process ever harvested carried `systemLaneCount: 0`, and with it
`maxSequentialSystemActivities: 0`, `systemTasksNotDeletedOnCompletion: 0`, an
understated `maxScriptSystemAlternation`, and an **over**-stated `mixedLanes`.
**All 28 processes in Test PA differed.** Five rules measured as silent on a
corpus when they were merely unmeasurable — the same failure as
`SQL.PRODUCT_TABLE`, arriving through the tooling rather than the pattern.

The tool now reads through `readModel`, so it and the page use one path rather
than two that can drift — the property the tool was written to protect.

> **Anything measured from a harvest before 2026-08-30 understates
> lane-dependent rules.** The counts in `guided-rules-2026-08-30.md` were taken
> another way and are non-zero, so they are unaffected.

### 4. Almost none of a coach's code was being read

Reported by the owner, from the Designer: the panel showed "This script —
none" beside a 36-line event handler, and a `debugger` two lines into another
handler went unreported.

A coach carries **two kinds** of event handler, and they are not the same
thing:

| | where | standard |
|---|---|---|
| **lifecycle** | `header.loadJSFunction`, `viewJSFunction`, `unloadJSFunction`, … | the bpmext contract. Implementation belongs here; length is normal |
| **inline** | a layout item's `configData`, `eventON_CHANGE` and friends | should call a function. Where the implementation lives is free |

The reader saw only `loadJSFunction` and `unloadJSFunction`, so
`viewJSFunction` was missed outright and **every inline handler was
invisible**. Measured on Test PA: **16 inline handlers holding 4,214
characters**, three of them 36 to 41 lines. Harvesting the same application
went from 118 code surfaces to 138.

Two traps found on the way:

- `optionName` beginning with `event` is not enough. `eventName` and
  `eventValue` are ordinary options carrying strings and both appear in the
  corpus. The test is `/^event[A-Z][A-Z0-9_]*$/`.
- a CSHS keeps its coaches' layouts at `…userTaskImplementation[0]
  .flowElement[n].formDefinition.coachDefinition.layout` — the same shape a
  coach view uses, and `layoutItem` nests.

**New rule, `HOUSE.UI.INLINE_EVENT_HANDLER_LONG`** (draft, minor, checklist
`UI!B35`). Of **20 inline handlers across four applications, 17 are 3 lines or
fewer and 3 are 36 to 41** — the estate already follows the standard almost
everywhere, and the exceptions are whole implementations. The limit of 5 lines
sits in the gap between the two populations rather than being chosen.

It fires on exactly the two artifacts the owner photographed, naming the
events: `ON_CHANGE, ON_BEFORE_SHOW_DAY, ON_LOAD` on the coach view, and
`ON_LOAD, ON_ICONCLICK` on the CSHS.

`HOUSE.CODE.DEBUGGER` now also reaches inside inline handlers — 20 hits across
12 files, including the one from the screenshot.

### 5. An active rule was losing findings on generated code

The review reported 130, then 131, then 132 buffer findings **on identical
input**, and a category chip labelled `engine` came and went. That is
`BufferLinter` working as designed: a rule exceeding its 250 ms budget has its
findings for that buffer **dropped** and one advisory emitted instead. The
flapping count was not noise — it was findings going missing, and only when the
server was busy enough to tip over.

The rule was `HOUSE.CFG.HARDCODED_PATH`, which is **active policy**.

The obvious suspect was the pattern: `(?:/[A-Za-z0-9_.-]+){2,}` is a nested
quantifier, the classic catastrophic-backtracking shape. Making the inner `+`
possessive is safe here — the character class excludes both `/` and the quote,
so backtracking into it can never help — and it changed nothing measurable.
**170.7 ms to 162.9.** Kept, because it is strictly safer, but it was not the
bug.

The bug was the **guard**. `isGuarded` scoped a `notWhen` to `lineText`, and
Test PA holds a 48 KB service script **on a single line**. On that file the
pattern costs **1.2 ms** and the guard costs **231**, because nine matches each
re-scan 48 KB. On hand-written code a line and a neighbourhood are the same
thing; on generated code they are not.

The guard now looks 400 characters either side of the match:

| | before | after |
|---|---|---|
| `HOUSE.CFG.HARDCODED_PATH` | 170.7 ms | **5.3 ms** |
| slowest rule in the set | 170.7 ms | **7.5 ms** |

**Behaviour is identical** — all 107 rules over all four corpora produce
byte-identical output. That was the accept test; the speedup was the
by-product.

---

## Things deliberately not built

- **Unused-artifact detection** (catalogue B11, I8). `calledElement` is a real
  poId on a `callActivity` and `null` genuinely means unimplemented — but a
  coach flow references a view by `viewUUID`, a UCA by its attached service and
  a team by `teamService`. A reachability graph missing any of those calls live
  artifacts dead, which is the exact class of false positive this project keeps
  catching. It needs its own measurement pass.
- **Toolkit dependency depth** (I1–I5). No dependency endpoint found.
- **A health score.** IDA prints one. Ours would be an unmeasured weighting,
  and a single number is the one thing on a report that gets quoted and
  targeted. Ship the counts, calibrate the bands against the real corpora
  (2.04M, 1.41M and 266K characters), then add it.
- **No new rule kind.** `Corpus.java` states the engine's position and it
  holds: every rule kind judges one thing in isolation, so a set-level fact —
  duplicate code, per-type counts, migration counts — belongs to the report,
  not to a rule that would lie about what it can see.

## Still open

- The **panel** does not lint an inline event handler while the developer is
  looking at one. The committed reader now sees them, so the review does; the
  live path does not, because `discoverSurfaces()` does not find those editors
  in the Designer's DOM. That needs a live DOM probe.
- The page's own advice that a large application "takes a few minutes" is
  unverified above 218 artifacts.

# Two axes: when a rule runs, and what would let it run at all

Written 2026-08-30, at the owner's request. Regenerate the numbers with
`node tools/classify-rules.js`.

---

## Axis 1 — develop-time or snapshot-review

The distinction that matters is **not** where a rule runs, because a full
application review runs everything. It is what a rule *needs in order to be
answerable at all*:

| | |
|---|---|
| **develop-time** | Answerable from the one artifact open in Designer: its code surfaces and its own model. Runs live in the panel, and again in a snapshot review. |
| **snapshot-only** | Needs another artifact, the whole application, or a second moment in time. Cannot run in the panel however much we improve it. |

Develop-time is a strict subset of what a snapshot review evaluates. So the
field worth carrying on a rule is `scope: snapshot` on the minority, with
develop-time as the default.

### Where the 138 rules fall today

| | rules | |
|---|---|---|
| develop-time | **121** | 71 automated + 50 manual prompts |
| snapshot-only | **17** | all of them manual prompts today |

Every automated rule we have — all 54 buffer and all 17 artifact rules — is
develop-time. That is not a coincidence: the engine was built around the panel,
so the only rules that exist are the ones the panel could evaluate.

**The snapshot-only population is much larger than 17.** It is 17 *of the rules
we carry*. Add the 41 application-scope rules from IBM's IDA catalogue
(`ida-checkstyle-2026-08-30.md`) and the real snapshot backlog is 58. None of
them can be written until the application-wide model exists — which is the
pre-deployment `.twx` report, PROJECT.md §8 item 9.

### The third case, which already exists

Five of the 17 snapshot-only prompts are not "whole app at one moment" but
**two moments compared**: Process!B8, Process!B9, Process!B13,
Variables & EPVs!B9 and General!B21 all ask whether something *changed*.
`/compare.jsp` already answers that shape — it diffs any two snapshots or
tracks and reports what a change introduced and fixed. These five are the
cheapest snapshot wins, because the machinery is built; what is missing is the
link from the prompt to the comparison.

---

## Axis 2 — what would let a manual prompt be measured

67 prompts, every one classified. 50 are develop-time and 17 snapshot-only;
the grouping below is by what actually blocks each one.

| bucket | count | meaning |
|---|---|---|
| already answered | 5 | an automated rule or the harvested validator settles it |
| automatable today | 6 | JSON only, no code change |
| one reader field away | 25 | the data is in the payload; `bridge.js` does not read it |
| condition-language change | 6 | needs two aggregates, or row-against-row |
| snapshot-only | 13 | needs the application model |
| blocked at the payload | 8 | the data does not come back from REST |
| genuinely human | 4 | a judgement, and should stay a prompt |

**Only 4 of 67 are genuinely human.** The other 63 are engineering, in
ascending order of cost.

### Already answered (5) — retire the prompt or link it to the rule

| cell | question | settled by |
|---|---|---|
| General!B10 | Is the code free from JavaScript errors? | Designer's own validator, harvested into the panel |
| General!B14 | Are all validation errors removed? | same |
| General!B17 | Is all unconnected components removed from the services? | `HOUSE.FLOW.UNCONNECTED_STEP`, added 2026-08-30 |
| UI!B20 | Are all coach view specific functions declared within the coach view scope? | `HOUSE.UI.WINDOW_BINDING` (the escaping-scope half) |
| UI!B21 | Are all exceptions handled and logged to console? | `HOUSE.CODE.EMPTY_CATCH`; `HOUSE.CODE.CONSOLE` already exempts `error`/`warn` for this row |

A prompt that a rule already settles should say so rather than being asked
again — but **the checklist row must not be deleted**: §3.3 is binding, and the
right place to reconcile is the endpoint, not the source.

### Automatable today — JSON only (6)

| cell | question | how |
|---|---|---|
| General!B8 | No code in pre and post assignment scripts | `surfaces[]` already names `preAssignmentScript` / `postAssignmentScript`. **432 of them across 255 artifacts** in the corpus. |
| Process!B14 | Are Pre and Post assignments not used | the same rule, scoped to the process |
| UI!B5 | Is one coach per service pattern followed? | count `components` of type `TFormTask`. **42 of 340** client-side human services have more than one. |
| UI!B13 | Are reusable functions written in Inline Javascript block? | `surfaces[]` distinguishes `inlineJavaScript` from `eventHandlersLoad` / `Unload` |
| UI!B29 | Are nested coachviews avoided? | count layout items on a CoachView (depth still needs the reader to recurse) |
| UI!B30 | Are many service calls from the Coach avoided? | count `callActivity` components |

`surfaces[]` being reachable by `any:` is the useful discovery here — it is
already in the artifact posted to `/api/check`, with `surface`, `name`,
`language` and `code` per row, and no rule has ever read it.

### One reader field away (25)

Grouped by the single addition that unlocks each set:

- **Lanes** (5): Process!B5, B11, B12, B21 and the sequential-activity checks.
  Lanes are not read at all today, and they are the largest single blocker in
  the Process sheet.
- **Process flags** (5): Process!B6 auto-tracking, B7 at-risk, B18
  optimize-for-latency, B19 durable subscription, B20 timer trigger.
- **Documentation** (3): General!B5, Services!B11, UI!B38 tags. The same field
  unlocks 11 rules in IBM's catalogue.
- **UCA parameters** (2): UCA!B5, UCA!B6. The UCA reader reads event type,
  implementation, schedule and queue — and no parameters at all.
- **Coach-view behaviour** (7): UI!B9, B10, B12, B25, B26, B28, B33, B34.
- **Sequence-flow names** (1): General!B19. The reader drops sequence flows
  entirely, so their labels go with them.
- **Service settings** (1): Services!B7 caching.

### Needs a condition-language change (6)

The engine allows **one aggregate per rule**, and a `where` predicate sees one
row at a time. These six need more:

| cell | question | what is missing |
|---|---|---|
| General!B11 | Are all unnecessary variables deleted? | `variables[]` correlated against `surfaces[]` — two aggregates |
| Services!B16 | Does an exposed service's response carry status, code, details? | exposure *and* output-variable names — two aggregates |
| UI!B11 | Are unique control ids given for all controls? | row against row |
| UI!B15 | Are unnecessary DOMs destroyed on unload? | the load surface against the unload surface |
| UI!B18 | Is a reserved keyword used as the coach view name? | **the artifact's own `name` is not reachable by a `where` predicate at all** — `field:` compares numbers only |
| Variables & EPVs!B8 | Are repeated attributes kept in a list object? | row against row |

UI!B18 is the cheapest of the six and the most embarrassing: the artifact's name
is right there in the model and no rule can test it. A `where` that can read a
top-level string field would fix it.

### Blocked at the payload (8)

Two causes, both already documented:

- **Coach-view config options are absent from the payload entirely** (4):
  UI!B16, B17, B31, B35. Noted in `artifact-model-map.md` — config options are
  the coach view's signature and the asset endpoint does not return them. Until
  another endpoint is found, four checklist rows cannot be measured.
- **`envVarSet` returns HTTP 500** (4): UCA!B7, Variables & EPVs!B6, B7, B10.
  PROJECT.md §8 item 12. Every other artifact type is readable; this one is not.

### Genuinely human (4)

General!B18 (does the implementation match the process model), Process!B15
(is the diagram readable), UI!B6 (do sequence lines cross), UI!B23 (browser
compatibility tested). These should stay prompts and should never be given a
mechanical answer.

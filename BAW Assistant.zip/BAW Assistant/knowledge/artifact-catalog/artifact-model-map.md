# The artifact model, per type

What the design REST API actually returns for each artifact type, probed live
on 2026-08-29 against the CAPOC process app (Main branch
`2063.595f5dc8-e7e0-469e-845d-26497db1f58a`).

Every payload quoted here is saved under `payloads/` and is what
`test/bridge-model.test.js` runs against, so these shapes are pinned by tests
rather than by memory.

---

## One endpoint, and the response says what it is

```
/rest/bpm/wle/pd/v1/asset/{poId}?containerRef={ref}
```

The name in the path is ignored — the `poId` picks the model. The response's
`data.domainProperty` names the key the model arrived under. All ten probed
artifacts, covering all seven editor types, returned 200 from this one
endpoint.

That is why `bridge.js` keys its readers on `domainProperty` rather than on the
editor type on screen: it is the server saying what it sent, instead of the
client inferring it from the DOM.

Every response also carries `commitSeq`, `hasUnCommittedChanges`, `readonly`,
`modifiedBy` and `modifiedDate`.

---

## The map

| Editor type | `domainProperty` | Variables | Steps | Settings read |
|---|---|---|---|---|
| CoachView | `CoachViewModel` | **none — the concept does not apply** | `layout.layoutItem[]` (nested views) | `header`: isTemplate, hasLabel, isMobileReady, useUrlBinding, firesBoundaryEvent, description |
| SERVICEFLOW | `definitions` | `rootElement[process].ioSpecification` | `rootElement[process].flowElement[]` | processType, isClosed, exposedAs, resourceRoles |
| COACHFLOW | `definitions` | root `ioSpecification` | **`extensionElements.userTaskImplementation[0].flowElement`** | as above, plus `nestedImplementation: true` |
| HERITAGEFLOW | `definitions` | root `ioSpecification` | same nesting as COACHFLOW | `isHeritageHumanService`, `cachingType` |
| CaseProcess | `definitions` | `rootElement[process].ioSpecification` | `rootElement[process].flowElement[]` | resourceRoles (4 on the probe artifact) |
| Team | `definitions` | none — no signature | none | `extensionElements.team[0]`: type, members |
| AppSettings | `processAppSettings` | none | none | acronym, targetEnvironment, isToolkit, isWbmEnabled, namespace, envVarSet |
| UCA | `uca` | none | none | eventType, implementationType, isEnabled, scheduleType, frequency, queue, attachedService |
| BusinessObject | `schema` | `complexType[0].sequence.element[]` (as `category: "Attribute"`) | none | isEnumeration, shared, allowAdditionalProperties, shadow, targetNamespace |
| *enumerated type* | `schema` | **none — the concept does not apply** | `simpleType[0].restriction.enumeration[]` (as `EnumerationValue`) | isEnumeration, targetNamespace, hasDocumentation |
| RESTService | `restService` | none | none | hasOpenApiDefinition |

---

## Traps, each one verified

**A coach view has no `definitions` key at all.** Its model is `header`,
`inlineScript` and `layout`. The old reader sent coach views to `/coachview`
and then parsed `definitions.rootElement[0].ioSpecification` out of the reply,
so it produced zero variables for every coach view ever opened — and, because
the result was still non-null, the panel reported "0 input/output variables (as
last saved)", stating as committed fact a number it had never read. That was
finding F2.

**Never `rootElement[0]`.** A CaseProcess returns **three** roots — the
`process`, its `interface`, and a `globalUserTask`. The process happened to be
first on the probe artifact, which is exactly the kind of luck that hides a bug.
Select by `declaredType === 'process'`.

**A client-side human service nests its flow.** Its root carries an
`ioSpecification` (empty on the probe artifact) but no `flowElement`; the eight
flow elements live under
`extensionElements.userTaskImplementation[0].flowElement`. Code written for
service flows finds zero steps there, silently.

**A coach view keeps two code surfaces the editor never shows together.**
`header.loadJSFunction` and `header.unloadJSFunction` sit apart from
`inlineScript[]`, so a developer reading the Behavior tab does not see them
beside the inline script. Both are read into `surfaces[]`.

**Absent, not empty.** `layout` is missing entirely on a coach view with no
nested views; `incoming`/`outgoing` are missing on an unconnected node;
`documentation` content can be an empty array. Absence is the signal — never
treat it as an error.

**`hasDefault` is `useDefault`, not the presence of a value.** A variable can
carry a recorded default with `useDefault: false`, which means it is not
applied. Reading `value` instead would over-report defaults.

**Sequence flows are not steps.** `flowElement[]` mixes activities, events,
gateways, data objects *and* `sequenceFlow` connections. The probe service flow
has 14 elements, of which 5 are sequence flows. Counting them would inflate
every step-count rule by roughly a third.

**`declaredType` is a full class name.** Step types arrive as
`com.ibm.bpmsdk.model.bpmn20.ibmext.TFormTask`. The readers shorten this to
`TFormTask` so a rule matching a step type does not have to carry the package
prefix.

**`envVarSet` still returns HTTP 500** for its own poId (PROJECT.md §8 item 12).
The AppSettings model names the set, so its existence is known even though its
contents are not readable. Not chased.

---

## An enumerated type is not a business object

Added 2026-08-30, after a rule's hits were read line by line rather than
counted.

Both come back under `domainProperty: "schema"`. A business object is a
`complexType` with a `sequence`; an **enumeration is a `simpleType` with a
`restriction.enumeration`** and carries no `complexType` anywhere:

```json
"simpleType": [ { "name": "VisibilityEnum",
                  "restriction": { "enumeration": [ { "value": "NONE" },
                                                    { "value": "READ" } ] } } ]
```

Reading `complexType[0]` alone gave a business object with **no name at all**
and zero attributes — and the zero was then reported as committed fact. That is
finding F2 in a second artifact type: a count stated for a concept that does not
apply. Two of the four artifacts flagged by a draft "business object has no
attributes" rule across the measured corpus were enumerations, which is how it
surfaced; both were confirmed by reading their payloads live.

The reader now takes the name from the `simpleType`, reports the values as
`components` typed `EnumerationValue`, sets `variablesApply: false`, and marks
`settings.isEnumeration` on **both** branches so a rule can test it rather than
infer it from a missing key.

`payloads/BusinessObjectEnum.json` pins this. Unlike its siblings it is
**synthetic**: the shape was read from a live customer artifact, but that
artifact is customer source and may not be committed, so the names and values in
the fixture are invented and the structure is not.

---

## Three kinds of human service, and how to tell them apart

Added 2026-08-30 after probing an application carrying all three.

A **heritage** human service and a **client-side** human service both nest their
flow under `extensionElements.userTaskImplementation[0].flowElement`, so the
nesting that separates either from a service flow does **not** separate them
from each other. What does:

| | discriminator |
|---|---|
| Heritage human service | `extensionElements.cachingType` on the root, with `cacheLength`, `cacheResults`, `sboSyncEnabled` |
| Client-side human service | `userTaskImplementation[0].htmlHeaderTag`, with `isShadow` on the root |
| Coach view | no `definitions` key at all — see above |

Probed across **9 heritage and 64 client-side** services in one application,
with zero overlap. `derivedEditorType` returns `HERITAGEFLOW` for the first.

## A multi-instance loop is `loopSettings`, not `loopCharacteristics`

BAW does not use the BPMN `loopCharacteristics` element. A multi-instance loop
is `extensionElements.loopSettings[0]`, a `TMultiInstanceLoopSettings` carrying
`startQuantity`, `sequential` (**false means parallel**), `miFlowCondition` and
`cancelRemainingInstances`.

Searching a payload for `loopCharacteristics` finds nothing and reads as "this
application uses no loops", which is the wrong answer — the first scan of an
application with four of them reported none.

## A team filter service is reached from the team, not from the service

A team of `type: "TeamByService"` carries a `teamService` reference to the
service that resolves its membership. The service itself carries no marker, so
"is the team filter service simple and lightweight" is a cross-artifact question
and belongs to the whole-application review rather than the panel.

## The System team is shared, not per-application

The system lane's participant resolved to the same poId
(`24.6fd38d02-…`) in two unrelated applications: it is a built-in that lives
outside the application's own Team list. Resolving it by poId works anyway;
enumerating an application's teams and stopping there does not.

## The graph facts, and where each one actually lives

Probed against a process built to carry one of everything.

| Fact | Where |
|---|---|
| error handler that loops | `boundaryEvent.attachedToRef`, compared with the target of its outgoing flow |
| terminate that purges | `endEvent.eventDefinition[n].extensionElements.terminateEventSettings[0].deleteProcessInstance` |
| conditional join | `inclusiveGateway` with **more than one incoming** flow |
| multi-instance loop | `extensionElements.loopSettings[0]` — `sequential: false` means parallel |

**A `parallelGateway` needs no conditions.** It is an AND split: every path is
taken and none of them chooses. Counting its outgoing flows as "missing a
condition" reported three defects on a correctly built parallel split. Only
`exclusiveGateway`, `inclusiveGateway` and `complexGateway` choose.

**An inclusive gateway is a split or a join depending on its incoming count.**
One incoming is a split and costs nothing; more than one is the conditional
join that makes the engine evaluate every upstream path.

**The Designer's gateway NAME does not match its type.** A gateway named
"Exclusive gateway" came back as `declaredType: parallelGateway`. Read the
declaredType, never the name.

**A default gateway label is `To <target name>`** — capital T in one
application, lower-case in another, so match it case-insensitively when
deciding whether an outgoing line was deliberately labelled.

## A process is `bpdExtension`, not a globalUserTask

Added 2026-08-30, after process rules were reported firing on service flows.

`derivedEditorType` returned `CaseProcess` only for a payload carrying a
`globalUserTask` root beside the `process` root. A globalUserTask is an
**inline user task**, so any process without one fell through to
`SERVICEFLOW`. On Test PA that was **all 4 BPDs and 10 of the 24 case
processes**.

| | discriminator |
|---|---|
| process (BPD or case process) | `rootElement[process].extensionElements.bpdExtension` |
| service flow | no `bpdExtension`; carries `isAjaxExposed`, `isSecured`, `sboSyncEnabled` |
| integration service | no `bpdExtension`; carries `cachingType`, `cacheLength` |

`bpdExtension` is where the process settings themselves live -
`atRiskCalcEnabled`, `autoTrackingEnabled`, `optimizeExecForLatency`,
`enableTracking`, `dueDateSettings`, `workSchedule` - so a rule about any of
them is asking exactly whether the artifact has one.

**A BPD and a case process cannot be told apart from the payload.** Both come
back as converged processes with `isConvergedProcess: [true]`, a
`caseExtension` and a `bpdExtension`, differing only in fields neither is
guaranteed to fill. The asset listing is the only thing that separates them,
and `readInventory` keeps it as `listedAs`. Both are classified `CaseProcess`,
which is the vocabulary every process rule already uses.

**A service flow has a `laneSet` too.** Lanes do not discriminate, which is why
a lane rule scoped to service flows fired on 8 real ones.

## `<field>Names`: which elements a counter counted

Every graph fact arrives in `settings` as a number, and `settings` is a single
anonymous object - so a finding derived from one could name nothing, on exactly
the rules where "which one?" is hardest to answer by hand.

The readers now publish a companion list beside each count, and
`ArtifactChecker` picks it up through the field the rule's own predicate
already names. No rule changes its check, message or examples to gain it.

```json
"gatewayConditionsIncomplete": 2,
"gatewayConditionsIncompleteNames": ["Inclusive gateway", "Route by amount"]
```

Published for `activitiesWithoutSubject`, `activitiesNotImplemented`,
`gatewayConditionsIncomplete`, `conditionalJoins`, `unlabelledGatewayLinks`,
`errorHandlersRoutedBackToOwner` and `terminateEventsDeletingInstanceData`.
Where no companion list exists the finding names nothing rather than inventing
a subject.
